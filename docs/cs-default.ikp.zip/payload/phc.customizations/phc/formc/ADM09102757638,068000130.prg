* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM09102757638,068000130
* ecran: PDU_2IQ0L94J6
* nome: dados_viatura
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

local custokm,custo100km
custokm=0
custo100km=0
Text to m.viatura textmerge noshow

select segvalfim,segvalfim1,segvalfim2,kmsatehoje, (Kmsatehoje-KmsInicial) as Kms,ecustotota,leasfim, 
isnull((ecustotota/(Kmsatehoje-KmsInicial)),0) as custokm, 
isnull(((ecustotota/(Kmsatehoje-KmsInicial))*100),0) as custo100km,'Kms_medios'=round((Kmsatehoje/datediff(dd,datainicia,getdate())),2)
from va(nolock) where
va.matricula='<<m.ObjRecebido.Janela.pageframe1.udcpage3.combo_matricula.value>>' 

endtext

if u_sqlexec(m.viatura,"dados_viatura")
    select dados_viatura
    mysegvalfim=dtoc(dados_viatura.segvalfim)
    mysegvalfim1=dtoc(dados_viatura.segvalfim1)
    mysegvalfim2=dtoc(dados_viatura.segvalfim2)
    myleasfim=dtoc(dados_viatura.leasfim)
    
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_seguros1.controlsource="mysegvalfim"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_seguros2.controlsource="mysegvalfim1"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_seguros3.controlsource="mysegvalfim2"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_kms.controlsource="dados_viatura.kmsatehoje"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_custo_total.controlsource="dados_viatura.ecustotota"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_leasing.controlsource="myleasfim"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_custo_kms.controlsource="dados_viatura.custokm"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_100_kms.controlsource="dados_viatura.custo100km"
    m.ObjRecebido.Janela.pageframe1.udcpage3.textbox_kms_medios.controlsource="dados_viatura.Kms_medios"

else
   Msg("Erro na pesquisa, consulte a analise interna...dados_viatura")
endif

