* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM09121662004.947000097
* ecran: PDU_2TG15KHQS
* nome: hide_calcula_combos
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

********** calcula combo loja ***********************
m.ObjRecebido.Janela.loja.RowSource=""
Text to m.loja textmerge noshow
   select SPACE(1) as Loja union
   select lv.site as Loja from lv(nolock)
   order by 1
EndText

if u_sqlexec(m.loja,"cursor_loja")
   select cursor_loja
   m.ObjRecebido.Janela.loja.RowSource="cursor_loja"
   m.ObjRecebido.Janela.loja.RowSourceType=2
   m.ObjRecebido.Janela.loja.ColumnCount=1
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_loja")
endif

********** calcula combo ano ***********************
m.ObjRecebido.Janela.ano.RowSource=""
Text to m.ano textmerge noshow
   select distinct ft.ftano as ano from ft(nolock)
   inner join pos(nolock) on ft.pno=pos.pno
   where ft.pno>0 and pos.isrest=0
--   and (''='<<m.ObjRecebido.Janela.loja.value>>' or ft.site='<<m.ObjRecebido.Janela.loja.value>>')
   order by 1 desc
EndText
if u_sqlexec(m.ano,"cursor_ano")
   select cursor_ano
   if reccount("cursor_ano")<=0
      append blank
      replace cursor_ano.ano with (year(date())) IN "cursor_ano"
   endif
   select cursor_ano
   go top
   m.ObjRecebido.Janela.ano.RowSource="cursor_ano"
   m.ObjRecebido.Janela.ano.RowSourceType=2
   m.ObjRecebido.Janela.ano.ColumnCount=1
   if empty(m.ObjRecebido.Janela.ano.value)
      m.ObjRecebido.Janela.ano.value=alltrim(m.ObjRecebido.Janela.ano.list(1))
   endif
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_ano")
endif
********** calcula combo posto ***********************

m.ObjRecebido.Janela.pos.RowSource=""
Text to m.posto textmerge noshow
   select SPACE(1) as Posto, SPACE(1) as Descrição union
   select distinct convert(char,ft.pno) as Posto, ft.pnome as Descrição from ft(nolock)
   inner join pos(nolock) on ft.pno=pos.pno
   where ft.pno>0 and pos.isrest=0 and 
--ft.site='<<m.ObjRecebido.Janela.loja.value>>'
   (''='<<m.ObjRecebido.Janela.loja.value>>' or ft.site='<<m.ObjRecebido.Janela.loja.value>>')
   order by 1
EndText

if u_sqlexec(m.posto,"cursor_posto")
   select cursor_posto
   m.ObjRecebido.Janela.pos.RowSource="cursor_posto"
   m.ObjRecebido.Janela.pos.RowSourceType=2
   m.ObjRecebido.Janela.pos.ColumnCount=2
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_posto")
endif

************ Inicialização da combo da ESCOLHA e da combo PERIODO e combo  POR *******************
if empty(m.ObjRecebido.Janela.pageframe1.page1.esco.value)
   m.ObjRecebido.Janela.pageframe1.page1.esco.value='Valores'
endif

if empty(m.ObjRecebido.Janela.per.value)
   m.ObjRecebido.Janela.per.value='Ano'
endif

if empty(m.ObjRecebido.Janela.pageframe1.page1.por.value)
   m.ObjRecebido.Janela.pageframe1.page1.por.value='Loja'
endif

