* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM10011566804.385000082
* ecran: PDU_2TG15KHQS
* nome: hide_calculos
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

m.margemdia=0
m.margemmes=0
m.margemano=0
if type("m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.value")<>"N"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.value=1
endif
if type("m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.value")<>"N"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.value=1
endif
if type("m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.value")<>"N"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.value =1
endif

********** calcula combo posto ***********************

m.ObjRecebido.Janela.pos.RowSource=""
Text to m.posto textmerge noshow
   select SPACE(1) as Posto, SPACE(1) as Descrição union
   select distinct convert(char,ft.pno) as Posto, ft.pnome as Descrição from ft(nolock)
   inner join pos(nolock) on ft.pno=pos.pno
   where ft.pno>0 and pos.isrest=0 and 
--ft.site='<<m.ObjRecebido.Janela.loja.value>>'
   (''='<<m.ObjRecebido.Janela.loja.value>>' or ft.site='<<m.ObjRecebido.Janela.loja.value>>')
   order by 1
EndText

if u_sqlexec(m.posto,"cursor_posto")
   select cursor_posto
   m.ObjRecebido.Janela.pos.RowSource="cursor_posto"
   m.ObjRecebido.Janela.pos.RowSourceType=2
   m.ObjRecebido.Janela.pos.ColumnCount=2
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_posto")
endif


** mostra ou não o campo para colocar os objectivos em função da escolha feita na combo tipo de objectivo ********************

if empty(m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value)
   m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Vendas"
endif

if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Vendas"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.visible   = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.visible = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.visible  = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasdia.gaugevalue=50
   m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasmes.gaugevalue=50
   m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasano.gaugevalue=50
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pdia.value=0
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pmes.value=0
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pano.value=0
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasdia.value=0
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasmes.value=0
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasano.value=0
endif
if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Diário"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.visible   = .t.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.visible = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.visible  = .f.
endif
if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Mensal"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.visible   = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.visible = .t.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.visible  = .f.
endif
if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Anual"
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.visible   = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.visible = .f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.visible  = .t.
endif
**** inicializa o valor da combo "agrupa por" da listagem **********
if empty(m.ObjRecebido.Janela.pageframe1.udcpage2.por2.value)
   m.ObjRecebido.Janela.pageframe1.udcpage2.por2.value="Loja"
endif

************************************************************************************************************
**** C A L C U L O   D O S   G A U G E S **************
************************************************************************************************************
Text to m.mselgau textmerge noshow
select 
isnull(sum(case when year(ft.fdata)='<<m.ObjRecebido.Janela.ano.value>>' and month(ft.fdata) = month(getdate()) and 
day(ft.fdata) = day(getdate()) then 
(ft.etotal) else 0 end),0) as vendasdia,

isnull(sum(case when year(ft.fdata)='<<m.ObjRecebido.Janela.ano.value>>' and month(ft.fdata) = month(getdate()) and 
day(ft.fdata) <= day(getdate()) then 
(ft.etotal) else 0 end),0) as vendasmes,

isnull(sum(case when year(ft.fdata)='<<m.ObjRecebido.Janela.ano.value>>' then 
(ft.etotal) else 0 end),0) as vendasano,

datediff(dd,'01/01/'+str(year(getdate())),getdate())+1 as diasano,

datediff(dd,('01/'+str(month(getdate()))+'/'+str(year(getdate()))),getdate())+1 as diasmes1,

day(getdate()) as diasmes

from ft(nolock)
inner join pos(nolock) on ft.pno=pos.pno
where ft.pno>0 and pos.isrest=0 and
('<<m.ObjRecebido.Janela.loja.value>>' = '' or ft.site='<<m.ObjRecebido.Janela.loja.value>>') 
endtext
if u_sqlexec(m.mselgau,"cursor_vgau")
   if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Diário"
      m.objdia=m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objdia.value
*!*  m.margemdia=round(((cursor_vgau.vendasdia - m.objdia) / (1+cursor_vgau.vendasdia)),2) * 100
*!*  m.margemmes=round(((cursor_vgau.vendasmes - (m.objdia*day(date()))) / (.1+cursor_vgau.vendasmes)),2) * 100 
*!*  m.margemano=round(((cursor_vgau.vendasano - (m.objdia*cursor_vgau.diasano)) / (.1+cursor_vgau.vendasano)),2) * 100
      m.margemdia  =((cursor_vgau.vendasdia   / (.0+(m.objdia)))) * 100
      m.margemmes=((cursor_vgau.vendasmes / (.0+(m.objdia*cursor_vgau.diasmes)))) * 100
      m.margemano=((cursor_vgau.vendasano  / (.0+(m.objdia*cursor_vgau.diasano)))) * 100
   endif

   if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Mensal"
      m.objmes=m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objmes.value
*!*  m.margemdia=round(((cursor_vgau.vendasdia - (m.objmes/30)) / (.1+cursor_vgau.vendasdia)),2) * 100
*!*  m.margemmes=round(((cursor_vgau.vendasmes - ((m.objmes/30)*cursor_vgau.diasmes)) / (.1+cursor_vgau.vendasmes)),2) * 100
*!*  m.margemano=round(((cursor_vgau.vendasano - ((m.objmes/30)*cursor_vgau.diasano)) / (.1+cursor_vgau.vendasano)),2) * 100
      m.margemdia  =((cursor_vgau.vendasdia   / (.0+(m.objmes/30)))) * 100
      m.margemmes=((cursor_vgau.vendasmes / (.0+((m.objmes/30)*cursor_vgau.diasmes)))) * 100
      m.margemano =((cursor_vgau.vendasano / (.0+((m.objmes/30)*cursor_vgau.diasano)))) * 100
   endif

   if m.ObjRecebido.Janela.pageframe1.udcpage2.combo_obj.value="Anual"
      m.objano=m.ObjRecebido.Janela.pageframe1.udcpage2.valor_objano.value
*!*  m.margemdia=round(((cursor_vgau.vendasdia - (m.objano/365)) / (.1+cursor_vgau.vendasdia)),2) * 100
*!*  m.margemmes=round(((cursor_vgau.vendasmes - ((m.objano/365)*cursor_vgau.diasmes)) / (.1+cursor_vgau.vendasmes)),2) * 100
*!*  m.margemano=round(((cursor_vgau.vendasano - ((m.objano/365)*cursor_vgau.diasano)) / (.1+cursor_vgau.vendasano)),2) * 100
*!*  m.margemmes=round((cursor_vgau.vendasmes / (.1+((m.objano/365)*cursor_vgau.diasmes))),2) * 100
      m.margemdia  =((cursor_vgau.vendasdia   / (.0+((m.objano/365))))) * 100
      m.margemmes=((cursor_vgau.vendasmes / (.0+((m.objano/365)*cursor_vgau.diasmes)))) * 100
      m.margemano =((cursor_vgau.vendasano / (.0+((m.objano/365)*cursor_vgau.diasano)))) * 100
   endif
   if m.margemdia<-100
         m.margemdia=-100
   endif
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasdia.value=nvl(cursor_vgau.vendasdia,0)
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pdia.value=nvl(m.margemdia,0)
   if m.margemmes<-100
      m.margemmes=-100
   endif
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasmes.value=nvl(cursor_vgau.vendasmes,0)
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pmes.value=nvl(m.margemmes,0)
   if m.margemano<-100
      m.margemano=-100
   endif
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_vendasano.value=nvl(cursor_vgau.vendasano,0)
   m.ObjRecebido.Janela.pageframe1.udcpage2.text_pano.value=nvl(m.margemano,0)
   if abs(m.margemdia) > 100 
      if m.margemdia >0 
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasdia.gaugevalue=nvl(100,0)
      else
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasdia.gaugevalue=nvl(0,0)
      endif
   else
      m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasdia.gaugevalue=nvl(m.margemdia,0)
   endif
   if abs(m.margemano) > 100 
      if m.margemano >0 
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasano.gaugevalue=nvl(100,0)
      else
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasano.gaugevalue=nvl(0,0)
      endif
   else
      m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasano.gaugevalue=nvl(m.margemano,0)
   endif
   if abs(nvl(m.margemmes,0)) > 100 
      if nvl(m.margemmes,0) >0 
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasmes.gaugevalue=nvl(100,0)
      else
         m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasmes.gaugevalue=nvl(0,0)
      endif
   else
      m.ObjRecebido.Janela.pageframe1.udcpage2.gauge_vendasmes.gaugevalue=nvl(m.margemmes,0)
   endif
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_vgau")
endif

