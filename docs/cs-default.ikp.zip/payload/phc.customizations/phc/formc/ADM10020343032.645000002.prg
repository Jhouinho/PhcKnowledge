* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM10020343032.645000002
* ecran: PDU_2UW0PDD9T
* nome: hide
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

if m.ch_vendedor <> 0
   m.ObjRecebido.Janela.txt_nome.value=GetUmValorString("CM3","CM3.NOME","CM3.CM="+astr(m.ch_vendedor))
   if empty(m.ObjRecebido.Janela.ano.value)
      m.ObjRecebido.Janela.ano.value=str(year(date()))
   endif
   if empty(m.ObjRecebido.Janela.per.value)
      m.ObjRecebido.Janela.per.value='Ano'
   endif
   if empty (m.ObjRecebido.Janela.pageframe1.page1.tipo.value)
      m.ObjRecebido.Janela.pageframe1.page1.tipo.value='Visitas'
   endif
else
   Messagebox("Não tem vendedor associado a este utilizador, por esse motivo o painel vai aparecer sem dados",0+64,"Informação")
endif

