* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM10112452788,369000066
* ecran: PDU_2VN0ZP3ZZ
* nome: hide_iniciooci
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

m.adjudicados=""
m.fechados=""
*!* carregar as variaveis das combo-box no arranque

if empty(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.value)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.value='zero ! 0 * 2010'
*!*   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.forecolor=RGB(255,255,255)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.visible=.f.
   m.ObjRecebido.Janela.pageframe1.udcpage4.obj3.visible=.f.
endif

if empty(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_anooci.value)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_anooci.value=1
endif

if empty(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_fechadosoci.value)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_fechadosoci.value='Todos'
endif

Do Case
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_fechadosOCI.value='Todos'
      m.fechados=""
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_fechadosOCI.value='Sim'
      m.fechados=" and bo.fechada=1 "
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_fechadosOCI.value='Não'
      m.fechados=" and bo.fechada=0 "
EndCase

if empty(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_adjudicadosOCI.value)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_adjudicadosOCI.value='Todos'
endif

Do Case
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_adjudicadosOCI.value='Todos'
      m.adjudicados=""
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_adjudicadosOCI.value='Sim'
      m.adjudicados=" and bo2.adjudicado=1 "
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_adjudicadosOCI.value='Não'
      m.adjudicados=" and bo2.adjudicado=0 "
EndCase

*!* calculo do combo-box OBRA

m.ObjRecebido.Janela.pageframe1.udcpage4.combo_obraoci.RowSource=""
Text to m.obraOCI textmerge noshow
   select bo2.processo, opc.descricao, convert(varchar,count(*)) as Total from bo(nolock)
   inner join bo2(nolock) on bo2.bo2stamp=bo.bostamp
   inner join ts(nolock) on ts.ndos=bo.ndos and ts.orcamento=1
   inner join opc(nolock) on opc.processo=bo2.processo
   where (1='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_anooci.value>>' or year(opc.dataa)='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_anooci.list(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_anooci.value)>>') <<m.fechados>>  <<m.adjudicados>>
   group by bo2.processo, opc.descricao
   order by 1
EndText

if u_sqlexec(m.obraOCI,"cursor_obraOCI")
   select cursor_obraOCI
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_obraOCI.RowSource="cursor_obraOCI"
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_obraOCI.RowSourceType=2
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_obraOCI.ColumnCount=3
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_obraOCI")
endif

*!* calculo do combo-box ORÇAMENTO ***************************************************

m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.RowSource=""
Text to m.orcamOCI textmerge noshow
   select (convert(varchar,bo.nmdos)+' ! '+convert(varchar,bo.obrano)+ ' * '+convert(varchar,bo.boano)) as dados from bo(nolock)
   inner join bo2(nolock) on bo2.bo2stamp=bo.bostamp
   inner join ts(nolock) on ts.ndos=bo.ndos and ts.orcamento=1
   inner join opc(nolock) on opc.processo=bo2.processo
   where bo2.processo='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_obraoci.value>>'
   order by 1
EndText
if u_sqlexec(m.orcamOCI,"cursor_orcamOCI")
   if reccount("cursor_orcamOCI")>0
      select cursor_orcamOCI
      m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.RowSource="cursor_orcamOCI"
      m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.RowSourceType=2
      m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.ColumnCount=1
      m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.visible=.t.
      m.ObjRecebido.Janela.pageframe1.udcpage4.obj3.visible=.t.
      if empty(cursor_orcamOCI.dados)
         m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.value='zero ! 0 * 2010'
      endif
   else
      m.ObjRecebido.Janela.pageframe1.udcpage4.combo_orcamOCI.value='zeros ! 0 * 2010'
   endif
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_orcamOCI")
endif

