* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11021964542,026000018
* ecran: PDU_34A0NUPM6
* nome: gauge_hide
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

if empty(m.ObjRecebido.Janela.pageframe1.udcpage1.combo_agrupa.value)
   m.ObjRecebido.Janela.pageframe1.udcpage1.combo_agrupa.value="Recrutamento"
endif
********** Popular a combo recrutamento só com os recrutamentos do ano
Text to m.recruta2 textmerge noshow
   select top 1 '' as recrutamento from rct
   union all
   select idrct as recrutamento from rct(nolock)
   where   (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') 
endText

m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.RowSource=""
if u_sqlexec(m.recruta2 ,"cursor_recruta2")
   select cursor_recruta2
   m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.RowSource="cursor_recruta2"
   m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.RowSourceType=2
   m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.ColumnCount=1
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_Recruta2")
endif

******** RECRUTAMENTOS
Text to m.recruta textmerge noshow
   select COUNT(*) as Valor from rct(nolock)
   where   (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') and
  (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>' or rct.idrct='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>') and
 (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>' or rct.situacao ='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>') 
endText

if u_sqlexec(m.recruta,"cursor_recruta")
   select cursor_recruta
   m.ObjRecebido.Janela.pageframe1.udcpage1.gauge_rec.gaugevalue=nvl(cursor_recruta.valor,0)
   m.ObjRecebido.Janela.pageframe1.udcpage1.txt_rec.value=nvl(cursor_recruta.valor,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_recruta")
endif
********* APURADOS
Text to m.seleci textmerge noshow
   select COUNT(*) as valor from srt (nolock) 
   inner join rct(nolock) on rct.idrct=srt.idrct
where (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') and
  (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>' or srt.idrct='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>') and  srt.apurado=1 and
 (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>' or rct.situacao ='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>') 
endText

if u_sqlexec(m.seleci,"cursor_seleci")
   select cursor_seleci
   m.ObjRecebido.Janela.pageframe1.udcpage1.gauge_sel.gaugevalue=nvl(cursor_seleci.valor,0)
   m.ObjRecebido.Janela.pageframe1.udcpage1.txt_sel.value=nvl(cursor_seleci.valor,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_seleci")
endif
********* CANDIDATOS
Text to m.candid textmerge noshow
   select COUNT(*) as valor from srt (nolock) 
   inner join rct(nolock) on rct.idrct=srt.idrct
where (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') and
  (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>' or srt.idrct='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>') and
 (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>' or rct.situacao ='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>') 
endText

if u_sqlexec(m.candid,"cursor_candid")
   select cursor_candid
   m.ObjRecebido.Janela.pageframe1.udcpage1.gauge_can.gaugevalue=nvl(cursor_candid.valor,0)
   m.ObjRecebido.Janela.pageframe1.udcpage1.txt_can.value=nvl(cursor_candid.valor,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_candid")
endif

********* ENTREVISTAS
Text to m.entrev textmerge noshow
   select COUNT(*) as valor from  etr(nolock) 
   inner join rct(nolock) on rct.idrct=etr.idrct
where (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') and
  (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>' or etr.idrct='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>') and
 (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>' or rct.situacao ='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>') 
endText

if u_sqlexec(m.entrev,"cursor_entrev")
   select cursor_entrev
   m.ObjRecebido.Janela.pageframe1.udcpage1.gauge_ent.gaugevalue=nvl(cursor_entrev.valor,0)
   m.ObjRecebido.Janela.pageframe1.udcpage1.txt_ent.value=nvl(cursor_entrev.valor,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_entrev")
endif

********* REALIZADAS
Text to m.realiz textmerge noshow
   select COUNT(*) as valor from  etr(nolock) 
   inner join rct(nolock) on rct.idrct=etr.idrct
where (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or year(rct.dtabre)='<<m.ObjRecebido.Janela.combo_ano.value>>') and
  (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>' or etr.idrct='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_rec.value>>') and etr.realizada=1 and
 (''='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>' or rct.situacao ='<<m.ObjRecebido.Janela.pageframe1.udcpage1.combo_sit.value>>') 
endText

if u_sqlexec(m.realiz,"cursor_realiz")
   select cursor_realiz
   m.ObjRecebido.Janela.pageframe1.udcpage1.gauge_rea.gaugevalue=nvl(cursor_realiz.valor,0)
   m.ObjRecebido.Janela.pageframe1.udcpage1.txt_rea.value=nvl(cursor_realiz.valor,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_realiz")
endif

