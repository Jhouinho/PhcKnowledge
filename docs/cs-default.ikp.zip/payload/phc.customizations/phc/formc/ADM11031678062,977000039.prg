* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11031678062,977000039
* ecran: PDU_34A0NUPM6
* nome: hide_clb
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

local m.inactivo
m.inactivo=""
if empty(m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value)
   m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value='Todos'
endif

do case
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value="Todos"
      m.inactivo="1=1"
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value="Sim"
      m.inactivo="clb.inactivo=1"
   case m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value="Não"
      m.inactivo="clb.inactivo=0"
endcase

********* GAUGE TOTAL
Text to m.total textmerge noshow
   select COUNT(*) as valortotsel,
   (select count(*) from clb(nolock)) as valortottot from  clb(nolock) 
   where
  -- (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>' or clb.nomecomp=replace('<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>','-',',')) and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_dep.value>>' or clb.nmdpt='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_dep.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_func.value>>' or clb.nmfcc='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_func.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_chefe.value>>' or clb.chefe='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_chefe.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value>>' or <<m.inactivo>>) and
   (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or (year(clb.cinicio)<='<<m.ObjRecebido.Janela.combo_ano.value>>' and (year(clb.cfim)>='<<m.ObjRecebido.Janela.combo_ano.value>>'or convert(char,year(clb.cfim))=1900))) 
endText

if u_sqlexec(m.total,"cursor_clbgaugetot")
   select cursor_clbgaugetot
   m.ObjRecebido.Janela.pageframe1.udcpage4.gauge_total.gaugevalue=nvl((cursor_clbgaugetot.valortotsel/cursor_clbgaugetot.valortottot),0)*100
   m.ObjRecebido.Janela.pageframe1.udcpage4.ptotal.value=nvl((cursor_clbgaugetot.valortotsel/cursor_clbgaugetot.valortottot),0)*100
   m.ObjRecebido.Janela.pageframe1.udcpage4.vtotaltot.value=nvl(cursor_clbgaugetot.valortottot,0)
   m.ObjRecebido.Janela.pageframe1.udcpage4.vtotalsel.value=nvl(cursor_clbgaugetot.valortotsel,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_clbgaugetot")
endif

********* GAUGE SELECCAO
Text to m.sele textmerge noshow
   select COUNT(*) as valorempsel,
   (select count(*) from clb(nolock) 
   where    (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>' or clb.nomecomp=replace('<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>','-',','))) as valoremptot
   from  clb(nolock) 
   where
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>' or clb.nomecomp=replace('<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_empresa.value>>','-',',')) and

   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_dep.value>>' or clb.nmdpt='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_dep.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_func.value>>' or clb.nmfcc='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_func.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_chefe.value>>' or clb.chefe='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_chefe.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.udcpage4.combo_inactivo.value>>' or <<m.inactivo>>) and
    (''='<<m.ObjRecebido.Janela.combo_ano.value>>' or (year(clb.cinicio)<='<<m.ObjRecebido.Janela.combo_ano.value>>' and (year(clb.cfim)>='<<m.ObjRecebido.Janela.combo_ano.value>>' or convert(char,year(clb.cfim))=1900))) 
endText

if u_sqlexec(m.sele,"cursor_clbgaugesel")
   select cursor_clbgaugesel
   m.ObjRecebido.Janela.pageframe1.udcpage4.gauge_emp.gaugevalue=nvl((cursor_clbgaugesel.valorempsel/cursor_clbgaugesel.valoremptot),0)*100
   m.ObjRecebido.Janela.pageframe1.udcpage4.pemp.value=nvl((cursor_clbgaugesel.valorempsel/cursor_clbgaugesel.valoremptot),0)*100
   m.ObjRecebido.Janela.pageframe1.udcpage4.vemptot.value=nvl(cursor_clbgaugesel.valoremptot,0)
   m.ObjRecebido.Janela.pageframe1.udcpage4.vempsel.value=nvl(cursor_clbgaugesel.valorempsel,0)
else
   Msg("Erro na pesquisa, consulte a análise interna... cursor_clbgaugesel")
endif

