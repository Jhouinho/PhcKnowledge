* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11033042048,348000049
* ecran: PDU_36L1CNTC6
* nome: hide
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

Text to m.mselano textmerge noshow
   select distinct top 1 convert(char,YEAR(data)) as Ano from mr(nolock) order by convert(char,YEAR(data)) desc
EndText
if u_sqlexec(m.mselano,"cursor_ultimoano")
   select cursor_ultimoano
   if reccount("cursor_ultimoano")>0
      qano=cursor_ultimoano.ano
   else
      qano=str(year(date()))
   endif
endif

if empty(m.ObjRecebido.Janela.combo_ano.value)
   m.ObjRecebido.Janela.combo_ano.value=qano
endif

if empty(m.ObjRecebido.Janela.combo_per.value)
   m.ObjRecebido.Janela.combo_per.value="Ano"
endif

if empty(m.ObjRecebido.Janela.pageframe1.page1.combo_agrupa.value)
   m.ObjRecebido.Janela.pageframe1.page1.combo_agrupa.value="Família"
endif

m.ObjRecebido.Janela.pageframe1.page1.combo_espe.RowSource=""
Text to m.especialidades textmerge noshow
   select top 1 '' as especialidade from dr(nolock)
   union 
   select distinct drdiv.div as especialidade from drdiv(nolock)
   inner join dr(nolock) on dr.drno=drdiv.drno
   where (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espa.value>>' or dr.nome='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espa.value>>')
   order by 1
endText
if u_sqlexec(m.especialidades,"cursor_espe")
   select cursor_espe
   m.ObjRecebido.Janela.pageframe1.page1.combo_espe.RowSource="cursor_espe"
   m.ObjRecebido.Janela.pageframe1.page1.combo_espe.RowSourceType=2
   m.ObjRecebido.Janela.pageframe1.page1.combo_espe.ColumnCount=1
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_espe")
endif


***** calcula o total geral

Text to m.totalgeral textmerge noshow
   select sum(mr.etotref) as totalgeral from mr(nolock)
   inner join mn(nolock) on mr.mrstamp=mn.mrstamp
   inner join st(nolock) on st.ref=mn.ref
   where YEAR(mr.data)='<<m.ObjRecebido.Janela.combo_ano.value>>' 
Endtext

if u_sqlexec(m.totalgeral,"cursor_totalgeral")
   select cursor_totalgeral
   m.ObjRecebido.Janela.pageframe1.page1.txt_totalgeral.value=nvl(cursor_totalgeral.totalgeral,0)
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_totalgeral")
endif

***** calcula o total da seleção

do case
   case m.ObjRecebido.Janela.combo_per.value='Dia'
      m.periodo=" day(mr.data)=day(getdate()) and month(mr.data)=month(getdate()) and "

   case m.ObjRecebido.Janela.combo_per.value='Semana'
      m.periodo=" datepart(wk,mr.data)=datepart(wk,getdate()) and "

   case m.ObjRecebido.Janela.combo_per.value='Mês'
      m.periodo=" month(mr.data)=month(getdate()) and "

   case m.ObjRecebido.Janela.combo_per.value='Trimestre'
      m.periodo=" datepart(qq,mr.data)=datepart(qq,getdate()) and "

   case m.ObjRecebido.Janela.combo_per.value='Ano'
      m.periodo= " "
endcase

Text to m.totalsel textmerge noshow
   select sum(mr.etotref) as totalsel, sum(mr.etotag) as totalentidade, sum(etotcl) as totalpaciente from mr(nolock)
   inner join mn(nolock) on mr.mrstamp=mn.mrstamp
   inner join st(nolock) on st.ref=mn.ref
   where <<m.periodo>>
   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espa.value>>' or mr.drnome='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espa.value>>') and

   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espe.value>>' or mr.div='<<m.ObjRecebido.Janela.pageframe1.page1.combo_espe.value>>') and

   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_ent.value>>' or 
mr.nmentidade ='<<m.ObjRecebido.Janela.pageframe1.page1.combo_ent.value>>') and

   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_pac.value>>' or mr.idnome='<<m.ObjRecebido.Janela.pageframe1.page1.combo_pac.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_fam.value>>' or st.familia='<<m.ObjRecebido.Janela.pageframe1.page1.combo_fam.value>>') and
   (''='<<m.ObjRecebido.Janela.pageframe1.page1.combo_act.value>>' or mn.ref='<<m.ObjRecebido.Janela.pageframe1.page1.combo_act.value>>') and
   YEAR(mr.data)='<<m.ObjRecebido.Janela.combo_ano.value>>' 
Endtext

if u_sqlexec(m.totalsel,"cursor_totalsel")
   select cursor_totalsel
   m.ObjRecebido.Janela.pageframe1.page1.txt_totalsel.value=nvl(cursor_totalsel.totalsel,0)
   m.ObjRecebido.Janela.pageframe1.page1.txt_entv.value=nvl(cursor_totalsel.totalentidade,0)
   m.ObjRecebido.Janela.pageframe1.page1.txt_pacv.value=nvl(cursor_totalsel.totalpaciente,0)

   if m.ObjRecebido.Janela.pageframe1.page1.chkbox_peso.value=.F.
      m.ObjRecebido.Janela.pageframe1.page1.gauge_ent.gaugevalue=nvl(((cursor_totalsel.totalentidade/cursor_totalsel.totalsel)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.gauge_pac.gaugevalue=nvl(((cursor_totalsel.totalpaciente/cursor_totalsel.totalsel)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.txt_entp.value=nvl(((cursor_totalsel.totalentidade/cursor_totalsel.totalsel)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.txt_pacp.value=nvl(((cursor_totalsel.totalpaciente/cursor_totalsel.totalsel)*100),0)
   else
      m.ObjRecebido.Janela.pageframe1.page1.gauge_ent.gaugevalue=nvl(((cursor_totalsel.totalentidade/cursor_totalgeral.totalgeral)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.gauge_pac.gaugevalue=nvl(((cursor_totalsel.totalpaciente/cursor_totalgeral.totalgeral)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.txt_entp.value=nvl(((cursor_totalsel.totalentidade/cursor_totalgeral.totalgeral)*100),0)
      m.ObjRecebido.Janela.pageframe1.page1.txt_pacp.value=nvl(((cursor_totalsel.totalpaciente/cursor_totalgeral.totalgeral)*100),0)
   endif
else
   Msg("Erro na pesquisa, consulte a Análise interna... cursor_totalsel")
endif

