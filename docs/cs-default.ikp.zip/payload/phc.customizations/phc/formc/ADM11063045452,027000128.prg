* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11063045452,027000128
* ecran: PDU_34X0QNQFL
* nome: gau_abertas
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

*** vai olhar para o parametro do software para ver qual é o status da letra em aberto, ou seja 7 ou 8 ***
m.ObjRecebido.Objecto.gaugevalue=substr(u_lraber("","F"),11,1)

