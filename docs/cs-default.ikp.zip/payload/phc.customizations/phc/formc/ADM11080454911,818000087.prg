* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11080454911,818000087
* ecran: PDU_36K0ZARAH
* nome: hide_inicio
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

**Ocupação Alvéolos
** Iniciar a combo_armazem
If Empty(m.ObjRecebido.Janela.pageframe1.page1.combo_armazem.Value)
	m.ObjRecebido.Janela.pageframe1.page1.combo_armazem.Value="1"
Endif


** Alimentar a combo_zonas
TEXT To m.zonas Noshow Textmerge
	select distinct szz.zona, szz.sznome, szz.armazem from szz(nolock)
	where szz.armazem= '<<m.ObjRecebido.Janela.pageframe1.page1.combo_armazem.value>>'
	order by szz.zona asc
ENDTEXT

m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.RowSource=""

If u_sqlexec(m.zonas,"cursor_zonas")
	Select cursor_zonas
	m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.RowSource="cursor_zonas"
	m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.RowSourceType=2
	m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.ColumnCount=3
	
      If Empty(m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.Value)
		m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.ListIndex=1
             m.ObjRecebido.Janela.pageframe1.page1.listbox_alveolo.value=1
	Endif
Else
	Msg("Erro na pesquisa, consulte a análise interna... cursor_zonas")
Endif

** Alimentar a listbox_alveolo
TEXT To m.listbox_alveolo Noshow Textmerge
	select alv.identificacao from alv(nolock)
	where alv.armazem = '<<m.ObjRecebido.Janela.pageframe1.page1.combo_armazem.value>>'
	and alv.zona = '<<m.ObjRecebido.Janela.pageframe1.page1.combo_zonas.value>>'
	order by alv.identificacao
ENDTEXT

m.ObjRecebido.Janela.pageframe1.page1.listbox_alveolo.RowSource=""


If u_sqlexec(m.listbox_alveolo,"cursor_listbox_alveolo")
	Select cursor_listbox_alveolo
	m.ObjRecebido.Janela.pageframe1.page1.listbox_alveolo.RowSource="cursor_listbox_alveolo"
	m.ObjRecebido.Janela.pageframe1.page1.listbox_alveolo.RowSourceType=2
	m.ObjRecebido.Janela.pageframe1.page1.listbox_alveolo.ColumnCount=1
Else
	Msg("Erro na pesquisa, consulte a Análise interna... cursor_listbox_alveolo")
Endif

