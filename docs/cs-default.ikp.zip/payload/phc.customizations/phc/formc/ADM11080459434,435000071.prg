* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM11080459434,435000071
* ecran: PDU_36K0ZARAH
* nome: hide
* tag: US6
* tvalobj: C                                                                               
* udcVisible: False

** Data Inicial 
If Empty(m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_datai.value)
	m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_datai.value = DATE(YEAR(DATE()),1,1)
Endif

** Data Final

If Empty(m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_dataf.value)
	m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_dataf.value = DATE(YEAR(DATE()),12,31)
Endif

if packactivo("Lotes",.t.)
   m.ObjRecebido.Janela.pageframe1.udcpage2.obj12.visible=.t.
   m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_lote.visible=.t.
else
   m.ObjRecebido.Janela.pageframe1.udcpage2.obj12.visible=.f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_lote.visible=.f.
endif
if packactivo("equipamento",.t.) or packactivo("suporte",.t.)
   m.ObjRecebido.Janela.pageframe1.udcpage2.obj16.visible=.t.
   m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_lequipamento.visible=.t.
else
   m.ObjRecebido.Janela.pageframe1.udcpage2.obj16.visible=.f.
   m.ObjRecebido.Janela.pageframe1.udcpage2.textbox_equipamento.visible=.f.
endif

