* TECLA (ti.retorno)
* tistamp: ADM25121649637.1510000-1
* ecran: SPE
* teclas: ALT+1
* descricao: Apoio preenchimento DMR substituição
* estado: Activo
* inactivo: False

&&Vamos pedir as variáveis ao utilizador
&&criar o cursor com os campos para guardar os valores indicados pelo utilizador
Select 0
Create Cursor xvarsdata (no N(5), tipo c(1), Nome c(40), Pict c(100), lordem N(10), nvalor N(4, 0))
Select xvarsdata
Append Blank
Replace xvarsdata.no With 1
Replace xvarsdata.tipo With "N"
Replace xvarsdata.Nome With "Gratificações - % isenção"
Replace xvarsdata.Pict With "###%"
Replace xvarsdata.lordem With 1
Replace xvarsdata.nvalor With 6

Append Blank
Replace xvarsdata.no With 2
Replace xvarsdata.tipo With "N"
Replace xvarsdata.Nome With "Ano das Gratificações"
Replace xvarsdata.Pict With "####"
Replace xvarsdata.lordem With 2
Replace xvarsdata.nvalor With Year(Date())

m.escolheu = .F.
docomando("do form usqlvar with 'xvarsdata', 'Confira as informações a usar', .t.")

If m.escolheu
	&&obter os dados inseridos pelo utilizador
	Select xvarsdata					&& primeiro registo
	Locate
	m.m_nPctGratif = xvarsdata.nvalor
	Select xvarsdata					&& segundo registo
	Skip
	m.m_nAnoGratif = xvarsdata.nvalor
	fecha("xvarsdata")

	TEXT to m.myCSel textmerge noshow
	DECLARE @nPctLimIsenGratif as Integer = <<m.m_nPctGratif>>, @nAnoGratif as Integer = <<m.m_nAnoGratif>>
	select month(prre.dtref) as mesgrat, pr.nome as nomefunc, pr.no as nofunc, pe.ncont as niffunc,
		sum(prre.ere) as gratifval,
		round((pe.ebasemes * 14) * (cast(@nPctLimIsenGratif as numeric(4,2)) / 100), 2) as isenlim,
		iif(sum(prre.ere) < round((pe.ebasemes * 14) * (cast(@nPctLimIsenGratif as numeric(4,2)) / 100), 2),
			0,
			sum(prre.ere) - round((pe.ebasemes * 14) * (cast(@nPctLimIsenGratif as numeric(4,2)) / 100), 2))
																						as valsuj,
		iif(sum(prre.ere) < round((pe.ebasemes * 14) * (cast(@nPctLimIsenGratif as numeric(4,2)) / 100), 2),
			sum(prre.ere),
			round((pe.ebasemes * 14) * (cast(@nPctLimIsenGratif as numeric(4,2)) / 100), 2))
																						as valisen
	from prre (nolock)
	inner join cm6 (nolock) on cm6.cm = prre.cr
	inner join pr (nolock) on prre.prstamp = pr.prstamp
	inner join pe (nolock) on pe.no = pr.no
	inner join pe2 (nolock) on pe2.pe2stamp = pe.pestamp
	where year(pr.data) = @nAnoGratif
	and cm6.egratificacao = 1 and cm6.limirsanual = 1 and cm6.optlimirs = 2 and cm6.limirspct = 100
	group by month(prre.dtref), pr.nome, pr.no, pe.ncont, pe.ebasemes, pr.data
	order by month(pr.data), pr.nome
	ENDTEXT

	If u_sqlexec(m.mycSel, "myGratifs")
		Declare list_tit(8), list_cam(8), list_tam(8), list_pic(8)
		list_tit(1) = "Mês da Gratificação"
		list_tit(2) = "Nome do Funcionário"
		list_tit(3) = "Número do Funcionário"
		list_tit(4) = "NIF do funcionário"
		list_tit(5) = "Valor Total da Gratificação"
		list_tit(6) = "Valor Limite de Isenção"
		list_tit(7) = "Valor Sujeito (código A/A61/A68)"
		list_tit(8) = "Valor Isento (código A41)"

		list_cam(1) = "myGratifs.mesgrat"
		list_cam(2) = "myGratifs.nomefunc"
		list_cam(3) = "myGratifs.nofunc"
		list_cam(4) = "myGratifs.niffunc"
		list_cam(5) = "myGratifs.gratifval"
		list_cam(6) = "myGratifs.isenlim"
		list_cam(7) = "myGratifs.valsuj"
		list_cam(8) = "myGratifs.valisen"

		list_tam = 8*20

		list_pic(1) = "##"
		list_pic(2) = ""
		list_pic(3) = "######"
		list_pic(4) = ""
		list_pic(5) = "###,###,###.##"
		list_pic(6) = "###,###,###.##"
		list_pic(7) = "###,###,###.##"
		list_pic(8) = "###,###,###.##"

		browlist("Gratificações Isentas de IRS", "mygratifs", "mygratifs")
	Else
		msg("Ocorreu um erro ao produzir a listagem de valores de Gratificações. Consulte a análise interna.")
	Endif
Endif
fecha("xvarsdata")

