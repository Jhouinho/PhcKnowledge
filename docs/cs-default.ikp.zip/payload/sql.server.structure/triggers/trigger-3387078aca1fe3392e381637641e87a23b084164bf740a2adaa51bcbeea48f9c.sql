CREATE TRIGGER tr_tfd_delete ON tfd  FOR DELETE  AS SET NOCOUNT ON			declare @notf numeric(6,0)
			DECLARE cr CURSOR FOR SELECT notf from deleted

			OPEN cr

			FETCH NEXT FROM cr into @notf

			WHILE @@FETCH_STATUS = 0
			BEGIN
				if (select count(*) from tfd where tfd.notf=@notf)>0
				begin
					update tf set
						tf.usrinis=sel.usrinis,
						tf.usrdata=sel.usrdata,
						tf.usrhora=sel.usrhora,
						tf.ready=sel.tfaprovada,
						tf.tdata=case sel.tfaprovada when 1 then sel.datae else tf.tdata end,
						tf.rejeitada= case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then 1 else 0 end,
						tf.rejdata=case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then sel.datae else tf.rejdata end
					from (select top 1 tfd.notf, tfd.iteste, tfd.tfaprovada, tfd.estaencprog, tfd.estaencerrado, tfd.datae, tfd.usrinis, tfd.usrdata, tfd.usrhora from tfd where tfd.notf=@notf  order by tfd.datac desc, tfd.horac desc, tfd.notfd desc) as sel 
					where tf.notf=@notf

					update tf set
						tf.hteste=tf.hteste-d.hteste,
						tf.horasc=tf.horasc-d.hprog
					from deleted as d
					where tf.notf=d.notf
				end
				else
					update tf set
						tf.ready=0,
						tf.rejeitada=0,
						tf.hteste=0,
						tf.horasc=0
					where tf.notf=@notf
			   FETCH NEXT FROM cr into @notf
			END

			CLOSE cr
			DEALLOCATE cr

			--*&&CM - 02.10.2012delete from ctt where notfd=(select notfd from deleted) &&CM - Correcção sem tarefa (a pedido de FC, via Email) - Isto dá erro, quando se elimina uma tarefa com mais do que um diálogo
			delete from ctt where notfd in (select notfd from deleted)