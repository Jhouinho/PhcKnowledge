CREATE TRIGGER tr_tfd_insert ON tfd  FOR INSERT  AS SET NOCOUNT ON			SET NOCOUNT ON;
			update tf set
				tf.usrinis=sel.usrinis,
				tf.usrdata=sel.usrdata,
				tf.usrhora=sel.usrhora,
				tf.ready=sel.tfaprovada,
				tf.tdata=case sel.tfaprovada when 1 then sel.datae else tf.tdata end,
				tf.rejeitada= case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then 1 else 0 end,
				tf.rejdata=case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then sel.datae else tf.rejdata end
			from (select top 1 * from tfd where tfd.notf=(select notf from inserted) order by tfd.datac desc, tfd.horac desc, tfd.notfd desc) as tfd inner join inserted as sel on tfd.tfdstamp=sel.tfdstamp
			where tf.notf=sel.notf 

			declare @notf as numeric(10,0)

			select @notf=notf from inserted

			UPDATE tf SET 
				tf.hteste=t.hteste,
				tf.horasc=t.hprog
			from (select notf, sum(hteste) as hteste, sum(hprog) as hprog from tfd where notf=@notf group by notf) as t
			where tf.notf=t.notf