CREATE TRIGGER tr_tfd_update ON tfd  FOR UPDATE  AS SET NOCOUNT ON			SET NOCOUNT ON;

			if update(notf)
				if (select count(*) from tfd where tfd.notf=(select notf from deleted))>0
				begin
					update tf set
						tf.usrinis=sel.usrinis,
						tf.usrdata=sel.usrdata,
						tf.usrhora=sel.usrhora,
						tf.ready=sel.tfaprovada,
						tf.tdata=case sel.tfaprovada when 1 then sel.datae else tf.tdata end,
						tf.rejeitada= case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then 1 else 0 end,
						tf.rejdata=case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then sel.datae else tf.rejdata end
					from (select top 1 tfd.notf, tfd.iteste, tfd.tfaprovada, tfd.estaencprog, tfd.estaencerrado, tfd.datae, tfd.usrinis, tfd.usrdata, tfd.usrhora from tfd where tfd.notf=(select notf from deleted)  order by tfd.datac desc, tfd.horac desc, tfd.notfd desc) as sel 
					where tf.notf=(select notf from deleted)

					update tf set
						tf.hteste=tf.hteste-d.hteste,
						tf.horasc=tf.horasc-d.hprog
					from deleted as d
					where tf.notf=d.notf
				end
				else
					update tf set
						tf.ready=0,
						tf.rejeitada=0,
						tf.hteste=0,
						tf.horasc=0
					where tf.notf=(select notf from deleted)

			if update(tfaprovada) or update(estaencerrado) or update(estaencprog) or update(datae) or update(notf)
				update tf set
					tf.usrinis=sel.usrinis,
					tf.usrdata=sel.usrdata,
					tf.usrhora=sel.usrhora,
					tf.ready=sel.tfaprovada,
					tf.tdata=case sel.tfaprovada when 1 then sel.datae else tf.tdata end,
					tf.rejeitada= case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then 1 else 0 end,
					tf.rejdata=case when (sel.tfaprovada=0 and (sel.estaencerrado=1 and sel.estaencprog=0)) then sel.datae else tf.rejdata end
				from (select top 1 * from tfd where tfd.notf=(select notf from inserted) order by tfd.datac desc, tfd.horac desc, tfd.notfd desc) as tfd inner join inserted as sel on tfd.tfdstamp=sel.tfdstamp
				where tf.notf=sel.notf 

			declare @notf as numeric(10,0)

			select @notf=notf from inserted

			if update(hprog) or update(hteste) or update(notf)
				UPDATE tf SET 
					tf.hteste=t.hteste,
					tf.horasc=t.hprog
				from (select notf, sum(hteste) as hteste, sum(hprog) as hprog from tfd where notf=@notf group by notf) as t
				where tf.notf=t.notf