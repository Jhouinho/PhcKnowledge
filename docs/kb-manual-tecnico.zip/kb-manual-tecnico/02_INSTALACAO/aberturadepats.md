---
title: Aberturadepats
source: aberturadepats.htm
tipo: Manual Técnico
idioma: PT
---

# Aberturadepats

Abertura de Pats

|  |
| --- |
| Abertura de Pats |

|  |
| --- |
| Para [abrir um PAT](funcionamentodaaberturadepedidos.htm) (pedido de assistência técnica), é necessário antes de mais, ter [acesso de introduzir](acessosdospedidosdeassistência.htm) pedidos de assistência técnica. De seguida deve definir o cliente e o equipamento em questão, sendo possível observar todos os dados de cada equipamento ou instalação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Abertura de Pats' ) |