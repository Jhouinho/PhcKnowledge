---
title: Acessosdasinstalações
source: acessosdasinstalações.htm
tipo: Manual Técnico
idioma: PT
---

# Acessosdasinstalações

Acessos das Instalações

|  |
| --- |
| Acessos das Instalações |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O funcionamento dos acessos encontra-se explicado nas opções globais em [Acessos de Utilizador](acessosdeutilizador.htm), no entanto explica-se neste local as particularidades dos acessos para as instalações.     **Instalações**  Permite impedir/autorizar a execução de operações sobre a tabela das instalações (apagar, introduzir, consultar, alterar, mapas, mapas definidos, alterar mapas desenhados e impressões definidas, imprimir mapas desenhados e impressões definidas, texto e supervisão). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Acessos das Instalações' ) |