---
title: Activarologísticacomlocalização
source: activarologísticacomlocalização.htm
tipo: Manual Técnico
idioma: PT
---

# Activarologísticacomlocalização

Activar o Logística com Localização

|  |
| --- |
| Activar o Logística com Localização |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para se poder começar a utilizar a gestão de alvéolos da Logística (localização), quando a empresa já tem o módulo Gestão, basta seguir alguns simples passos.    Antes de efetuar os respetivos procedimentos, deve-se fazer um Backup à Base de Dados.    Para usar Logística com localização é necessário ter ativo o parâmetro **Usa stock por Localização (tem de reinstalar triggers)**.    Ao gravar este parâmetro, é apresentado um assistente para ajudar a efetuar as configurações iniciais para a questão da Localização.         Neste passo definem-se as zonas e alvéolos, que irão receber o stock que se possui atualmente nos diversos armazéns.    De seguida é apenas necessário seguir os passos do assistente. A ativação da opção de Logística, é uma situação irreversível, ou seja, após definir que a Base de dados passa a utilizar este módulo, já não é possível voltar ao estado inicial.        Após terminar o Assistente de localização é necessário efetuar a reinstalação de triggers, para que as novas tabelas fiquem a funcionar de forma correta.    Assim já é possível aceder ao ficheiro de artigos e confirmar que os stocks foram distribuídos pelos diversos locais definidos no Assistente.        Para terminar, falta ainda criar todas as Zonas e Alvéolos que a Base de dados vai possuir e depois transferir dos Alvéolos iniciais todos os artigos e respetivas quantidades. Este processo pode ser efetuado através de Dossiers de transferência entre Alvéolos, ou de forma mais simples, através de um Inventário, valorizando-se simultaneamente os diversos artigos nas diversas localizações.    Para efetuar a Transferência através de Dossiers internos, é necessário ativar as seguintes configurações nos mesmos:        Além destas configurações poderá ainda configurar o Dossier para não ultrapassar a capacidade máxima do Alvéolo e para usar Alvéolos alternativos (no separador de Logística).    De notar que os documentos lançados antes da ativação da localização (Compras, Dossiers internos e Faturação), ficam também corretamente lançados, isto é, se movimentavam stock então fica também registada a Zona e o Alvéolo por defeito definidos no Assistente. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Activar o Logística com Localização' ) |