---
title: Actualizaçãodevaloresemeuros
source: actualizaçãodevaloresemeuros.htm
tipo: Manual Técnico
idioma: PT
---

# Actualizaçãodevaloresemeuros

Actualização de Valores em Euros

|  |
| --- |
| Actualização de Valores em Euros |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção serve para actualizar os valores em Euros, após a empresa passar a utilizar o Euro como moeda principal.  Esta actualização deve ser efectuada porque após passar para o Euro como moeda principal, existem determinados valores que devem ser arredondados a duas decimais e não serem apenas a conversão dos valores antigos (escudos em Euros) sem arredondamento.      **Converter os preços de venda e os preços de custo dos artigos**  Esta opção só está disponível se tiver instalado o módulo de stocks.  Esta opção converte os cinco preços de venda e o preço de custo de tabela.      **Converter os preços de vendas dos dossiers de preços de clientes**  Esta opção converte os seguintes campos nas linhas do dossier: Venda e Valor da Venda.  Converte também o total da venda.  A opção só faz a conversão caso o dossier esteja configurado como um «dossier de preço de clientes».       **Converter os preços de custo dos dossiers de preços de fornecedores**  Esta opção converte os seguintes campos nas linhas do dossier: Compra e Valor da Compra.  Converte também o total da compra.  A opção só faz a conversão caso o dossier esteja configurado como um «dossier de ref. e preços de fornecedor».      **Converter os vencimentos dos funcionários**  Esta opção só está disponível se tiver instalado o módulo do Pessoal.  Esta opção converte no ficheiro de funcionários:  O vencimento base,   Subsídio de turno  Subsídio de refeição  Valor das diuturnidades  Valor do IHT  Ajudas de custo  Ajudas de custo no estrangeiro  As sete remunerações/descontos fixos sujeitas a descontos oficiais  As seis remunerações/descontos fixos não sujeitas a descontos oficiais e   Desconto hora    *Dica:* Para ser efectuada a actualização é necessário que a data de fim de contrato seja superior à data do sistema.      **Converter os valores do imobilizado**  Esta opção só está disponível se tiver instalado o módulo do Imobilizado.  Converte no ficheiro de bens:  Valor de compra  Valor de aquisição reintegrável  Valor de aquisição actualizado  Valor matricial  Reintegrações perdidas  Reintegrações não reavaliadas  Reintegrações reavaliadas  Diferença no valor de aquisição por Reavaliação especial  Diferença nas reintegrações por reavaliação especial  Valor líquido após reavaliação especial  Valor residual de Gestão  Valor de avaliação de Gestão      **Converter os valores dos Imóveis**  Esta opção só está disponível se tiver instalado o módulo do Imóveis.  Converte os campos de valores nas tabelas de:  Propriedades (IB), Visitas a propriedades (VB), Vendas Realizadas de propriedades (VD) e Agenda de vendas realizadas de propriedades (AV).      **Número de decimais para arrendondar**  Esta opção permite indicar a precisão do arredondamento, escolhendo o número de casas decimais (estas podem ser de 0 a 6). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Actualização de Valores em Euros' ) |