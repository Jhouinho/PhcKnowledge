---
title: Adaptaçãodoplanodecontasàdeclaraçãodeivacomanexor
source: adaptaçãodoplanodecontasàdeclaraçãodeivacomanexor.htm
tipo: Manual Técnico
idioma: PT
---

# Adaptaçãodoplanodecontasàdeclaraçãodeivacomanexor

Adaptação do Plano de Contas à Declaração de Iva com Anexo R

|  |
| --- |
| Adaptação do Plano de Contas à Declaração de Iva com Anexo R |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O novo modelo da Declaração Periódica de IVA disponibilizado no FTP da ComunidadePHC, prevê a possibilidade de gerar anexos com informação relativa ao apuramento de IVA não só na sede, mas também nas Regiões Autónomas.    Para que seja possível, referenciar quais as contas do plano de contas que devem ser consideradas para a elaboração de cada um dos anexos, há que lhes atribuir um código de IVA.    Este código de IVA por sua vez, terá que estar registado na tabela de códigos de IVA, indicando para o mesmo, qual o campo da declaração periódica de IVA ao qual se refere.    Para simplificar o processo de associação de código de IVA às contas de movimento do actual plano de contas, foi criada uma rotina que com base em alguns pressupostos e suportada numa tecla de utilizador, lhe permitirá de forma instantânea, ver o seu plano de contas adaptado aos requisitos técnicos das fórmulas de IVA constantes do novo modelo.    Os pressupostos referidos anteriormente são:   - O plano de contas que se pretende actualizar, tem como base o plano de contas PHC e está associado a tabela de códigos de IVA PHC;    - Existem contas de movimento que contêm no seu descritivo, as expressões "Madeira" ou "Açores"     A tecla de utilizador em causa é do tipo **Programa**, deverá ser implementada no ecrã SPC (Plano de Contas) e tem na **Expressão de Retorno** o seguinte código:    *Nota*: Ao longo do código, está explicada a funcionalidade de cada segmento de código de forma que o mesmo possa ser adaptado, caso se mostre necessário.     local c\_num, tamanho,unCodIVA    \*\*\*Nota: Actualiza apenas as contas Madeira e Açores  if pergunta("Vai actualizar os códigos de IVA para o ano "+ transform(mano)+"."+chr(13)+"Quer continuar ?")    \*\* Preparar a instrução de Select  Text to m.cSel noshow textmerge  select pc.pcstamp, pc.conta, pc.descricao, pc.codiva from pc (nolock) where pc.ano=<<+Transform(mano)>> and pc.integracao=0 order by pc.conta  EndText    \*\* Criar o Cursor  u\_sqlexec(m.cSel,"meuPC")    \*\* Transformar o cursor em Updatable, ou seja, o cursor fica editável  criaupdatecursor("MeuPC","PC","conta")  \*\* Agora vamos ao Browlist Editável  DECLARE list\_tit(3),list\_cam(3),list\_tam(3),list\_pic(3),list\_ronly(3)    list\_tit(1)="Nº Conta"  list\_tit(2)="Descrição"  list\_tit(3)="Código de Iva"    list\_cam(1)="MeuPC.conta"  list\_cam(2)="meupc.descricao"  list\_cam(3)="meupc.codiva"    list\_ronly=.t.  list\_ronly(2)=.t.  list\_ronly(3)=.f.     list\_pic=""  list\_pic(3)="999"    list\_tam(1)=8\*15  list\_tam(2)=8\*45  list\_tam(3)=8\*10     tamanho = 0  c\_num = 'XXXXXXXXX'  unCodIva = 0    =CURSORSETPROP('Buffering',5,"Meupc")    select meupc  scan   if !empty(meupc.codiva) and occurs("Continente",meupc.descricao)=1  tamanho=(len(alltrim(meupc.conta))-1)  c\_num = substr(meupc.conta,1,tamanho)  unCodIva = meupc.codiva  Endif    If 'Açores' $ meupc.descricao And Alltrim(substr(meupc.conta,1,tamanho)) == Alltrim(c\_num)  Replace meupc.codiva With unCodIva+600  Endif    if 'Madeira' $ meupc.descricao And Alltrim(substr(meupc.conta,1,tamanho)) == Alltrim(c\_num)  Replace meupc.codiva With unCodIva+300  Endif  endscan      m.escolheu=.f.    \*\* Chamamos o browlist  browlist('Edição de codigos de IVA','meupc','meupc',.T.,.F.,.F.,.T.,.T.,'',.t.)    if m.escolheu    \*\* Vamos actualizar os dados   If u\_tabupdate(.t.,.t.,"meupc")  \*\* Foi enviado com sucesso.  mensagem("Actualização efectuada.")  endif  Else  \*\* Deu erro. Vamos mostrá-lo ao utilizador  Tablerevert(.t.,"Meupc")  mensagem("Atenção, não gravou as alterações propostas.")  Endif   else  mensagem("Cancelou a actualização!")  endif      Gama de software PHC em que foi testado: Advanced 2012 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Adaptação do Plano de Contas à Declaração de Iva com Anexo R' ) |