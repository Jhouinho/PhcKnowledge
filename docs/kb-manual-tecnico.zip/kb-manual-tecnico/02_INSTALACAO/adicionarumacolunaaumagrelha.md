---
title: Adicionarumacolunaaumagrelha
source: adicionarumacolunaaumagrelha.htm
tipo: Manual Técnico
idioma: PT
---

# Adicionarumacolunaaumagrelha

Adicionar uma Coluna a uma Grelha

|  |
| --- |
| Adicionar uma Coluna a uma Grelha |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| É possivel adicionar uma coluna a uma grelha (grid) de um ecrã a partir de código XBASE através dos ecrãs personalizados. O exemplo aqui descrito é para ser utilizado numa página de utilizador do ecrã de Intervenções (MH), neste ecrã é adicionado uma nova coluna à grelha dos contadores.    Deve-se primeiro criar um campo de utilizador na tabela que alimenta a grelha, neste exemplo a grelha de contadores é alimentada pela **tabela MHCT** - Contadores de Intervenções. Sendo assim deve-se seleccionar a opção Campos de Utilizador a partir do menu Supervisor. Nos campos de utilizador deve-se escolher a tabela MHCT, o nome do campo é "contini", o titulo do campo é "Contagem Inicial" e o valor do destino é 3 para que o campo seja criado na tabela e visível na lista. Este campo é do tipo numérico com comprimento 10 e sem decimais.    Depois de instalar o campo deve-se seleccionar a opção Ecrãs Personalizados, escolher o **ecrã SMH** e clicar em Desenhar ou através do menu de opções diversas do ecrã de intervenções escolher a opção "Personalizações deste ecrã" e escolher a opção "Criar".  No ecrã personalizado das intervenções deve-se seleccionar o objecto grelha dos contadores e seleccionar o **evento Init**. Na definição do evento deve ser colocado o seguinte código XBASE:      \* Se a coluna ainda não foi acrescentada à grelha:  if [type](type.htm)("ObjRecebido.Objecto.Continicial") = "U"    \* Criar uma nova coluna na grelha  ObjRecebido.Objecto.newobject("Continicial", "cgecoluna")    \* É uma coluna de edição  ObjRecebido.Objecto.Continicial.readonly = .f.    \* Título da coluna  ObjRecebido.Objecto.Continicial.header1.caption = "Contagem inicial"    \* Tamanho da letra do título da coluna  ObjRecebido.Objecto.Continicial.header1.fontsize = 8    \* Tamanho da letra do texto que vai ser introduzido pelo utilizador  ObjRecebido.Objecto.Continicial.fontsize=8    \* Posição da coluna dentro da grid, neste exemplo vem em 3º lugar  ObjRecebido.Objecto.Continicial.columnorder = 3    \* Alinhamento do título da coluna  ObjRecebido.Objecto.Continicial.header1.alignment = 2    \* Indica-se qual é o campo da tabela MHCT que vai alimentar a coluna, neste exemplo é o nosso campo de utilizador  ObjRecebido.Objecto.Continicial.controlsource = "mhct.u\_contini"    \* Cria-se uma caixa de texto na coluna para o utilizador poder inserir texto e disponibilizar os botões de gravar e cancelar  ObjRecebido.Objecto.Continicial.newobject("MyTxtBox", "nossocampo")    \* Caixa de texto visivel  ObjRecebido.Objecto.Continicial.mytxtbox.visible = .t.    \* Caixa de texto activa  ObjRecebido.Objecto.Continicial.mytxtbox.enabled = .t.    \* Caixa de texto é editável  ObjRecebido.Objecto.Continicial.mytxtbox.readonly = .f.    \* A caixa de texto é um objecto da coluna que foi acrescentada  ObjRecebido.Objecto.Continicial.CurrentControl = "MyTxtBox"    endif    Para além de uma coluna também é possível [adicionar um botão a uma coluna de uma grelha](adicionarumbotãoaumacolunadeumagrelha.htm).    **Versões em que foi testado:** 2007  **Plataforma a que se destina:** Enterprise |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Adicionar uma Coluna a uma Grelha' ) |