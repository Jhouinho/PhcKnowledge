---
title: Agendatelefónica
source: agendatelefónica.htm
tipo: Manual Técnico
idioma: PT
---

# Agendatelefónica

Agenda Telefónica

|  |
| --- |
| Agenda Telefónica |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Procurar um Nome / Telefone / Telemóvel / E-mail / Fax**    Esta opção funciona como agenda telefónica e poderá efetuar a pesquisa por nome, telefone, telemóvel, e-mail e fax onde irá retornar os registos que se encontram nas respetivas páginas de informação dos respetivos módulos.    Clientes (CL), Fornecedores (FL), Entidades (AG) e Vendedores (CM3) - Vários módulos    Instalações (SN) e Técnicos (CM4) - Módulo Suporte    Contactos (EM) e Pessoas (CT5) - CRM Comercial    Colaboradores (CLB) - Recursos Humanos    Funcionários (PE) - Módulo Pessoal    Após digitar o nome, ou a parte inicial do nome que se procura, basta indicar as tabelas pretendidas e clicar em **Procurar**. De notar que as tabelas aparecerão consoante os módulos que possua.    Desta forma são apresentados os registos de cada tabela, bastando clicar no sinal mais (+), para poder observar os respetivos registos. Após clicar no sinal +, são apresentados os registos que correspondem à condição indicada pelo utilizador.  Desta forma são visualizados os registos pretendidos, sendo possível, através de um duplo-clique na linha do registo, abrir a respetiva ficha.    Outra forma de abrir os nós é utilizar a barra de espaços, do teclado, ao posicionar em cima do nó que pretende abrir.        A pesquisa de registos pode, no entanto, ser executada de forma diferente, devendo para esse efeito utilizar as seguintes opções:    Ao clicar na opção **Envio SMS** a aplicação abre o ecrã para ser possível [enviar um sms](mensagenssms.htm) para o registo selecionado.     * Procura contida (mais lento) - permite executar uma pesquisa livre, ou seja, ao procurar um determinado registo na tabela, é possível indicar um conjunto de letras ou números que faça parte desse registo. Desta forma não é necessário digitar as **primeiras** letras do nome ou do número, sendo possível procurar partes do meio ou do fim.  * Procurar por - permite pesquisar os registos pelo nome, número de telefone, telemóvel ou pelo endereço de E-mail.       Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre como Procurar nome/telefone, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=ef36g743g%3a5.bc7%3a.b445.275).      A opção de **E-mail** abre uma janela do Outlook, que contém o e-mail do cliente selecionado (caso exista registo do mesmo na respetiva ficha) para que o utilizador possa enviar o E-mail.    Ao clicar na opção de **Ligar** a aplicação abre um ecrã com uma listagem dos números de telefone disponíveis para o cliente em questão. Ao selecionar o número pretendido, a aplicação abre outro ecrã com o número selecionado em forma de edição de forma a que o mesmo possa ser alterado pelo utilizador. Para fazer a ligação basta clicar em **Ligar**, sendo que a [aplicação permite optar](ParâmetrosGerais.htm#mcoligação) entre a utilização de TAPI normal (Ligação Telefónica) ou o software VOIP, como por exemplo o Skype, para a realização da chamada telefónica.    Ao clicar no opção  será enviado um fax para o número escolhido, abrindo um e-mail. O texto do parâmetro **Conteúdo do assunto do e-mail para envio de fax** deve conter a variável #fax# para ser substituído pelo número de fax quando é enviado o fax.      O ecrã de procura pode ser automaticamente fechado, bastando clicar na opção **Fechar depois de pedir ligação telefónica.**     Se tiver [PHC ON](oqueéophcon.htm) obtenha mais informação sobre a "Agenda Telefónica", [aqui](https://www.phc.pt/portal/programs/ewpview.aspx?codigo=IDIR110323) . |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Agenda Telefónica' ) |