---
title: Alterarmétododeautenticaçãoemphccsweb
source: alterarmétododeautenticaçãoemphccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Alterarmétododeautenticaçãoemphccsweb

Alterar Método de Autenticação em Phc Cs Web

|  |
| --- |
| Alterar Método de Autenticação em Phc Cs Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| As aplicações Internas e Externas do PHC CS Web, suportam a funcionalidade de o utilizador ser autenticado pelo próprio Windows em vez de ser autenticado pela própria aplicação via ecrã login.aspx.    Para mudar o método de autenticação deve-se fazer as seguintes alterações no appSettings.config :    **Autenticação pela aplicação via ecrã login.aspx**    <configuration>  <system.web>  <authentication mode="Forms">  <forms loginUrl="Login.aspx" />  </authentication>    <authorization>  <deny users="?" />  </authorization>  </system.web>  </configuration>      **Autenticação pelo Windows**    <configuration>  <appSettings>  <add key="AuthenticationMode" value="Windows" />  </appSettings>    <system.web>  <authentication mode="Windows"/>  <authorization>  <deny users="?" />  </authorization>  </system.web>  </configuration>    na autenticação pelo Windows nas aplicações externas, o número do cliente para os utilizadores é definido pela seguinte chave no ficheiro *appSettings.config*:    <configuration>  <appSettings>  <add key="NumeroCliente" value="X" />  </appSettings>  </configuration>    Onde X é o número do cliente desejado para ser usado por defeito para todas as autenticações dos utilizadores.   Caso essa chave não exista no ficheiro *appSettings.config*, a aplicação tenta autenticar o utilizador ignorando o número de cliente, ou seja, irá usar o número de cliente do primeiro utilizador que encontrar na tabela, cujo nome é igual ao que foi inserido na autenticação do Windows.    Quando se usa o modo de autenticação Windows, no Internet Information Services (IIS) deve selecionar-se o Website ao qual se pretende aceder. Por exemplo: *Intranet3setup*. Depois com clique direito acede-se às propriedades. Dentro deste ecrã no separador Directory security deve premir o botão EDIT e nele selecionar um dos modos de autenticação:   - Digest authentications for windows domain servers;  - Basic authentication (password is sent in clear text);  - Integrated Windows authentication. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Alterar Método de Autenticação em Phc Cs Web' ) |