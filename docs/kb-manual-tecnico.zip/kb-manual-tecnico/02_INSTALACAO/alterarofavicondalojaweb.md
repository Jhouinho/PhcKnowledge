---
title: Alterarofavicondalojaweb
source: alterarofavicondalojaweb.htm
tipo: Manual Técnico
idioma: PT
---

# Alterarofavicondalojaweb

Alterar o Favicon da Loja Web

|  |
| --- |
| Alterar o Favicon da Loja Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico apresenta como pode alterar o *favicon*, ou seja, o ícone que aparece ao lado do nome do site no *browser*.     Por defeito na aplicação da Loja Web aparece o ícone do PHC CS Web, conforme a imagem seguinte:            No entanto, pode alterar o *favicon* para, por exemplo, o logo da sua empresa. Para isso, é necessário efetuar os seguintes passos:     **1º Passo**  Ter um ficheiro com a extensão *.ico* com a imagem pretendida. Existem algumas ferramentas online que permitem transformar uma imagem em ícone.    **2º Passo**  Na pasta "pimages" da instalação do portal, onde está instalada a Loja, deverá ser colocada o ícone com a imagem pretendida.    **3º Passo**  Para que o *favicon* apareça terá de ter o nome *cicon.ico*, pelo que deverá ser renomeado o ícone para ter este nome. Em princípio, dará uma mensagem que já existe um ficheiro com esse nome, neste caso deverá ou, renomear o ícone já existente para outro nome, ou sobrepor ao existente, sendo que nesta última o ícone anterior deixará de existir.     Depois dos passos efetuados, ao aceder à loja, já tem o novo *favicon*, caso não apareça será necessário limpar a cache do browser, pois poderá estar em cache a imagem anterior. Exemplo de como ficará:            **Funcionalidade disponível nas gamas PHC CS:** Corporate, Advanced e Enterprise  **Subscrição de PHC On:** Não  **Ambiente de teste:**    * **Versão de software PHC CS Web:** 20  * **Versão do browser:** Chrome 54.0.2840.71 m  * **Versão do Android/IOS:** 5.1.1 / 9.3.1 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Alterar o Favicon da Loja Web' ) |