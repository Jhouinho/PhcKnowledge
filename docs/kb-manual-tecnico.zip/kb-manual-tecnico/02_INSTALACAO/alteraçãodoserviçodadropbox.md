---
title: Alteraçãodoserviçodadropbox
source: alteraçãodoserviçodadropbox.htm
tipo: Manual Técnico
idioma: PT
---

# Alteraçãodoserviçodadropbox

Alteração do Serviço da Dropbox

|  |
| --- |
| Alteração do Serviço da Dropbox |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A Dropbox alterou as normas de autenticação a partir de software. Até ao momento, a Dropbox disponbilizava a norma OAUTH1, que vai ser descontinuada em junho. Para fazer face a esta alteração, a Dropbox disponibilizou uma nova norma chamada OAUTH2, que permite que os clientes possam continuar a usufruir desta funcionalidade.    Por essa razão, houve a necessidade de atualizar a aplicação"PHCControls.dll" para poder continuar a usufruir desta funcionalidade no PHC CS, disponível apenas nas gamas Advanced e Enterprise.      **Atualizar PHCControls.dll**   Transfira o ficheiro PHCControls.dll no seguinte caminho do FTP:  ../pub/    É necessário desinstalação do antigo PHCControls.dll para uma correta instalação do novo setup e, executar o novo setup para que possa seja possível voltar a autenticar-se com a nova norma.      **Fazer reautenticação na Dropbox**    Aceda ao ecrã "Parâmetros", através do menu "Sistema", e pesquise pelo parâmetro **Dropbox: Autenticação para comunicação Dropbox** e clique no botão **Reautenticar-se no Dropbox**.            Ao clicar no botão **Reautenticar-se no Dropbox** será questionado se pretende autenticar-se novamente e clique no botão **Sim**.            Posteriomente, navegará para a aplicação da Dropbox, onde deverá colocar as suas credenciais da Dropbox.            Após estar ligado, apresentará a mensagem "PHC gostaria de ter acesso aos arquivos e pastas em seu Dropbox." e clique no botão **Permitir**.            Por fim, será apresentada a mensagem de sucesso da reatenticação.            **Plataforma a que corresponde esta funcionalidade:** PHC CS Desktop  **Esta funcionalidade está disponível na seguinte localização:** Portugal, África, Espanha e Peru  **Gama em que está disponível:** Advanced e Enterprise  **Versão de software:** 21  **Subscrição de PHC On:** Não |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Alteração do Serviço da Dropbox' ) |