---
title: Alterações na Reforma do Irc no Âmbito do Cliente
source: alteraçõesnareformadoircnoâmbitodocliente.htm
tipo: Manual Técnico
idioma: PT
---

# Alterações na Reforma do Irc no Âmbito do Cliente

Regime de Transparência Fiscal
Periodização do lucro tributável
Subsídios - novas regras de inclusão no lucro tributável
Dedutibilidade de gastos e perdas
Contratos de construção
Clarificação do regime de dedutibilidade de Gastos Fiscais
Gastos não dedutíveis
Perdas por imparidade em créditos
Depreciações e amortizações
Projetos de Desenvolvimento
Realizações de utilidade social
Mais-valias e menos-valias
Participation exemption
para dividendos, reservas, mais-valias e menos-valias
CFC - Regras anti abuso e Tributação autónoma
Redução de capital social
Ações Próprias
Regime de neutralidade fiscal
Fusão, cisões, entradas de ativos ou permutas de partes sociais
Liquidações de Sociedade
Exit tax
- Redomiciliação de sociedades
Crédito de imposto
Dispensa de retenção na fonte
Preços de Transferência
Pessoas coletivas e outras entidades que não exerçam, a título principal, atividade comercial, industrial ou agrícola
Rendimentos decorrentes da cessão ou utilização temporária de patentes e desenhos ou modelos industriais, sujeitos a registo
Limitação à dedutibilidade de gastos de financiamento
RETGS - Regime Especial de Tributação dos Grupos de Sociedades
Entidades não residentes e sem estabelecimento estável em Portugal
Comunicação de alterações na declaração de inscrição
Manutenção do processo de documentação fiscal
Obrigações contabilísticas
Obrigações acessórias
Regime de transparência fiscal
É alterado o conceito de sociedade de profissionais, tendo em vista a inclusão daquelas cujos rendimentos provenham, em mais de 75%, do exercício conjunto ou isolado de atividades profissionais especificamente previstas na lista constante do artigo 151.º do Código do IRS, e não apenas de uma, desde que, cumulativamente, em qualquer dia do período de tributação, o capital social pertença a um número de sócios não superior a cinco, nenhum deles seja pessoa coletiva de direito público, e pelo menos 75% do capital social seja detido por profissionais que exercem as referidas atividades, total ou parcialmente, através da sociedade.
Para que uma sociedade fique enquadrada no Regime de Transparência Fiscal, basta preencher os seguintes requisitos:
Os Rendimentos provenham em mais de 75% do exercício conjunto ou isolado de atividades profissionais especificamente previstas na lista constante do Art.º 151º do CIRC e não apenas de uma sociedade como era até 31.12.2013.
Número de Sócios não seja superior a 5 (cinco);
Não existam sócios que sejam Pessoas Coletivas de Direito Público;
75% Do Capital seja detidos por profissionais que exercem as referidas atividades, total ou parcialmente, através da sociedade.
Exemplo:
Uma sociedade que exerça a sua atividade de enfermagem e de medicina fica enquadrada no Regime de Transparência Fiscal, contudo se possuir mais de 5 sócios esse mesmo enquadramento não se aplica. Ver tabela para outros exemplos.
As sociedades que não queiram ficar enquadradas na transparência fiscal, deveriam efetuar as alterações até 31 de dezembro de 2013, incluindo o registo na conservatória dos atos sujeitos a registo, no sentido de alterarem convenientemente a estrutura societária em que os profissionais detenham menos de 75% do capital social e os rendimentos não ultrapassem 75% do total de rendimentos da sociedade.
Periodização do lucro tributável
Não concorrem para a determinação do lucro tributável, nos empreendimentos conjuntos que sejam sujeitos passivos de IRC, os rendimentos ou gastos e outras variações patrimoniais decorrentes do método de consolidação proporcional.
As variações do justo valor de instrumentos de capital próprio, com preço formado em mercado regulamentado, apenas passam a ser relevantes fiscalmente se a participação no capital for inferior a 5%.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Subsídios - novas regras de inclusão no lucro tributável
Ativos intangíveis sem vida útil definida: 20 anos, independentemente do recebimento.
Propriedades de investimento mensurados ao justo valor: durante o período máximo de vida útil, independentemente do recebimento.
Ativos biológicos não consumíveis mensurados ao justo valor: durante o período máximo de vida útil, independentemente do recebimento.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Dedutibilidade de gastos e perdas
A Dedutibilidade deixa de estar condicionada à indispensabilidade, sendo no entanto exigido que os gastos e as perdas sejam incorridos ou suportados para "obter ou garantir" os rendimentos sujeitos a IRC.
O documento comprovativo, na aquisição de bens ou serviços, terá de conter pelo menos os seguintes elementos:
Nome ou denominação social de vendedor e adquirente;
NIF de ambas as entidades, se residentes em território nacional;
Quantidade e denominação usual dos bens adquiridos ou dos serviços prestados;
Preço;
Data de aquisição.
Sempre que nos termos do CIVA haja obrigação de emissão de fatura, esta será o documento comprovativo exigível.
Ao aceitar um documento de Faturação emitido por fornecedores de bens e serviços deve sempre ter em atenção para o correto preenchimento desse mesmo documento em relação aos dados obrigatórios de forma a não inviabilizar a sua aceitação na esfera fiscal.
Contratos de construção
Passa a ser usado como critério único de reconhecimento dos resultados dos contratos de construção o da percentagem de acabamento, apenas sendo aceite a aplicação do método do lucro nulo, quando tal decorra da aplicação das regras contabilísticas.
Os contratos de construção devem ser reconhecidos e mensurados através da aplicação da NCRF 19 - Contratos de construção. Esta NCRF é baseada na IAS 11e prevê o reconhecimento do rédito dos contratos de construção com base na percentagem de acabamento, método obrigatório a partir do dia 01 de Janeiro de 2014.
Este princípio geral da NCRF 19 tem subjacente a ideia de que o desfecho do contrato pode ser determinado com fiabilidade, entenda-se, que os custos incorridos e os custos a incorrer para a conclusão do contrato possam ser mensurados com fiabilidade.
Sempre que o desfecho do contrato não possa ser estimado com fiabilidade a NCRF 19 prevê a aplicação do chamado método do lucro nulo, em que o rédito a reconhecer em cada período iguala os custos incorridos, contudo este método só pode ser aplicado se tal decorrer da aplicação de regras contabilística.
Percentagem de Acabamento = Custos Incorridos / (Custos Incorridos + Custos estimados)
Clarificação do regime de dedutibilidade de Gastos Fiscais
É eliminado o conceito da indispensabilidade, estabelecendo-se que sejam fiscalmente dedutíveis os gastos relacionados com a atividade do sujeito passivo.
No geral mantêm-se os mesmos contornos atualmente em vigor, contudo há a destacar o seguinte:
A dedutibilidade dos juros e outras formas de remuneração de suprimentos considerados excessivos deixa de ter por referência a taxa Euribor a 12 meses à data da constituição, passando a ter como referência, exclusivamente, taxa a definir por Portaria.
A dedutibilidade dos pagamentos a entidades não residentes sujeitas a um regime fiscal privilegiado passa a ser limitada aos residentes ou domiciliados em território identificado por Portaria do membro do Governo responsável pela área das Finanças.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Gastos não dedutíveis
Tributações autónomas;
Encargos cujo documento de suporte não cumpra os requisitos legais agora impostos;
Juros de mora;
Taxas e outros tributos que incidam sobre terceiros que o sujeito passivo não esteja legalmente obrigado a suportar;
Menos-valias e outras perdas relativas a instrumentos de capital próprio, na parte que correspondam a mais-valias e a lucros que tenham, no próprio ou nos últimos 4 exercícios, beneficiado do regime de
participation exemption
ou do crédito por dupla tributação económica internacional.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Perdas por imparidade em créditos
Os juros pelo atraso no cumprimento de obrigação passam a ser incluídos no valor das perdas por imparidade dedutíveis para efeitos fiscais, relativamente aos créditos resultantes da atividade normal.
Esclarece-se os processos em que se considera verificado o risco de incobrabilidade:
Processo de execução;
Processo de insolvência;
Processo especial de revitalização ou procedimento de recuperação de empresas por via extrajudicial ao abrigo do SIREVE.
Não são considerados como créditos de cobrança duvidosa os créditos:
Sobre pessoas singulares ou coletivas que detenham, direta ou indiretamente, mais de 10% do capital;
Sobre participadas detidas, direta ou indiretamente, em mais de 10% do capital. Créditos incobráveis.
A dedutibilidade deixa de ter como requisito a existência de prova de comunicação ao devedor do reconhecimento do gasto para efeitos fiscais.
Relativamente a créditos sobre entidades relacionadas, é esclarecida a forma como deve ser determinada a participação de 10%.
É ainda definida a data do evento gerador da perda por crédito incobrável, em resultado de processo de execução, insolvência, processo especial de revitalização ou procedimento de recuperação de empresas ou equivalente. Pretende-se, assim, uma harmonização com a solução prevista no Código do IVA.
Informação a ter em conta no registo contabilístico de Créditos Incobráveis. Com a Reforma do IRC deixa de ser obrigatório para efeitos de dedutibilidade a existência de prova de comunicação ao devedor, facilitando assim o processo contabilístico e fiscal.
Depreciações e amortizações
O pedido de autorização para a utilização de outros métodos para além do método da linha reta e do método das quotas decrescentes terá que ser solicitado até ao termo do período de tributação em que se pretende fazer a alteração.
Passa expressamente a determinar-se que aos valores de aquisição, reavaliação ou mercado, seja deduzido o valor residual e não sejam consideradas as despesas de desmantelamento.
As taxas de depreciação de componentes, de grandes reparações e beneficiações ou de benfeitorias, são calculadas com base no respetivo período de vida útil esperada.
Alterações a ter em conta pelo cliente na execução da sua contabilidade e na adoção dos métodos de depreciação e de amortização, respeitante ao ano fiscal de 2014, a entregar em 2015.
Projetos de Desenvolvimento
As despesas com projetos de desenvolvimento passam a ser consideradas como gasto fiscal no período de tributação em que sejam suportadas, mesmo que contabilizadas como ativos intangíveis.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Realizações de utilidade social
Explicita-se que os contratos de seguros, de doença ou saúde em benefício dos familiares dos colaboradores estão abrangidos pelo mesmo regime dos mesmos seguros a favor dos colaboradores.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Mais-valias e menos-valias
Sempre que não seja aplicável o regime de
participation exemption
, a diferença negativa entregas mais e menos-valias realizadas e outras perdas relativas a partes de capital deixam de ter qualquer limitação quanto à respetiva dedutibilidade fiscal, exceto quanto a perdas relativas à transmissão onerosa de entidades residentes em território com regime fiscal claramente mais favorável.
Esta limitação à dedução é igualmente aplicável à transmissão onerosa de outros instrumentos de capital próprio de entidades residentes nestes territórios;
Na transmissão onerosa de partes de capital da mesma natureza e que confiram direitos idênticos, passa a aplicar-se o método de custeio à saída FIFO;
Na equivalência dos valores de realização ou de aquisição estabelecidos em moeda estrangeira, passa a aplicar-se a taxa de câmbio da data da realização ou aquisição ou, não existindo, a da última cotação anterior a essa data;
Em determinadas condições, o sujeito passivo pode passar a adotar o custo médio ponderado na determinação do custo de aquisição fiscalmente relevante de partes de capital da mesma natureza e desde que confiram direitos idênticos.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Participation exemption
para dividendos, reservas, mais-valias e menos-valias
Passa a existir um regime de
participation exemption
de caráter universal.
Os lucros e reservas distribuídos, bem como as mais e menos-valias realizadas por sujeitos passivos de IRC, com sede ou direção efetiva em Portugal, não concorram para a determinação do seu lucro tributável, desde que se verifiquem cumulativamente os seguintes requisitos:
O sujeito passivo detenha uma participação não inferior a 5% do capital social ou direitos de voto da entidade que distribui os lucros ou cuja transmissão onerosa do capital dê origem a uma mais ou menos-valia, deste que a participação seja detida por um período mínimo de doze meses, de forma ininterrupta, ou, para o caso dos dividendos, se detida há menos tempo, seja mantida durante o tempo necessário para completar aquele período;
O sujeito passivo não seja abrangido pelo regime da transparência fiscal;
A entidade que distribui os lucros ou reservas ou cujo capital social é objeto de transmissão onerosa, esteja sujeita e não isenta de IRC ou imposto similar, a uma taxa legal mínima de, pelo menos, 60% da taxa do IRC. Caso não cumpra tal requisito, deverá preencher cumulativamente as seguintes condições:
a) Os lucros ou rendimentos advenham de, pelo menos, 75% do exercício de uma atividade agrícola ou industrial ou comercial ou de prestação de serviços que não esteja dirigida predominantemente ao mercado português;
b) A atividade principal da participada não consista em operações de atividade bancária e seguradora, nem de rendimentos de operações passivas, entre outras, detenção de partes de capital inferior a 5% (desde que não residentes em jurisdição integrante de lista de "paraísos fiscais").
A entidade que distribui os lucros ou reservas, ou cujo capital social é objeto de transmissão onerosa, não poderá ter residência ou domicílio em país, território ou região sujeito a um regime fiscal claramente mais favorável constante da lista aprovada por portaria do Ministério das Finanças.
Este regime aplica-se também aos lucros, reservas e mais ou menos-valias que sejam imputáveis a estabelecimento estável situado em território português de uma entidade residente num Estado-membro da União Europeia ou do Espaço Económico Europeu e preencha, em qualquer um dos casos, os requisitos do artigo 2.º da Diretiva 2011/96/EU ou num Estado, que não paraíso fiscal, com quem Portugal tenha celebrado uma CDT que preveja cooperação administrativa e que e que nesse Estado esteja sujeita e não isenta de um imposto de natureza idêntica ou similar ao IRC.
Prevê-se ainda que a aplicação do regime de eliminação da dupla tributação económica apenas seja aplicável no caso de as entidades distribuidoras de dividendos e respetivas sua afiliadas se encontrarem sujeitas e não isentas de imposto, exceto se domiciliadas num Estado-membro da União Europeia ou do Espaço Económico Europeu.
O regime de
participation exemption
exclui as mais e menos valias realizadas com a transmissão de partes sociais quando o valor dos imóveis detidos pela participada representa mais de 50% do respetivo ativo (com algumas exceções).
Por outro lado, quando uma entidade residente em Portugal, que se encontre sujeita e não isenta de IRC, e não esteja abrangida pelo regime da transparência fiscal, proceda à distribuição de lucros ou reservas, tais rendimentos estarão isentos, desde que a entidade beneficiária:
Seja residente num Estado-membro da UE/EEE ou num Estado com o qual Portugal tenha celebrado uma CDT, que preveja uma cláusula de cooperação administrativa no domínio da fiscalidade similar às existentes no âmbito da UE;
Esteja sujeita e não isenta de IRC ou imposto semelhante, cuja taxa nominal não seja inferior a, pelo menos, 60% da taxa do IRC (não aplicável a entidades residentes em Estados-membro da UE);
Detenha direta ou indiretamente, uma participação não inferior a 5% do capital social ou direitos de voto da entidade que distribui os lucros ou reservas, durante os doze meses anteriores à distribuição ou, se detida há menos tempo, seja mantida durante o tempo necessário para completar aquele período.
Tal isenção também se aplicará, quando uma entidade residente em Portugal distribua lucros ou reservas a um estabelecimento estável situado noutro Estado-membro da UE ou do EEE, de uma entidade que cumpra os requisitos anteriormente apresentados para entidades não residentes.
Paralelamente, introduz-se um regime de crédito de imposto para eliminação da dupla tributação económica internacional
(underlying tax credit)
caso não se encontrem observadas a totalidade das regras associadas ao regime de participation exemption, sendo que, para o efeito, é necessária a detenção de 5% do capital social ou direitos de voto, por um período superior a doze meses, ou, se detida há menos tempo, seja mantida durante o tempo necessário para completar aquele período.
Cumpre ainda referir que, no que respeita à alienação de partes de capital, o presente regime será igualmente aplicável à diferença positiva entre as mais e menos-valias realizadas antes de 1 de Janeiro de 2001, que não tenha sido ainda incluída no lucro tributável do sujeito passivo, desde que o reinvestimento tenha sido realizado no respetivo prazo legal, nos moldes aplicáveis.
Adicionalmente, prevêem-se as seguintes medidas interligadas com o regime de
participation exemption
:
Eliminação do critério da "tributação efetiva" para a aplicação do mecanismo de eliminação da dupla tributação económica de lucros distribuídos;
Alteração do regime da liquidação de sociedades, desconsiderando a mais-valia emergente do resultado da partilha para a determinação do lucro tributável, por força do regime de
participation exemption.
Caso seja apurada uma menos-valia fiscal, que seja fiscalmente relevante, existirá uma recaptura do montante deduzido, com uma majoração de 15%, na esfera dos sócios da sociedade liquidada, se voltarem a desenvolver a atividade que era prosseguida por esta, até quatro anos após a sua liquidação.
Acresce que, é alargado o prazo mínimo de detenção da participação de três para quatro anos para efeitos da dedutibilidade fiscal da menos-valia;
O crédito de imposto por dupla tributação que não for deduzido no período de tributação em que foi gerado poder ser utilizado nos cinco períodos de tributação seguintes, de acordo com as regras da legislação portuguesa.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
CFC - Regras anti abuso e Tributação autónoma
Deixa de ser critério para a aplicação das regras CFC que o imposto efetivamente pago por uma entidade corresponda a um valor igual ou menor que 60% do IRC que seria devido se a entidade fosse residente em território português, passando este critério a ser aferido por referência à taxa de imposto, a qual terá que ser inferior a 60% da taxa geral de IRC legalmente prevista.
Deixam de qualificar para o âmbito de aplicação das regras CFC as entidades não residentes sujeitas a um regime fiscal privilegiado, cuja atividade principal consista na realização de operações relativas a partes sociais representativas de mais de 5% do capital social ou direitos de voto desta.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Redução de capital social
Esclarece-se que apenas há rendimento tributável quando o montante entregue aos sócios exceda o valor de aquisição das respetivas partes de capital.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Ações próprias
Não concorrem para a determinação do lucro tributável as variações patrimoniais, positivas ou negativas, decorrentes da aquisição ou alienação de acções ou quotas próprias.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Regime de neutralidade fiscal
Explicitam-se as situações a que é aplicável o regime, passando a prever-se expressamente a aplicabilidade, entre outras, a fusões e cisões entre sociedades detidas pelo mesmo sócio, ainda que não exista qualquer troca de participações, e a fusões inversas.
Esclarece-se que as mais ou menos valias, resultantes para a sociedade beneficiária da anulação de partes sociais da sociedade fundida, não concorrem para a formação do lucro tributável.
Estabelecem-se regras para a determinação do valor fiscal das participações detidas pelos sócios das sociedades cindidas ou fundidas, quando não lhes sejam atribuídas partes de capital na sequência das operações neutrais.
Os prejuízos fiscais das sociedades fundidas ao abrigo do regime da neutralidade podem ser transmitidos para a sociedade beneficiária.
Benefícios fiscais e saldos apurados no âmbito da limitação da dedutibilidade dos gastos de financiamento líquidos, são transmissíveis da sociedade fundida para a sociedade beneficiária.
Admite-se a possibilidade de estender esta transmissão a operações de cisão e entrada de ativos, mediante autorização governamental.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Fusão, cisões, entradas de ativos ou permutas de partes sociais
Quando não seja aplicável o regime de neutralidade fiscal, não há fato tributário ao nível da entidade beneficiária (variação patrimonial não relevante), mas sim ao nível da sociedade "transmitente".
Ao rendimento daí resultante, ainda que classificado como mais-valia, não lhe é aplicável o regime do reinvestimento.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Liquidação de sociedades
O resultado da partilha passa a ser qualificado como mais ou menos valia.
A mais valia é tributável, exceto se abrangida pelo regime de
participation exemption
, ao passo que a menos-valia será, por regra, integralmente dedutível, quando as participações tenham sido detidas por um período igual ou superior a 4 anos.
Outros instrumentos de capital próprio entram para o cômputo do custo de aquisição das participações.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Exit tax
- Redomiciliação de sociedades
A transferência da residência de uma sociedade com sede ou direção efetiva em território português para fora desse território é sujeita a exit tax, mas o pagamento de imposto poderá ser diferido, caso a transferência seja feita para um Estado Membro da UE ou do EEE, mediante certas condições.
Este regime não se aplica caso os elementos patrimoniais sejam afetos a um EE em Portugal da entidade redomiciliada.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Crédito de imposto
Prevê-se um crédito por dupla tributação económica internacional, aplicável por opção do sujeito passivo que receba lucros ou reservas aos quais não seja aplicável o regime da
participation exemption
, desde que aquele detenha, ou venha a deter, por um período de 12 meses, uma participação não inferior a 5%.
Quando seja exercida a opção pelo crédito de imposto por dupla tributação económica internacional, deve o sujeito passivo acrescer à matéria coletável o imposto sobre o lucro pago pelas entidades nos estados de origem, correspondente aos dividendos que lhe tenham sido distribuídos.
O prazo de utilização do crédito de imposto por dupla tributação jurídica internacional é alargado para cinco exercícios.
O crédito de imposto por dupla tributação jurídica internacional passa a ser determinado por país, considerando a totalidade dos rendimentos, exceto no caso de rendimentos imputáveis a estabelecimento estável, cuja dedução é calculada isoladamente.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Dispensa de retenção na fonte
Deixam de estar sujeitos a retenção na fonte, quando esta tenha a natureza de imposto por conta, os juros e outros rendimentos resultantes de contratos de suprimento, papel comercial ou obrigações, pagos a detentores, diretos ou indiretos, de mais de 10% do capital social, durante o ano anterior à data da colocação à disposição.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Preços de transferência
Aumento da percentagem que implica a existência de relações especiais de 10% para 20%.
São também aplicáveis as regras de preços de transferência nas relações entre uma entidade residente e os seus EE situados fora do território português ou entre estes.
Passa a prever-se a possibilidade dos sujeitos passivos solicitarem a celebração de acordos prévios sobre preços de transferência com caráter bilateral.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Pessoas coletivas e outras entidades que não exerçam, a título principal, atividade comercial, industrial ou agrícola
Ao rendimento global apurado pelas entidades que não exercem, a título principal, uma atividade comercial, industrial ou agrícola passam a ser dedutíveis, até à respetiva concorrência, os gastos com a realização dos seus fins estatutários, desde que não exista qualquer interesse dos MOE (Membros dos Orgãos Estatuários) nos resultados da exploração das atividades económicas por elas prosseguidas.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Rendimentos decorrentes da cessão ou utilização temporária de patentes e desenhos ou modelos industriais, sujeitos a registo (registados em ou após 01/01/2014)
É introduzido um regime de tributação dos rendimentos provenientes da cessão ou da utilização temporária de patentes, desenhos ou modelos industriais. Neste contexto, os ganhos provenientes de contratos cujo objeto seja a cessão ou utilização temporária de propriedade industrial, são considerados apenas em 50% no cálculo do lucro tributável do sujeito passivo.
No regime de eliminação da dupla tributação jurídica internacional, deverá considerar-se apenas 50% destes rendimentos, quando obtidos no estrangeiro.
Este regime apenas é apenas aplicável a ativos registados em ou após 1 de Janeiro de 2014.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Limitação à dedutibilidade de gastos de financiamento
Diminuição do valor absoluto para efeito de limitação dos gastos de financiamento líquidos de € 3 Milhões para € 1 Milhão, mantendo-se a possibilidade de aceitar como custo até 30% do resultado antes de depreciações, amortizações, gastos de financiamento líquido e impostos, se superior (bem como o escalonamento previsto no período transitório).
O reporte dos gastos de financiamento deixa de ser utilizado conjuntamente com os gastos de financiamento desse período, passando antes a ser deduzido após a consideração dos gastos de financiamento líquidos desse mesmo período.
Critério FIFO para identificação dos gastos de financiamento líquidos não dedutíveis e da parte não utilizada do limite que deva acrescer ao montante máximo dedutível nos períodos subsequentes.
Nos casos em que exista um grupo de sociedades, a sociedade dominante pode optar pela aplicação do limite aos gastos de financiamento líquidos do grupo. Neste caso os limites são calculados com base no resultado antes de depreciações, amortizações, gastos de financiamento líquidos e impostos consolidado relativo à totalidade das sociedades que o compõem.
Esta opção deve ser mantida por um prazo mínimo de 3 anos e deverá ser comunicada à AT até ao fim do 3.º mês do período de tributação em que se pretenda iniciar a respetiva tributação.
O reporte dos gastos líquidos de financiamento bem como o reporte da parte não utilizada que acresce ao montante máximo dedutível nos períodos subsequentes, deixa de poder ser utilizado se se verificar a alteração da titularidade de mais de 50% do capital social ou da maioria dos direitos de voto do sujeito passivo.
Conceito de resultado antes de depreciações, amortizações, gastos de financiamento líquidos e impostos para efeitos fiscais passa a constar expressamente da norma.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
RETGS - Regime Especial de Tributação dos Grupos de Sociedades
Diminuição da percentagem de detenção mínima para a integração de uma sociedade no perímetro do grupo, passando a mesma de 90% para 75%.
Passou a constar expressamente na lei que sociedades detidas, em mais de 75% por intermédio de sociedades residentes noutro Estado Membro da União Europeia ou do Espaço Económico Europeu (neste caso desde que exista obrigação de cooperação administrativa no domínio da fiscalidade), poderão integrar o perímetro do consolidado fiscal.
A não comunicação de alterações na composição do grupo não resulta na cessação automática do regime.
Possibilidade de continuidade do RETGS caso se verifique a alteração da sociedade dominante, mediante comunicação à AT efetuada nos 30 dias seguintes à data em que se verifique esse facto.
Quando se verifique a alteração da sociedade dominante de um grupo, a utilização do reporte dos prejuízos fiscais apurados pelo grupo em períodos anteriores fica condicionada à obtenção de autorização por parte das entidades competentes.
Previsão de regras para a aquisição pela dominante de um grupo do domínio da sociedade dominante de outro grupo.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Entidades não residentes e sem estabelecimento estável em Portugal
Consagra-se o alargamento e a harmonização dos prazos previstos para o cumprimento das obrigações acessórias por parte das entidades não residentes e sem estabelecimento estável em Portugal, como seja:
Consagração de prazo único para apresentação da declaração periódica de rendimentos ("Modelo 22");
Alargamento do prazo de entrega da declaração de inscrição pelas entidades obrigadas a apresentar a Modelo 22, até à data de entrega desta última.
Alterações a ter em conta no exercício fiscal de 2014, a entregar em 2015.
Comunicação de alterações na declaração de inscrição
É alargado, de 15 para 30 dias, o prazo de entrega da declaração de alterações.
Sempre que existam alterações a efetuar no cadastro, o prazo para proceder às mesmas é alargado para 30 dias.
Manutenção do processo de documentação fiscal
É aumentado, de 10 para 12 anos, o prazo de conservação do processo de documentação fiscal.
Alteração a ter em conta no que diz respeito à conservação dos documentos e do processo fiscal. Aplicável aos períodos de tributação que se iniciem em ou após 1 de janeiro de 2014.
Obrigações contabilísticas
Passa de 10 para 12 anos o prazo de conservação dos livros, registos contabilísticos e respetivos documentos de suporte.
Alteração a ter em conta no que diz respeito à conservação dos documentos e do processo fiscal. Aplicável aos períodos de tributação que se iniciem em ou após 1 de janeiro de 2014.
Obrigações acessórias
Simplificam-se os requisitos para aplicação dos ADT (Acordo de Dupla Tributação), admitindo-se a utilização de certificados de residência no formato do Estado de residência do beneficiário.
Foi simplificado o processo para evitar a Dupla Tributação, passando a ser admitido a simples entrega da declaração de Residência que pode ser solicitada diretamente no Portal das Finanças.
