---
title: Alterações na Reforma do Irc no Âmbito do Phc
source: alteraçõesnareformadoircnoâmbitodophc.htm
tipo: Manual Técnico
idioma: PT
---

# Alterações na Reforma do Irc no Âmbito do Phc

Taxa de IRC
Tributação Autónoma
Regime Simplificado
Regime de Reporte e Prejuízos Fiscais
Taxa de IRC
A taxa de IRC é reduzida para 23%, mantendo-se o pagamento da Derrama, a qual será agravada.
A derrama estadual, criada a título de "contribuição de solidariedade" das grandes empresas, terá um terceiro escalão: empresas com lucros tributáveis acima de 35 milhões de euros pagarão uma taxa de 7% sobre o remanescente tal com o Governo já pretendia. Para os dois primeiros escalões, não haverá alterações, mantendo-se nos 3% para lucros entre 1,5 milhões e 7,5 milhões e de 5% para mais de 7,5 milhões e, agora, até aos 35 milhões de euros.
Nota:
Estabeleceu-se no preâmbulo que a eliminação das derramas municipal e estadual apenas ocorrerá em 2018.
Refere ainda a Lei 2/2014 no seu Artigo 8º que a taxa de IRC sofrerá reduções graduais e que em 2015 a mesma será fixada em 21%, e entre 17% e 19% em 2016. Esta alteração será efetuada após análise e ponderação por uma comissão de monitorização da reforma a constituir para o efeito.
É ainda criada uma taxa intermédia de IRC de 17% destinada às Pequenas e Médias Empresas, que será aplicada aos primeiros 15.000 € (quinze mil euros) de matéria coletável, enquanto ao restante valor aplicar-se-á a taxa normal de 23%.
De forma a dar cumprimento a esta alteração serão efetuadas alterações ao nível do mapa fiscal do IRC - Modelo 22, existente no Módulo PHC Contabilidade CS.
Tributação autónoma
Os encargos com viaturas ligeiras de passageiros, motos ou motociclos, excluindo veículos elétricos, passam a estar sujeitos a tributação autónoma às taxas de:
15%, se o custo de aquisição for inferior a €20.000;
27,5%, se o custo de aquisição for igual ou superior a € 20.000 mas inferior a € 35.000;
35%, se o custo de aquisição for igual ou superior a € 35.000.
Estas taxas são elevados em 10 p.p. em caso de prejuízos fiscais.
A tributação autónoma deixa de ser aplicável a despesas incorridas por estabelecimentos estáveis situados fora de Portugal, relativas à atividade exercida por seu intermédio.
Algumas tributações autónomas também não serão aplicáveis em caso de opção pelo regime simplificado de tributação.
De forma a dar cumprimento a esta alteração serão efetuadas alterações ao nível do mapa de Gestão
Tributações Autónomas
respeitante ao ano fiscal de 2014.
Regime simplificado
Estabelece-se um regime simplificado de tributação para os sujeitos passivos que, entre outras condições, tenham obtido no período de tributação anterior um montante anual ilíquido de rendimentos não superior a € 200.000 e cujo total de balanço não exceda € 500.000.
Neste caso a matéria coletável, que não pode ser inferior a 60% do valor anual da RMMG, obtém-se através da aplicação de coeficientes a determinados rendimentos:
0,04 Das vendas e prestações de serviços de atividades hoteleiras, restauração e bebidas;
0,75 Dos rendimentos das atividades profissionais constantes da tabela a que se refere o artigo 151.° Do CIRS;
0,10 Dos restantes rendimentos de prestações de serviços e subsídios destinados a exploração;
0,04 Das vendas e prestações de serviços de atividades hoteleiras, restauração e bebidas;
0,95 Dos rendimentos provenientes de cessão ou utilização temporária da propriedade intelectual ou industrial ou
know-how
, dos outros rendimentos de capitais, do resultado positivo de rendimentos prediais, do saldo positivo das mais e menos-valias e dos restantes incrementos patrimoniais;
1,00 Do valor de aquisição dos incrementos patrimoniais obtidos a título gratuito.
Os sujeitos passivos abrangidos pelo regime simplificado ficam isentos de tributação autónoma, relativamente aos encargos com despesas de representação e com ajudas de custo e compensação pela deslocação em viatura própria, lucros distribuídos por entidade isentas e bónus e indemnizações pagas a órgãos diretivos.
Os sujeitos passivos abrangidos pelo regime simplificado ficam dispensados da obrigação de efetuar PEC.
O Artigo 6º da Lei da Lei 2/2014 refere ainda a possibilidade do alargamento do Regime Simplificado poder ser alargado às empresas que se encontram enquadradas no Regime de IVA de Caixa.
A cessação do Regime Simplificado
O regime simplificado cessa:
Quando deixem de se verificar os requisitos anteriormente referidos;
Quando o sujeito passivo não cumpra a obrigação de comunicação das faturas prevista no Código do IVA e n.º 1 do artigo 3.º do Decreto-Lei n.º 198/2012, de 24 de Agosto;
Quando o sujeito passivo renuncie à sua aplicação.
Os efeitos da cessação ou da renúncia reportam-se ao primeiro dia do período de tributação em que se verifique alguma das causas acima referidas.
Artigo 6.º
Alargamento do regime simplificado
Após uma primeira avaliação da aplicação do regime simplificado de determinação da matéria coletável em IRC, será ponderado o alargamento gradual deste regime às empresas que podem beneficiar do regime de IVA de caixa, tendo nomeadamente em conta as respetivas implicações no regime simplificado de IRS.
Transmissão de bens imóveis
Os sujeitos passivos que adotem o regime simplificado não podem considerar na transmissão de direitos de bens imóveis um valor inferior ao valor patrimonial tributário que serviu de base à liquidação do IMT ou que serviria de base à liquidação deste imposto caso este se mostrasse devido.
De forma a dar cumprimento a esta nova alteração a PHC irá analisar as necessárias adaptações aos mapas de gestão existentes no PHC Contabilidade CS, contudo teremos de aguardar a publicação das obrigações declarativas para o Regime Simplificado que serão ainda legisladas. Todas estar alterações apenas são aplicáveis para o exercício de 2014 que será entregue à AT em 2015.
Regime de Reporte e Prejuízos fiscais
O prazo de reporte dos prejuízos fiscais é aumentado de 5 para 12 anos. Por outro lado, passa a estar expressamente previsto que devem ser utilizados os prejuízos fiscais apurados há mais tempo.
A limitação à dedução de prejuízos fiscais é alterada de 75% para 70% do lucro tributável apurado em cada exercício.
Procede-se à harmonização do prazo limite para se proceder a anulações ou liquidações adicionais de IRC, decorrentes de correções aos prejuízos fiscais reportáveis (atualmente 5 anos), com o prazo geral de caducidade de 4 anos.
É eliminada a limitação à dedução dos prejuízos fiscais, quando se verifique a modificação do objeto social ou a alteração da atividade exercida, sendo, assim, somente mantida a limitação à dedução de prejuízos fiscais quando se verificar a alteração da titularidade de mais de 50% do capital social ou dos direitos de voto.
Os elementos a constar do requerimento a apresentar à AT, no prazo de 30 dias a contar da data de alteração da titularidade, destinado a afastar tal limitação, passam a ser definidos por portaria do membro do Governo responsável pela área das finanças.
Não são consideradas como alterações de titularidade, para estes efeitos, as decorrentes:
Da passagem da titularidade do capital social ou dos direitos de voto de direta para indireta, e vice-versa;
De operações de concentração a que se aplique o regime da neutralidade fiscal:
De sucessão por morte;
De aquisições por titulares que já detenham ininterruptamente, direta ou indiretamente, mais de 20% do capital social ou da maioria dos direitos de voto da sociedade;
ando o adquirente seja trabalhador ou membro dos órgãos sociais.
No que respeita às duas últimas situações mantém-se a necessidade de apresentação de requerimento à AT relativamente à parte dos prejuízos fiscais respeitantes ao período de tributação em que o adquirente tenha passado a deter, direta ou indiretamente, mais de 20% do capital social ou da maioria dos direitos de voto ou tenha iniciado funções na sociedade, respetivamente, bem como aos períodos anteriores àquele.
As alterações em apreço aplicam-se aos prejuízos apurados em períodos de tributação iniciados em ou após 1 de Janeiro de 2014.
Por último, e no que respeita ao reporte de prejuízos fiscais individuais em operações de concentração com neutralidade fiscal, este passa a ser automático, sem que seja necessária autorização do membro do Governo responsável pela área das finanças, estipulando-se, desde logo, que a dedução dos prejuízos fiscais das entidades fundidas ou contribuidoras fica limitada ao valor correspondente à proporção entre o valor do respetivo património líquido e o património líquido de todas as entidades envolvidas nas operações.
De forma a dar cumprimento a esta nova alteração a PHC irá analisar as necessárias adaptações aos mapa de gestão Modelo 22 do IRC, o qual faz parte do Módulo PHC Contabilidade CS, contudo teremos de aguardar a publicação dos layouts dos mesmos.
Todas estas alterações apenas são aplicáveis para o exercício de 2014 que será entregue à AT em 2015.
