---
title: Análisecomlistaderesultadosemvbnet
source: análisecomlistaderesultadosemvbnet.htm
tipo: Manual Técnico
idioma: PT
---

# Análisecomlistaderesultadosemvbnet

Análise com Lista de Resultados em Vb.net

|  |
| --- |
| Análise com Lista de Resultados em Vb.net |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A criação de [Análises de Utilizador](configuraçãodeanálises.htm) está disponível na Framework Drive FX.    Através desta opção podem ser criadas novas análises (globais ou dedicadas a entidades - nativas ou personalizadas) para posteriormente serem aplicadas nas instalações de clientes, através de [add-ons](add-ons.htm) - [públicos](publicaçãodeadd-onsnadrivefxstore.htm) ou [privados](add-onsprivados.htm).    As análises podem ser criadas recorrendo a uma expressão *SQL* ou a programas em *VB.NET*.    Neste artigo pretende-se exemplificar a criação de uma análise em *VB.NET* que retorna uma lista de resultados.    Neste caso em concreto a análise elaborada retorna a lista de todos os nomes dos clientes, presentes na instalação.      Para criar a análise deve-se aceder ao menu **Framework/Configuração de Análises**. Criar novo registo preenchendo os seguintes valores nos campos:    **Nome** -> "Lista do nome de todos os clientes".  **Grupo** -> Clientes.  **Descrição completa** -> A análise retorna uma lista com o nome de todos os clientes existentes na base de dados.  **Plano Mínimo** -> Grow (pois apesar de a entidade Clientes existir no plano Ready, os Add-ons apenas se encontram disponíveis a partir do plano Grow).  **É um programa VB.NET** -> Sim.  **Programa** -> *´initialize a new QueryVO object  Dim query As QueryVO = New QueryVO()  ´select the table name  query.entityName = "CL"  ´select the field(table column)  query.SelectItems.Add("nome")    ´Run the query and obtain the result  Dim result = SDK.Query.getEntityData(query)    Return resultado*    **Colunas expressão sql** -> nome  **Tipo de dados para cada coluna** -> c  **Títulos das expressões Sql** -> Nome do Cliente  **Áreas** (de acesso) -> Vendas    A análise construída pode ser alvo de [pré-visualização](simularumaanálise.htm), clicando sobre o botão **Prever análise** que se encontra no canto superior direito do ecrã.    Depois de construída, a análise poder ser adicionada a um Add-On que se encontre em modo de desenho, que depois bastará ser publicado na [Drive FX Store](comofuncionaadrivefxstore.htm), ou em instalações de clientes específicos (caso se trate de um Add-On [privado](add-onsprivados.htm)). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Análise com Lista de Resultados em Vb.net' ) |