---
title: Análisedimensionaldosistema
source: análisedimensionaldosistema.htm
tipo: Manual Técnico
idioma: PT
---

# Análisedimensionaldosistema

Análise Dimensional do Sistema

|  |
| --- |
| Análise Dimensional do Sistema |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta análise permite visualizar a dimensão do sistema instalado entre determinada data.   A análise apresenta a seguinte informação:   * Nome da Base de Dados;  * Utilizadores registados;  * Número de documentos de facturação, dossiers internos, compras, recibos, pagamentos, documentos contabilísticos;  * Número médio de documentos de facturação, dossiers internos, compras, recibos, pagamentos e documentos contabilísticos por dia;  * Número de linhas de cada documento de facturação, dossiers internos, compras, recibos, pagamentos e documentos contabilísticos;  * Número médio de linhas por documento de facturação, dossiers internos, compras, recibos, pagamentos e documentos contabilísticos;  * Tamanho das tabelas principais;  * Número médio de utilizadores diferentes que estiveram a trabalhar em determinada tabela;  * Número máximo num dia de utilizadores diferentes em determinada tabela;  * Número de tipos de documentos de facturação, dossiers internos;  * Número de funcionários;  * Número de bens imobilizados;  * Número de artigos;  * Número de famílias de artigos;  * Número de armazéns;  * Número de instalações;  * Número de técnicos;  * Número de equipamentos;  * Número de vendedores;  * Tamanho de base de dados (em MB).    Esta análise tem no total 63 linhas de análise, ou seja, se o utilizador tiver acesso a todos os módulos do Software PHC (pelo menos Gestão, Contabilidade, Suporte e Pessoal), consegue visualizar todos os dados da análise.    Caso possua a Gama Enterprise poderá criar um evento fixo «AposPrepararCursor» ao ecrã DIMSIS. Este evento ocorre quando o utilizador escolhe a opção e introduz as datas da análise, antes de aparecer o ecrã com a análise.        Poderá visualizar, Imprimir e exportar a referida [análise](opçõesdasanálises.htm).      Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação acerca do volume e distribuição dos dados no seu sistema de informação, através do nosso [filme](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=2cbcf87f12g.cge%3a.33g5.5eg) ou da nossa [idirecto](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=87%3a1764431f.f64b.5485.f97). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Análise Dimensional do Sistema' ) |