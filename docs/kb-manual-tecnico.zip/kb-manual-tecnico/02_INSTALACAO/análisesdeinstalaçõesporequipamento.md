---
title: Análisesdeinstalaçõesporequipamento
source: análisesdeinstalaçõesporequipamento.htm
tipo: Manual Técnico
idioma: PT
---

# Análisesdeinstalaçõesporequipamento

Análises de Instalações por Equipamento

|  |
| --- |
| Análises de Instalações por Equipamento |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite obter uma listagem com todas as instalações que possuem, ou não, determinados equipamentos. Para obter uma listagem basta definir o modelo que a instalação deve ou não conter, determinando desta forma a condição para a listagem.    Isto significa que esta opção pode ser utilizada de três formas distintas: visualizar todas as instalações que possuem determinado modelo, observar todas as instalações sem determinado modelo e visualizar todas as instalações com determinado modelo mas sem outro modelo.        Adicionalmente é possível definir um filtro, limitando desta forma a escolha das instalações. Após **Executar a Análise** são apresentadas as informações das instalações e dos equipamentos respectivos.        Ao clicar no separador **Equipamento** é ainda possível observar os equipamentos da instalação seleccionada.        *Nota:*  Todos os botões deste ecrã estão explicados nas [Opções das Análises](opçõesdasanálises.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Análises de Instalações por Equipamento' ) |