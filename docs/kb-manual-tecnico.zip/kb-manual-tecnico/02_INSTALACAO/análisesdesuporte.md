---
title: Análisesdesuporte
source: análisesdesuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Análisesdesuporte

Análises de Suporte

|  |
| --- |
| Análises de Suporte |

|  |
| --- |
| Esta opção permite obter diversas listagens e análises estatísticas dos dados que estão contidos nas diversas tabelas da aplicação. Para tal é necessário que o utilizador possua os [acessos](AcessosdeUtilizador.htm#mpsacanali) necessários.    As análises disponíveis são:     * [Monitor de Pedidos de Assistência](monitordepedidosdeassistência.htm)  * [Monitor de Conhecimento Técnico](monitordeconhecimentotécnico.htm)  * [Monitor Técnico de Clientes](monitortécnicodeclientes.htm)  * [Relatórios Vários](relatóriosvários.htm)  * [Análises de instalações por equipamento](análisesdeinstalaçõesporequipamento.htm)  * [Facturação periódica de Instalações por pagar](facturaçãoperiódicadeinstalaçõesporpagar.htm)  * [Análise de Totais de Equipamento](análisedetotaisdeequipamento.htm)  * [Análise de Totais por Técnico](análisedetotaisportécnico.htm)      Existe ainda a possibilidade de construir [Análises multidimensionais](análisesmultidimensionais.htm) e [Mapas definidos](mapasdefinidos.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Análises de Suporte' ) |