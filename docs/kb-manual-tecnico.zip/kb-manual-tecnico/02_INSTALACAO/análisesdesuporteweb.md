---
title: Análises de Suporte Web
source: análisesdesuporteweb.htm
tipo: Manual Técnico
idioma: PT
---

# Análises de Suporte Web

O utilizador dispõem de análises exclusivamente dedicadas a
Suporte
, que são compostas pela informação existente na aplicação.
Instalações de Suporte Web
Consulta de Pedidos
Equipamentos
Galeria de Anúncios
Galeria Multimédia
Análises da Aplicação
