---
title: Assistentedeligação
source: assistentedeligação.htm
tipo: Manual Técnico
idioma: PT
---

# Assistentedeligação

Assistente de Ligação

|  |
| --- |
| Assistente de Ligação |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O PHC Manufactor representa o módulo de gestão de produção da gama de produtos da PHC.     No entanto este módulo possui características únicas em relação aos restantes, pelo facto de operar numa base de dados à parte. Visto que existe a necessidade de integrar os dados da aplicação com os restantes módulos, o PHC Manufactor possui processos de instalação dos diversos mecanismos de ligação. No entanto existiam algumas sugestões de utilizadores para tornar este processo ainda mais intuitivo do que já ocorria.     Assim, criamos o Assistente de ligação.    A ideia geral foi a de criar um mecanismo tão intuitivo que o próprio utilizador poderia simplesmente realizar todo o processo simplesmente seguindo os passos indicados pela aplicação.  O assistente encontra-se organizado em 7 passos diferentes, os quais correspondem a cada uma das áreas a configurar.     1- Numa 1ª fase a aplicação questiona pela base de dados do PHC CS que o utilizador pretende ligar. A aplicação apresenta todas as bases de dados relacionadas com o PHC CS que o servidor possui instaladas. O utilizador necessita unicamente de escolher.        2- Posteriormente o utilizador é convidado a indicar se deseja importar alguns tipos de dados, bem como definir o tipo de ligação que pretende.     - Interligação Assíncrona (vulgo [Conector](interligaçãoassíncrona(conector).htm))  - Sincronizar dados de qualidade de fornecedor com os artigos importados.   Na prática a aplicação vai ler os dados de qualidade a fornecedor existentes no PHC CS e sincronizar os mesmos com o PHC Manufactor. Deste modo durante o processo de criação e agendamento de ordens de fabrico a informação de entrega de mercadoria é tida em conta, pelo que torna mais fidedigna a data planeada.   - Criação de movimentos de [inicialização de stock](configuraçãodomovimentodeinicializaçãodestock.htm) com data do dia da importação.    3- Num 3º passo a aplicação apresenta todos os tipos de movimentos de entrada existentes no PHC manufactor e questiona o utilizador como estes serão ligados aos já existentes no PHC CS.      Automaticamente a aplicação já contempla um padrão, no entanto este poderá ser alterado.   A aplicação conta com a possibilidade de tornar esta configuração algo completamente manual. Para isso o utilizador bastara desactivar a opção "Visualizar apenas códigos com descrição" .Quando inactiva o utilizador está activamente a criar códigos de movimentos de stock na base de dados do PHC CS.  Neste ponto importa realçar que a relação entre códigos de movimentos não é única.   Ou seja, para um dado código de movimento do PHC Manufactor o utilizador poderá ter vários associados no PHC CS. No entanto um terá de ser sempre o principal   A diferença é que o principal fica marcado com a marca redonda (vulga botão de Rádio). Os restantes com o visto (vulgo Check-mark).    4- O 4º ponto é semelhante aos movimentos de entrada unicamente o sentido é invertido, neste caso é inverso (movimentos de saída).        5- Como 5 passo o utilizador tem a possibilidade de definir o tipo de ligações entre dossiers. Numa 1ª fase a relação entre os dossiers de encomenda do PHC CS e o PHC Manufactor. É de realçar que é possível indicar a partir de que ano os dados relativos a dossiers deverão ser transferidos. As configurações do dossier que servirá como base documental para as reservas de produção no PHC CS terão de ser definidas aqui também.      Numa 2ª fase o utilizador terá de realizar também a definição do dossier e cliente (interno) que servirá como suporte documental das propostas de fabrico.     6- No 6 passo a aplicação irá propor a configuração do pessoal (caso este exista no PHC CS) de modo a que os funcionários e informação associada, seja transferida para o PHC Manufactor.      Terminado este 6 passo o utilizador unicamente terá de validar as configurações realizadas e colocar em marcha a sincronização.      A aplicação fará o resto do processo automaticamente.     No final do processo será apresentado um mini relatório com a indicação de término com sucesso.   Caso ocorra alguma situação anómala, a ligação não será completada, sendo apresentado um relatório com todas as situações encontradas.      Após resolução por parte do utilizador o processo poderá ser novamente colocado em marcha. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Assistente de Ligação' ) |