---
title: Attachdeumabasededadosnosqlexpress
source: attachdeumabasededadosnosqlexpress.htm
tipo: Manual Técnico
idioma: PT
---

# Attachdeumabasededadosnosqlexpress

Attach de uma Base de Dados no Sql Express

|  |
| --- |
| Attach de uma Base de Dados no Sql Express |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O SQL Express instala por defeito o utilizador SA como uma conta de Network Services, o que significa que a conta SA fica com permissões reduzidas, ficando a base de dados, consequentemente, como read-only.    Para que isto não aconteça, neste tópico são apresentadas duas soluções.   - Em primeiro lugar pode ligar-se, através da ferramenta Management Studio para o SQL Express, ao servidor SQL Express com "Windows Authentication" com o utilizador de rede que utilizou para fazer a instalação (que em princípio será administrador da sua máquina). Desta forma já conseguirá fazer o attach da base de dados correctamente.    - Como alternativa, pode aceder ao Microsoft SQL Server 2005, às opções de configuração - *Configuration Tools*. Seleccionar a opção *SQL Server Configuration Manager* e nesta seleccionar a pasta *SQL Server 2005 Services*. Do lado direito surgirá *SQL Server(SQLEXPRESS)*.     Deve entrar nas propriedades deste serviço, na pasta **Log-On** e alterar o item **Built In** para **Local System**.     Desta forma, o utilizador SA ficará com todos os acessos e conseguirá fazer attach da base de dados sem problemas.     Concluindo, qualquer uma das duas soluções apresentadas permite efectuar attach a uma base de dados no SQL Express sem que esta fique read-only. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Attach de uma Base de Dados no Sql Express' ) |