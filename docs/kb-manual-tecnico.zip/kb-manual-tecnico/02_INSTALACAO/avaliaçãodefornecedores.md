---
title: Avaliaçãodefornecedores
source: avaliaçãodefornecedores.htm
tipo: Manual Técnico
idioma: PT
---

# Avaliaçãodefornecedores

Avaliação de Fornecedores

|  |
| --- |
| Avaliação de Fornecedores |

|  |
| --- |
| A avaliação dos fornecedores é cada vez mais um ponto essencial para que uma empresa possa selecionar e qualificar os seus fornecedores, pois para que o seu produto tenha qualidade, é necessário que essa característica se encontre também nos artigos/serviços que lhe são fornecidos.    Nesta área do módulo é possível organizar, planear e avaliar todos os fornecedores pelos Tipos de Artigo que disponibilizam. Para isso é necessário que tenha o *Módulo Qualidade com Gestão* ou o *Módulo Qualidade com POS Back e Fornecedores para POS*.    A divisão dos Tipos de Artigo que será utilizada na classificação de fornecedores, é definida nos [parâmetros da qualidade](parâmetrosdomóduloqualidade.htm) da aplicação, onde deve ser indicado qual o campo de entre os vários campos da ficha do artigo que será considerado para assumir o papel de separador de tipos de artigo.    Após serem definidos os graus de qualificação, ou [Classes de Fornecedores](classesdefornecedores.htm), e de ser definido na ficha do fornecedor quais os Tipos de Artigo que este fornece, é necessário definir quais os critérios de avaliação pelos quais a qualificação dos fornecedores se vai guiar.     Cada [Critério de Avaliação](constituiçãodatabeladecritériosdeavaliação.htm) deve ser definido cuidadosamente para que não fique esquecido nenhum ponto a avaliar e para que a qualificação seja tão rigorosa e exata quanto possível.    Os vários critérios de avaliação são agrupados em [Estruturas de Avaliação](constituiçãodatabeladeestruturasdeavaliação.htm), às quais são associados os Tipos de Artigo que já constam na ficha do fornecedor. Cada estrutura pode ser utilizada para avaliar vários tipos de artigo, se estes tiverem características semelhantes, pois a avaliação da qualidade de artigos semelhantes pode focar os mesmos pontos.    As estruturas de avaliação irão ser usadas para realizar uma [Qualificação Inicial](constituiçãodatabeladequalificaçõesiniciais.htm) de cada tipo de artigo disponibilizado por um fornecedor, esta primeira avaliação será a base primária da qualificação desse fornecedor. Posteriormente serão lançados, [Registos de Entrega](constituiçãodatabeladeregistosdeentregas.htm) de cada fornecimento desse fornecedor que serão criteriosamente avaliados, e irão fornecer os dados necessários para que seja realizada a classificação periódica de todos os fornecedores da empresa.    Encerrada a [Classificação de Fornecedores](constituiçãodatabeladeclassificaçãodefornecedores.htm) a pontuação calculada na classificação e, consequentemente a classe em que o fornecedor se enquadra são assumidos no separador de Qualidade da Ficha do Fornecedor.    É possível nos parâmetros da qualidade, definir uma das classes de fornecedores como Classe de Desqualificação de Fornecedores. Os fornecedores que se enquadrarem nesta classe podem ser considerados desqualificados para responder aos requisitos e necessidades da empresa. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Avaliação de Fornecedores' ) |