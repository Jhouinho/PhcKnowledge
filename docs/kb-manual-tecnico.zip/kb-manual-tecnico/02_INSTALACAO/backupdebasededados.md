---
title: Backupdebasededados
source: backupdebasededados.htm
tipo: Manual Técnico
idioma: PT
---

# Backupdebasededados

Backup de Base de Dados

|  |
| --- |
| Backup de Base de Dados |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite efetuar backup de bases de dados na aplicação. Disponível no menu **Supervisor**, esta opção efetua o *backup* da base de dados que se encontra em uso pela aplicação.    Vejamos como é constituído o ecrã desta opção:        **Nome do Backup**  Este campo permite definir um nome para o *backup* a realizar.    **Descrição do Backup**  Este campo permite introduzir uma descrição relativa ao Backup em si.    **Diretoria**  Campo que permite seleccionar uma diretoria na qual vai ser colocado o ficheiro com o backup realizado.    Os três campos acima mencionados são de preenchimento obrigatório.     O botão de lista permite escolher a diretoria para o backup, porém, só pode ser utilizado caso a base de dados esteja no próprio computador, pois a diretoria é relativa ao servidor da base de dados.  Caso não utilize o botão de lista e digite o caminho pretendido, se a base de dados que pretende efetuar o *backup* está noutra máquina, o caminho digitado é do Servidor remoto e não da máquina local, onde se está a efetuar o *backup*.    **Nome do ficheiro**  Este campo permite introduzir um nome para o ficheiro que vai ser criado.    Para mais informações sobre backup de Base de Dados consulte, por favor, o modo de funcionamento do [parâmetro](ParâmetrosGerais.htm#mchbackup) **Faz Backups das tabelas que sejam alteradas na Instalação e Manutenção** e do [parâmetro](ParâmetrosGerais.htm#mchexebck) **Intervalo de dias para executar o backup (1-365)** nos Parâmetros Gerais.     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais, sobre como realizar o backup a uma base de dados a partir do software PHC, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=bf29868637e.4539.37e5.93g).    Nota: Se desejar efectuar o *restore* da base de dados terá de recorrer à ferramenta do *SQL Server Management Studio*. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Backup de Base de Dados' ) |