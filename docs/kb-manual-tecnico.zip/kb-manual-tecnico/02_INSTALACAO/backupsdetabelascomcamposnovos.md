---
title: Backupsdetabelascomcamposnovos
source: backupsdetabelascomcamposnovos.htm
tipo: Manual Técnico
idioma: PT
---

# Backupsdetabelascomcamposnovos

Backups de Tabelas com Campos novos

|  |
| --- |
| Backups de Tabelas com Campos novos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Backups de tabelas com campos novos**  Quando se executa a instalação e manutenção para uma determinada tabela, ou se entra num ecrã de uma determinada tabela, caso o software detecte que existem campos a adicionar à tabela, quer eles sejam do tipo de utilizador ou simplesmente tenham sido acrescentados na versão que está a correr no momento, o software irá executar algumas rotinas internas de verificação. Estas rotinas permitem distinguir se é necessário ou não proceder á actualização dos dados da tabela.    Por exemplo, pode ter sido acrescentado um campo á tabela no novo EXE que o utilizador está a correr, e pode existir necessidade de se actualizar esse novo campo com informação proveniente da mesma tabela ou de tabelas relacionadas com ela. Este procedimento é automático e o utilizador não tem qualquer controle sobre ele.    Uma vez que esta operação implica uma actualização aos dados actuais da tabela a aplicação efectua uma cópia de segurança (BackUp) da tabela com a informação dos dados antes de eles poderem ser actualizados nesta operação automática.    Assim, caso se esteja a utilizar a versão Corporate essa cópia é efectuada para a directoria "Backup" que é criada automaticamente pelos exe, logo abaixo da directoria do próprio executável. Esta directoria é sempre criada independente da versão do software, embora só seja utilizada para guardar os backups da aplicação em Corporate nesta situação.    No caso do utilizador possuir Advanced ou Enterprise, os backups são efectuados para dentro da própria base de dados no SQL.    Os nomes dos ficheiros que são guardados como copia seguem a seguinte nomenclatura:    **BackUpXX0YYYY**    O *XX* é o nome da tabela original de onde se procedeu a cópia, o *0* separa o nome da tabela do número sequencial do backup que é designado por *YYYY*. Assim podemos ter por exemplo para a tabela de clientes (CL) caso já tenham sido feito dois backups, os seguintes ficheiros de cópia:    BackUpCL000001  BackUpCL000002 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Backups de Tabelas com Campos novos' ) |