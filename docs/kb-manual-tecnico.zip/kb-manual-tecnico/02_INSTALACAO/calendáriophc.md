---
title: Calendáriophc
source: calendáriophc.htm
tipo: Manual Técnico
idioma: PT
---

# Calendáriophc

Calendário Phc

|  |
| --- |
| Calendário Phc |

|  |
| --- |
| Esta funcionalidade permite fazer a gestão de [Datas](datasdocalendáriophc.htm) do Calendário PHC.    Para aceder ao Calendário PHC deve activar o parâmetro [Utiliza Calendário PHC](ParâmetrosGerais.htm#cncalendariophc).     Do lado direito do ecrã pode visualizar os registos das datas do Calendário PHC:        Do lado esquerdo do ecrã pode seleccionar a data que pretende visualizar:        A amarelo aparecem os fins de semana e feriados.  A azul aparecem os dias que contêm registos.  A vermelho o dia em que se está posicionado.     - Este botão permite sincronizar as datas do calendário PHC. Para efectuar esta sincronização, devem estar definidos os [parâmetros](ParâmetrosGerais.htm#cncalendariophc) de Url do WebService, o nº de instalação e a password para webservice. Esta opção envia para a PHC esses parâmetros e o seu licenciamento.  Após a primeira sincronização, o ecrã [Datas](datasdocalendáriophc.htm) do Calendário PHC também ficará disponível.    **Funcionamento do Calendário PHC**  Esta funcionalidade está disponível para os clientes que possuam [PHC ON](oqueéophcon.htm).     Para utilizar o Calendário PHC deve começar por definir os respectivos [parâmetros](ParâmetrosGerais.htm#cncalendariophc).    No ecrã de [utilizadores](GestãodeUtilizadores.htm#cncalendariophc) e de [Grupos](gruposdeutilizadores.htm), aparece a opção **O Calendário PHC surge ao entrar na aplicação** e o **n.º de dias de antecedência para aviso**.  Caso esta opção esteja activa no ecrã de Grupos ou de Utilizadores, o Calendário PHC aparece visível ao entrar-se na aplicação. Se existirem datas no intervalo entre a data corrente e o n.º de dias definido para o utilizador, ou caso não esteja definido para o grupo, o Calendário PHC aparece posicionado na data actual.  Se o campo de número de dias estiver preenchido, no ecrã de utilizadores e no ecrã de grupos, o número que prevalece é aquele que se encontra no campo do ecrã de utilizadores.    Após definidos os pressupostos anteriormente explicados, deve começar por efectuar a primeira sincronização e utilizar o Calendário PHC.     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre como verificar diversas datas fiscais de forma simples e rápida, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=b5f754c9b9d.869c.7615.%3acd). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Calendário Phc' ) |