---
title: Cdata.getcacheddatatable
source: cdatagetcacheddatatable.htm
tipo: Manual Técnico
idioma: PT
---

# Cdata.getcacheddatatable

## Descrição

Esta função permite converter um
datatable
numa
tabela em HTML (string)
;
Classe:
cdata;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Texto: String | mchace | Obrigatório : mchace As String NOTA: mchace é a key com a qual ficará guardado, em cache, o datatable em questão. |
| 2 | Texto: String | msel | Obrigatório : msel As String NOTA: msel é a query cujos dados vão criar o datatable. |
| 3 | Variável: Boolean | mforcereload | Facultativo: mforcereload as Boolean (Default = False)) Caso esta variável seja verdadeira, mesmo que este objeto já se encontre em cache, efetua a query de novo e guarda os seus dados em cache. NOTA: A variável Boolean tem por default o valor = False. |
| 4 | Variável: Integer | hoursabsoluteexpiration | Facultativo: hoursabsoluteexpiration As Integer (Default = 24)) Diz respeito ao número de horas que existirá a cache, sendo que após essas horas, a mesma é eliminada. NOTA: A variável hoursabsoluteexpiration tem por default o valor = 24 |
