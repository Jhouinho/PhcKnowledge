---
title: Cdata.getsessiondatatable
source: cdatagetsessiondatatable.htm
tipo: Manual Técnico
idioma: PT
---

# Cdata.getsessiondatatable

## Descrição

Esta função que recebe seis

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: do tipo String | mcache | Obrigatório : É a key, na qual ficará guardada a datatable , na sessão onde o utilizador se encontra |
| 2 | Objeto: do tipo String | msel | Obrigatório : É a query cujos dados vão criar a datatable |
| 3 | Objeto: do tipo Boolean | mforcereload | Facultativo : Caso o utilizador não especifique, o valor deste parâmetro é False . Caso seja True , mesmo que este objeto já se encontre em sessão, efetua a query de novo. |
