---
title: Certificaçãoperiféricospossoftvoicehp
source: certificaçãoperiféricospossoftvoicehp.htm
tipo: Manual Técnico
idioma: PT
---

# Certificaçãoperiféricospossoftvoicehp

Certificação Periféricos Pos Softvoicehp

|  |
| --- |
| Certificação Periféricos Pos Softvoicehp |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Introdução**    Este documento visa dar a conhecer de forma simples e rápida, como configurar uma panóplia de equipamentos distribuídos pelo parceiro *Soft Voice* para a área da venda a retalho em particular para o nosso *software* **PHC POS CS**.    Os equipamentos sobre os quais vamos tecer considerações de seguida são:    **HP RP7 Retail System Model 7800, com processador Intel Celeron G540 a 2.5Ghz HDD disco de 320GB e 2GB RAM, ecrã touch de 15"** totalmente integrado.          **Visor de Cliente 2x20 RS232**          **Scanner Unitech MS837, ligação USB**          **Impressora Star TSP143 USB**          **Gaveta de Dinheiro Venus 03 8C/4B**          **HP RP7 Retail System Model 7800HP**  Este POS por estar equipado com um processador Intel G540 é um POS bastante ágil.  Disponível com HDD ou SSD e com possibilidade de fazer upgrade de RAM, é uma opção que complementada com um visor de cliente e com uma impressora de talões fica um POS pronto a trabalhar.        **Visor de Cliente 2x20 RS232**    Este *visor* de cliente, pode ser configurado no OPOS da Epson como um visor DM-D110, desta forma fica totalmente funcional. É um visor de 2 linhas com 20 caracteres.          Bastará na configuração de terminal de vendas, no separador OPOS, indicar que usa visor de cliente OPOS, indciar o nome lógico do mesmo, e definir que informação aparece em cada momento da venda.           **Scanner Unitech MS837, ligação USB**        Este *scanner* com ligação USB, permite ser um complemento excelente para facilitar o utilizador na introdução de artigos no documento de venda. Lê vários standards de códigos de barra e é muito rápido na leitura.  Não necessita de configuração visto que vem pronto a trabalhar, injetando no buffer do teclado, o código de barras lido, encarregando-se o **PHC** de transformar o código de barras na referência do artigo em causa. O *scanner* pode no entanto ser configurado para ler outros formatos de códigos de barra.      **Impressora Star TSP143 USB**        Esta impressora imprime 22 RPM recibos por minuto. Com guilhotina de corte integral ou parcial com a possibilidade de ser configurada com *driver Windows* ou OPOS, é uma solução versátil e eficaz.    No que diz respeito à configuração da impressora no sistema operativo, recorrendo ao OPOS, teremos que numa primeira etapa, instalar os drivers da Impressora que vêem no CD de Instalação em Windosws\Installer\Setup. Após a instalação da Impressora é criado a uma Pasta em Iniciar\Programas chamada StarMicronics que tem uma opção que é o "Utilitário de Configuração".    Quando abrimos esse utilitário selecionamos a Opção "Modo Star Line (predefinição):        Após escolher esssa opção entramos na "Configuração", selecionamos a opção "OPOS" e clicamos "Adicionar Novo", tanto na impressora como na gaveta.          **OPOS EPSON**    O **PHC** quando integra impressora de talões configuradas para modo de texto e/ou *visor* configurados para OPOS precisa sempre do OPOS da Epson instalado, pelo que, depois de instalar os driver OPOS dos pontos anteriores, deve proceder à instalação do OPOS da EPSON.    A impressora e a gaveta aparecem aqui disponíveis com os respetivos nomes lógicos definidos na Configuração do OPOS da Star.          NOTA IMPORTANTE COMUM A QUALQUER IMPRESSORA DE TALÕES:    Apenas as impressoras que suportem o *codepage* wpc1252 são passiveis de usar, com o **PHC** e em IDUs modo texto, os caracteres com acentuação cedilhados etc. A ativação do referido *code page* pode ser através de mnemónica.    **Gaveta de Dinheiro Venus 03 8C/4B**        A gaveta de dinheiro em causa é de dois conetores, existindo também de 5 conetores. Por regra é ligada através de ficha RJ11 à impressora .  Se optarmos por ligar a gaveta à impressora e se a impressora estiver configurada para ser usada com *driver* OPOS, então temos que na configuração de terminal de vendas no PHC, no separador OPOS, definir o seu nome lógico definido à *priori* no OPOS proprietário da impressora à qual a gaveta está ligada.         Certificação de periféricos de Parceiros Tecnológicos  Versão PHC CS 15 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Certificação Periféricos Pos Softvoicehp' ) |