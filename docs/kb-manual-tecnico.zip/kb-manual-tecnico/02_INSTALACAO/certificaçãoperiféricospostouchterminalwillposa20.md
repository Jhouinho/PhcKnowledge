---
title: Certificaçãoperiféricospostouchterminalwillposa20
source: certificaçãoperiféricospostouchterminalwillposa20.htm
tipo: Manual Técnico
idioma: PT
---

# Certificaçãoperiféricospostouchterminalwillposa20

Certificação Periféricos Pos Touch Terminal Willpos A20

|  |
| --- |
| Certificação Periféricos Pos Touch Terminal Willpos A20 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Introdução**    Este documento visa a auxiliar na configuração de um dos equipamentos distribuídos pelo Parceiro **Toshiba** para a área da venda a retalho, em particular para o nosso *software* **PHC POS CS**.    **Equipamentos**    Os equipamentos sobre os quais vamos tecer considerações de seguida são:    **Touch Terminal WillPOS A20**            Este terminal POS tem as seguintes características indicadas no seu site:          Fonte: [http://www.toshibatec-eu.com/Europe/en/pos-solutions/pos-systems/pos-overview/\_products/willpos\_a20/?info=1](http://www.toshibatec-eu.com/Europe/en/pos-solutions/pos-systems/pos-overview/_products/willpos_a20/?info=1!)      **Instalação**      **Touch Terminal WillPOS A20**    Este Terminal POS que nos foi disponibilizado será uma opção mais avançada pois, apesar das características acima descritas, o terminal WillPOS A20 vinha equipado com maior robustez e capacidade:     Windows Embedded 7 SP1  Intel Core 2 T7400 2.16 Ghz  3 GB Ram  Sistema 32 bits     De realçar que este terminal não vinha equipado com *display* de cliente embutido no próprio terminal, mas existe essa possibilidade.     Não nos foi facultado uma impressora nem uma gaveta de dinheiro, mas a Toshiba possui periféricos desta natureza que poderão ser incorporadas numa solução mais completa para o retalho.    Todas as soluções de periféricos poderão ser consultadas  [aqui](http://www.toshibatec-eu.com/Europe/en/products/pos/overview_pos/).    Certificação de periféricos de Parceiros Tecnológicos    Versão PHC CS 17 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Certificação Periféricos Pos Touch Terminal Willpos A20' ) |