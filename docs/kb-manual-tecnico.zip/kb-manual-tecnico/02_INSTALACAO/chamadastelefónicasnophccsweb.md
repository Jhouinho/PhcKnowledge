---
title: Chamadastelefónicasnophccsweb
source: chamadastelefónicasnophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Chamadastelefónicasnophccsweb

Chamadas Telefónicas no Phc Cs Web

|  |
| --- |
| Chamadas Telefónicas no Phc Cs Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite o controlo das chamadas telefónicas recebidas e está diretamente relacionada com as "Chamadas Telefónicas" de todas as aplicações *PHC CS Desktop*.  Também é possível introduzir novas chamadas para o próprio utilizador ou para outro utilizador, e visualizar todas as chamadas.    Nas "Minhas Opções" do menu principal encontra-se a lista das Chamadas não atendidas, ou seja, as chamadas recebidas para o utilizador que ainda não foram dadas como atendidas, e também o botão "+ Introduzir" para a introdução de uma nota chamada.    **Origem da chamada**  Ao introduzir uma chamada temos o campo "O+  rigem da chamada" onde o utilizador pode escolher a tabela que deseja procurar (Cliente, Fornecedores, Entidade, contacto) a visualização destas tabelas depende do software adquirido:  **Gestão Web**: Clientes, Fornecedores e Entidades  **Suporte Intranet web**: Clientes  **CRM Web**: Contactos    **Nome da Empresa**  O campo "Nome da Empresa" está relacionado com o campo "Origem da chamada", ou seja, quando é escolhido cliente, fornecedor, entidade ou contacto o conteúdo da procura vai estar de acordo com o que está na tabela escolhida, caso tenha escolhido a opção "nenhuma" na origem da chamada o campo é de texto livre.    **Data da chamada/ Hora de chamada**  "Data da chamada" e "Hora de chamada" são campos obrigatórios que são preenchidos automaticamente com a data/hora de introdução do registo, mas que podem ser alterados.    **Data do atendimento**  Este campo deverá ser preenchido com a data em que foi recebida a chamada telefónica. Ao clicar no campo é chamado o calendário, onde através do dia pretendido, é preenchido automaticamente o campo de Data do atendimento.    **Hora do atendimento**  A hora da chamada é um campo obrigatório e deverá conter a hora em que a chamada foi recebida.    **Nome da Pessoa**  O campo "Nome da Pessoa" está relacionado com o campo "Origem da chamada", ou seja, quando é escolhido cliente, fornecedor, entidade ou contacto o conteúdo da procura vai estar de acordo com o que está na tabela escolhida, caso tenha escolhido a opção "nenhuma" na origem da chamada o campo é de texto livre.    **Telefone do Contacto**  Corresponde ao número de telefone da origem da chamada.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Assunto da chamada telefónica**  O assunto deverá corresponder ao motivo pelo qual foi recebida a chamada telefónica.    **Resposta à chamada telefónica**  Caso a chamada tenha sido atendida, deverá colocar aqui a resposta dada pelo utilizador.    **Para quem é a chamada**  Ao introduzir uma chamada telefónica, esta poderá ser para qualquer um dos utilizadores existentes no ficheiro de utilizadores da aplicação PHC CS Desktop. Aqui deverá ser selecionado o utilizador a quem se destina a chamada.  Estas chamadas introduzidas via *internet* serão reconhecidas, na aplicação *PHC CS Desktop*, como contactos externos.    **Duração da resposta**  Duração da chamada telefónica em minutos.    **Atendido**  Esta opção dá a chamada como atendida. Seguidamente deverá ser preenchida a informação relativa ao atendimento, nomeadamente, a data, a hora e a duração da chamada.    Na barra de ferramentas de "Chamadas Telefónicas" existem [variadas opções](opçõesdabarradeferramentas.htm). Algumas destas opções são comuns a todos os ecrãs, nomeadamente, a "Procura", a "Introdução" e a "Eliminação" de registos.    **Dar como atendida**  Ao selecionar esta opção terá acesso à chamada telefónica em consulta, que passará a estar em modo de alteração com a opção "Atendido" ativa, possibilitando a gravação ou cancelamento da operação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Chamadas Telefónicas no Phc Cs Web' ) |