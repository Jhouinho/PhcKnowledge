---
title: Chamar Funções de Utilizador no Cs Web Através do Cs Desktop
source: chamarfunçõesdeutilizadornocswebatravésdocsdesktop.htm
tipo: Manual Técnico
idioma: PT
---

# Chamar Funções de Utilizador no Cs Web Através do Cs Desktop

Devido à sistemática evolução da aplicação PHC CS Web, sentiu-se a necessidade de otimizar os recursos utilizados, estabelecendo mais "uma ponte" entre PHC CS Web e PHC CS Desktop, no que respeita à utilização de funções de utilizador em CS Desktop, que tenham sido criadas em CS Web. Desta forma, prevê-se maximizar as sinergias entre as plataformas, tornando-as ainda mais produtivas, fiáveis, robustas e ágeis, evitando a duplicação de código em Web e/ou Desktop.
Para que a partilha/comunicação de funções de utilizador seja possível entre CS Web e CS Desktop, o utilizador deverá garantir obrigatoriamente a existência dos 3 registos (funções de utilizador e Script) nas respetivas plataformas:
PHC CS Web
;
1.
Função de Utilizador
;
2.
Script de Utilizador
;
PHC CS Desktop
;
3.
Função de Utilizador
;
Após a existência destes registos, qualquer função criada no CS Web, já poderá ser chamada a partir do CS Desktop. No entanto, no final deste artigo técnico, está um
exemplo
representativo desta funcionalidade.
Na aplicação PHC CS Web
1º Passo
-
Função de utilizador "mestre" que permite utilizar outras funções, chamadas posteriormente através do CS Desktop:
- Função de Utilizador
(Executar por "REFLECTION")
Public Function user_ExecutaFuncao(cNomeFunc As String, oParams As Object()) As Object
' Vamos guardar a lista de tipos do parâmetros passados à função, ou seja a assinatura da função, para depois procurar a função com a assinatura correta
Dim lParamsTypes As New List(Of Type)
For Each oParam In oParams
' Tratamos dos casos especiais
Dim typeRecebido As Type = oParam.GetType()
Select Case typeRecebido
Case GetType(Int64)
lParamsTypes.Add(GetType(Integer))
Case GetType(Int32)
lParamsTypes.Add(GetType(Integer))
Case Else
lParamsTypes.Add(oParam.GetType())
End Select
Next
Dim aParamTypes As Array = lParamsTypes.ToArray
' Vamos encontrar a função
Dim PhcDynamicFunctionsType As Type = Type.GetType("PhcDynamicFunctions")
Dim UserFunction As System.Reflection.MethodInfo = PhcDynamicFunctionsType.GetMethod(cNomeFunc, aParamTypes)
' Se não a encontramos dizemos isso mesmo
Dim oRetval As Object
If UserFunction Is Nothing Then
' Vamos criar o texto com a lista de parâmetros
Dim cParams As String = ""
For Each mtype In aParamTypes
If cParams < > "" Then
cParams += ","
End If
cParams += mtype.ToString
Next
oRetval = "A função de utilizador com o nome " + cNomeFunc + " não existe com a assinatura " + cParams
Else
' Executamos e retornamos
oRetval = UserFunction.Invoke(Nothing, oParams)
End If
Return oRetval
End Function
