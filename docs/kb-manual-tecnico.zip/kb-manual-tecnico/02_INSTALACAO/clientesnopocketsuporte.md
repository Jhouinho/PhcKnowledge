---
title: Clientesnopocketsuporte
source: clientesnopocketsuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Clientesnopocketsuporte

Clientes no Pocket Suporte

|  |
| --- |
| Clientes no Pocket Suporte |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite consultar os Clientes das Instalações que passaram para o PDA.        Na parte superior do ecrã existe uma opção de procura. Os campos disponíveis para a procura são:  . Cliente  . Nº  . Est.  . N.Contribuinte    e as condições de procura são:  = (igual),   < (menor),   > (maior),   <= (menor ou igual),   >= (maior ou igual),   começado por,   contém e   <> (diferente)    Na grelha apresentada é possível ver os registos das Intervenções ordenadas pelas colunas. Para tal, basta clicar no nome da coluna pela qual se pretende ver a listagem ordenada.    Ao escolher o cliente poderá consultar os dados disponíveis navegando pelas páginas que constituem o ecrã.  Na página **Dados** encontram-se os campos de identificação do cliente, como se pode observar na imagem.          Na pagina **Observações** pode observar-se o texto do campo Observações da ficha do cliente.          Se pretender ter mais informação, poderá criar campos do utilizador. Estes campos são criados no módulo Supervisor na opção Campos para Dispositivos.  Se ao criar um campo para dispositivo, este já existir por defeito no Pocket, o mesmo não é considerado.     Os botões  e  permitem percorrer, uma a uma, as linhas das listagens apresentadas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Clientes no Pocket Suporte' ) |