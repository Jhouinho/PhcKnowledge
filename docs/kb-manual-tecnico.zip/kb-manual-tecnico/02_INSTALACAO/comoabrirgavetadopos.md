---
title: Comoabrirgavetadopos
source: comoabrirgavetadopos.htm
tipo: Manual Técnico
idioma: PT
---

# Comoabrirgavetadopos

Como Abrir Gaveta do Pos

|  |
| --- |
| Como Abrir Gaveta do Pos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para se abrir a gaveta do POS programáticamente, basta escrever o código:  do oposcdopen.prg    Deve-se assegurar que o OPOS está correctamente instalado de forma a que a gaveta possa ser aberta programáticamente. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Abrir Gaveta do Pos' ) |