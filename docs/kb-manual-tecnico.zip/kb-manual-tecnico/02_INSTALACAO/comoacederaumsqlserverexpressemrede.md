---
title: Comoacederaumsqlserverexpressemrede
source: comoacederaumsqlserverexpressemrede.htm
tipo: Manual Técnico
idioma: PT
---

# Comoacederaumsqlserverexpressemrede

Como Aceder a um Sql Server Express em Rede

|  |
| --- |
| Como Aceder a um Sql Server Express em Rede |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para aceder a um SQL Server em rede é necessário efectuar um conjunto de configurações específicas, que se encontram explicadas abaixo.      **Permitir conecções Remotas ao Servidor**  O SQL Express apenas permite o acesso local, pelo que, os postos (cliente) não conseguem aceder (via ODBC) às bases de dados que estão no servidor.  Como resposta a esta situação leia-se o que vem mencionado na pág. 9 do documento Getting Started 2007.pdf, que se encontra na pasta Startup do CD PHC:    ««Por defeito, a instalação do Microsoft SQL Server Express 2005 apenas permite ligações ao servidor localmente, isto implica que os postos clientes não conseguem aceder ao Servidor.  A solução passa por utilizar uma ferramenta do Microsoft SQL Server Express 2005, a SQL Server Surface Area Configuration, para permitir conexões remotas ao servidor.  A forma de aceder a esta opção é a seguinte:  Programs - Microsoft SQL Server 2005 - Configuration Tools - SQL Server Surface Area Configuration.  Ao entrar nesta opção, seleccione Surface Area Configuration for Services and Connections, irá entrar na instância de SQL instalada nessa máquina.  Escolha a opção Remote Connections, e seleccione Local and remote connections optando por Using both TCP/IP and named pipes.»»      **Activar os Protocolos para o SQL Express**  Outra configuração que deve ainda efectuar passa pela verificação dos protocolos para o SQL Express, colocando-os Enabled e Active.   Para isso, no ecrã do SQL Server Configuration Manager na opção SQL Server 2005 Network Configuration, deve seleccionar: Protocols for SQL Express".   - Com um clique direito deve aceder Properties do protocolo TCP/IP. Na pasta Protocol, no campo Enabled, deve verificar se está Yes;    - De seguida, na pasta IP Addresses, nos campos Enabled e Active dos IPs presentes nesse ecrã, colocar todos eles a Yes;    - Se porventura utilizar o protocolo Named Pipes deve também verificar se este está Enabled.    - É ainda necessário colocar serviço SQL Browser activo. Para tal é necessário seleccionar do lado esquerdo do ecrã a opção "SQL Server 2005 Services". Do lado direito ficará visível, entre outros, o serviço "SQL Server Browser".    - Com um clique direito, deve aceder às Propriedades do SQL Browser, pasta "Log-On" alterar o item "Built In account" para "Local System" e colocar o parâmetro Start Mode em Automatic.     *NOTA*: Não esquecer, que todas as alterações que são descritas aqui só têm efeito quando reiniciar o serviço do SQL Express.      **Preparação da Firewall para que a mesma não barre as comunicações**  Deverá na Firewall do Windows abrir 2 excepções, ou seja, abrir a porta de comunicação para o SQL (1433 TCP e 1434 UDP) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Aceder a um Sql Server Express em Rede' ) |