---
title: Como Acrescentar novos Campos em Grelhas Nativas do Drive Fx
source: comoacrescentarnovoscamposemgrelhasnativasdodrivefx.htm
tipo: Manual Técnico
idioma: PT
---

# Como Acrescentar novos Campos em Grelhas Nativas do Drive Fx

Através da Framework Drive FX é possível criar campos adicionais em grelhas que já vêm de base com a aplicação.
A criação deste tipo de campos obedece a regras que iremos descriminar num exemplo prático, como seja a
inclusão de novos campos na grelha de linhas dos documentos de faturação
.
Para tal devemos efetuar os seguintes passos:
1.
Aceder ao ecrã de
Add-Ons
(localizado no menu Configurações/Framework) e posicionando-se sobre o
Add-On
pretendido, para posteriormente no botão de
Ações
colocá-lo em
Modo de Desenho
.
2.
Aceder ao ecrã de
Personalização de Entidade
em modo de introdução.
3.
Preencher o campo
Entidade
com um nome identificativo para a personalização.
Nota
No preenchimento do campo acima mencionado, é de notar que só o poderá fazer no momento da introdução, dado que após a gravação da personalização, deixa de ser possível alterar o valor deste campo. Ao gravar o registo, a aplicação acrescenta automaticamente ao campo o prefixo
uX_
(onde "
u
" refere-se ao prefixo para identificar que se trata de uma personalização de utilizador, e "
X
" será substituído pelo número que identifica a sua instalação de parceiro).
4.
Segue-se o preenchimento de um texto informativo da personalização no campo da
Descrição
. Por exemplo, com o texto
Tabela adicional ligada ao FI
.
5.
Ativar o campo
Entidade secundária
de forma a determinar que se trata de uma personalização de entidade secundária, que terá ligação a uma tabela principal que vem de base no Drive FX.
6.
No campo
Tipo de Ligação
é estabelecido o tipo de ligação a aplicar à Entidade Secundária.
Dado que pretendemos colocar novos campos numa grelha nativa da aplicação, no caso nas linhas dos documentos de faturação, então selecionaremos o tipo
"Extensão da grelha"
e no campo
Entidade Origem
as
"Linhas Faturação"
.
Nota
No
Tipo de Ligação
por
Extensão de Grelha
, são apresentados no campo da
Entidade Origem
, um conjunto de entidades de grelhas, tais como as
Linhas de Faturação
,
Linhas de Dossiers
,
Linhas de Compras
,
Linhas de Recibos
,
Linhas de Pagamentos a Fornecedores
e
Linhas de Avenças
.
7.
Para finalizar a personalização, é necessário definir a estrutura da tabela na base de dados. Neste exemplo foram criados os campos
Data Validade
e
Observações artigo
com a seguinte estrutura:
Nome
Descrição
Tipo
Comprimento
Decimais
Obrigatório
dataval
Data Validade
Data
0
0
-
obsartigo
Observações artigo
Texto
200
0
-
u<enum>_<nome_addon>_fistamp
(*)
ID
Texto
25
0
-
fistamp
(*)
fi ID
Texto
25
0
-
(*)
Estes campos são criados automaticamente após gravar a personalização de entidade.
Nota
No caso de se tratar de campos de Extensão para Grelhas, a aplicação não suporta a possibilidade de colocar campos como obrigatórios de base.
8.
Gravar o registo e associar ao Add-On a personalização da extensão da grelha, mediante um clique no rodapé da barra de desenho do Add-On, na área dos
Dados
que exibe um número.
9.
Ainda no rodapé, clicar na área à esquerda com o
Nome do Add-on e instalá-lo
.
10.
Uma vez concluída a instalação e feito o Login na aplicação, aceder ao ecrã das
Faturas
e
consultar um registo
.
11.
Irão surgir no canto superior direito de cada um dos componentes do ecrã, um
símbolo de uma varinha
que ao ser clicada, permite aceder às
Propriedades do componente
em questão. Neste exemplo, iremos clicar sobre a
varinha da grelha que lista as linhas do documento
.
12.
Surge a lista de campos nativos da grelha onde é possível criar os novos campos, mediante clique em
Adicione campo
.
Assim irá ser feita a associação de um dos campos criados anteriormente na personalização
(Data Validade)
, para depois adicionar novamente um 2º campo da personalização
(Observações artigo)
.
13.
Procede-se à gravação das alterações aos campos da grelha.
14.
De volta ao ecrã de consulta da Fatura, na área do rodapé da barra de desenho do Add-On, procedemos à instalação das últimas alterações efetuadas.
15.
Ao fazer login na aplicação, fica-se posicionado na consulta da Fatura e estarão
refletidas na grelha das linhas
as
novas colunas adicionadas
que vêm
ativadas por defeito
.
Nota
Caso altere a ordem sequencial pela qual são visualizadas as colunas na grelha, tenha em consideração que essa ordenação poderá não ser aquela que o utilizador final do Add-On irá ver refletida, isto porque, o próprio utilizador poderá ter feito alterações à ordem original das colunas nativas da grelha (antes da aquisição do Add-On).
Nesses casos é necessário que o utilizador final clique no botão
para aceder à lista das colunas da grelha, onde pode ativar/desativar colunas da mesma e alterar a ordem das colunas, bastando clicar com o cursor do rato sobre o símbolo
da coluna a alterar e arrastar verticalmente para a posição pretendida. Estas alterações são automaticamente guardadas em cache na aplicação, pelo que, da próxima vez que o utilizador lançar uma Fatura, a grelha assume a última ordenação feita.
