---
title: Comoatualizarmapasdegestão
source: comoatualizarmapasdegestão.htm
tipo: Manual Técnico
idioma: PT
---

# Comoatualizarmapasdegestão

Como Atualizar Mapas de Gestão

|  |
| --- |
| Como Atualizar Mapas de Gestão |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Se possuir o Módulo Contabilidade, tem a possibilidade de efetuar os Mapas Legais Obrigatórios. Esses mapas são efetuados na opção de Mapas de Gestão.    Pode desenhar mapas de gestão e posteriormente imprimi-los, onde efetuar na aplicação?   - Se possuir o parâmetro **Utiliza o Painel Global de Análises (Tem que reiniciar a aplicação!)** Inativo:   Para desenhar os mapas de gestão deve aceder à opção de Desenhar Mapas de Gestão que se encontra em: Tabelas - Contabilidade - Desenhar Mapas de Gestão.  Para visualizar e imprimir o respetivo mapa, deve aceder à opção de menu Análises - Contabilidade - Mapas de Gestão.   - Se possuir o parâmetro **Utiliza o Painel Global de Análises (Tem que reiniciar a aplicação!)** Ativo:   Com este parâmetro ativo tem a vantagem de aceder à opção de desenho e impressão no mesmo ecrã, para tal deve aceder ao Painel Global de Análises - Análises - Análises do Utilizador - Mapas de Gestão.    Neste ecrã é possível visualizar os mapas efetuados e disponibilizados pela PHC:      Sempre que existe uma alteração fiscal nos Mapas Legais efetuados pela PHC, são efetuadas as devidas alterações e depois disponibilizadas. Para que seja possível atualizar as bases de dados dos clientes.    Existem diversas formas de atualizar Mapas de Gestão, são elas: - Actualização importando **ZIP**   Esta atualização é efetuada, importando um ficheiro ZIP que contém o respetivo mapa. Ao importar é criado um novo mapa, não eliminando nenhum mapa existente na base de dados.    Deve aceder ao ecrã de **Desenho de IDU (Mapas de Gestão)**, se possuir o Painel Global de Análises ativo, deve clicar na opção de **Editar e Criar** para aceder a este ecrã.  Neste ecrã clique na opção , deve escolher a diretoria onde se encontra o ficheiro Zip e importar o mapa.   - Atualização importando o **IDU**   Esta importação é efetuada importando página a página do mapa. Ao importar é criado um novo mapa, não eliminando nenhum mapa existente na base de dados.  Deve aceder ao ecrã de **Desenho de IDU (Mapas de Gestão)**, se possuir o Painel Global de Análises ativo, deve clicar na opção de **Editar e Criar** para aceder a este ecrã.  Neste ecrã clique na opção **Desenhar na impressão**, no menu Sistema deve selecionar a opção **Importar**.   - Atualização importando **DBFs**   Esta atualização é efetuada através da importação das respetivas tabelas dos mapas de gestão. Ao optar por esta forma de atualização vai apagar todos os mapas de gestão que possui na base de dados.  Deve aceder à opção de Instalação e Manutenção que se encontra no Módulo Supervisor e importar as seguintes tabelas:  - CE - Fórmulas dos Mapas de Gestão;   - MG\_GRUPO - Tabela de Grupos de Mapas de Gestão;   - MGE1MDC - Mapas de Gestão, Cabeçalhos;   - MGE1MDL - Mapas de Gestão, Linhas;   - MGE1MDTXT - Mapas de Gestão, Linhas (Modo Texto);   - MGE1MDTU - Tabela de Grupo do IDU de Mapas de Gestão, Cabeçalhos, Mapas desenhados;   - IDUPNM - Nomes das Páginas dos Mapas de Gestão.   - Atualização para **várias bases de dados** ao mesmo tempo   Se possuir um grupo de empresas ou é um gabinete de contabilidade, pode atualizar os mapas de gestão em várias bases de dados ao mesmo tempo.  Para tal, deve possuir o Módulo Interop, no ecrã de Sociedades aceder à opção **Copiar**. Deve selecionar a base de dados onde o mapa já se encontra atualizado e selecionar as bases de dados que pretende criar o mapa.     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre InterOp, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=248389cf1c8.e9%3a%3a.ec55.8cg).      *Nota*: Sempre que existam alterações a efetuar nos mapas, a PHC disponibiliza as várias formas de atualização, para que possa optar por uma delas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Atualizar Mapas de Gestão' ) |