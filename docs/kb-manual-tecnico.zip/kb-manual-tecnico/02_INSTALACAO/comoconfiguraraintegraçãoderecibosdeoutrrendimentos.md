---
title: Comoconfiguraraintegraçãoderecibosdeoutrrendimentos
source: comoconfiguraraintegraçãoderecibosdeoutrrendimentos.htm
tipo: Manual Técnico
idioma: PT
---

# Comoconfiguraraintegraçãoderecibosdeoutrrendimentos

Como Configurar a Integração de Recibos de Outr. Rendimentos

|  |
| --- |
| Como Configurar a Integração de Recibos de Outr. Rendimentos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico tem como objetivo explicar as possibilidades de configuração das contas do Plano de contas de forma a efetuar a integração de recibos de outros rendimentos.    A forma de funcionamento da integração de recibos de outros rendimentos depende da ativação do parâmetro **Lança os recibos de outros rendimentos nos documentos de tesouraria (vs. movimentos de tesouraria) - (re-instalar triggers)**.    Caso ative o parâmetro deverá configurar também os seguintes parâmetros:   * Código de tesouraria por defeito para os Recibos de outros rendimentos. Exemplo: P10005  * Documento de tesouraria por defeito para os Recibos de outros rendimentos. Exemplo: Recibos de Outros Rendimentos     - O parâmetro vai definir também quais as contas a configurar, caso o parâmetro esteja **ativo** as contas a configurar são as seguintes:         *Exemplo:*  Na emissão do recibo do outro profissional nacional existe a seguinte informação:  Importância - 1000  Iva - 190  IRS - 200    No recibo está ativa a opção **lançar na tesouraria**, neste caso é lançado um registo nos documentos de tesouraria com o respetivo valor e a integração é efetuada da seguinte forma:    Aquando a integração do recibo do outro profissional:  Conta para Custos a debitar - 1000  Conta para Custos a creditar - 990  Conta de IVA dedutível - 190  Conta de IRS (que se encontra no ecrã de integração) - 200    Aquando a integração do documento de tesouraria de vencimentos:   Conta para Custos a creditar - 990  Conta do local de tesouraria - 990     - Caso o parâmetro esteja **inativo**, as contas a configurar são as seguintes:         As contas de IVA Liquidado só serão utilizadas na integração de recibos de Outros Profissionais estrangeiros e sempre a debitar.  As contas de IVA Dedutível serão utilizadas na integração de recibos de Outros Profissionais, a debitar para profissionais nacionais e a creditar para profissionais estrangeiros.      *Exemplo:*  Na emissão do recibo do outro profissional existe a seguinte informação:  Importância - 1000  Iva - 190  IRS - 200    A integração do recibo depende da ativação da opção **lançar na tesouraria**. Se estiver ativa é lançado um registo nos movimentos de tesouraria com o respetivo valor e a integração do recibo do outro profissional é efetuado da seguinte forma:  Conta para Custos a debitar - 1000  Conta de Iva dedutível utilizada quando o recibo lança em tesouraria - 190  Conta de IRS (que se encontra no ecrã de integração) - 200  Conta do local de tesouraria - 990    Se a opção **lançar na tesouraria** estiver inativa a integração é efetuada da seguinte forma:  Conta para Custos a debitar - 1000  Conta de Iva dedutível utilizada quando o recibo não lança em tesouraria - 190  Conta de IRS (que se encontra no ecrã de integração) - 200 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Configurar a Integração de Recibos de Outr. Rendimentos' ) |