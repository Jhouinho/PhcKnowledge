---
title: Como Configurar a Loja Web
source: comoconfiguraralojaweb.htm
tipo: Manual Técnico
idioma: PT
---

# Como Configurar a Loja Web

Uma das formas de se configurar uma loja passa por importar templates através da plataforma PHC CS Desktop, no menu "Supervisor" > opção "Templates de Software".
Ao importar e aplicar os templates, permite rapidamente ter uma loja pronta a funcionar.
A importação de templates pode ocorrer quando já existe uma base de dados do cliente ou quando se pretende criar numa base de dados vazia a loja demo. Para isso, existem diferentes tipos de instalação e configuração para a loja.
Para que se enquadre em cada cenário, iremos colocar os passos a ter em conta na instalação da loja quando temos um cliente novo que nunca trabalhou com PHC Desktop/Web, um cliente que já tem PHC CS Desktop e vai instalar agora a Loja Web, ou caso pretenda ter uma base de dados demo para mostrar aos meus clientes e, por fim, um cliente que quer ter a Loja Web criando tudo de raiz, ou seja, não vai usar os nossos templates.
1º Cenário
Cliente novo PHC que nunca teve PHC Desktop/Web
1º Passo:
Instalação do PHC CS Desktop
.
2º Passo:
Instalação do PHC CS Web
.
3º Passo:
Configurar uma loja através de templates. Aqui deve seguir a opção de
Uma base de dados do cliente
e, para finalizar, deve configurar as categorias através do configurador de categorias de artigos.
2ª Cenário
Cliente que já tem PHC CS Desktop e vai instalar agora PHC CS Loja web
1º Passo:
Instalação do PHC CS Web.
2º Passo:
Configurar uma loja através de templates - aqui deve seguir a opção de
Uma base de dados do cliente
e, para finalizar, deve configurar as categorias através do configurador de categorias de artigos.
3º Cenário
Como instalar as BDs Demo (já tem o PHC CS Desktop)
1º Passo:
Instalação do PHC CS Web.
2º Passo:
Configurar uma loja através de templates - aqui deve seguir a opção de
Criar numa base de dados vazia
(DEMO).
4º Cenário
Criar de raiz
1º Passo:
Instalação do PHC CS Desktop.
2º Passo:
Instalação do PHC CS Web.
3º Passo:
Como configurar uma loja de raiz
.
Uma base de dados do cliente
No PHC CS Desktop, através do menu "Supervisor" > opção "Templates de software", deve proceder à importação dos templates. Neste caso, apenas terá de importar o ficheiro
Template_Template_Geral.zip
disponível na pasta do FTP no caminho:
../Pub/Templates/PHC CS Web/Loja/
.
Nota:
Deverá
importar
e
aplicar
cada
template.
As tabelas que são importadas através do ficheiro
Template_Template_Geral.zip
:
Parâmetros
(Para1)
Templates Básicos
(ETPB)
Templates Tabela
(ETPL)
Temas (TLJ)
Após a importação dos templates deve proceder à configuração das categorias de artigos através do
Assistente de Configuração do Tema
ou através do menu Configuração, acedendo a
Configuração de Categorias de Artigos
. Deverá, também, adicionar um novo menu com o link para aceder à Loja, aos menus já existentes do cliente.
Nota:
As imagens dos artigos do cliente devem estar gravadas na base de dados ou em disco desde que nessa pasta o IIS tenha acesso.
Criar numa base de dados vazia (DEMO)
No PHC CS Desktop, através do menu "Supervisor" > opção "Templates de software", deve proceder à importação dos templates, neste caso, terá de importar todos os templates disponíveis na pasta do FTP no caminho:
../Pub/Templates/PHC CS Web/Loja/
.
Nota:
Deverá
importar
e
aplicar
cada
template.
Os templates a importar são:
Template_Banner (EBN)
Template_Links (ELK)
Template_Template_básico
Menus (EME)
Páginas de Internet (EWP)
Template_Template_Geral
Parâmetros
(Para1)
Templates Básicos
(ETPB)
Templates Tabela
(ETPL)
Temas (TLJ)
Caso pretenda utilizar as imagens referentes aos vários temas, pode copiar a respetiva pasta do tema, como por exemplo,
GMT_images
, para dentro da pasta
pimages
do Portal. As pastas encontram-se na diretoria
../Pub/Templates/PHC CS Web/Loja/Imagens/
.
Nota:
É necessário copiar a pasta das imagens visto que estão todas a ser usadas nos temas, como por exemplo, no
header
da página do carrinho, logo da empresa, header da pesquisa, imagens de Banners e links.
Como configurar uma Loja Web de raiz
Para criar uma Loja configurando tudo de raiz sem que exista qualquer tipo de dados, deverá seguir as seguintes indicações.
Caso pretenda criar os temas de raiz e, posteriormente, exportar para template, é extremamente importante que nas tabelas
Templates Básicos
,
Templates de Tabela
,
Links
e
Páginas de Internet
ter no campo título uma designação que deve começar por iniciais seguido de - (traço), como por exemplo GMT-XXXX. Desta forma, posteriormente, poderá exportar para template o tema criado.
Dentro de cada tópico encontra o que é necessário fazer e um exemplo de como pode desenvolver. Nos pontos seguintes, irão ser exemplificados os passos a efetuar desde criar os templates, atualizar os parâmetros, criar
Banners
,
Links
,
Menus
,
Páginas de Internet
,
Regras de finalização
e as
Categorias
.
Todos os exemplos apresentados nos passos seguintes tem por base o Tema "Gourmet".
1º Passo criar Templates Básicos e Templates de Tabela
Para criar os templates é necessário aceder ao menu "Framework PHC" e selecionar Templates Básicos e Templates de Tabela.
Templates básicos
:
Template para o Header
Templates para a homepage
Template do Footer
Templates de categorias e subcategorias
Template para Procura Global
Template para o Carrinho
Template para a Página de Login
Template para a Página de Checkout
Template para As Minhas Encomendas
Template para As Minhas Faturas
Templates Tabela
Template para o detalhe do produto
2º Passo ativar os templates nos Parâmetros
Para ativar os templates é necessário aceder ao menu Framework PHC e selecionar
Parâmetros
.
3º Passo configurar os parâmetros
Para configurar os parâmetros é necessário aceder ao menu Framework PHC e selecionar
Parâmetros
.
4º Passo criar os Banners
Para criar os Banners é necessário aceder ao menu Configuração e selecionar
Banners
.
5º Passo criar Links
Para criar os links é necessário aceder ao menu Configuração e selecionar
Links
.
6º Passo criar Páginas de Internet
Para criar as páginas de internet é necessário aceder ao menu Configuração e selecionar
Páginas de Internet
.
7º Passo criar os Menus
Para criar os menus é necessário aceder ao menu Framework PHC e selecionar
Menus
.
8º Passo criar Categorias
Para criar as categorias é necessário aceder ao menu Configuração e selecionar
Configuração de Categorias de Artigos
.
9º Passo criar as Regras de Finalização
Para criar as regras é necessário aceder ao menu Framework PHC e selecionar
Regras
.
10º Passo criar os Custos Extra
Para criar todos os custos extra relativamente ao envio da encomenda é necessário aceder ao menu Configuração e selecionar
Custos Extra
Loja.
Existem outras configurações necessárias:
Configurar o ficheiro appSettings.config
O ficheiro appSettings.config é o local onde indicamos que módulos o cliente irá trabalhar e algumas configurações genéricas à aplicação.
Para que surjam os dados da Loja Web deve estar ativo o portal e também devem estar incluídas as seguintes chaves com os valores das licenças:
Appsetting.config do Portal
&ltadd key="INS.LOJA" value="S"/>
&ltadd key="INS.LOJA_SERIE" value=""/>
Appsetting.config da Intranet
&ltadd key="INS.LOJAINTRANET" value="S"/>
&ltadd key="INS.LOJAINTRANET_SERIE" value=""/>
&ltadd key="INS.DPORTAL" value="S" />
&ltadd key="INS.DPORTAL_SERIE" value="" />
Após a colocação das novas chaves no ficheiro
Appsettings.config
é necessário efetuar um
iisreset
ao IIS (Internet information Service).
Considerações Importantes
Todos os objetos que sejam referentes a preços, o valor inclui o IVA, só o objeto
#??#BASE#??#
é que refere o preço sem o IVA.
Todos os CSS referentes à loja terão de ser colocados no parâmetro
CSS
para a Loja. O conteúdo deste parâmetro sobrepõe-se sobre todos os outros CSS (user.css).
Caso pretenda fazer as configurações através do
Assistente de configuração
de templates é necessário importar os templates existentes antes de proceder à configuração através do assistente.
No PHC CS Web, Parâmetros, no nó Loja no parâmetro
Artigos disponíveis para a loja web
deve definir quais os artigos que estarão disponíveis para a loja. Estes artigos são considerados quando se geram as categorias através do assistente de configuração de temas e, também, ao procurar, quando se efetuam as pesquisas globais (é importante preencher corretamente este campo, uma vez que quando este campo não está preenchido são considerados todos os artigos existentes na tabela ST).
Após alterações aos templates e parâmetros é necessário
limpar cache total
do Portal para que as alterações sejam aplicadas.
Existem vários temas disponíveis podendo encontram-se no FTP no caminho: ../Pub/Templates/PHC CS Web/Loja/, no ficheiro Template_Template_Geral.zip.
A importação de templates pode ocorrer quando já existe uma base de dados do cliente ou quando se pretende criar uma loja demo numa base de dados vazia.
Configurações da Loja web
