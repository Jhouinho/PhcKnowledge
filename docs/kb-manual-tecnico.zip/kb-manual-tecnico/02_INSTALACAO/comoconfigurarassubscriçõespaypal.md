---
title: Comoconfigurarassubscriçõespaypal
source: comoconfigurarassubscriçõespaypal.htm
tipo: Manual Técnico
idioma: PT
---

# Comoconfigurarassubscriçõespaypal

Como Configurar As Subscrições Paypal

|  |
| --- |
| Como Configurar As Subscrições Paypal |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para que se efetue o pagamento de uma fatura, ao abrigo do protocolo com a Paypal, está disponível em todas as gamas uma opção que permite efetuar o pagamento de faturas por subcrição.    Para ativar esta opção é necessário ativar algumas funcionalidades. Desta forma, deve proceder às seguintes configurações:    **1º Passo**    Nos parâmetros gerais, no nó PHC CS Web existem 7 opções. Ao serem preenchidas vai permitir usufruir da ligação para a configurar os pagamentos por subcrição. As opções são:    - Paypal - Acordo de subscrição  - Paypal - Assinatura digital do comerciante  - Paypal - Código que identifica univocamente o comerciante  - Paypal - Palavra chave do comerciante<  - Paypal - Paypal em Funcionamento sandbox  - Paypal - URL para a imagem de logotipo da empresa no Paypal    **2ª Passo**  Na configuração dos documentos de faturação, onde se pretende usar para as subscrições, deve-se ativar a opção **"Web: Permite pagamento via PAYPAL".**  Assim, no documento de faturação configurado passa a estar disponíveis os seguintes campos: Pago Via Paypal, Permite Subscrição via Paypal, Períodos de subscrições e Periodicidade de subscrições.      **3º Passo**  No ecrã de instalações foi adicionados campos referentes ao PAYPAL onde o utilizador decide se essa inscrição permite subscrições via PayPal e quais os períodos a sua periodicidade, bem como o acordo de subscrição que por defeito é idêntico ao parâmetro geral "PAYPAL - Acordo de subscrição.  Essas instalações poderão dar origem a documentos de faturação.   No ecrã de documentos de faturação, os documentos de faturação que tenham sido criados a partir de uma instalação passam a ter no separador de "Dados de Tesouraria" dados informativos de PAYPAL.   Ao lançar um documento de faturação para um cliente, ao gravar o documento passa a estar disponível no extranet, para o cliente validar e aceitar, as condições da subscrição do serviço.    **4º Passo**  No ecrã de Subscrição de Paypal, nas opções diversa, ao clicar na opção de *atualizar todas as subscrições*, vão surgir as subcrições que foram validadas e dadas como pagas, por parte da paypal.        Neste ecrã é visível a informação referente às configurações do documento. Esta informação é configurada no ecrã de instalações e é preenchida automaticamente.           Ao clicar nesta opção irá atualizar todas as subscrições dadas como pagas pela paypal.      Ao clicar nesta opção é possível cancelar a subcrição da paypal.      Ao clicar neste botão permite navegar para o registo da instalação e verificar os dados referentes à subcrição Paypal.    **5º Passo**  No ecrã de "Emissão automática de faturação" foi adicionado um novo campo de seleção "na preparação se o documento tem subscrição ativa, só mostra os pagos" e caso esta opção esteja ativa, ao escolhermos as instalações para dar origem a documentos de faturação, os documentos de faturação que seriam passíveis de serem emitidos serão alvo de verificação no Paypal de pagamento já efetuado. Caso não esteja ativa a opção, a verificação apenas será realizada aquando a emissão real de faturação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Configurar As Subscrições Paypal' ) |