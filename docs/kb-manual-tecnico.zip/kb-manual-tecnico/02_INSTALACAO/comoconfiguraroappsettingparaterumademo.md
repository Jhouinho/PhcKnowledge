---
title: Comoconfiguraroappsettingparaterumademo
source: comoconfiguraroappsettingparaterumademo.htm
tipo: Manual Técnico
idioma: PT
---

# Comoconfiguraroappsettingparaterumademo

Como Configurar o Appsetting para Ter uma Demo

|  |
| --- |
| Como Configurar o Appsetting para Ter uma Demo |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Quais as configurações necessárias para ter um site para demonstrações dos produtos PHC CS Web?**   Após ter efetuado a instalação da aplicação, deve aceder ao ficheiro *appsettings.config* para proceder às seguintes configurações, sendo que, para ter a aplicação em demonstração têm que existir obrigatoriamente as seguintes chaves:   **<add key="ENUMEROSERIE" value="NºSerie" />** **< add key="INS.DEMO" value="S" />** **<add key="INS.DEMO\_SERIE" value="" />**   ***Nº Serie***- Corresponde ao número de série dos módulos de uma aplicação Demo. O preenchimento deste campo é obrigatório apenas quando o utilizador pretende usufruir de uma aplicação Demo. Para obter informação sobre qual o número de série pode aceder através da comunidade > parceiros> [consulta de instalações]( http://comunidade.phc.pt/parceiros/programs/gensel.aspx?eusql=399 ).   Nas restantes keys dos produtos não necessitam a inserção dos números de série, apenas deve colocar as keys com o **value="S",** nos módulos que pretende ususfruir.   Após estas configurações, no ecrã de autenticação da Intranet e Extranet aparece a frase "Versão de Demonstração.   Após a autenticação, na aplicação, o logotipo definido pelo utilizador é ignorado e passa a apresentar o logotipo da MaisRitmo com a frase "Versão de Demonstração".  Nos diferentes ecrãs surge junto do título o texto "Versão de Demonstração", exceto nos ecrãs que são "../gensel.aspx"   Relativamente à impressão de documentos através de IDUs (ter no appsettings.config a key < add key="USAIDU" value="S" / > ) o IDUServer passa a verificar se na base de dados está a informação que se entrou com o PHC CS Desktop em versão demonstração, nesse caso, imprime o documento com a mensagem "Software em versão demonstração".   Continua no entanto a fazer a validação anterior, ou seja, verifica se existe o ficheiro "Demo.win" na diretoria do PHC CS Desktop, se existir imprime também com a indicação que é uma versão demostração, mesmo que na base de dados não esteja a informação de que é uma versão demonstração.   Gama e versão de software PHC em que foi testado: PHC CS 21 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Configurar o Appsetting para Ter uma Demo' ) |