---
title: Comoconfigurarpróximasaçõesdeutilizador
source: comoconfigurarpróximasaçõesdeutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Comoconfigurarpróximasaçõesdeutilizador

Como Configurar Próximas Ações de Utilizador

|  |
| --- |
| Como Configurar Próximas Ações de Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Através da Framework Drive FX é possível configurar em ecrãs da aplicação, ações incluídas no próprio botão de **Ações** que poderão ser refletidas mediante determinadas condições. Também permite configurar ações para que as mesmas possam ser incluídas como uma **próxima ação** após gravação de um registo de um ecrã.    Para melhor entendimento, passemos então a mostrar um exemplo prático de **configuração no ecrã de Clientes de uma ação ao gravar um cliente**, que permite criar uma **Marcação** na **Agenda**. Esta ação irá ser disponibilizada quer através do botão de **Ações**, quer na lista de sugestões de **Próximas Ações**.    **Para tal, teríamos de efetuar os seguintes passos:**    **1.** Ír ao ecrã de **Add-Ons** (localizado no menu Configurações/Framework), posicionando-nos sobre o Add-On no qual pretendemos efetuar estas configurações. De seguida clicar no botão de **Ações** e colocá-lo em **Modo de Desenho**.    **2.** Acedemos ao ecrã de **Clientes** e entramos em modo de consulta sobre um registo qualquer.    **3.** Na parte superior direita do ecrã, encontra-se o botão **Ações** e à direita deste encontra-se um outro botão com o mesmo nome com as bordas a tracejado verde que iremos clicar.    **4.** De seguida iremos adicionar uma **Nova ação**.    **5.** É aberta a janela de configuração da ação, onde iremos preencher o campo **Nome** com a designação que a ação irá ter, no caso seria **Criar Marcação**.  Também iremos ativar o campo **Próxima ação** de forma a que esta surja exibida na lista de próximas ações.    **6.** No **Código a executar** iremos incluir o seguinte código:  ``` sdk.createRecord('calendarevent'); ```  Este código configura a ação para abrir em modo de introdução o ecrã das Marcações que se encontra associado à entidade *calendarevent*.    **7.** Para ultimar esta configuração, no campo **Validação** iremos determinar que essa ação só estará visível para clientes ativos, assim o código seria:  ``` return !sdk.readRecord().inactivo; ```    Nota   *Caso aplique este exemplo num Add-On, tenha em consideração que deverá incluir na validação se o produto da **Agenda** está licenciado, se tem acesso total à área da Agenda nos Perfis de Acesso e às respetivas entidades, de forma a que ação de **Criar Marcação** seja exibida caso essas condições se verifiquem.*       **8.** Gravamos a configuração da ação.    **9.** Gravamos a ação que inserimos.    **10.** Clicamos no botão com o nome do Add-on localizado na barra de desenho de Add-Ons, selecionando **Instalar o Add-On**.    **11.** Uma vez instalado o Add-On, somos encaminhados diretamente em modo de consulta para o registo do Cliente em consulta, no entanto, para vermos o efeito da nova ação configurada iremos proceder à introdução de um novo cliente preenchendo apenas os campos obrigatórios e gravar.    Sendo a gravação do cliente bem sucedida, a ação que configurámos surge desde logo refletida no painel de **Próximas Ações** e no botão de **Ações** ao clicar sobre este.  Tal como configurado no código, esta ação ao ser acedida irá abrir em modo de introdução o ecrã de **Marcações** e só estará visível quando estiver a consultar um registo de cliente e só quando o cliente estiver ativo (caso contrário não será exibida). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Configurar Próximas Ações de Utilizador' ) |