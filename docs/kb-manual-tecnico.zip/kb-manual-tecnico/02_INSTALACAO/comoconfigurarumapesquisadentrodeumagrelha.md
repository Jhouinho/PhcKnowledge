---
title: Como Configurar uma Pesquisa Dentro de uma Grelha
source: comoconfigurarumapesquisadentrodeumagrelha.htm
tipo: Manual Técnico
idioma: PT
---

# Como Configurar uma Pesquisa Dentro de uma Grelha

## Descrição

ref
Campo para valor: ststamp
Campo para desnormalização do valor: ref (uxxxxx_artfor)
Designação
design (uxxxx_artfor)
ENTITYDATAFIELD.UXXXXX_ARTFOR.DESIGN
Input box
Sim
Tipo: Texto
Preço Venda
epv1 (uxxxxx_artfor)
ENTITYDATAFIELD.UXXXXX_ARTFOR.EPV1
Input box
Sim
Tipo: Dinheiro
12.
De seguida clicar no botão
Configure pesquisa da grelha
e na janela pop-up que surge, escrever o código para o objecto
QueryVO
que vai corresponder ao conjunto de registos que poderão ser consultados na grelha para efeitos da pesquisa e onde serão incluídos apenas os registos ativos da entidade em causa.
No exemplo seria:
query.entityName=TABLES.ST;
var filterItem = new FilterItem();
filterItem.filterItem = FIELDS.ST_INACTIVO
filterItem.valueItem = "0";
if (textFilter)
filterItem.groupItem = FilterGroupItemEnum.AND;
query.filterItems.push(filterItem);
if (textFilter)
{
var openFilter = new FilterItem();
openFilter.groupItem = FilterGroupItemEnum.OPENBKT;
query.filterItems.push(openFilter);
var refFilter = new FilterItem();
refFilter.filterItem = FIELDS.ST_REF
refFilter.comparison = ComparisonEnum.CONTAIN;
refFilter.valueItem = textFilter;
refFilter.groupItem = FilterGroupItemEnum.OR;
query.filterItems.push(refFilter);
var designFilter = new FilterItem();
designFilter.filterItem = FIELDS.ST_DESIGN;
designFilter.comparison = ComparisonEnum.CONTAIN;
designFilter.valueItem = textFilter;
designFilter.groupItem = FilterGroupItemEnum.CLOSEBKT;
query.filterItems.push(designFilter);
}
query.orderByItems =
[
{
OrderItem: FIELDS.ST_REF,
OrderType: OrderTypesEnum.ASCENDING
}
];
13.
Ainda nesta janela, indicar quais os campos que deverão ser mostrados como colunas da tabela de pesquisa e indicar quais os campos que fazem a ligação entre o QueryVO e a tabela de utilizador associada à grelha.
No exemplo, associamos os campos:
Campo
Título
Tipo
ref
Referência
Texto
design
Designação
Texto
epv1
Preço de Venda
Moeda
Na secção
Ligação
preencher o
Campo da pesquisa para ligação com a grelha
com o valor
ref
e selecionar no
Campo da entidade para ligação com a pesquisa
o valor
ref (uxxxxx_artfor)
.
14.
Clicar em
Grave
para guardar as configurações da pesquisa da grelha e fechar o pop-up.
15.
Clicar novamente em
Grave
para guardar as configurações da grelha e voltar ao ecrã da secção.
16.
Clicar outra vez em
Grave
para guardar as alterações feitas à secção.
17.
Por último, falta-nos proceder à criação de
Código de Entidade
, de forma a que quando se alterar o valor do campo da Referência (ref) este irá atualizar os valores dos campos Designação (design) e Preço Venda (epv1).
Assim, devemos aceder ao ecrã de
Código de Entidade
em modo de introdução e preencher os seguintes dados:
Entidade:
Fornecedores
Título:
Ao sincronizar Artigos do Fornecedor
Tipo Código:
Ao Sincronizar
No
Código
colocar as seguintes instruções:
select case changedItems
.
first
.
baseType
' Se a alteração for feita nos campos para a entidade dos Artigos do Fornecedor
case getType(U4902_artforVO)
dim item
as
U4902_artforVO
=
Nothing
if
changedItems
.
getChangedItemByField(item,
"ref"
) isnot nothing then
Dim filterItems
as
FilterItems
=
New FilterItems()
filterItems
.
Add(New FilterItem(
"ref"
, Comparison
.
Equal,
"'"
+
item
.
ref
+
"'"
))
Dim itemSt As StVO
=
SDK
.
Query
.
getEntityData(of StVO)(filterItems)
.
FirstOrDefault
If itemSt isnot nothing Then
item
.
design
=
itemSt
.
design
item
.
epv1
=
itemSt
.
epv1
end
if
End
if
end select
18.
Gravar o registo e de seguida associar ao Add-On a regra de entidade, mediante um clique no rodapé da barra de desenho do Add-On, na área dos
Dados
que exibe um número.
19.
Clicar no botão com o nome do Add-on localizado na barra de desenho de Add-Ons e
Instalar o Add-On
para que a grelha que foi adicionada passe a fazer parte do ecrã de Fornecedores do Drive FX.
20.
Uma vez instalado o add-on, somos encaminhados diretamente para o ecrã de Fornecedores e vamos criar um novo registo. A grelha adicionada que surge com a designação
Artigos do Fornecedor
já se encontra disponível para utilização, permitindo através desta associar ao fornecedor o(s) artigo(s) comercializados pelo mesmo e ver/atualizar os respetivos preços.
Poderá associar artigos mediante a introdução manual de linhas, ou recorrer ao botão de
Pesquise
para através da lista de artigos selecionar o(s) artigo(s) a passar para a grelha.
