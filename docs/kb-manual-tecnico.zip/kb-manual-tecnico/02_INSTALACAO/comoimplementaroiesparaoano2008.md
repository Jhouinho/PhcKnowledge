---
title: Comoimplementaroiesparaoano2008
source: comoimplementaroiesparaoano2008.htm
tipo: Manual Técnico
idioma: PT
---

# Comoimplementaroiesparaoano2008

Como Implementar o Ies para o Ano 2008

|  |
| --- |
| Como Implementar o Ies para o Ano 2008 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O IES é um mapa de gestão disponível nas gamas Corporate, Advanced e Enterprise. Este mapa está disponivel na versão 2008 e 2009.    Para **implementar o IES** no Software PHC, existem 2 formas de o fazer, uma para clientes que ainda não tenham o módulo de contabilidade e só agora começam a trabalhar com este módulo, outra para clientes que já se encontram a trabalhar.     **Clientes já a trabalhar com o módulo de Contabilidade:**  1º Passo - Importar o suporte papel:  No ecrã de desenho dos mapas de gestão importar os mapas utilizando o ficheiro ZIP.  ftp://ftp.phc.pt/Pub/MapasdeGestao/IES\_DEC\_ANUAL\_2008\_V2008\_V2009/Mapas\_Gestão\_IES    2º Passo - Importar o Suporte Informático:  Este passo pode ser efectuado de duas formas: Importando individualmente os layouts do suporte informático ou então através da instalação e manutenção importar os dbfs das tabelas MGDISK e MGDIKL.  Atenção: Ao importar dbfs irá perder toda a informação que se encontra nas respectivas tabelas.    3º Passo - Códigos de IVA  O Anexo L do IES, é um mapa de gestão especifico, pois possui fórmulas de IVA associadas aos códigos de iva. Este ano, este mapa sofreu algumas alterações, tendo sido necessário criar novos campos.   No caso de clientes que já se encontram a trabalhar e utilizam a tabela de códigos de iva, este passo é um passo manual e que deve ser efectuado pelo contabilista da empresa, pois passa pela criação/alteração dos códigos de iva que já são utilizados por outras rotinas e associar estes códigos às contas do POC.     No caso de clientes que apesar de já estarem a trabalhar com o módulo contabilidade não usam códigos de iva, poderá optar pela importação da tabela IV e neste caso será necessário associar os códigos ao seu plano de contas, isto porque a estrutura da tabela de códigos de IVA foi totalmente reformulada.    Para apoiar esta tarefa disponibilizamos uma tabela com as contas que devem estar associadas e respectivos códigos de IVA que devem constar nas mesmas. Ver documento chamado 'Plano de Contas codigos de iva e cis.xls' disponível no ftp na pasta, Mapas de Gestao/Plano\_Contas/V2009.          **Clientes que só agora iniciam o módulo de contabilidade, ou seja, não possuem Documentos Contabilisticos:**  Importação das tabelas de configuração, pela opção de Instalação e Manutenção devem ser importadas as seguintes tabelas:  PC - Plano de Contas (Esta tabela encontra-se no FTP na pasta: Mapas de Gestao/Plano\_Contas/V2009).  CE - Fórmulas dos Mapas de Gestão  IV - Códigos de Iva   IVPAMDC - Declaração Anual de IVA, Cabeçalhos   IVPAMDL - Declaração Anual de IVA, Linhas   IVPAMDTU - Tabela de Grupo do IDU de Declaração Anual de IVA, Cabeçalhos, Mapas desenhados   IVPAMDTXT - Declaração Anual de IVA, Linhas (Modo Texto)   MG\_GRUPO - Tabela de Grupos de Mapas de Gestão   MGDISK - Mapas Gestão em Suporte Informático, Cabeçalhos   MGDISKL - Mapas Gestão em Suporte Informático, Linhas   MGE1MDC - Mapas de Gestão, Cabeçalhos   MEG1MDL - Mapas de Gestão, Linhas   MGE1MDTXT - Mapas de Gestão, Linhas (Modo Texto)   MGE1MDTU - Tabela de Grupo do IDU de Mapas de Gestão, Cabeçalhos, Mapas desenhados   IDUPNM - Nomes das Páginas dos Mapas de Gestão     IMPORTANTE: Ao importar estas tabelas irá perder a informação que já se encontra nestas tabelas da base de dados.        Nota: Visto que esta obrigação legal é demasido extensa existe um documento de instruções que explica a importação e actualizações efectuadas, anexo a anexo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Implementar o Ies para o Ano 2008' ) |