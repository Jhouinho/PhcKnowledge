---
title: Comoimplementaroimpostodeselo
source: comoimplementaroimpostodeselo.htm
tipo: Manual Técnico
idioma: PT
---

# Comoimplementaroimpostodeselo

Como Implementar o Imposto de Selo

|  |
| --- |
| Como Implementar o Imposto de Selo |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Existem empresas e utilizadores que optam por não tratar o Imposto de Selo na sua contabilidade visto que a Tabela Geral do Imposto de Selo é lista demasiado extensa e difícil de atualizar que inclui muitas rubricas de que não necessitam.    O PHC CS Contabilidade desktop facilita todo esse trabalho, pois a Tabela de Códigos de Imposto de Selo (acessível a partir do menu Tabelas » opção Contabilidade) é incluída de base e está disponível em todas as gamas da aplicação, sendo a sua atualização uma tarefa que se executa rapidamente.      **Como atualizar a Tabela de Códigos de Imposto de Selo**      1. **Atualizar os Códigos de Imposto de Selo**      * Atualização manual: O utilizador pode criar manualmente os códigos pretendidos de acordo com a versão mais recente da Tabela Geral de Imposto de Selo em vigor.    * Importação de códigos: É disponibilizada aos parceiros, via FTP, a versão mais recente da Tabela integral de todos os códigos da T.G.I.S.              Esta Tabela encontra-se em formato .ZIP, no FTP, na diretoria:              *..Pub/TabelasEspecificas/PHC CS Contabilidade desktop/Imposto\_Selo)*              Após descomprimir os ficheiros, deve ser usada a opção de Instalação e Manutenção para importar as novas tabelas              *Importante:* Ao importar estes ficheiros irá perder a informação que já se encontra nas mesmas tabelas (versão anterior) da base de dados; este procedimento só deve ser efetuado se utilizar o Plano de Contas PHC ou se se tratar da primeira vez que configura a Tabela de Imposto de Selo. 2. **Associação dos Códigos de Imposto de Selo às contas SNC**          Após ter os códigos atualizados, torna-se necessário apenas associar as contas SNC correspondentes a cada rubrica. Se estiver a executar esta rotina pela primeira vez, deverá aceder a todos os registos da Tabela e efetuar a associação de cada registo, individualmente, às contas do seu plano personalizado.     Esta associação é necessária para que a aplicação possa não só calcular os valores para os documentos contabilísticos mas também recolhê-los para a Guia mensal de Retenções na Fonte de IRS/IRC e I. Selo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Implementar o Imposto de Selo' ) |