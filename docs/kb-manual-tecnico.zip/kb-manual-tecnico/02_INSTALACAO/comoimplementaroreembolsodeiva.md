---
title: Comoimplementaroreembolsodeiva
source: comoimplementaroreembolsodeiva.htm
tipo: Manual Técnico
idioma: PT
---

# Comoimplementaroreembolsodeiva

Como Implementar o Reembolso de Iva

|  |
| --- |
| Como Implementar o Reembolso de Iva |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para configurar o software PHC para esta funcionalidade é necessário ativar o seguinte parâmetro **Utiliza anexos para a declaração periódica para reembolso de IVA**.  Após a ativação deste parâmetro, no ecrã de Apuramento de IVA (Menu Contabilidade) surge um novo botão **Reembolso de IVA**.    Para utilizar esta funcionalidade é necessário algumas configurações, são elas:  - Opcional: Criação/importação dos IDUs dos respetivos anexos da declaração;  - Preenchimento da Tabela de Códigos de IVA;  - Configuração de códigos no ecrã de reembolso;  - Associação das contas do Plano do Contas aos respetivos códigos de IVA.      Para **implementar o reembolso de IVA** no Software PHC, devem ser seguidos os seguintes passos:    1. Na opção de instalação e manutenção devem ser selecionadas as seguintes tabelas (de forma a importar os IDUs dos anexos):  Relação de Clientes:  RELCLIVAIDUC - Declaração Periódica de IVA - Relação de Clientes - Cabeçalhos;  RELCLIVAIDUL - Declaração Periódica de IVA - Relação de Clientes - Linhas;  RELCLIVAIDUTU - Tabela de Grupo do IDU de Declaração Periódica de IVA - Relação de Clientes - Cabeçalhos;    Relação de Fornecedores:  RELFLIVAIDUC Declaração Periódica de IVA - Relação de Fornecedores - Cabeçalhos;  RELFLIVAIDUL Declaração Periódica de IVA - Relação de Fornecedores - Linhas;  RELFLIVAIDUTU Tabela de Grupo do IDU de Declaração Periódica de IVA - Relação de Fornecedores - Cabeçalho;    Relação de Regularizações:  RELREGIVAIDUC - Declaração Periódica de IVA - Relação de Regularizações - Cabeçalhos;  RELREGIVAIDUL - Declaração Periódica de IVA - Relação de Regularizações - Linhas;  RELREGIVAIDUTU - Tabela de Grupo do IDU de Declaração Periódica de IVA - Relação de Regularizações - Cabeçalhos.          2. O segundo passo é a criação / importação dos códigos de IVA e a sua associação às contas do Plano de Contas.  Neste passo existem 2 formas de o fazer, uma para clientes que ainda não tenham o módulo de contabilidade e só agora começam a trabalhar com este módulo, outra para clientes que já se encontram a trabalhar.     **Clientes já a trabalhar com o módulo de Contabilidade:**  No caso de clientes que já se encontram a trabalhar este passo é um passo manual e que deve ser efetuado pelo contabilista da empresa, pois passa pela criação/alteração dos códigos de IVA que já são utilizados por outras rotinas, tais como a Declaração periódica de IVA e a associação destes códigos às contas do SNC. Neste caso, o ecrã de reembolso de IVA (ponto 3) deve ser configurado de acordo com os códigos existentes na base de dados.     No caso de clientes que não usam códigos de IVA, poderá optar pela importação da tabela IV e neste caso apenas será necessário associar os códigos ao seu plano de contas.     Para apoiar esta tarefa disponibilizamos uma tabela com as contas que devem estar associadas e respetivos códigos de IVA que devem constar nas mesmas. Ver documento chamado 'Plano de Contas códigos de IVA e cis.xls' disponível no FTP na pasta, Mapas de Gestao/Plano\_Contas/V2009.      **Clientes que só agora iniciam o módulo de contabilidade:**  Pela opção de Instalação e Manutenção devem ser importadas as seguintes tabelas:  IV - Tabela de Códigos de IVA (Esta tabela encontra-se no FTP na pasta: Mapas de Gestao/Tabelas em DBF/V2009);  PC - Plano de Contas (Esta tabela encontra-se no FTP na pasta: Mapas de Gestao/Plano\_Contas/V2009).    IMPORTANTE: Ao importar estas tabelas irá perder a informação que já se encontra nestas tabelas da base de dados.      3. O passo seguinte é a configuração do ecrã de reembolso de IVA com os respetivos códigos de IVA:    . Para a Relação de Clientes as configurações devem ser as seguintes:           . Para a Relação de Fornecedores as configurações devem ser as seguintes:       Nota: No que diz respeito ao valor das aquisições, esta coluna é repartida em duas, a coluna débito e a coluna crédito. No mapas será apresentado o saldo das duas (débito - crédito).    . Para a Relação de Regularizações as configurações devem ser as seguintes:     \*O campo "Sujeitos passivos nacionais" deve conter o seguinte:  63, 64, 65, 82, 83, 84, 101, 102, 103        Após estes 3 passos o software encontra-se configurado para a funcionalidade do Reembolso de IVA, para mais informações sobre este assunto consulte o manual da aplicação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Implementar o Reembolso de Iva' ) |