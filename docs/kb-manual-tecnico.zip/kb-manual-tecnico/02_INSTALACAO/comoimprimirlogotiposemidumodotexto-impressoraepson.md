---
title: Comoimprimirlogotiposemidumodotexto Impressoraepson
source: comoimprimirlogotiposemidumodotexto-impressoraepson.htm
tipo: Manual Técnico
idioma: PT
---

# Comoimprimirlogotiposemidumodotexto Impressoraepson

Como Imprimir Logotipos em Idu Modo Texto - Impressora Epson

|  |
| --- |
| Como Imprimir Logotipos em Idu Modo Texto - Impressora Epson |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico, tem como objectivo ajudar a configurar impressoras Epson com memória NVRAM, para posteriormente imprimir Logotipos nos IDU's em modo texto.    Foi testado com uma impressora Epson TM-T88IV.        Com 5 simples passos vamos fazer a configuração.      **1º Instalar na máquina os aplicativos da Epson**    EPSOM OPS ADK e TM Flash Logo Setup    Ambos estão disponíveis no site da Epson:  <https://download.epson-biz.com/modules/pos/index.php?page=soft&pcat=3&scat=38>  <https://download.epson-biz.com/modules/pos/index.php?page=soft&scat=44>    Respectivamente.      **2º Indicar no OPOS que a impressora tem memoria NVRAM**        - No aplicativo EPSOM OPS ADK depois de criado o device da impressora, aceder à opção "Device Specific Settings";  - Ir ao separador **Bitmap**;  - Colocar um visto em NVRAM e fazer "Apply";  - Clicar no botão "TMFlogo" e abre-se de forma automática o aplicativo "TM Flash Logo Setup".      **3º Escolher a imagem e fazer upload da imagem para a impressora**        É neste aplicativo "TM Flash Logo Setup"que indicamos qual a imagem que queremos carregar para a memória da impressora:  - No separador **Bitmap Selection** escolhemos a imagem;  - No separador **Preview** é possível visualizar o resultado e fazer ajustes á imagem;  - No separador **Logo Upload** carregar a imagem para a memória da impressora clicando no botão "Device";  - No separador **Logo Printout** fazer testes de impressão.    Se os testes resultarem no pretendido está tudo configurado a nível dos programas da EPSON, está na altura de passar para o PHC.      **4º Criar Mnemónica**         No PHC vamos criar uma Mnemónica para se poder chamar e imprimir uma imagem residente na memória da impressora, nos IDU's em modo texto.    O Código de configuração deverá ser:     28.112.**n**.**m**    **n** - pode variar de 1 a 255 e indica das várias imagens que se pode ter na memória da impressora, qual a que pretendemos imprimir.    **m** - pode variar de 0 a 3.    0 = Tamanho real  1= 2 x largura  2= 2 x altura  3= 2 x largura e 2 x altura      **5º Colocar Mnemónica no IDU em modo texto**    E para terminar, basta no IDU em modo texto, colocar no início a Mnemónica para que seja impresso o logótipo escolhido. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Imprimir Logotipos em Idu Modo Texto - Impressora Epson' ) |