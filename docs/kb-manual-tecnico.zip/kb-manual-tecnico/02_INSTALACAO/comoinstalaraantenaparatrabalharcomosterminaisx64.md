---
title: Comoinstalaraantenaparatrabalharcomosterminaisx64
source: comoinstalaraantenaparatrabalharcomosterminaisx64.htm
tipo: Manual Técnico
idioma: PT
---

# Comoinstalaraantenaparatrabalharcomosterminaisx64

Como Instalar a Antena para Trabalhar com os Terminais X64

|  |
| --- |
| Como Instalar a Antena para Trabalhar com os Terminais X64 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico tem como objectivo exemplificar como se instala a antena para que se possa efectuar a ligação com os terminais de restauração X64.     A ligação da antena ao computador é feita por cabo série e de preferência a uma distância entre 3 a 50 metros, sendo que, a distâncias inferiores podem provocar interferência e prejudicar o seu desempenho.  Para trabalhar com a antena deverá instalar o software DEVKIT, sendo necessário proceder às seguintes configurações:    1- Clicar em Edit, Configuration, Base e na opção "Retr Name" colocamos o nome que pretendemos dar a antena.   O nome deve ser XXX00, onde o XXX pode ser qualquer coisa (exemplo: BAS00). Esse nome servirá para efectuar a configuração nos terminais restauração X64.        2- Na opção ComPort, colocar a porta série a qual a antena se vai encontrar ligada. A opção Serial BaudRate, por defeito é 19200.   No painel de control, device manager, propriedades da COM, no separador "Port Setting" a opção "Bits per Second" o valor deve ser igual.   NOTA: Caso o computador não tenha porta série, será necessário adquirir um adaptador (Usb to COM - Prolifiic Driver Installer).    3- Após terminar, clicar em " Write Configuration to base " para a antena reinicializar. A antena deverá emitir 3 sinais sonoros.    Gama de software PHC em que foi testado: Advanced 2011. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Instalar a Antena para Trabalhar com os Terminais X64' ) |