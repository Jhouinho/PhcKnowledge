---
title: Comoinstalarasnovasdllsnaversão2013Xfrxepdfcreact
source: comoinstalarasnovasdllsnaversão2013xfrxepdfcreact.htm
tipo: Manual Técnico
idioma: PT
---

# Comoinstalarasnovasdllsnaversão2013Xfrxepdfcreact

Como Instalar As novas Dlls na Versão 2013: Xfrx e Pdfcreact

|  |
| --- |
| Como Instalar As novas Dlls na Versão 2013: Xfrx e Pdfcreact |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Foram detectados alguns problemas que ao longo dos tempos têm vindo a ser associados a deficiências do componente XFRX utilizado nas aplicações PHC. Este componente é responsável por transformar impressões em documentos PDF.     **As novas dlls são:**  zlib.dll (27.07.2012), hndlib.dll (27.07.2012), xfrxlib.fll (27.07.2012), pdfcreactivex.dll (14.08.2012)      **Para que servem:**  Estes novos componentes vêm resolver o problema detectado na produção de documentos pdf, de forma a diminuir o tamanho dos pdf gerados a partir da aplicação. Esta alteração é válida para documentos assinados e não assinados.    **O que Fazer:**  **1º PASSO: Actualizar o executável do Software PHC**  Estas novas dlls apenas vão funcionar em executáveis da versão 2013, com data igual ou superior ao dia 18.08.2012.      **2º PASSO: Copiar os seguintes ficheiros para a directoria do executável**  Deve copiar os ficheiros: zlib.dll (27.07.2012), hndlib.dll (27.07.2012), xfrxlib.fll (27.07.2012), pdfcreactivex.dll (14.08.2012) e RegPdfCreactivex.bat (14.08.2012), que se encontram no FTP na pasta: /Pub/Dlls\_V2013/Xfrx, para a directoria onde se encontra o executável da aplicação PHC.  Apenas o pdfcreactivex.dll é necessário registar no System32, para ajudar nesta tarefa encontra-se na pasta o ficheiro RegPdfCreactivex.bat.      **3º PASSO: Registar no System32 o pdfCreactivex.dll**  Pode escolher uma das seguintes formas para registar o pdfcreactivex.dll, utilizando o batchfile disponibilizado:  - seleccionar o ficheiro RegPdfCreactivex.bat, efectuar clique direito do rato sobre a dll e seleccionar a opção "Run as administrator";  - aceder à linha de comandos (cmd) como administrador ("Run as administrator"). Na linha de comando digitar o seguinte "cd "directoria do executável "" (por exemplo: "cd C:\ PHC2013").  Depois deve executar o batchfile, exemplo, C:\ PHC2013> RegPdfCreactivex.bat.  Caso não pretenda utilizar este batchfile deve registar a dll no System32. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Instalar As novas Dlls na Versão 2013: Xfrx e Pdfcreact' ) |