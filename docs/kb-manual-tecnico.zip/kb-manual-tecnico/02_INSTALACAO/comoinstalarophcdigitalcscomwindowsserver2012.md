---
title: Como Instalar o Phc Digital Cs com Windows Server 2012
source: comoinstalarophcdigitalcscomwindowsserver2012.htm
tipo: Manual Técnico
idioma: PT
---

# Como Instalar o Phc Digital Cs com Windows Server 2012

Para instalar o
PHC Digital
no
Windows server 2012
, a partir da instalação do
IIS (Internet Information Services)
, deverá aceder ao painel de controlo, programas,
turn Windows features on or off
e definir as seguintes configurações:
No painel de controlo do computador, opção "Adicionar/Remover Programas" tem de escolher a opção "Adicionar/Remover Componentes do Windows" para instalar o
IIS
. Este componente vai ser instalado por defeito em:
É necessário ter o
Web Pllaform Instaler (Deploy)
instalado no
IIS
. Pode fazer o
download
em
aqui
.
No
Default Web Site
ao clicar no notão direito do rato e escolher a opção "deploy - Import application", deve efetuar os seguintes passos:
1 - Escolher o caminho onde se encontra o ficheiro ".zip" da aplicação intranet e extranet (servernt2/release/dnet2015).
2 - Estes são os ficheiros que vão ser instalados. Não desseleccionar nenhum.
3 - Dar o nome que pretendemos ao nosso projeto, caso seja uma atualização ao projeto dar o mesmo nome.
No caso de já exista o projeto, ao fazer a atualização, surge na instalação o seguinte ecrã:
Caso existam ficheiros que tenham sido modificados devemos escolher a primeira opção, caso contrário perderá todos os ficheiros.
4- Ao clicar em "next", será então instalada a aplicação.
Outros passos necessários:
Na
Application Pools
verificar se o "Net v4.5" está configurado com a "framework v4.0 Integrated" e com a "identity ApplicationPoolldentity".
No "webconfig" que é instalado por defeito é necessário proceder à eliminação dos seguintes items:
&ltassemblies>
&ltadd assembly="DevExpress.Data.v12.2, Version=12.2.5.0, Culture=neutral,
PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.Web.v12.2, Version=12.2.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.Utils.v12.2, Version=12.2.5.0, Culture=neutral,
PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.Charts.v12.2.Core, Version=12.2.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.XtraCharts.v12.2, Version=12.2.5.0, Culture=neutral,
PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.XtraCharts.v12.2.Web, Version=12.2.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a"/>
&ltadd assembly="DevExpress.Printing.v12.2.Core, Version=12.2.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a"/>
</assemblies>
No CD de instalação existe uma diretoria chamada 'Aplicações', dentro desta diretoria existem as aplicações que adquiriu, dentro de cada aplicação está um
setup
que deve correr.
Este
setup
vai verificar se está instalada a "Framework.net", no caso de não estar, esta será instalada. Este processo demora algum tempo (aproximadamente 5 minutos).
Se pretender instalar a "Framework.net" manualmente encontra dentro do CD uma diretoria chamada 'DOTNET', deverá correr o ficheiro que lá se encontra (dotnetfx.exe).
A aplicação que instalou fica por defeito na seguinte diretoria:
C:\inetpub\wwwroot\NomeDaAplicacao - Se não estiver neste local é porque o
IIS (Internet Information Services)
, não foi instalado em c:\inetpub, neste caso, terá que verificar qual o caminho para a diretoria do
IIS
.
No local da instalação fica o ficheiro "Web.Config" onde é configurada muita da informação necessária à execução da aplicação.
O
setup
vai também verificar se tem tecnologia "AJAX" instalada no PC e se não tiver instalá-la. Se pretender instalar manualmente, no CD encontra uma diretoria chamada 'AJAX' que contém o ficheiro que deve correr (aspajaxextsetup.msi).
Depois de instalar (correr o setup), é necessário aceder ao
Internet Information Services (administrative tools do control panel)
, selecionar o
website
instalado, ir a propriedades > página "ASP.net" e verificar se tem a versão 2.0xxx. Se não estiver deve alterá-la.
Gama e versão de software PHC em que foi testado: PHC Digital CS versão 16.
