---
title: Comoinstalarosmanuaisdasaplicaçõesphccsweb
source: comoinstalarosmanuaisdasaplicaçõesphccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Comoinstalarosmanuaisdasaplicaçõesphccsweb

Como Instalar os Manuais das Aplicações Phc Cs Web

|  |
| --- |
| Como Instalar os Manuais das Aplicações Phc Cs Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Na aplicação PHC CS Supervisor desktop, nas opções relativas ao **PHC CS Web** existe uma opção que se chama **Importação da Tabela de Ajuda**, que serve para importar a tabela dos manuais das aplicações digitais.  É também através desta opção que se efetua a atualização de manuais fornecidos pela PHC.    O campo **Diretoria das imagens e nome da tabela a importar (ambos devem estar no mesmo local)** serve para inserir o caminho para a tabela fornecida. A tabela a importar tem que ter a extensão DBF. Nessa mesma diretoria devem estar todas as imagens a importar.    Por exemplo C:\web\Aplicacoes\Intranet\Intranet.dbf    O campo  **Diretoria para onde serão importadas as imagens** serve para indicar o caminho para a diretoria para onde serão copiadas as imagens dos manuais. Esta diretoria tem obrigatoriamente que se chamar **Images** e deve ser criada abaixo da diretoria **Programs**, dentro da aplicação respetiva.    Por exemplo c:\inetpub\wwwroot\Intranet\programs\images    Após as definições dos caminhos, basta clicar na opção "Executar a Importação" para que os manuais estejam prontos a ser utilizados na sua aplicação PHC CS Web.    Nota: No CD de instalação do PHC CS Web existe uma directoria chamada Manuais, onde se encontram os ficheiros necessários à importação dos manuais para a base de dados. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Instalar os Manuais das Aplicações Phc Cs Web' ) |