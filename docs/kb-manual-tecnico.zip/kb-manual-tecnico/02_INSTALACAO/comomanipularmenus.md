---
title: Como Manipular Menus
source: comomanipularmenus.htm
tipo: Manual Técnico
idioma: PT
---

# Como Manipular Menus

No "Menu Geral" ou no "Menu Aplicacional" existe, muitas vezes, a necessidade de adicionar ou retirar opções.
Vejamos como é simples adicionar uma opção ao menu, assim como, condicionar o acesso a determinado menu.
1. Neste 1º exemplo, vamos adicionar uma opção no "Menu Global" da
Extranet
, que permita ao utilizador localizar as nossas instalações. Na prática, às opções que visualizamos abaixo, será adicionada uma nova.
Para isso, vamos criar uma opção de Menu na
Intranet
:
A criação deste menu deverá respeitar as seguintes configurações:
Caminho completo para o link:
../programs/ewpview.aspx?codigo=ondeestamos
Texto do link:
Onde estamos
Tooltip do link:
Onde estamos
Surge no Menu Global no Cabeçalho:
ativar
Package a incluir:
sim
Package:
Extranet
A partir deste momento, ao entrar na
Extranet
, o utilizador já encontrará uma opção no "Menu Global", para verificar a localização da nossa empresa.
E ao clicar nesta opção, será apresentada a página para a qual o
link
aponta.
Se necessitar de condicionar o acesso a este menu, poderá efetuar as seguintes filtragens na construção do próprio menu:
2. Neste exemplo, retiremos do "Menu Aplicacional", o acesso de "Equipamento" a todos os utilizadores da
Extranet
. O menu assinalado na imagem abaixo deixará de estar disponível.
Para isso, deverá ser criado um evento de web com a seguinte configuração:
Nome do evento:
aposdefinirmenu
Ecrã:
opcoesdomenu
Reação ao evento:
programa interno
Package a incluir:
sim
Package:
Extranet
Expressão
Dim f as system.int32
Dim a as system.int32
for f=0 to mainformdataset.tables(0).rows.count-1
if mainformdataset.tables(0).rows( a ).item("menu")="Equipamento" or mainformdataset.tables(0).rows( a ).item("submenu")="Equipamento" or mainformdataset.tables(0).rows( a ).item("subsubmenu")="Equipamento"
mainformdataset.tables(0).rows( a ).delete
else
a=a+1
end if
next
Como resultado, quando o utilizador entrar na
Extranet
, deixa de ter disponível o menu "Equipamento".
Gama e versão de software PHC em que foi testado: PHC Digital 15
