---
title: Comoprepararosadd Onsparaorgpd
source: comoprepararosadd-onsparaorgpd.htm
tipo: Manual Técnico
idioma: PT
---

# Comoprepararosadd Onsparaorgpd

Como Preparar os Add-ons para o Rgpd

|  |
| --- |
| Como Preparar os Add-ons para o Rgpd |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O RGPD (Regulamento Geral de Proteção de Dados) ou GDPR (General Data Protection Regulation) é um diploma Europeu (EU 2016/679) que estabelece as regras referentes à proteção, tratamento e livre circulação de dados pessoais das pessoas singulares em todos os países membros da União Europeia.    Este regulamento surgiu com o objetivo de reforçar a Proteção de Dados, prevista no art.º 8.º da Carta dos Direitos Fundamentais da União Europeia, e harmonizar a legislação existente nos Estados-Membros, criando as bases para o mercado único digital.      Assim, os add-ons que um parceiro developer Drive FX pretender publicar na Drive FX Store, ou que já tenha sido antes publicado, tem de ser adaptado a esta realidade.    O seu kit parceiro já possui a Framework adaptada para estas atualizações, por isso, pode começar desde já a preparar os seus add-ons de forma a ter tudo pronto para **publicação na Drive FX Store aquando do lançamento da nova versão do Drive FX**.    Leia este artigo se pretende saber como classificar os campos de novos add-ons ou adaptar os campos de add-ons que já se encontram publicados por si.      **COMO CRIAR NOVOS ADD-ONS AO ABRIGO DO RGPD**  O ecrã **Personalização de Entidades** pertencente à Framework, permite a criação de novas tabelas e campos de utilizador para a construção de add-ons.  Na definição dos campos, feita na grelha desse ecrã, existem as seguintes colunas:    **Classificação RGPD** - Determina se o campo da linha selecionada é abrangido pelos processamentos do add-on RGPD. Pode selecionar as seguintes opções: Pessoal, Legal ou Sensível.  **Identificador RGPD** - Campo lógico que serve para indicar que o campo será um identificador e que os seus dados serão abrangidos nas pesquisas por dados identificadores, no momento do Registos de Processamentos do add-on RGPD.  Depois de classificar os campos através destas duas colunas, pode proceder à criação das restantes opções do add-on. Quando o mesmo for publicado na Drive FX Store, estará preparado para cumprir com as diretrizes do RGPD, em conjunto com o add-on RGPD.    Aproveite e destaque para o seu mercado de clientes, que o seu add-on está "Preparado para o RGPD" colocando esta informação no campo referente aos Benefícios do seu add-on, presente no ecrã Add-ons.      **COMO ADAPTAR OS ADD-ONS EXISTENTES AO RGPD**  Se já tem add-ons publicados na Drive FX Store e esses add-ons têm campos suscetíveis de serem considerados dados pessoais, é necessário fazer a sua adaptação a esta realidade.  Assim, devem ser efetuados os seguintes passos: - Aceder à instalação de kitparceiro Drive FX, onde foram criados/publicados os add-ons. - Criar uma nova versão do add-on, posicionando-se no ecrã de add-ons pertencente à framework, consultar o add-on e clicar na ação intitulada **crie nova versão**. - Com o add-on em modo de desenho, aceder à personalização de entidades criada para esse add-on (uma ou várias) e classificar cada campo através das colunas:    **Classificação RGPD** - Determina se o campo da linha selecionada é abrangido pelos processamentos do add-on RGPD. Pode selecionar as seguintes opções: Pessoal, Legal ou Sensível.    **Identificador RGPD** - Campo lógico que serve para indicar que o campo será um identificador e que os seus dados serão abrangidos nas pesquisas por dados identificadores, no momento do Registos de Processamentos do add-on RGPD.        Depois de classificar os campos, poderá publicar a nova versão do add-on e o mesmo estará preparado para cumprir com as diretrizes do RGPD.        Aproveite e destaque para o seu mercado de clientes, que o seu add-on está "Preparado para o RGPD" colocando esta informação no campo referente aos Benefícios do seu add-on, presente no ecrã Add-ons.      Alerta   Para um cliente estar preparado para o RGPD não basta o seu add-on estar preparado para o RGPD, ele terá também de subscrever o add-on RGPD, publicado na Drive FX Store. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Preparar os Add-ons para o Rgpd' ) |