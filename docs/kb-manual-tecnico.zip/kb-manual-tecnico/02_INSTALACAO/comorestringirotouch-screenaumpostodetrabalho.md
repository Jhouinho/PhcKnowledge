---
title: Comorestringirotouch Screenaumpostodetrabalho
source: comorestringirotouch-screenaumpostodetrabalho.htm
tipo: Manual Técnico
idioma: PT
---

# Comorestringirotouch Screenaumpostodetrabalho

Como Restringir o Touch-screen a um Posto de Trabalho

|  |
| --- |
| Como Restringir o Touch-screen a um Posto de Trabalho |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para tornar o módulo de **TOUCH** mais rápido e eficiente, apresentamos uma configuração que permite que o *Touch-Screen* fique associado, exclusivamente, aos centros de trabalho desejados.     Após entrar no *Touch-Screen* e efetuar o seu *login*, o seu monitor aparecerá com todos os postos trabalhos associados:           No ecrã "Postos de Trabalho" poderá associar os centros de trabalho disponíveis aos respetivos postos de trabalho.        Para restringir um *Touch-Screen* a um posto de trabalho, é utilizado um ficheiro com a extensão TXT com o nome TOUCH (TOUCH.TXT), na diretoria onde se encontra instalado o **PHC Manufactor**.   O conteúdo deste ficheiro deverá ter o código utilizado no campo "Posto" do ecrã "Postos de Trabalho" (ou códigos separados por virgula).   Caso este ficheiro tenha apenas um código de terminal ativo, a seleção do terminal será feita automaticamente, e assim todas as operações ficarão imediatamente disponíveis. Se o mesmo ficheiro conter vários terminais ativos, será selecionado o primeiro da lista.          Para contrariar o automatismo apresentado anteriormente, deverá iniciar o conteúdo do ficheiro com "-," ex: "-,C,P", desta forma o resultado apresenta apenas os dois terminais P(Pintura) e C (Corte).        Gama de software PHC onde foi testado: PHC Executive Manufactor CS 2013 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Restringir o Touch-screen a um Posto de Trabalho' ) |