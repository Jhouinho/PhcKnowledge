---
title: Comoteromanufactornabasededadosdophccsdesktop
source: comoteromanufactornabasededadosdophccsdesktop.htm
tipo: Manual Técnico
idioma: PT
---

# Comoteromanufactornabasededadosdophccsdesktop

Como Ter o Manufactor na Base de Dados do Phc Cs Desktop

|  |
| --- |
| Como Ter o Manufactor na Base de Dados do Phc Cs Desktop |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta funcionalidade surgiu para facilitar os backups da base de dados para um só ficheiro .MDF e, também, o código x-Base ou SQL das implementações que deixam de ter a referência às bases de dados quanto interagem com o SQL.     Além disso, os templates que a PHC disponibiliza para o PHCCS Web, também vão por defeito programados nesta premissa.    Desta forma, passa a ser possível incluir todas as tabelas do PHC CS Manufactor juntamente com as tabelas do PHC CS Desktop na mesma Base de Dados SQL (ficheiros .MDF e .LDF).     A configuração e instalação da integração entre as duas plataformas continua a ser necessária. Todo o motor de integração, como os triggers de conexão, continuam a existir. No Dicionário de Dados apenas aparecerá as tabelas da plataforma que possui, caso tenha o PHC CS Web apenas terá esta informção no PHC CS Desktop.     Para clientes atuais com as duas plataformas instaladas em separado, caso pretenda juntar todas as tabelas numa só base de dados SQL, na linha de comando do PHC CS Manufactor deve executar o comando *ChangeDB*. Ao entrar na aplicação é disponibilizado um ecrã de confirmação.    O comando *ChangeDB* é uma processo demorado e exige que o disco tenha espaço disponível o tamanho ocupado pelas duas Bases de Dados SQL.      Durante este processo, **não** deverão estar utilizadores a trabalhar nas plataformas e é essencial a criação de backups das bases de dados.        **Instalação e configuração**      Em primeiro lugar, é necessário abrir uma janela de linha de comandos "cmd", e chamar a aplicação Manufactor com o comando *CHANGEDB*.     Por exemplo:  *C:\MANUFACTOR19\PHCEXECUTIVE.EXE CHANGEDB*            No ecrã de entrada, deve selecionar a Base de Dados e efetuar o *login* da forma normal.            Após o *login*, o processo de migração é iniciado.               **A migração é efetuada em 7 passos**     **Passo 1/7** - Eliminar triggers interligação Manufactor             **Passo 2/7** - Eliminar triggers interligação CS             **Passo 3/7** - Criar tabelas Manufactor na BD de PHC CS Desktop.            **Passo 4/7** - Copiar dados tabelas Manufactor para a BD PHC CS Desktop.            **Passo 5/7** - Atualizar Framework Manufactor na BD PHC CS Desktop.            **Passo 6/7** - Instalar *Triggers* e *Store procedures*.            **Passo 7/7** - Instalação de *Triggers* de conexão.            No final, é apresentada uma mensagem de sucesso e a aplicação é encerrada, ao voltar a entrar já estará a trabalhar sobre a Base de Dados conjunta.             *Notas:*     * O processo pode ser demorado;  * Deve ser feito um *backup* das duas bases de dados antes de iniciar a junção;  * As duas bases de dados devem estar na versão atual;  * Não devem existir outros utilizadores a trabalhar sobre as bases de dados durante todo o processo.  * *Triggers* e *Stored Procedures* que não tenham sido criadas através da aplicação não serão migrados;  * Deve existir, no mínimo, o dobro do tamanho da base de dados de Manufactor de espaço em disco disponível.      *Exemplo:*    * Base de dados CS 10 gigabytes;  * Base de dados Manufactor 8 gigas;  * Deve existir no mínimo 16 (8+8) gigas de espaço em disco.      Gama de software PHC em que foi testado: Executive v19. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Como Ter o Manufactor na Base de Dados do Phc Cs Desktop' ) |