---
title: Configurar Pesquisas em Grelhas com Constantes do Enumerador
source: configurarpesquisasemgrelhascomconstantesdoenumerador.htm
tipo: Manual Técnico
idioma: PT
---

# Configurar Pesquisas em Grelhas com Constantes do Enumerador

## Descrição

no
Campo para valor: flstamp
Campo para desnormalização do valor: no (uxxxxx_fornecst)
Tem navegação associada: TRUE
Rota de destino da navegação: fl
Campo de ligação na entidade de destino da navegação: flstamp
Nome Fornecedor (nome)
nome (uxxxx_fornecst)
ENTITYDATAFIELD.UXXXXX_FORNECST.NOME
Input box
Sim
Tipo: Texto
Telefone (telefone)
telefone (uxxxx_fornecst)
ENTITYDATAFIELD.UXXXXX_FORNECST.TELEFONE
Input box
Sim
Tipo: Texto
E-mail (email)
email (uxxxxx_fornecst)
ENTITYDATAFIELD.UXXXXX_FORNECST.EMAIL
Input box
Sim
Tipo: E-mail
12.
De seguida clicar no botão
Configure pesquisa da grelha
e na janela pop-up que surge, escrever o código para o objeto
QueryVO
que vai corresponder ao conjunto de registos que poderão ser consultados na grelha para efeitos da pesquisa e onde serão incluídos apenas os registos ativos da entidade em causa.
No exemplo seria:
query.entityName=TABLES.FL;

var filtroFL = new FilterItem();

 filtroFL.filterItem = FIELDS.FL_PAIS;

 filtroFL.valueItem = "Portugal";

 filtroFL.groupItem = FilterGroupItemEnum.AND;

query.filterItems.push(filtroFL);

filtroFL = new FilterItem();

 filtroFL.filterItem = FIELDS.FL_ESTAB;

 filtroFL.valueItem = 0;

query.filterItems.push(filtroFL);
13.
Ainda nesta janela, indicar quais os campos que deverão ser mostrados como colunas da tabela de pesquisa e indicar quais os campos que fazem a ligação entre o QueryVO e a tabela de utilizador associada à grelha.
No exemplo, associamos os campos:
Campo
Título
Tipo
no
Nº
Numérico
nome
Nome
Texto
telefone
Telefone
Texto
email
E-mail
Email
Na secção
Ligação
preencher o
Campo da pesquisa para ligação com a grelha
com o valor
flstamp
e selecionar no
Campo da entidade para ligação com a pesquisa
o valor
flstamp (uxxxxx_fornecst)
.
14.
Clicar em
Grave
para guardar as configurações da pesquisa da grelha e fechar o pop-up.
15.
Clicar novamente em
Grave
para guardar as configurações da grelha e voltar ao ecrã da secção.
16.
Clicar outra vez em
Grave
para guardar as alterações feitas à secção.
17.
Por último, falta-nos proceder à criação de
Código de Entidade
, de forma a que quando se alterar o valor do campo do Nome (nome) este irá atualizar os valores dos campos Telefone (telefone) e E-mail (email).
Assim, devemos aceder ao ecrã de
Código de Entidade
em modo de introdução e preencher os seguintes dados:
Entidade:
Artigos
Título:
Ao sincronizar Fornecedores do Artigo
Tipo Código:
Ao Sincronizar
No
Código
colocar as seguintes instruções:
select
case
changedItems.first.baseType
' Se a alteração for feita nos campos para a entidade dos Fornecedores do Artigo
case
getType
(U4902_fornecstVO)
dim
item
as
U4902_fornecstVO
=
Nothing
if
changedItems.getChangedItemByField(item,
"flstamp"
)
isnot
nothing
then
Dim
itemFl
As
FlVO
=
SDK.Query.getEntityData(
Of
FlVO)(
New
FilterItem(
"flstamp"
, Comparison.Equal,
"'"
+
item.flstamp
+
"'"
)).FirstOrDefault()
If
itemFl
isnot
nothing
Then
item.no
=
itemFl.no

 item.nome
=
itemFl.nome

 item.telefone
=
itemFl.telefone

 item.email
=
itemFl.email
end
if
End
if
end
select
18.
Gravar o registo e de seguida associar ao Add-On a regra de entidade, mediante um clique no rodapé da barra de desenho do Add-On, na área dos
Dados
que exibe um número.
19.
Clicar no botão com o nome do Add-on localizado na barra de desenho de Add-Ons e
Instalar o Add-On
para que a grelha que foi adicionada passe a fazer parte do ecrã de Artigos do Drive FX.
20.
Uma vez instalado o Add-On, somos encaminhados diretamente para o ecrã de Artigos e Serviços e vamos criar um novo registo. A grelha adicionada que surge com a designação
Fornecedores do Artigo
já se encontra disponível para utilização, permitindo através desta associar ao artigo o(s) fornecedore(s) desse artigo e consultar os dados de contacto dos mesmos.
Poderá associar fornecedores mediante a introdução manual de linhas, ou recorrer ao botão de
Pesquise
para através da lista de fornecedores selecionar o(s) fornecedore(s) a passar para a grelha. De notar, que na lista apenas se exibem Fornecedores cujo País é Portugal e as Sedes de Estabelecimento.
