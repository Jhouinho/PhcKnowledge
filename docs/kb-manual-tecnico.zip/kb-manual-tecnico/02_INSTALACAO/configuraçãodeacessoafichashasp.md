---
title: Configuraçãodeacessoafichashasp
source: configuraçãodeacessoafichashasp.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãodeacessoafichashasp

Configuração de Acesso a Fichas Hasp

|  |
| --- |
| Configuração de Acesso a Fichas Hasp |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A validação de acesso ao software PHC Manufactor CS é efetuada por controlo através de uma ficha de proteção (SUPERPRO,SPRONET,HASP,[UNIKEY](configuraçãodeacessoafichasunikey.htm),UNIKEYPRO) ou via Internet.    Neste tópico iremos abordar apenas a ficha de proteção HASP.    Após instalar os *Drivers* da ficha HASP no servidor, é necessário configurar o ficheiro NETHASP.INI, para "direcionar" a validação para a ficha correta.      Esta operação obriga a que seja editado (com o Notepad, por exemplo), o ficheiro NETHASP.INI e seja indicado o endereço IP do servidor de fichas HASP.           *Nota*: é possível aceder à ficha sem configurar o ficheiro NETHASP.INI (podendo apagá-lo da diretoria). Dessa forma, a validação é feita em *broadcast*, ou seja, o software procura (na rede) quais as fichas disponíveis, para se tentar validar. Esta solução (embora, aparentemente, mais fácil) torna o processo de validação mais lento! Aconselhamos a utilização do 1º processo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração de Acesso a Fichas Hasp' ) |