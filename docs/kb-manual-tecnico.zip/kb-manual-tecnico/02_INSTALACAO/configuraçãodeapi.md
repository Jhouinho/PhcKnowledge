---
title: Configuração de Api
source: configuraçãodeapi.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração de Api

Para que possa invocar e executar o código de um
Script
, a partir de uma aplicação
API - Interface de Programação de Aplicações
, o utilizador deverá utilizar percorrer os seguintes passos:
1 -
Ter configurado um registo de Script, dedicado à necessidade específica do utilizador.
Por exemplo:
- Preenchimento dos dados de um Cliente através de uma API:
Código
do Script: cllista
Expressão
no Programa Interno do Script:
dim sql as new stringbuilder
sql.appendformat("select * from cl (nolock) where cl.no={0}",mstamp)
dim dt as datatable = cdata.getdatatable(sql.tostring)
return dt.WriteXmlToString()
2 -
Após a criação do Script, o utilizador poderá aceder à API, colocando no URL o seguinte caminho:
.../ws/wscript.asmx
.
Por exemplo:
http://localhost/intranet
/ws/wscript.asmx
(caso aceda através da Intranet)
Por motivos de segurança, a API apenas pode ser utilizada na máquina local, onde a aplicação se encontra instalada.
Ao colocar o caminho indicado anteriormente, o utilizador vai invocar o método
"RunCode"
desse webservice.
3 -
Posteriormente, ao clicar na opção
RunCode
, dependendo da aplicação pela qual se está a aceder à API (Intranet ou Extranet), é pedido ao utilizador para preencher os seguintes parâmetros:
Intranet
;
Onde deverá preencher os seguintes parâmetros:
userName
: id de utilizador para login;
password
: palavra passe do utilizador para login;
code
: código do registo de scripts do utilizador a executar. Este código tem sempre que retornar uma string;
parameter
: parâmetro para o código. A variável no código chama-se mstamp.
Extranet
Onde deverá preencher os seguintes parâmetros:
custumerCode
: Nº de cliente;
userName
: id de cliente para login;
password
: Palavra passe do utilizador para login;
code
: Código do registo de scripts do utilizador a executar. Este código tem sempre que retornar uma string;
parameter
: Parâmetro para o código. A variável no código chama-se mstamp.
Regressando ao exemplo, os campo que se indicam de seguida deverão ser preenchidos com a informação que se indica:
code
: cllista - Representa o
Código
do registo do Script do utilizador.
parameter
: 02 - De acordo com o exemplo, representa o número de cliente.
4 -
Posteriormente, ao clicar na opção
Invoke
a aplicação ATI irá retornar uma string XML com os dados do cliente nº 2 resultantes do "select" efetuado à base de dados, incluído no Script.
Esta string poderá resultar num documento com extensão
".XML"
, que pode ser utilizado por exemplo, para exportar todos os dados existentes num registo (neste caso de clientes), num ficheiro XML, de forma rápida, fácil e assertiva.
Instalação e Configurações do Phc Cs Web
