---
title: Configuração de Documentos de Faturação - Configuração
source: configuraçãodedocumentosdefaturação-configuração.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração de Documentos de Faturação - Configuração

Configuração:
Utiliza data efetiva de entrega nas linhas do documento
Se esta opção estiver ativa, quando o utilizador introduzir um documento de faturação do tipo: Fatura (Tipo 1); Guia de Remessa (Tipo 4); ou Documento de Conferência (tipo 5), ficará disponível uma coluna
(nas linhas do documento) com a identificação da "Data de Entrega". O utilizador poderá em cada linha do documento indicar a data em que o artigo ou serviço foi ou será colocado à disposição do adquirente.
Nota:
Esta opção de configuração não se visualiza quando se trata de um documento de retificação: Nota de Débito (Tipo 2) ou Nota de Crédito (Tipo 3).
Pergunta se quer copiar de outro documento
Se esta opção estiver ativa e o utilizador introduzir um novo documento de faturação, então ser-lhe-á perguntado se quer copiar os dados de outro documento de faturação (p. e. guia de remessa). Ao copiar os dados de outro documento, são copiadas para além das linhas, as
informações que se encontrem em
Outros Dados
, relativas à faturação.
É importante referir que qualquer documento de faturação que se encontre anulado, não aparece disponível para cópia.
Permite alterar o número sequencial do documento
Permite alterar o número do próximo documento de faturação, o que possibilita iniciar a emissão de faturas com o sistema de numeração antigo.
Nota:
É possível gravar documentos de faturação com uma numeração superior para uma data inferior ao último documento, desde que o último documento se encontre anulado.
No entanto, caso seja uma série de documentos certificados, mesmo com esta opção ativa, será controlada a numeração sequencial dos documentos. Ou seja, ao gravar um novo registo numa série assim configurada é controlado, se o número do mesmo, fora alterado. Caso seja o primeiro registo do ano na série, permite alterar o número, caso não seja, não é possível alterar o número do documento.
Não controla a data de emissão do documento
Esta opção permite ao utilizador introduzir documentos que tenham data de emissão inferior a documentos já existentes, ou data de emissão superior a documentos posteriores ao introduzido.
Atenção:
não é aconselhável utilizar esta opção para documentos oficiais, já que neste tipo de documentos, seja obrigatório que a data e o respetivo número sejam sequenciais.
Nota:
Esta opção só está disponível para documentos do tipo "Outro (i.e. fact. proforma)" e que não tenham a opção
Série de documento a ser assinada digitalmente
ativa.
Controla dívidas do cliente com idades acima do limite máximo
Esta opção permite controlar a emissão de documentos para clientes com dívidas acima do limite máximo. Este
limite máximo de dias de crédito
é definido na ficha do cliente.
Mostra botão de conferência de quantidades
Ao ativar esta opção surge mais um botão no documento de faturação, permitindo assim executar a conferência de quantidade. Para mais informações sobre esta opção consulte por favor a
Conferência de quantidades
.
Esta opção só se encontra disponível se o utilizador possui o módulo de
Stocks.
Conferência de quantidades com descontos
Se esta opção estiver ativa surgirão mais colunas na conferência de quantidades, para assim se poder indicar os descontos. A quantidade de colunas de descontos depende da configuração feita no parâmetro: Número de descontos nas linhas do documento de faturação (0 a 6).
Esta opção só se encontra disponível se o utilizador possui o módulo de
Stocks
.
Conferência de quantidades com preços
Se esta opção estiver ativa, surgirá mais uma coluna na conferência de quantidades, para assim se poder indicar o preço dos artigos.
Esta opção só se encontra disponível se o utilizador possui o módulo de
Stocks
.
Ao introduzir actualiza promoções
Esta opção permite ativar as promoções definidas no respetivo ficheiro.
Isto significa que na gravação de um documento de faturação, serão atualizados os preços ou as quantidades das referências com promoções.
Da mesma forma, perante os artigos com quantidade alternativa onde recaia a promoção, ao faturar estes artigos, nas linhas das promoções, aparecem os valores relativos às
quantidades alternativas
. Ou seja, ao indicar a quantidade na linha do documento de faturação, a quantidade alternativa do artigo de promoção é
automaticamente preenchida
.
Ao imprimir pergunta se quer imprimir as encomendas pendentes
Após a impressão do documento aparece o ecrã para impressão das encomendas em aberto do respetivo cliente. Esta impressão é desenhada no
menu de opções
.
Se possuir
PHC ON
poderá obter mais informação de como ter conhecimento das encomendas dos seus clientes que se encontram pendentes, carregando
aqui
.
Só do estabelecimento do cliente do documento
Ao ativar esta opção faz com que os documentos selecionados pela opção
Imprimir as encomendas pendentes de clientes
, sejam apenas relativos ao estabelecimento do cliente que está definido no documento, com o qual se está a trabalhar.
A funcionalidade desta opção na impressão das encomendas pendentes mantém-se, se na "Configuração de Documentos de Faturação" estiver ativa a opção
Ao imprimir pergunta se quer imprimir as encomendas pendentes
.
Utiliza semáforos para gerir multi-utilização
Através desta opção é possível gerir a gravação simultânea de documentos. Para esse efeito existe o seguinte funcionamento:
O semáforo está ligado durante o processo de gravação do documento, sendo apenas desligado quando a gravação termina.
Desta forma, quando se está a gravar um documento, se alguém tenta gravar outro ao mesmo tempo, são dadas as seguintes opções ao utilizador:
Forçar a gravação
Voltar atrás e tentar mais tarde
Pôr o programa a tentar automaticamente (esta opção utiliza os parâmetros já existentes para n.º de tentativas e segundos entre tentativas). Para mais informações consulte por favor os
Parâmetros gerais
.
Controla faturação abaixo do preço de custo
Esta opção impede a faturação de referências abaixo do preço de custo (ficha do artigo), independentemente do custeio de
stock
que se esteja a utilizar.
Nos documentos de faturação configurados para controlar a faturação abaixo do preço de custo, ao faturar a um preço inferior ao preço de custo, surge uma mensagem a avisar-lo do mesmo indicando a referência em causa. Caso haja mais do que uma artigo, é mostrada um lista de
referências.
Permite agregar equipamento ao documento
A cada documento de faturação, esta opção indica se permite agregar equipamentos (n.º de série). Só está disponível se possuir os módulos
PHC CS Suporte desktop
ou
PHC CS Equipamento desktop
.
Abre o ecrã para preencher os nºs de série
Quando selecionada a opção "
preencher os números de série
", que dizem respeito à referência/quantidade introduzida na linha do documento.
Abre o ecrã para eliminar os nºs de série
Esta opção permite ao utilizador
selecionar os números de série
que pretende eliminar pertencentes a determinada referência existente na linha do documento.
Controla plafond do cliente ultrapassado
Se esta opção estiver ativa, ao gravar um documento, o utilizador é alertado que o cliente vai ultrapassar o
plafond
de crédito definido na ficha do cliente.
Soma o saldo de c/c e de títulos de dívida para controlar o plafond
Esta opção só está disponível se possuir o módulo
PHC CS Letras desktop
e a opção "Controla plafond do cliente ultrapassado" ativa , neste caso o saldo de c/c das letras entra para o controlo do
plafond
.
Desc.Qtt/Valor automáticos ao gravar (POS)
Ao selecionar esta opção, os documentos de faturação no
POS front
utilizam automaticamente os descontos por quantidade/valor, ou seja, na
introdução de qualquer documento no
POS
, o
valor líquido
do documento já traz os descontos incluídos.
A única diferença de funcionamento relativamente aos documentos de faturação do
Gestão
, é que no caso do
POS
, não são emitidas quaisquer mensagens ao utilizador, caso o cliente não tenha tipo de descontos definido na sua ficha, ou se não existirem descontos por quantidade ou valor na tabela de descontos por quantidade ou valor.
Os Desc.Qtt/Valor automáticos ao gravar no
POS
podem ter dois comportamentos diferentes, baseados no valor do parâmetro de faturação
Só aplica os descs.Qtt/Valor se nas linhas existirem campos de desconto vazios
.
Se o parâmetro se encontrar inativo, os valores vindos da tabela de descontos por quantidade e valor são aplicados nas linhas do documento, mesmo que estas tenham os campos de desconto preenchidos. Se o parâmetro estiver ativo, a aplicação tenta encontrar um campo de desconto vazio nas linhas para aplicar os descontos. Caso não existam campos vazios, os descontos não são aplicados. Para mais informações consulte o
tópico sobre os descontos
de quantidade ou valor.
Calcula descontos por quantidade ou valor "Just in time"
Permite ao utilizador configurar, para cada documento de faturação, se a percentagem de
descontos por quantidade ou valor
é calculada no momento da introdução do artigo nas linhas.
Esta configuração só funciona quando o documento de faturação está em modo de introdução. Ao alterar um documento já existente para obter o mesmo resultado, tem que selecionar a opção
Descontos por Quantidade ou Valor
no menu de opções das linhas.
Os descontos por quantidade ou valor
Just in time
são gravados nos campos
Desc1
e
Desc2
, mesmo que estes se encontrem preenchidos e não se encontram sujeitos ao parâmetro
Só aplica os descs. Qtt/Valor se nas linhas existirem campos de desconto vazios
.
Não procura referências e preços em dossiers
Ao ativar esta opção faz com que, ao introduzir uma referência num documento de faturação, a aplicação não faça procuras dentro da tabela de dossiers internos, preços e referências. Assim, a performance da aplicação durante a introdução de referências no documento é melhorada, pois o sistema já não terá que percorrer as linhas de dossiers internos, que possam existir na base de dados, à procura de outros preços de venda para um determinado cliente e artigo ou por referência de cliente.
Ao criar um novo tipo de documento de faturação, esta opção é automaticamente ativada. Enquanto que nos documentos já criados esta opção mantém-se inativa.
Utiliza metros lineares nas linhas
Permite a utilização de metros lineares nas linhas do documento.
Metros lineares representa que estamos a vender quantidades de uma medida fixa. Esta medida fixa vem do campo configurado nos parâmetros de
stocks
Metros Lineares
.
Neste caso o campo
Partes
configurado nas parâmetros da faturação deverá ser, por exemplo, Unidades.
No documento de faturação configurado desta forma aparecem duas colunas: Unidades e
Comprimento
(este campo fica com o valor preenchido na ficha do artigo) e a quantidade vendida é o produto destas duas colunas.
Exemplo
: Rolo de tecido vendido ao metro quadrado. No entanto eu sei que o rolo tem 1 metro e 60 de largura.
Quando eu vendo 3 metros de tecido, eu sei que estou a vender 3 x 1,6=4,8 metros quadrados de tecido.
Neste caso, na ficha do artigo deve estar indicado que a largura do tecido é 1,6 metros.
Ao vender indico no campo partes que estou a vender 3 metros. Os 1,6 de largura são automaticamente introduzidos no campo respetivo da fatura e a quantidade (4,8 metros quadrados) também é automaticamente criada.
Utiliza m2 nas linhas
Permite a utilização de metros quadrados nas linhas do documento. Neste caso surgem três colunas definidas nos parâmetros da faturação (
Partes
,
Altura
e
Largura
). A quantidade vendida é o produto da Altura pela Largura multiplicado pelas Partes.
Utiliza m3 nas linhas
Permite a utilização de metros cúbicos nas linhas do documento. Neste caso surgem quatro colunas definidas nos parâmetros da faturação (
Partes
,
Altura
,
Largura
e
Espessura
). A quantidade vendida é o produto da Altura pela Largura pela espessura multiplicado pelas Partes.
Ao introduzir um documento de faturação que utilize metros lineares, metros quadrados, ou metros cúbicos, copiando o mesmo desde um dossier interno (documento de origem), existe a possibilidade de registar no documento de origem quantas partes já foram "fornecidas" (se estiver preenchido o Parâmetro "
Se utiliza m2 ou m3 - nome do campo PARTES2 (fornecido)
".
Nota
: É possível no mesmo documento de faturação a utilização nas linhas de metros lineares e [ metros quadrados (m2) ou metros
cúbicos (m3) ] em simultâneo.
No caso do documento estar configurado com 2 opções, a descrição da
coluna referente aos dados "Altura" será a definida no parâmetro
Metros Lineares
.
No documento de faturação ao alterar a quantidade das linhas o campo PARTES é recalculado de acordo com as seguintes fórmulas:
Utilizando metros lineares e metros2; (PARTES x COMPRIMENTO X LARGURA = QTT)
Utilizando metros lineares e metros3; (PARTES x COMPRIMENTO X LARGURA X ESPESSURA = QTT)
Utilizando metros lineares; (PARTES x COMPRIMENTO = QTT)
Utiliza um vendedor por linha
Com esta opção ativa, todas as linhas do documento têm uma coluna para introdução do vendedor. Quando é introduzida uma linha este campo é preenchido com o valor do campo vendedor do cabeçalho do documento.
Por exemplo, ao ser introduzido um documento de faturação para o cliente X, se este tiver o vendedor "Carlos" definido na sua ficha, este campo fica automaticamente preenchido com"Carlos".
Não vê as grelhas no documento
Esta opção só está ativa se nos parâmetros de
stocks
estiver ativa a opção "Utiliza grelhas de cor e tamanho" e o módulo
PHC CS Grelhas desktop
adicionado.
Serve para desativar os campo de cor e tamanho no documento de faturação em questão.
Mostra o centro analítico nas linhas
Ao ativar esta opção fica disponível o campo "
centro analítico
" nas linhas do documento.
Este campo de centro analítico é atualizado em algumas tabelas, como por exemplo, movimentos de
stocks
e produtos vendidos, consoante a configuração do documento, isto é, se estiver configurada neste local (nas linhas) então passa o valor das linhas, caso contrário passa o do cabeçalho.
Mostra a modalidade nas linhas
(apenas disponível no executável de Espanha)
Com esta opção ativa é possível em cada linha do documento de faturação definir uma modalidade diferente.
Modalidade por defeito
(apenas disponível no executável de Espanha)
Nesta opção, ao escolher uma das modalidades apresentadas, sempre que utilizar este documento de faturação, o mesmo fica configurado para aparecer sempre por defeito com a modalidade escolhida.
Mostra o armazém nas linhas
Com esta opção, todas as linhas do documento têm uma coluna para introdução do armazém.
Utiliza os modos de pagamento
Esta opção só esta disponível se existir o módulo PHC CS POS desktop . A opção refere-se aos modos de pagamento e, se ativa, indica que ao faturar em POS Front é necessário indicar os modos de pagamento utilizados.
Nota
: Os documentos que lançam em tesouraria apresentam sempre os modos de pagamento. Pelo fato que, ao gravar o tipo do documento, o campo dos modos de pagamento é sempre atualizado como o referido nesta nota.
Guarda automaticamente documento no POS
Esta opção apenas existe com o módulo PHC CS Sincro desktop. Ao ativar esta opção, caso exista falha de energia, a venda fica guardada no ecrã de documentos suspensos e quando o utilizador volta a entrar na aplicação é-lhe apresentada uma mensagem perguntando se pretende recuperar.
Utiliza produtos compostos
Esta opção está sempre selecionada por defeito e permite utilizar, ou não, de acordo com a preferência do utilizador, os produtos compostos nos documentos de faturação.
Para esta opção ficar visível é necessário que o respetivo
parâmetro
esteja ativo.
Ligado a esta opção está um
parâmetro
da
Faturação
, que quando inativo, não permite visualizar os componentes do produto composto em nenhum documento de faturação.
Ou seja, o utilizador pode ter configurada toda a aplicação de forma a que, todos os documentos, estejam preparados para utilizar produtos compostos, e para serem visualizados os seus componentes nas respetivas linhas. Esta opção permite que determinados documentos utilizem produtos compostos sem, no entanto, se possa visualizar os seus componentes. Esta opção está intimamente ligada com a
cópia de documentos de faturação
.
Quando esta opção se encontra ativa e os componentes destes produtos são visualizados nas linhas, como se encontra explicado no parágrafo anterior, surge a seguinte opção:
Permite incluir novos componentes
Esta opção determina se, este tipo de documento a ser configurado, permite incluir novos componentes na estrutura do composto.
Caso esta opção se encontre ativa nas opções das linhas vai ficar disponível a opção de
Introduzir um componente na estrutura do composto
.
Ao lançar um artigo composto no respetivo documento, é lançada a sua estrutura predefinida e as respetivas quantidades por unidade.
Caso insira um novo componente na estrutura do composto, a aplicação não irá preencher automaticamente os descontos nessa linha.
Sempre que se verificar alterações ao artigo composto, a estrutura não é atualizada pela sua origem, mas sim pela estrutura definida no próprio documento.
Existe no entanto uma exceção que se verifica quando, apesar do artigo composto se encontrar lançado no documento, a sua quantidade for zero, pelo que quando se atualizar a quantidade do artigo composto "pai", as quantidades dos componentes são calculadas pelos valores definidos na sua estrutura predefinida.
Recalcula o custo produto composto
Uma vez ativa, esta opção determina se ao alterar a estrutura do artigo composto, os custos do mesmo (artigo principal) são, ou não, recalculados.
Utiliza Ref. Interna nas linhas
Esta opção permite utilizar o campo "
refª interna
" nas linhas do documento.
Este campo de "refª interna" é atualizado em algumas tabelas, como por exemplo, movimentos de
stocks
e produtos vendidos, consoante a configuração do documento, isto é, se estiver configurada neste local (nas linhas) passa o valor das linhas, caso contrário passa o do cabeçalho.
Utiliza descontos em valor nas linhas
Ao ativar esta opção, passa a ser possível utilizar descontos em valor nas linhas do documento, ficando disponível nas linhas, mais uma coluna
Valor de Descontos em Euros
. O desconto em valor entra nos cálculos com os outros descontos da seguinte forma: primeiro são aplicados os descontos percentuais à linha e, posteriormente, subtrai-se o desconto em valor multiplicado pela quantidade.
Se possuir
PHC ON
poderá obter mais informação sobre como efetuar descontos em valor nas linhas dos "Documentos de Faturação", carregando
aqui
.
Custo das linhas fixo
Esta opção serve para indicar que o custo neste documento é fixo, ou seja, não deve ser atualizado pela rotina de atualização do custo das vendas.
Ao atualizar o custo das vendas pela rotina de
corrigir
erros no stock atual, o custo da venda é atualizado para todas as linhas de documentos de faturação que não tenham esta opção ativa.
Entra para Mapas Intrastat (Entrada)
Esta opção só está disponível se estiver instalado o módulo
PHC CS Intrastat desktop
. Define se este documento serve para documento de entrada nos mapas intrastat.
Entra para Mapas Intrastat (Saída)
Esta opção só está disponível se estiver instalado o módulo
PHC CS Intrastat desktop
.
Define se este documento serve para documento de saída nos mapas intrastat.
Se tiver
PHC ON
poderá aprender um pouco mais sobre
Intrastat
, carregando
aqui
.
Ligado a Negócios
Este campo, uma vez selecionado, permite que o documento de faturação em questão seja um documento ligado aos
Negócios
do Módulo
PHC CS CRM desktop
. Este assume automaticamente uma nova página com campos
Código
e
Status
relativos aos negócios, de forma a permitir identificar o negócio a que o documento criado se refere.
Não controla lotes com
stock
Ao ativar esta opção, nas linhas do documento de faturação na coluna lote, ao digitar "?" ou efetuar clique direito do rato, a aplicação apresenta uma listagem dos lotes independentemente de terem
stock
maior que zero ou não. Só faz sentido utilizar esta opção numa base de dados com lotes.
Documento para previsão de faturação de PAT
Esta opção só está disponível se existir o módulo
PHC CS Suporte desktop
.
Ao criar um documento de faturação do tipo 4 (configurado como
Outro documento
) e ativar esta opção, ao faturar um dossier interno ou uma intervenção, os mesmos não são dados efetivamente como faturados.
Nota
: Nem os dossiers nem as intervenções ficam marcados como faturados no ecrã de
PATs
.
Nºdecimais Pr.Unit.Moeda Estrangeira
Este campo permite definir o
número de decimais
a utilizar no preço unitário em moeda estrangeira.
Podem ser definidas 1 a 6 decimais, e inicialmente o valor deste campo será de 2 decimais.
Os cálculos efetuados para o cálculo do valor unitário em moeda estrangeira, terão em conta a configuração do tipo de documento.
Dossier interno a usar por defeito nas opções de cópia
Esta opção permite definir um dossier a ser utilizado por defeito na cópia de dossiers. Quando efetuar uma cópia, a lista de dossiers a copiar, aparecerá com o dossier posicionado conforme o definido.
Reabre o dossier interno que deu origem à linha
Ao ativar esta opção é possível reabrir um dossier interno aquando a finalização, a anulação ou a eliminação de um documento de faturação.
Ou seja, ao finalizar, anular ou ao eliminar um documento de faturação que teve origem num dossier interno, se a opção estiver ativa e se a linha do dossier respetiva não se encontrar totalmente satisfeita, a aplicação reabre o dossier de origem.
A reabertura do dossier de origem não é impeditiva de gravar ou apagar o documento ou dossier.
Nota:
Caso o parâmetro
Usa Processamento Assíncrono (Reentrar no programa e reinstalar triggers)
esteja ativo, apenas é reaberto o dossier quando o Documento de Faturação é processado.
Manter número sequencial na mudança de Ano
Ao ativar esta opção, a numeração dos documentos na mudança do ano passa a ser sequencial, obedecendo à numeração do último documento.
Se tiver
PHC ON
saiba como manter a mesma numeração dos documentos quando se procede à mudança de ano,
aqui
.
Na lista de Lotes, mostra apenas Lotes com stock no armazém da linha
Se ativar esta opção e na coluna "Lote" da grelha do Documento fizer "?" ou fizer clique direito no rato, é apresentada uma listagem com os lotes que tenham stock no armazém indicado na linha.
Caso esta opção se encontre inativa na listagem, serão disponibilizados os lotes com
stock
em qualquer armazém.
Permite regularizar Recibos de Adiantamento associados aos Dossiers Internos
Esta opção está disponível quando, no nó "Integração", está ativa a opção "Conta corrente: Regulariza adiantamentos".
Esta configuração permite a escolha de uma de três de opções: "Não faz nada"; "Pergunta"; "Automático".
Se escolher a opção "Não faz nada", o documento de faturação segue a rotina já existente de regularização de recibos de adiantamento, ou seja, manual.
Se escolher a opção "Pergunta" é apresentada uma lista, onde deve selecionar os recibos a regularizar, caso as linhas do documento provenham de um Dossier Interno.
Se escolher a opção "Automático" nada é mostrado e a regularização de todos os recibos de adiantamento para o cliente é efetuada, caso as linhas do documento provenham de um Dossier Interno.
Utiliza Referências Multibanco/Easypay
Ao ativar esta opção passa a ser possível gerar referências multibanco para o documento em questão.
Assim que ativar esta opção ficam disponíveis no respetivo documento os
campos
relativos às referências multibanco.
Se tiver
PHC ON
poderá saber mais sobre como gerar referências automaticamente nos documentos de faturação, clicando
aqui
.
Permite documentos em rascunho
Esta opção quando ativa permite ter vários documentos de faturação em
rascunho
, ou seja, sem estarem ainda certificados.
Não é possível ter simultaneamente esta opção ativa e a opção
Assina digitalmente apenas ao imprimir
.
Quando se ativar esta opção não podem existir documentos por certificar na série.
Assina digitalmente apenas ao imprimir
Ao ativar esta opção está a indicar que, ao gravar o documento de faturação em questão, será gerada uma assinatura através do algoritmo RSA com base na informação da fatura e na assinatura do documento de faturação anterior. Para gerar a assinatura o algoritmo considera a data da fatura, data e hora da última alteração, nº da fatura de acordo com o formato que surge no SAF-T (PT) e o valor da fatura.
Além da assinatura é gravada a versão da chave utilizada para gerar a assinatura.
Nota:
Se lançar um documento de faturação certificado e, posteriormente, colocar esta opção inativa, a aplicação não deixa alterar nem apagar o documento de faturação, mesmo que a série de faturação deixe de ser assinada, pois encontra-se preenchida.
Série para cópias de documentos originais
Esta opção serve para indicar que se trata de uma série para inserir documentos de faturação que foram originalmente emitidos num livro tipográfico.
Ao emitir um documento de uma série configurada desta forma, irão surgir o campos
Série do doc. manual
e
nº
para indicar o nome e o n.º da série, no ecrã de
Faturação
.
Série para registo manual de documentos produzidos externamente
Esta opção serve para indicar que se trata de uma série para inserir documentos de faturação, manualmente produzidos noutro
software
sem recorrer a importações. Os documentos desta série não são exportados no ficheiro SAF-T (PT) Mensal.
No executável internacional, esta opção passa a designar-se
Série não assinada digitalmente
.
Série não assinada digitalmente
(disponível no executável internacional)
Ao ativar esta opção deixa de ser obrigatório preencher o
tipo de documento para SAFT
na configuração do documento de faturação. Por outro lado, ao gravar um documento de faturação desta série, o mesmo não vai ser assinado.
Série para registo manual ou importação de documentos autofaturados
Esta opção permite criar documento de autofaturação. Apenas está visível com as seguintes premissas:
Documento: Tipo de documento
tenha o valor 1, 2 ou 3;
Série para registo manual de documentos produzidos externamente
ou
Série para documentos importados
apenas uma pode estar ativa.
Notas:
Caso já existam documentos de faturação criados a aplicação não deixa alterar a opção
Série para registo manual ou importação de documentos autofaturados
;
Ao produzir o ficheiro SAFT anual através da opção "Ficheiro SAF-T (PT)", o elemento 4.1.4.2.1. referente ao Estado atual do documento (InvoiceStatus) dos documentos de faturação passa a ser exportado com o valor "S".
Envia SMS para o Motorista com o Código da AT quando comunica por WebService à AT
Esta opção está disponível na gama Enterprise e com o PHC ON ativo e apenas surge quando o parâmetro
Método de envio de documentos de transporte
está como Webservice.
Quando esta opção está ativa, se possuir o módulo PHC CS SMS desktop, depois de comunicar o documento de transporte à AT via webservice, a aplicação envia (ou grava em standby) um SMS para o telemóvel do motorista
Preenche e valida o Local de Carga e o Local de Descarga
Esta opção apenas surge quando o documento é do tipo 1 e o tipo para SAF-T é "FT" ou "FR", e permite que o documento de faturação seja validado o preenchimento do Local de Carga e Descarga.
Série de documentos de faturação fechada
Esta opção quando é ativada fecha a série. Ou seja, deixa de ser possível introduzir documentos na série.
As séries fechadas deixam de aparecer disponíveis para utilização na emissão automática de faturação e na emissão de "Vales de Reembolso".
Numa série de faturação fechada não é possível apagar e anular documentos.
Série de documentos de faturação para emissão de Notas de Crédito referentes a Adiantamentos
Esta opção apenas surge quando o documento é do tipo 3 (Nota de Crédito) e permite indicar que esta série irá ser a utilizada na emissão automática da Nota de Crédito de Adiantamento.
Quando a série tem esta opção ativa, as seguinte opções devem estar inativas:
Conta corrente: Lança os movimentos em c/c automaticamente
Tesouraria: Lança os movimentos em tesouraria REAL
Documento a ser integrado na contabilidade assim que é gravado
Stocks: Lança os movimentos em stock
Assina digitalmente apenas ao imprimir
Série para registo manual de documentos produzidos externamente
Série para documentos importados
E a opção
Utiliza Motivo de Isenção de Imposto nas linhas
deverá estar ativa.
Permite indicar se é um ativo nas linhas
Ao ativar esta opção irá surgir nas linhas do documento de faturação uma coluna que permite indicar que o artigo definido é um ativo.
Configuração de Documentos de Faturação
