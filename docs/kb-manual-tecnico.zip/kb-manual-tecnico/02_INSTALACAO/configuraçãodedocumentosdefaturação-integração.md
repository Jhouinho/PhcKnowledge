---
title: Configuração de Documentos de Faturação - Integração
source: configuraçãodedocumentosdefaturação-integração.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração de Documentos de Faturação - Integração

Integração:
Documento: Tipo de documento
Este campo permite definir o tipo de documento, sendo preenchido com os números 1 a 5:
1 - Documento de faturação (i.e. fatura, fatura-recibo)
2 - Documento para débitos extra-faturação (i.e. nota de débito)
3 - Documento para créditos (i.e. nota de crédito)
4 - Documentos para trânsito de mercadorias (i.e. guia de remessa)
5 - Outros (i.e. fact. proforma)
Documento: É um documento para Vales de Reembolso (POS)
Esta opção está disponível quando o documento a configurar é um documento para crédito (por exemplo uma nota de crédito) e deve estar ativa em todos os documentos de crédito, sobre os quais, pretende efetuar o controlo de artigos devolvidos.
Se não tiver pelo menos um documento de crédito com esta opção ativa, não vai poder utilizar a opção de
Vales de Reembolso
.
Documento de XML
Esta opção permite definir qual o documento de XML que o Documento de Faturação vai utilizar:
Compras;
Encomenda a fornecedor;
Encomenda a cliente;
Faturas;
Pagamento a fornecedor;
Recibo.
Estes documentos são criados no menu "Tabelas" -> módulo Supervisor ->
Documentos XML
.
Documento: É Guia de Remessa a ser faturada
(executável de Espanha)
Esta opção deve ser ativa para que no XML sejam preenchidos os dados da guia de remessa que deu origem à fatura.
Assim, quando a fatura que é enviada no formato Facturae é criada por cópia de uma guia de remessa são preenchidos os elementos de DeliveryNotesReferences (indice 3.1.6.1.12.) com os dados da Guia de Remessa.
Nota:
Para mais informações consulte por favor o tópico Facturae.
Stocks: Lança os movimentos em
stock
Esta opção permite que os movimentos do documento gerem movimentos no ficheiro de stocks.
Stocks: Código do movimento de stocks
Esta opção permite definir o
código de movimentação de Stocks
que este
documento de faturação utiliza:
V/Fatura Entrada;
V/Fatura Recibo Entrada;
Entrada p/ devolução Entrada;
Entrada p/ devolução Entrada;
Entrada prod. Entrada;
Entrada p/trf devolução Entrada;
Stock Inicial, etc.
Stocks: Código de movimento em valor de
stocks
para n.crédito
Esta opção permite definir o
código de movimentação de Stocks
utilizado por documentos de faturação do tipo nota de crédito, provocando alterações no preço de custo
ponderado
.
Stocks: Lança nos produtos vendidos
Permite que os movimentos do documento sejam lançados no ficheiro do
produtos vendidos
.
Conta-Corrente: Lança os movimentos em c/c automaticamente
Permite que os movimentos do documento sejam lançados em c/c.
Conta-Corrente: Regulariza os movimentos em c/c automaticamente
Permite que os movimentos do documento lançados em c/c se auto-regularizem, é necessário ativar a opção
Lança os movimentos em c/c automaticamente
e preencher o seu respetivo código de movimento.
A introdução de um documento configurado desta forma resulta em dois movimentos de Conta-Corrente automaticamente regularizados.
Conta-Corrente: Regulariza adiantamentos
Permite ativar a "página de adiantamentos", para incluir
recibos de adiantamentos
no documento de faturação.
Nota
: Não é possível desativar esta opção se existirem documentos com adiantamentos associados.
Conta-Corrente: Ao gravar pergunta se quer emitir recibo
Esta opção permite emitir um
recibo
quando se grava o documento de faturação. Se o documento de faturação estiver configurado para emitir recibo ao gravar e o ecrã de recibos estiver, por exemplo, em modo de introdução, o utilizador é avisado de que não será emitido um recibo para aquele documento, uma vez que o ecrã referido se encontra aberto.
Nota
: Com esta opção ativa, após a emissão do recibo, aparece o ecrã de
impressão
.
Conta-Corrente: Código de auto-regularização de c/c
Permite definir o
código de movimento de C/C
que ficará registado. É
possível apagar ou anular os documentos de faturação que se
autoregularizam em Conta-Corrente.
Se possuir
PHC ON
poderá obter mais informação, sobre como configurar documentos de compra com autorregularização na conta-corrente de fornecedor carregando
aqui
.
Conta-Corrente: Código do movimento de C/C de multi-pagamento
Esta opção permite definir um código para que seja possível lançar um
Documento de Faturação
através de multi-pagamento.
Conta-Corrente: Código do movimento de c/c
Permite definir o
código de movimento de c/c
que ficará registado.
Conta-Corrente: Série do recibo
Esta opção permite definir diversos tipos de recibos, ou seja, o utilizador pode criar várias séries de recibos no caso de possuir, por exemplo, tipos de vendas distintos ou séries de faturação distintas.
Para definir novos tipos de recibos deve-se aceder à
Configuração de recibos de c/c para clientes
. Para aceder à configuração é possível clicar o botão direito do rato neste campo.
Tesouraria: Lança os movimentos em tesouraria REAL
Esta opção só está disponível se estiver instalada a
Tesouraria
.
Se esta opção estiver ativa, então os valores do documento são lançados em tesouraria real e não em previsões de tesouraria.
Tesouraria: Código do movimento de tesouraria
Esta opção define o código do movimento de tesouraria.
Só está disponível se estiver instalada a tesouraria.
Tesouraria: Local do movimento de tesouraria
Este campo para definir o local do movimento de tesouraria é um
campo tabela
que faz ligação às contas de tesouraria.
Tesouraria: Permite alterar o local de tesouraria no documento
Ao ativar esta opção no documento de faturação aparece o campo
Local do movimento de tesouraria
. Permite alterar o local de tesouraria
no documento
Ao inativar esta opção, o registo criado no ecrã de
Previsões de Tesouraria
tem em conta o local de tesouraria que se encontra definido nos parâmetros de sistema
Conta bancária habitual
.
2º Cliente: Lança os movimentos no 2º Cliente
Esta opção só está disponível nas gamas Advanced e Enterprise.
Ao ativar a opção, o documento é efetuado para um cliente e os movimentos de Conta-Corrente, regularizações e integrações na contabilidade são lançados para um 2º cliente.
Esta funcionalidade apenas existe na introdução direta do ecrã de faturação.
Exemplo
: Podemos associar esta funcionalidade a empresas de
leasing
, em que temos o cliente 1- José Santos e o Cliente 2- Empresa de
Leasing. Ao cliente 1 são faturados 400€, no entanto, os movimentos de conta-corrente, documentos contabilísticos são lançados no 2º cliente, na empresa
leasing
.
2º Cliente: Nome do campo 2º Cliente
Esta opção só está disponível nas gamas
Advanced
e
Enterprise
.
Se o utilizador não pretender utilizar a designação "2º Cliente", pode preencher este campo com a designação pretendida.
Se possuir
PHC ON
poderá obter mais informação, sobre o documento de faturação com dois clientes, carregando
aqui
.
SAFT: Tipo para SAFT
Este campo permite indicar o tipo de documento que será incluído nos elementos InvoiceType, MovementType e WorkType.
Os tipos de documentos existentes são:
Fatura (FT)
Fatura Simplificada (FS)
Fatura-recibo (FR)
Nota de Débito (ND)
Nota de Crédito (NC)
Prémio ou Recibo de Prémio (RP)
Estorno ou Recibo de Estorno (RE)
Imputação a co-seguradoras (CS)
Imputação a co-seguradoras líder (LD)
Guia de Remessa (GR)
Guia de Transporte (GT)
Guia de Movimentação de Ativos Próprios (GA)
Guia de Consignação (GC)
Guia ou Nota de Devolução (GD)
Documento de Conferência (DC)
Fatura de Consignação (FC)
Outro
Nota:
Não é possível alterar este campo em séries que já tenham documentos inseridos e tenham um dos tipos de documento "Documento de faturação (i.e. fatura) ", "Documento para débitos extra-faturação (i.e. nota débito) ", "Documento para créditos (i.e. nota crédito) ", "Documento para trânsito de mercadorias (i.e. guia remessa) " ou "Outro (i.e. fatura proforma) " que tenha a opção
Série de documento a ser assinada digitalmente
ativa.
Código CAE
Permite indicar o Código de Atividade da Empresa.
Nota:
Poderá indicar o código na
Ficha Completa da Empresa
. É necessário que esteja preenchido pelo menos num dos ecrãs.
Comprovativo de pagamento
(Apenas disponível no executável do Peru)
Este campo permite indicar o tipo de documento do comprovativo de pagamento.
Neste campo surgem todos os registos definidos na tabela de Tipos de Documentos de Comprovativo de Pagamento.
Nota:
Para mais informações consulte por favor o tópico Constituição da Tabela de Tipos Doc. de Comprov. de Pagamento.
Configuração de Documentos de Faturação
