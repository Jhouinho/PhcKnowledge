---
title: Configuração de Dossiers
source: configuraçãodedossiers.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração de Dossiers

A configuração de Dossiers internos é de grande importância, pois permitirá criar novos dossiers internos e definir a forma como os mesmos se comportam na aplicação. Existem duas formas distintas para aceder à criação, ou configuração, dos dossiers internos:
Clicar o botão direito do rato no nome do Dossier interno.
Selecionar a opção
Configurar Dossiers Internos
no menu Tabelas.
De seguida cria-se ou configura-se o Dossier interno, sendo a criação do mesmo nada mais do que a configuração de um tipo de dossier novo.
Funcionamento
O método de configuração é bastante simples, podendo-se ativar as opções através dum simples clique numa das diversas check-boxes (clicando por exemplo na "caixa" à esquerda do texto "Utiliza campo para IVA nas linhas") ativando assim esta opção, ou através do simples processo de escrita (colocando o número 2 em "Nº de decimais nas quantidades") definindo assim a quantidade de casas decimais que o campo de quantidade irá ter.
Há primeiramente que dar um nome ao dossier a configurar. Como tal existem os seguintes campos a preencher:
Nome no singular
,
no plural
e
abrv
.
Uma vez preenchidos estes campos o dossier fica identificado, pelo que, a partir do momento que este tiver documentos introduzidos, estes campos deixam de poder ser alterados.
Deve gravar o nome do dossier a criar e só depois iniciar a sua configuração.
Campos das Linhas
Os campos seguintes estão localizados nas linhas do Dossier interno.
Quantidade 1 (real
)
Este é o campo para indicar quantidade nas linhas do dossier.
Quantidade real a 1 nas novas linhas
Esta opção permite definir que cada linha nova assuma automaticamente o valor 1 no campo da quantidade.
Quantidade 2 (previsional
)
Esta quantidade é alternativa, será a quantidade orçamentada ou fornecida, permitindo assim por exemplo apurar desvios. Esta opção é utilizada para ser atualizada por outro documento, permitindo desta forma saber se o dossier já se encontra satisfeito ou fornecido.
Quantidade 2 com valor próprio
Ao ativar a opção serão adicionadas duas colunas, uma para o valor unitário da segunda quantidade e outra com o total (quantidade multiplicada vezes o valor unitário).
Também através desta quantidade alternativa, e mediante a ativação/desativação do
parâmetro
respetivo, poderá atualizar-se a quantidade nos dossiers internos com valor positivo ou negativo.
Preço indicativo
Esta opção permite definir um 2º preço que poderá ser um preço teórico, por exemplo: orçamentado (Orçamento) ou o previsto (Folha-de-obra). Esta opção é bastante útil pois permitirá obter análises com desvios entre os preços indicados.
Preço real
Este é preço real utilizado na linha do dossier e que será multiplicado com a quantidade para o cálculo do Total.
Salto do preço real para a referência
Esta opção permite que, durante a introdução, o cursor se desloque do campo do preço real para o campo da referência.
Campos numéricos 1 e 2
Estes campos permitem introduzir nas linhas os mais variados valores numéricos.
Tabela de tipos nas linhas
Esta opção permite obter uma classificação nas linhas dos Dossiers, totalizando os 4 tipos possíveis para posterior análise.
Aqui deve definir-se a que corresponde o tipo 1, 2, 3 e 4 e ter em atenção que o software assume automaticamente o tipo 4 em todas as linhas, pelo que se pretendermos, poder deixar o campo Tipo em branco nos dossiers internos, devemos assim definir um dos 4 tipos.
Se possuir
PHC ON
poderá obter mais informação, sobre como classificar as linhas de um dossier interno, carregando
aqui
.
Campo de posição
Nos dossiers que tenham esse campo preenchido na configuração, está disponível nas linhas uma coluna cujo nome corresponde ao que foi preenchido na configuração. Ao adicionar uma linha a um desses dossiers, esse campo será automaticamente preenchida com o valor numérico máximo de todas as restantes linhas, acrescentado de 1. Esse campo poderá ser alterado em qualquer altura com nºs, letras ou qualquer caracter desejado.
Nome da data nas linhas
Permite colocar uma data em cada linha.
Nome de data de entrega de:
Permite colocar uma data para determinar um prazo de entrega, neste caso a data inicial prevista. Deste modo, será possível observar uma listagem de todos os dossiers que possuem linhas com a data de entrega preenchidas.
Nome de data de entrega até:
Permite colocar uma data para determinar um prazo de entrega, neste caso a data final prevista. Deste modo, será possível observar uma listagem de todos os dossiers que possuem linhas com a data de entrega preenchidas.
Campo de observações 1, 2 e 3
Serve para colocar um campo de observação em cada linha.
1ª e 2ª coluna de item
Esta opção permite colocar em cada linha um item para identificação da mesma. Deste modo será possível dividir um Dossier por itens ou por pontos.
Campos do dossier
Além dos campos anteriormente descriminados, existem campos adicionais que proporcionam uma melhor gestão da informação.
Estes campos podem e devem ser configurados pelo utilizador, não em termos de propriedades pois os campos de texto são de texto, os numéricos são numéricos, mas poderão ser configurados em termos de cabeçalhos de acordo com as necessidades de cada um.
Descritivo principal do Dossier
Serve para definir um campo do Dossier onde irá constar um título identificativo que permita uma identificação mais rápida nas listagens. Este campo é especialmente útil no processo de cópia de documentos. Quando se copia um dossier para dentro de outro, surgirá na lista dos dossiers o campo de descritivo e será ainda possível efetuar uma procura através da informação contida neste campo. Para mais informações consulte por favor o capítulo sobre
Opções na cópia de dossiers
.
Campo numérico 1,2,3 e 4
Estes campos permitem fazer associações a outros ficheiros, como por exemplo o dos vendedores e dos técnicos (caso o utilizador possua o módulo PHC CS Suporte desktop). Assim, ao abrir um cliente neste Dossier, irá ser preenchido de forma automática o nome do vendedor/técnico. Para este campo funcionar de forma automática é necessário ativar a opção
O campo num. 1 é o vendedor
ou
O campo num. 4 é o técnico
. Será portanto o utilizador a decidir quais os campos a incluir em cada tipo de Dossier.
Relativamente ao campo 3,
O campo num.3 é o campo da propriedade
, este só é incluído se o utilizador possuir os módulos PHC CS Gestão desktop e PHC CS Imóveis desktop ou o módulo PHC CS Obras desktop. O campo em referência faz a ligação dos Dossiers Internos à propriedade.
Se possuir
PHC ON
poderá obter mais informação sobre "como copiar informação entre Documentos de Faturação, Dossiers Internos e Compras", através do nosso
filme
.
Nome da data inicial/final
Estas datas serão colocadas no dossier, onde poderão servir de data de início, data de execução, data de limite, data entrega, etc.
Sugere primeiro armazém com stock
Se esta opção estiver ativa ao inserir a referência de um artigo ou depois quando se altera a quantidade, é inserido automaticamente, o primeiro armazém que satisfaça as quantidades pedidas para esse artigo.
Nota
: É necessário que o documento esteja configurado para originar um
movimento
de saída de stock.
Armazém por defeito
Permite definir o armazém habitual para este tipo de dossier. Caso este campo não esteja preenchido, o programa utilizará o parâmetro de faturação que determina o armazém habitual. Esta opção só se encontra disponível se o utilizador possuir o Módulo PHC CS Stocks desktop.
Se também possuir o Módulo PHC CS Logística desktope alterar ou limpar o
Armazém por defeito
automaticamente é limpo o campo
Zona por defeito
na página Logística.
Sugere armazém habitual (entradas)
Se esta opção estiver ativa ao dar entrada de uma referência é sugerido o armazém onde já tenha existido movimento do artigo.
Texto final 1,2 e 3
Estes campos servem para escrever um texto livre que irá constar no Dossier em "Outros dados". Deverá indicar os nomes dos campos neste local (por exemplo Condições de pagamento, Modo de entrega, Local de entrega, Observações, etc.).
Se estes campos no seu nome possuírem as palavras "Local" e "Entrega", aquando da introdução de um dossier a informação do Local de Descarga da ficha do cliente passa para esse campo no dossier.
Campo Aprovado
Este campo apenas se encontra disponível na gama Enterprise e deve ser preenchido quando se pretende usar o Sistema de Aprovações. Permite dar uma outra designação ao campo Aprovado que existe nos dossiers internos.
Controla cópias
Este campo só se encontra disponível na gama Enterprise e só fica ativo quando o
Campo Aprovado
, explicado anteriormente, se encontra preenchido.
Esta opção controla a cópia de dossiers, caso estes não se encontrem aprovados; ou seja, quando está ativa apenas é possível copiar documentos aprovados.
Permite Aprovar Doc. Aprovado sem nível
Este campo só se encontra disponível na gama Enterprise e depende do preenchimento do
Campo Aprovado
.
Esta opção permite alterar dossiers aprovados sem nível definido de aprovação.
Quando se utiliza o Sistema de Aprovações é sempre possível copiar um dossier aprovado para outro que não utilize o Sistema de Aprovações.
Impede Impressões
Este campo só se encontra disponível na gama Enterprise e só fica ativo quando o
Campo Aprovado
se encontra preenchido. Esta opção permite inibir o botão de impressão de documentos que usem o Sistema de Aprovações e que não se encontrem aprovados.
Com esta opção selecionada (caso o documento não esteja aprovado), o botão de Imprimir fica desabilitado e as opções de menu Impressões Definidas e Impressões Definidas de seguida não aparecem.
Nota
: Se tiver esta opção inativa e o
parâmetro
Ao introduzir um dossier pergunta se quer imprimir
ativo, ao gravar o dossier é apresentada a janela que permite imprimir o dossier interno.
Para mais informações relativamente a estes campos, caso possua a gama Enterprise, consulte por favor o tópico relativo ao
Sistema de Aprovações
.
Campo alfanumérico 1,2 e 3
Esta opção tem um funcionamento semelhante aos campos numéricos, podendo estes campos serem associados a outros ficheiros.
Para tal o utilizador deve possuir o módulo PHC CS Suporte desktop.
Neste caso, esses campos devem estar preenchidos com os mesmos valores dos parâmetros dos
equipamentos
relativos ao nome a adotar para
Marca
,
Modelo
e
Nome do Nº série principal
.
Uma vez cumpridos estes requisitos, sempre que numa
Intervenção
ou num
Pedido de Assistência
se abrir um dossier interno, estes campos são automaticamente atualizados no dossier com os valores existentes nos mesmos campos na Intervenção ou no Pedido de Assistência..
Campo em tabela 1 e 2
Esta opção é idêntica à anterior mas o campo é apresentado em formato de tabela.
O campo em tabela 2 poderá ser utilizado, por exemplo, como o Status do dossier, assim para as encomendas poderá dizer que está
em aberto
,
em produção
,
cancelada
, etc. Este campo tem um outro campo associado: observações da tabela 2, o qual poderá ser útil para colocar uma justificação ou outra informação sobre o conteúdo do campo em tabela.
Campos lógicos 1 a 8
Esta opção permite criar campos lógicos, isto é campos do tipo sim/não. Pode por exemplo criar os campos lógicos "Adjudicado" para o Dossier "Proposta" ou "Confirmado" para o Dossier da encomenda.
Configuração
Utiliza desconto nas linhas
Ao ativar esta opção poderá introduzir descontos comerciais nas linhas do documento. Esta opção permite ainda definir a quantidade de descontos a utilizar, podendo-se definir até 6 descontos.
Quando esta opção se encontra ativa e se encontram descontos definidos, passa a existir nas opções das linhas dos dossiers duas outras opções relacionadas com a
atribuição de descontos
.
Nota:
Sempre que se substitui um artigo, que já esteja registado na linha do Dossier Interno, os campos destes descontos são atualizados de acordo com o estipulado para o novo artigo.
Atenção
: Se um dossier possuir mais descontos do que outro documento/compra/dossier para onde é copiado, o desconto é copiado e considerado para os cálculos, contudo, como não fica visível para o utilizador parece que os valores estão errados.
Esta opção influencia todas as outras existentes na aplicação que funcionem com descontos, nomeadamente os
dossiers de preços
.
Utiliza descontos em valor nas linhas
Ao ativar esta opção passa a ser possível utilizar descontos em valor nas linhas do dossier, ficando disponível nas linhas mais uma coluna
Valor de Descontos em Euros
. O desconto em valor, entra nos cálculos com os outros descontos da seguinte forma, primeiro são aplicados os descontos percentuais à linha e posteriormente subtrai-se o desconto em valor multiplicado pela quantidade.
Se possuir
PHC ON
poderá obter mais informação sobre como efetuar descontos em valor nas linhas dos Dossiers Internos, carregando
aqui
.
Pergunta se quer copiar de outro Dossier
Quando o utilizador criar um novo Dossier e se tiver esta opção ativa, então ser-lhe-á perguntado se quer copiar os dados de outro Dossier.
Não controla a data de emissão do documento
Esta opção permite ao utilizador introduzir documentos que tenham data de emissão inferior a documentos já existentes, ou data de emissão superior a documentos posteriores ao introduzido.
Nota:
Esta opção apenas está disponível se uma das opções
Série para registo manual de documentos produzidos externamente
ou
Série para cópia de documentos originais
estiver ativa.
Sem acesso à opção de não passar a referência dos artigos
Se estiver ativa, não permite que qualquer utilizador ao copiar as linhas de outro dossier (seja nos dossiers internos, na faturação, nas compras), tenha a possibilidade de escolher se quer copiar ou não a referência dos artigos do documento utilizado na cópia.
É um Dossier de avenças ou quotas
Serve para definir que o Dossier controla a emissão periódica de avenças ou quotas. Para mais informações sobre este tipo de dossiers consulte por favor o capítulo sobre
Avenças
.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Gestão desktop.
Se tiver
PHC ON
poderá aprender um pouco mais sobre como criar um Dossier Interno de Avenças, a partir do nosso
vídeo
e na nossa
iDirecto
.
Permite alterar o número sequencial de Dossier
Esta opção possibilita alterar o número sequencial do Dossier durante a introdução. Para alterar o número basta simplesmente digitar o novo número no respetivo campo.
Em séries de dossier certificados apenas será possível alterar o número do dossier se for o 1º do ano.
Mostra o botão de conferência de quantidades
Ao ativar esta opção surge mais um botão no dossier, permitindo assim executar a conferência de quantidade. Para mais informações sobre esta opção consulte, por favor, o tópico de
Conferência de quantidades
.
Esta opção só se encontra disponível se o utilizador possui o módulo PHC CS Stocks desktop.
Conferência de quantidades com descontos
Se esta opção estiver ativa surgirão mais colunas na conferência de quantidades, para assim se poder indicar os descontos. A quantidade de colunas de descontos depende da configuração acima indicada (utiliza descontos nas linhas).
Esta opção só se encontra disponível se o utilizador possui o módulo de PHC CS Stocks desktop.
Conferência de quantidades com preços
Se esta opção estiver ativa surgirá mais uma coluna na
conferência de quantidades
, para assim se poder indicar o preço dos artigos.
Esta opção só se encontra disponível se o utilizador possui o módulo PHC CS Stocks desktop.
Permite introduzir a descrição técnica ou completa no dossier
Através desta opção é possível automatizar a introdução duma descrição longa da referência no dossier interno. Para mais informações sobre esta opção consulte por favor o manual de Stocks.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop.
Se tiver
PHC ON
poderá aprender um pouco mais sobre como configurar as descrições técnicas e os idiomas a utilizar nos artigos, simplificando e automatizando processos na sua empresa, com reflexo directo na comunicação com o cliente, carregando
aqui
.
Utiliza opções de impressão de proposta
Com esta opção é possível criar uma exportação para o Microsoft Word que produza um ficheiro com os dados da proposta. O ficheiro contém todos os dados do dossier, assim como a descrição técnica do artigo, o preço unitário, total e acumulado por linha, e os extensos (no mesmo campo da descrição técnica).
Esta opção só se encontra disponível se o utilizador possui o módulo PHC CS Stocks desktop
Passou a estar existir no MENU de dossiers internos a opção de menu, "Proc.texto com opções de impressão", que irá gerar um ficheiro de exportação a ser usado no Word.
No dossier interno na página de Outros dados, aparecem os campos relacionados com esta exportação e que são os seguintes:
IVA incluído - indica se os campos criados na exportação PPRUNIT (preço unitário), PPTOTAL (total na linha) e PACUMULADO (acumulado na linha) têm ou não o IVA incluído. Para que estes campos sejam criados, é necessário incluir no mapa os campos: DEBITO (venda), EDEBITO (Euro: venda), TTDEB (total venda), ETTDEB (Euro: total venda), IVA (taxa iva), IVAINCL (iva incluído).
Se as opções Pr.Unit extenso, Pr.totais extenso, Iva Pr.totais extenso ou Iva Pr.Unit extenso estão selecionadas é criado um registo que irá conter os extensos no campo de descrição técnica.
Pr.Unit extenso: Coloca por extenso o preço unitário;
Pr.totais extenso: Coloca por extenso o preço total da linha;
Iva Pr.Unit extenso: Coloca por extenso o iva do preço unitário;
Iva Pr.totais extenso: Coloca por extenso o iva do preço total da linha.
Para que se processem todos estes dados é necessário existir o campo REF (referência), que irá dar origem ao campo POBSTEC (observações técnicas do artigo).
Todos os registos são separados por um espaço em branco, terminado o ficheiro com a palavra FIM no campo WORDFIM.
Para mais informações sobre o funcionamento de impressão de texto para o Word, consulte por favor o capítulo
Ligação a processador de texto
.
Controla dívidas do cliente c/ idades acima do limite máximo
Permite controlar as dívidas de clientes para além do limite estabelecido na ficha do mesmo. Desta forma, caso o limite esteja mesmo ultrapassado, não será possível emitir o dossier.
Documento para adicionar ao arquivo morto
Esta opção marca o tipo de dossier interno para ser utilizado na opção
Transferir para arquivo
.
Controla encomendas canceladas de clientes
Este campo permite efetuar o controlo das encomendas canceladas.
Com esta opção ativa em conjunto com a opção Encomendas Canceladas na ficha do cliente, o utilizador fica impedido de elaborar novas encomendas a clientes, sendo-lhe mostrada uma mensagem informativa da situação do cliente, sempre que tentar fazer encomendas para esse cliente.
As Encomendas Canceladas são válidas para introdução direta em dossiers internos, cópia de dossiers internos via opções diversas ou através das linhas, emissão automática de dossiers internos, processamento especial de encomendas.
Se o cliente tiver o visto na opção Encomenda Canceladas e o dossier não fizer esse controlo, o dossier é lançado sem ser emitida qualquer mensagem ao utilizador.
Para que o dossier efetue o controlo das Encomendas Canceladas, é apenas necessário ter um visto nesta opção.
Se tiver
PHC ON
poderá aprender um pouco mais, sobre as opções de cancelar encomendas e faturação a clientes, de forma a controlar fácil e eficazmente a situação de cada um, carregando
aqui
.
Calcula descontos por quantidade ou valor Just in time
Permite ao utilizador configurar, para cada dossier, que a percentagem de
descontos por quantidade ou valor
é calculada no momento da introdução do artigo nas linhas.
Esta configuração só funciona quando o dossier está em modo de introdução. Ao alterar um documento já existente para obter o mesmo resultado tem que selecionar a opção
Descontos por Quantidade ou Valor
no menu de opções das linhas.
Utiliza Armazém apenas no Cabeçalho
Ao ativar esta opção o campo Armazém ficará disponível no cabeçalho do Dossier.
Se possuir o módulo PHC CS Logística desktop (disponível nas gamas Advanced e Enterprise) e se tiver o Dossier configurado como
Utiliza Armazém apenas no Cabeçalho
e como
Utiliza as quantidades do próprio documento na sugestão automática de Alvéolos
, irá constatar que após alterar o armazém no cabeçalho do Dossier Interno, a aplicação pergunta se deseja tentar atualizar automaticamente os Alvéolos. Caso responda afirmativamente, inicia-se o processo de sugestão automática de Alvéolos para todas as linhas do documento, de acordo com o novo armazém indicado no documento.
Em termos visuais, é disponibilizado um ecrã que indica uma previsão do tempo restante para que termine a atualização. Ao nível de performance, o método utilizado para a sugestão automática dos alvéolos é muito mais rápido na sugestão automática de Alvéolos em Dossiers Internos com muitas linhas. É possível interromper o processamento, pressionando a tecla ESC.
Dica
: Em Dossiers Internos de Transferência entre Armazéns, com os armazéns no cabeçalho, caso se pretenda alterar o armazém de origem e o armazém de destino, aconselha-se a que não se atualize os Alvéolos após a alteração do armazém de origem, mas apenas após a alteração do armazém de destino. Dessa forma, a atualização dos alvéolos de origem e destino é feita de uma só vez.
Nota
: Quando já existem dossiers do mesmo tipo lançados, não é possível ativar esta opção. Nesta situação apenas é possível inativar.
Se possuir
PHC ON
saiba mais sobre como anular a inversão de armazéns na cópia de dossiers internos>, clicando
aqui
Controla artigos bloqueados para entrada
Esta opção permite definir se o dossier controla artigos bloqueados, independentemente das opções de movimento de stocks e da tabela que utiliza (fornecedores...) que deixam de interferir neste controlo.
Controla artigos bloqueados para saída
Esta opção permite definir se o dossier controla artigos bloqueados, independentemente das opções de movimento de stocks e da tabela que utiliza (clientes, contactos...) que deixam de interferir neste controlo.
Estas duas configurações que permitem controlar se o artigo está bloqueado para entrada/saída, produzem efeitos não só na emissão direta de Dossiers, no ecrã de
Dossiers Internos
, mas também no
Lançamento Rápido de Dossiers
, na
Emissão de Encomendas
ao Fornecedor, à Entidade e ao Armazém Central e para quem possui a Gama Enterprise na Emissão Automática de Dossiers Internos.
Relativamente à cópia de Dossiers Internos, aqui a opção que prevalece é a definida nas opções de cópia. Ou seja, mesmo que o dossier de destino esteja configurado para bloquear artigos, se a opção
Não passa artigos bloqueados
se encontrar inativa, os artigos passam na mesma. Só não passam se esta opção se encontrar ativa.
Utiliza campo para IVA nas linhas
Ao ativar esta opção passa a ser possível visualizar três campos:
IVA, taxa de IVA e se o artigo tem ou não IVA incluído.
Para além da consulta é possível alterar o valor de cada um destes campos na linha do artigo. Deve-se ter em conta que quando a opção está inativa o artigo pode ou não ter IVA, tudo depende da forma como este se encontra configurado.
Utiliza Refª interna nas linhas
Através desta opção é possível utilizar o campo da Refª interna nas linhas do dossier. Para mais informações sobre este campo consulte por favor os
Parâmetros gerais
. Este campo de Refª interna é atualizado em algumas tabelas, por exemplo movimentos de stocks e produtos vendidos, consoante a configuração do documento, isto é, se estiver configurada neste local (nas linhas) então passa o valor das linhas, caso contrário passa o do cabeçalho.
Nota
: O campo Refª interna pode ter um nome diferente, já que este é configurado pelo utilizador.
É um dossier de custos de Refª interna
Ao ativar esta opção define-se que o dossier é um dossier referente a custos, o que é importante para algumas análises. A Análise global de referência interna e o Monitor de Dossiers internos podem utilizar a informação deste campo (bem como do campo explicado a seguir a este). A Análise global de refª interna só está disponível se o utilizador possuir o módulo PHC CS Gestão desktop, mas a
Análise de Dossiers internos
está disponível no menu dos Dossiers internos (se possuir apenas o módulo PHC CS Suporte desktop) ou também no menu das Análises (se possuir o módulo PHC CS Gestão desktop).
Para mais informações sobre a Análise global de Refª interna consulte por favor o manual do módulo PHC CS Gestão desktop.
É um dossier de receitas de Refª interna
Opção idêntica à anterior mas para dossiers de receitas.
Nota
: No caso de existirem dossiers que não são nem de custos nem de receitas, ambas as opções têm de ficar inativas.
Utiliza metros lineares nas linhas
Permite a utilização de metros lineares nas linhas do documento.
Metros lineares representa que estamos a vender quantidades de uma medida fixa. Esta medida fixa vem do campo configurado nos parâmetros de stocks Metros Lineares.
Neste caso o campo Partes configurado nos parâmetros da faturação deverá ser por exemplo Unidades.
No documento de faturação configurado desta forma aparecem duas colunas: Unidades e Comprimento (este campo fica com o valor preenchido na ficha do artigo) e a quantidade vendida é o produto destas duas colunas.
Exemplo
: Rolo de tecido vendido ao metro quadrado. No entanto sabe-se que o rolo tem 1 metro e 60 de largura.
Quando se vende 3 metros de tecido, sabe-se que se está a vender 3 x 1,6=4,8 metros quadrados de tecido.
Neste caso na ficha do artigo deve estar indicado que a largura do tecido é 1,6 metros.
Ao vender indica-se no campo partes que se está a vender 3 metros. Os 1,6 de largura são automaticamente introduzidos no campo respetivo da fatura e a quantidade (4,8 metros quadrados) também é automaticamente criada.
Utiliza m2 nas linhas
Permite a utilização de metros quadrados nas linhas do documento. Neste caso surgem três colunas definidas nos parâmetros da faturação (Partes, Altura e Largura). A quantidade vendida é o produto da Altura pela Largura multiplicado pelas Partes.
Utiliza m3 nas linhas
Permite a utilização de metros cúbicos nas linhas do documento. Neste caso surgem quatro colunas definidas nos parâmetros da faturação (Partes, Altura, Largura e Espessura). A quantidade vendida é o produto da Altura pela Largura pela espessura multiplicado pelas Partes.
Ao introduzir um dossier interno que utilize metros lineares, metros quadrados, ou metros cúbicos, copiando o mesmo desde um dossier interno (documento de origem), existe a possibilidade de registar no documento de origem quantas partes já foram "fornecidas" (se estiver preenchido o Parâmetro "
Se utiliza m2 ou m3 - nome do campo PARTES2 (fornecido)
".
Notas
: É possível no mesmo dossier, a utilização nas linhas, de metros lineares e [metros quadrados (m2) ou metros cúbicos (m3)] em simultâneo.
No caso do documento estar configurado com 2 opções, a descrição da coluna referente aos dados "Altura" será a definida no parâmetro
Metros Lineares
.
Os nomes dos campos PARTES e COMPRIMENTO, bem como alguns outros campos, podem ser alterados nos
Parâmetros de Dossiers
.
No dossier ao alterar a quantidade das linhas o campo PARTES é recalculado de acordo com as seguintes fórmulas:
Utilizando metros lineares e metros2; (PARTES x COMPRIMENTO X LARGURA = QTT)
Utilizando metros lineares e metros3; (PARTES x COMPRIMENTO X LARGURA X ESPESSURA = QTT)
Utilizando metros lineares; (PARTES x COMPRIMENTO = QTT)
Ao introduzir atualiza as promoções
Através desta opção é possível aplicar as promoções que foram definidas pelo utilizador.
Isto significa que na introdução ou na gravação de um dossier interno, serão atualizados os preços ou as quantidades das referências com promoções.
Da mesma forma, perante artigos com quantidade alternativa, sobre os quais recaia a promoção, ao emitir um dossier para estes artigos, nas linhas das promoções aparecem os valores relativos às
quantidades alternativas
. Ou seja, ao indicar a quantidade na linha do dossier, a quantidade alternativa do artigo de promoção é, (se o
parâmetro
da gestão das promoções se encontrar ativo), automaticamente preenchida.
Para mais informações sobre as promoções, consulte o tópico
das Promoções
.
Nota
: Esta opção só se encontra disponível se possuir o módulo PHC CS Gestão desktop. Para mais informações consulte por favor o respetivo manual.
Utiliza os campos de cor e tamanho
Esta opção permite a utilização de cores e tamanhos e só se encontra disponível se o utilizador possuir o módulo PHC CS Grelhas desktop. Para mais informações sobre esta opção consulte por favor o respetivo manual.
Utiliza semáforos para gerir multiutilização
Através desta opção é possível gerir a gravação simultânea de documentos. Para esse efeito existe o funcionamento e o semáforo está ligado durante o processo de gravação do dossier, sendo apenas desligado quando a gravação termina. Desta forma, quando se está gravar um dossier, se alguém tenta gravar outro ao mesmo tempo, são dadas as seguintes opções ao utilizador:
Forçar a gravação
Voltar atrás e tentar mais tarde
Pôr o programa a tentar automaticamente (esta opção utiliza os parâmetros já existentes para nº de tentativas e segundos entre tentativas). Para mais informações consulte por favor os
Parâmetros gerais
.
Utiliza tabela de classificação nas linhas
Ao ativar esta opção passa a existir nas linhas uma coluna do tipo
tabela do utilizador
.
Esta tabela por defeito já contém um registo: "NORMAL". Fazendo clique direito neste campo, o utilizador acede ao ecrã de manutenção de registos desta tabela.
Sempre que seja alterado esse campo (que ao criar a linha fica vazio) para "ACESSÓRIO" ou "OPÇÃO", o valor total da linha é posto a ZERO (não sendo alterado o valor unitário nem a quantidade) e não podendo esse valor ser alterado. De notar que se se voltar a alterar a classificação da linha para vazio ou "NORMAL", o valor total da linha será recalculado de acordo com o valor unitário, quantidade e descontos. Desta forma as linhas nessas condições não contarão para o total do documento. Da mesma forma que não contarão para análises de totais, faturação de dossiers (se possuir o módulo PHC CS Gestão desktop), totalização de linhas, descontos por quantidade, etc.
Utiliza um vendedor por linha
Através desta opção é possível ter um vendedor em cada linha do documento, sendo o mesmo atualizado aquando da introdução do cliente/fornecedor (conforme a tabela que utiliza) e aquando da introdução de novas linhas.
Quando se preenche a referência na linha, a coluna é reatualizada de acordo com a referência introduzida e a relação com a tabela Zonas/Vendedor. Para mais informações sobre esta opção consulte por favor o manual de Vendedores e Comissões.
Quando um dossier interno nessas condições é copiado para um documento de faturação (caso o utilizador possua o módulo PHC CS Gestão desktop), essa coluna (se o documento de faturação esteja configurado da mesma forma) é copiada tal como está, ou seja, quando é copiada para o documento de faturação, não é reatualizada.
Entra para Mapas Intrastat (entrada)
Através desta opção é possível definir que o dossier faz parte do ciclo do Intrastat, neste caso como entrada de mercadorias. Desta forma surgirão novos campos no Dossier, onde se deverá preencher os respetivos dados. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Intrastat desktop. Para mais informações consulte por favor o manual do Intrastat.
Entra para Mapas Intrastat (saída)
Idêntico á opção anterior mas para saída de mercadorias.
Se tiver
PHC ON
poderá aprender um pouco mais sobre Intrastat, carregando
aqui
.
Dossier Ligado a Negócios
Este campo, uma vez selecionado permite que o dossier em questão seja um dossier ligado aos Negócios do Módulo PHC CS CRM desktop. O Dossier assume automaticamente uma
nova página
com campos relativos aos negócios, de forma a permitir identificar o negócio a que o dossier criado se refere.
Tem campo de unidade
Ao ativar esta opção passa a ficar disponível a coluna de Unidade nas linhas do dossier.
Reabre o dossier interno que deu origem à linha
Ao ativar esta opção é possível reabrir um dossier interno aquando a anulação ou eliminação de um documento de faturação, ou seja, ao anular ou ao eliminar um documento de faturação, que teve origem num dossier interno, se a opção encontrar-se ativa, a aplicação reabre o dossier de origem se o mesmo não se encontrar totalmente satisfeito. A reabertura do dossier de origem não é impeditiva de se gravar ou apagar o documento ou dossier.
Caso seja um documento configurado como documento de rascunho, apenas é reaberto o dossier quando finalizar o documento rascunho.
Caso seja uma alteração ao documento, apenas é reaberto o dossier se o documento já estiver finalizado e o campo
Não processou triggers na introdução
esteja inativo.
Nota:
Caso o parâmetro
Usa Processamento Assíncrono (Reentrar no programa e reinstalar triggers)
esteja ativo, apenas é reaberto o Dossier quando este é processado.
Manter número sequencial na mudança de Ano
Ao ativar esta opção a numeração dos documentos, na mudança do ano, passa a ser sequencial, obedecendo à numeração do último documento.
Se tiver
PHC ON
saiba como manter a mesma numeração dos documentos quando se procede à mudança de ano,
aqui
.
Permite associar Recibos de Adiantamento
Esta opção está disponível quando a opção
Tabela que utiliza
está igual a "CL|Clientes" e quando as opções
É um dossier de Orçamentos
ou
É um dossier de Trabalhos a mais
ou
É um dossier de Trabalhos a menos
ou
É um dossier de Auto de Medição
estão inativas.
Quando esta opção está ativa, fica disponível no ecrã de Dossiers Internos o botão de
Adiantamento(s)
.
Na lista de Lotes, mostra apenas Lotes com stock no armazém da linha
Se ativar esta opção e se na coluna "Lote" da grelha do Dossier fizer "?" ou fizer clique direito no rato, é apresentada uma listagem com os lotes que tenham stock no armazém indicado na linha.
Caso esta opção se encontre inativa, na listagem serão disponibilizados os lotes com stock em qualquer armazém.
Série para cópias de documentos originais
Esta série permite indicar que é uma série para registo de documentos que foram anteriormente emitidos manualmente em papel.
Quando esta opção está ativa, ficam disponíveis no ecrã de dossiers internos os campos "Nº da série do Documento Manual" e "Nº do Documento Manual" para que se possa indicar qual a série e nº do documento original emitido em papel.
Neste tipo de documentos, o campo Versão da Chave Privada (versaochave) é preenchido de acordo com o Ofício Circulado nº 50000/2012 ponto 2.4.1.2, isto é, nº da versão da chave + "-" + Tipo para assinatura digital + "M" + um espaço + a série manual + "/" + o nº do documento manual.
Quando se imprime um documento configurado com esta opção ativa, o campo "Texto com nº de certificação para IDU" apresenta a expressão "Cópia do documento original" e separada por um hífen a expressão Tipo para assinatura digital + "M" + um espaço + a série manual + "/" + o nº do documento manual.
Série de documento a ser assinada digitalmente
Ao ativar esta opção, está a indicar que ao gravar o dossier interno em questão será gerada uma assinatura através do algoritmo RSA com base na informação do dossier interno e na assinatura do dossier anterior. Para gerar a assinatura o algoritmo considera a data do dossier, data e hora da última alteração, nº do dossier de acordo com o formato que surge no SAF-T (PT) e o valor do dossier.
Além da assinatura é gravada a Versão da Chave utilizada para gerar a assinatura.
Série para registo manual de documentos produzidos externamente
Esta opção serve para indicar que se trata de uma série para inserir dossiers internos, manualmente produzidos noutro software sem recorrer a importações.
Ao imprimir um documento de uma série configurada desta forma, o campo
Texto com nº de certificação para IDU
apresenta o texto "Cópia do documento original", como por exemplo: "Software PHC - vPdv-Processado por programa certificado nº 0006/AT-Cópia do documento original".
Os dados referentes à assinatura não serão iguais aos dados da assinatura original, pois a assinatura é diferente.
Nota
: Quando esta opção está ativa, o campo
Tipo para SAF-T (e para assinatura nos documentos certificados)
não pode ser do tipo
"--" Não entra para Saf-t
, e a opção
Série de documento a ser assinada digitalmente
é sempre ativada.
Tipo para SAF-T (e para assinatura nos documentos certificados)
Este campo permite escolher o tipo de documento que irá aparecer no SAF-T bem como o tipo de documento que será usado na assinatura de documentos certificados.
Deve, assim, ser selecionada uma das seguintes opções: --, GR, GT, GA, GC, GD, DC.
Não é possível alterar este campo em séries que já tenham registos e que estejam configuradas para assinar digitalmente.
Quando é selecionada uma das opções GR, GT, GA, GC ou DC, ao gravar um dossier interno é validada a quantidade das linhas, não podendo ser igual a 0 (zero).
Identificador da Série
Esta opção permite indicar o identificador da série, sendo depois o seu conteúdo utilizado na produção do ficheiro SAF-T (PT) nos elementos "OriginatingON" e "DocumentNumber".
Este campo não permite valores numéricos e por defeito a aplicação coloca o campo como "BO".
Envia SMS para o Motorista com o Código da AT quando comunica por WebService à AT
Esta opção está disponível na gama Enterprise e com o PHC ON ativo e apenas surge quando o parâmetro
Método de envio de documentos de transporte
está como Webservice.
Quando esta opção está ativa, se possuir o módulo PHC CS SMS desktop, depois de comunicar o documento de transporte à AT via webservice, a aplicação envia (ou grava em standby) um SMS para o telemóvel do motorista.
Não passa a referência do artigo
Permite escolher se se pretende passar a referência do artigo na
cópia das linhas de dossiers
ou não, ficando apenas disponível esta opção na configuração do dossier.
Notas
:
Quando ativa, a opção de acesso não permite a escolha de qualquer utilizador na passagem da referência do artigo na cópia das linhas de dossiers, e permite, a quem tenha acesso à configuração dos dossiers internos, a possibilidade de configurar de modo a que esta não apareça a qualquer utilizador. Ao mesmo tempo escolher se pretende passar ou não a referência do artigo, passando a ser um default para todos os documentos daquele dossier. Não esquecendo que se movimentar stock entre documentos, ou dossiers, para evitar duplicação de stock, nunca passa referência, independentemente da opção.
Ao ativar a opção "Não passa referência do artigo", os campos "Actualiza precos e descontos", "Actualiza preços e mantem os descontos do documento de origem " ou "Actualiza preço de custo com o valor actual" passam a modo de não-edição, não podendo ser selecionados. É necessário desativar a opção "Não passa referência do artigo" se o utilizador pretender ativar qualquer das 3 opções referidas.
Utiliza produtos compostos
Ao ativar esta opção será possível inserir produtos compostos no dossier, adicionando mais uma coluna nas linhas do dossier interno. É possível também visualizar o preço dos componentes dos produtos compostos; para isso é necessário ter em atenção os preços/quantidades dos componentes e do produto composto, para que o somatório dos componentes dê o preço do produto composto.
Sem ativar esta opção não é possível visualizar os componentes do produto composto e o utilizador visualiza apenas, na linha dos dossiers, a referência do artigo como se não se tratasse de um composto.
O funcionamento dos produtos compostos é diferente dos outros produtos. Para mais informações sobre produtos compostos consulte por favor o manual dos Stocks.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop.
Quando esta opção se encontra ativa e os componentes destes produtos são visualizados nas linhas, como se encontra explicado no parágrafo anterior, surge a seguinte opção:
Permite incluir novos componentes
Esta opção determina se este tipo de documento a ser configurado permite incluir novos componentes na estrutura do composto.
Caso esta opção se encontre ativa nas opções das linhas vai ficar disponível a opção de
Introduzir um componente na estrutura do composto
.
Ao lançar um artigo composto, no respetivo dossier é lançada a sua estrutura pré-definida e as respetivas quantidades por unidade.
Caso insira um novo componente na estrutura do composto, a aplicação não irá preencher automaticamente os descontos nessa linha.
Sempre que se verificar alterações ao artigo composto, a estrutura não é atualizada pela sua origem, mas sim pela estrutura definida no próprio dossier.
Existe no entanto uma exceção que se verifica quando, apesar do artigo composto se encontrar lançado no documento, a sua quantidade for zero, pelo que quando se atualizar a quantidade do artigo composto "pai", as quantidades dos componentes são calculadas pelos valores definidos na sua estrutura pré-definida.
Recalcula o custo do produto composto
Uma vez ativa, esta opção determina, se ao alterar a estrutura do artigo composto, os custos do mesmo (artigo principal) são ou não recalculados.
Diversos
Valida as alterações à quantidade principal
Esta opção permite controlar as alterações feitas ao campo da quantidade do dossier. Isto significa que quando se altera o campo da quantidade dum dossier já gravado, é calculada a percentagem da variação, podendo o utilizador ser avisado ou impedido de gravar o documento. Quando se ativa esta opção é possível definir diversos níveis de segurança, sendo os mesmos explicados de seguida.
Variações: de _ a _ % não avisa
Se a variação estiver compreendida entre as percentagens indicadas, não existirá qualquer tipo de aviso ou restrição quanto à alteração da quantidade.
Variações: de _ a _ % apenas avisa
Se a variação estiver compreendida entre as percentagens indicadas. O utilizador será advertido sobre a situação.
Variações: Maior que _ % só permite com a password
Se a variação estiver compreendida entre as percentagens indicadas, será necessário indicar a password indicada neste local, para assim se poder gravar o dossier com a nova quantidade.
Ignora a data fechada geral e utiliza a seguinte data fechada
Na parametrização do Software existe uma opção para definir uma Data fechada. Caso exista uma situação especial, pode-se definir uma data fechada só para um determinado tipo de dossier, ignorando assim a data que se encontra estipulada nos
Parâmetros
.
Código do terminal portátil
Neste local é possível definir o código do terminal portátil, para assim estabelecer a ligação entre a respetiva aplicação e o dossier interno.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Terminais desktop. Para mais informações consulte por favor o respetivo manual.
Código do dossier no terminal portátil
Neste local é possível definir o código do dossier no terminal portátil, para assim estabelecer a ligação entre a respetiva aplicação e o dossier interno.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Terminais desktop. Para mais informações consulte por favor o respetivo manual.
Código CAE
Permite indicar o Código de Atividade da Empresa.
Nota:
Poderá indicar o código na
Ficha Completa da Empresa
. É necessário que esteja preenchido pelo menos num dos ecrãs.
Integração
As seguintes opções encontram-se disponíveis se o utilizador possuir o módulo PHC CS Stocks desktop. Para mais informações é favor consultar o respetivo manual.
Utiliza estado de conferência
Esta opção de configuração só se encontra disponível se o utilizador ativar o parâmetro
Utiliza Dossiers em Conferência (tem de instalar triggers)
.
Um Dossier Interno que esteja configurado com esta opção ativa, passa a apresentar na página "Outros Dados", a opção (junto ao botão de fechar dossier) que permite antes de gravar um dossier, especificar se ele se encontra em conferência, ou não. O titulo desta opção pode variar, em função do descritivo indicado (ou não) no campo
Nome a utilizar ao invés da Conferência
(campo que apenas surge disponível quando o dossier se encontra em conferência).
Ao introduzir um Dossier Interno que esteja configurado para usar estado de conferência, este surge logo por defeito com a opção "Dossier em conferência" selecionada. O utilizador pode depois alterar esta opção, caso possua o
acesso necessário
.
Caso um dossier esteja em conferência no momento da gravação, então esse dossier é gravado na base de dados, mas sem serem corridos os procedimentos habituais, tais como:
atualizar stock;
inserir movimentos de stock;
verificar se os artigos têm stock;
atualizar equipamentos;
verificar se existem equipamentos agregados ao dossier sem número de serie preenchido;
se o cliente vai ultrapassar o plafond de crédito.
Fundamentalmente, se um dossier tiver sido gravado em conferência, significa que o mesmo ainda não existe fisicamente, apesar de estar gravado na base de dados.
Ao gravar (e só apenas ao gravar) um dossier em "conferência", são ignoradas as validações e atualizações que são efetuadas aquando da gravação de um dossier em "não conferência".
Nota
: Ao gravar um dossier, se existirem configurados eventos de utilizador, regras de utilizador, ou valores por defeito, para serem gerados no momento da gravação do dossier, estes serão sempre gerados, quer o dossier esteja ou não em conferência. Para que ao gravar um dossier em conferência esta situação não ocorra será necessário definir corretamente o evento, a regra, ou o valor por defeito, para que os mesmos não sejam gerados, aquando da gravação do dossier em conferência.
A funcionalidade de poder gravar um dossier em estado de conferência, possibilita o preenchimento de um dossier por etapas.
Numa primeira etapa, pode introduzir-se o dossier apenas como um registo provisório na Base de Dados (gravando o dossier, com o campo "Dossier em Conferência" ativado).
Numa segunda etapa, quando se considerar que o dossier está totalmente finalizado, então poderá inativar-se o referido campo ("Dossier em conferência"), ficando o dossier em não conferência. Ao gravar o dossier, depois de inativar o campo
Dossier em conferência
, serão executados todos os passos que seriam executados caso se tivesse gravado o dossier de uma só vez sem definir que o mesmo se encontrava em conferência.
Existe também a hipótese de colocar em conferência, um dossier que já tenha sido gravado em não conferência.
Os procedimentos que serão corridos neste caso, consistem na anulação de todas as alterações das tabelas (com exceção do BO e BI) que foram afetadas pela gravação do dossier. No fundo, para as tabelas afetadas pela gravação do dossier (com exceção do BO e BI), é como se o dossier tivesse sido eliminado, mas neste caso, o mesmo mantém-se gravado na base de dados e acessível ao utilizador, para que mais tarde possa ser alterado para "não conferencia" (de modo que ao voltar a gravar o dossier, sejam novamente executados os mesmos passos que seriam efetuados caso se tivesse inserido um dossier de uma só vez, sem definir que o mesmo estava em conferência).
Se possuir
PHC ON
poderá obter mais informação sobre a configuração de um dossier em estado de conferência, carregando
aqui
.
Movimenta as reservas de clientes nos Stocks
Ao lançar um Dossier com esta opção ativa irá ser lançada a quantidade da referência no campo
reservado a clientes
no ficheiro de Stock. Esta operação terá influência sobre a quantidade do Stock previsto.
Ao ativar esta opção, fica disponível a opção
Permite Cativar Stock
.
Só deixa abrir reservas de clientes se existir stock disponível no armazém de pedido
Esta opção permite complementar a anterior, ou seja, o utilizador só poderá emitir reservas se existir stock disponível para tal.
Movimenta as reservas de fornecedores nos Stocks
Idêntico à opção de reservas de clientes, mas para fornecedores.
Ao ativar esta opção, fica disponível a opção
Permite Pré-Cativar Stock
.
Movimenta a quantidade em receção
Esta opção é importante, pois permitirá dar entrada de artigos possuindo por exemplo apenas uma Guia de remessa, ou seja, sem dar entrada direta em stock, as quantidades ficam disponíveis para serem faturadas (por exemplo). Ao emitir o dossier que movimenta quantidades em receção, é possível não possuir ainda o preço de custo (documento não-valorizado), não se podendo atualizar o preço de custo ou de venda.
No entanto um dossier deste tipo (poder-se-ia chamar por exemplo Guia de remessa) pode satisfazer (copiar) a Encomenda do fornecedor e poderá ainda ser copiada para o documento de compra definitivo. Caso o utilizador coloque o preço de custo no dossier, já será possível atualizar os preços de custo e de venda, mas no documento não será possível obter análises de compras corretas, já que a referência só ficará disponível para a integração na Contabilidade.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Gestão desktop.
Movimenta a quantidade do utilizador na ficha do artigo
Esta opção permite a utilização do campo "quantidade especial" na ficha do artigo. Poderá portanto ser utilizada, por exemplo, para lançar consignações.
Documento de XML
Esta opção está disponível se tiver ativo o
parâmetro
, permite definir qual o documento de XML que o dossier vai utilizar. Para mais informações sobre esta opção consulte por o manual de
Configurações documentos XML
.
O
Módulo PHC CS Documentos Eletrónicos desktop
também utiliza esta opção, pois é através dela que se seleciona o documento
XML Livre
ou o documento
XML Padrão
.
Código para o D.I. na exportação de um XML Padrão
Esta opção serve para definir o código identificador do dossier que lhe deu origem.
Desta forma, a aplicação irá preencher o campo "ReftipoDoc" do documento eletrónico gerado de uma fatura com este código, desde que a mesma tenha sido criada através de um dossier interno.
Movimenta Stocks
Esta opção serve para definir se o Dossier Interno movimenta Stock. Ao selecionar esta opção, terá que selecionar um
Código de movimento 1
.
Se tiver
PHC ON
poderá aprender um pouco mais sobre como proceder ao lançamento de stock inicial, carregando
aqui
.
Avisa stocks negativos
Serve para definir se o utilizador é avisado em caso de Stocks negativos. Esta opção só se encontra disponível se o dossier movimentar Stocks.
Não deixa gravar com stocks negativos
Serve para definir que o Dossier interno não poderá ser gravado, caso um dos artigos indicados no Dossier tenha stock negativo. Esta opção só se encontra disponível se o dossier movimentar Stocks.
Se possuir
PHC ON
poderá obter mais informação, de forma a impossibilitar a realização de faturação de artigos que não existem em stock, carregando
aqui
.
É um Dossier de transferência entre armazéns
Através desta opção define-se o dossier como um dossier de transferência entre armazéns, sendo adicionada a coluna do segundo armazém na linha do dossier. Para definir qual o segundo armazém por defeito, basta definir o respetivo número nos
Parâmetros
.
Quando esta opção está ativa, ou seja, trata-se de um dossier de transferência, para atualizar equipamentos tem que movimentar stocks, isto é, tem que estar ativa uma das seguintes opções:
Movimenta stocks;
Movimenta as reservas de clientes nos stocks;
Movimenta as reservas de fornecedores nos stocks;
Movimenta a quantidade em recepção.
Se tiver
PHC ON
poderá aprender um pouco mais sobre como poderá criar Dossiers Internos de Transferências entre Armazéns, carregando
aqui
.
É um Dossier de produção
Define este Dossier como sendo um Dossier de produção. Desta forma será possível criar diversos dossiers para simular um ciclo de produção, onde serão utilizadas as matérias-primas e a mão-de-obra para produzir um artigo final. Para mais informações sobre esta opção consulte por favor o capítulo de
Exemplos de dossiers
.
Ao gravar, atualiza os valores do produto produzido com a soma das matérias primas
Se tiver esta opção ativa e apenas um artigo de produção nas linhas, irá verificar que ao gravar o dossier são atualizados os valores do produto produzido com a soma das matérias-primas, apenas no respetivo dossier. Só será possível ativar esta opção se tiver a opção "É um dossier de produção" ativa.
Ao gravar, pergunta se pretende atualizar os preços do produto produzido na ficha do artigo
Se tiver esta opção ativa e apenas um artigo de produção nas linhas, irá verificar que ao gravar o dossier abre um ecrã de atualização de preços que vai atualizar os valores do produto produzido com a soma das matérias-primas, apenas na ficha do respetivo produto produzido. Só será possível ativar esta opção se tiver a opção "É um dossier de produção" ativa.
Com esta opção ativa, ao gravar o dossier abre um ecrã de atualização de preços com as seguintes opções:
- "Atualizar os preços de venda dos artigos produzidos com os valores de Transf." - esta opção, permite atualizar na ficha do artigo o preço de venda do produto produzido com a soma dos valores transformados.
- "Atualizar os preços de custo dos artigos produzidos com o custo dos transformados" - esta opção, permite atualizar na ficha do artigo o preço de custo do produto produzido com a soma do custo dos transformados.
Se as duas opções anteriores estiverem ativas irá verificar que ao gravar o dossier abre o ecrã de atualização de preços que vai atualizar os valores do produto produzido com a soma das matérias-primas na ficha do respetivo produto produzido e também vai atualizar os valores do produto produzido com a soma das matérias-primas no dossier.
Ao gravar, atualiza os valores do produto produzido com a soma das matérias primas
Permite, quando se trata de um só artigo em produção, atualizar os valores do produto produzido com a soma das matérias primas.
Permite Cativar Stock
Esta opção apenas aparece disponível, quando se encontra ativa a opção
Movimenta as reservas de clientes nos Stocks
.
Ao ativar esta opção num determinado tipo de Dossier Interno, passará a surgir nas linhas desse Dossier um campo denominado de "Cativo". Este é um campo lógico, que quando ativo, indica que a quantidade introduzida para determinado artigo (numa determinada linha) se encontra Cativada para aquele dossier.
Esta opção não é permitida caso a opção
Tipo para SAF-T (e para assinatura nos documentos certificados)
esteja preenchida.
Para mais informações acerca do funcionamento das quantidades cativadas no Sofware PHC, consulte o tópico
Funcionamento do Stock Cativo e Pré-Cativo
.
Permite Pré-Cativar Stock
Esta opção apenas aparece disponível quando se encontra ativa a opção
Movimenta as reservas de fornecedores nos Stocks
.
Ao ativar esta opção num determinado tipo de Dossier Interno, poderá depois no dossier reservar uma quantidade que ainda não existe em stocks mas que está encomendada ao fornecedor, para que seja utilizada apenas para satisfazer uma determinada encomenda de cliente.
Esta opção não é permitida caso a opção
Tipo para SAF-T (e para assinatura nos documentos certificados)
esteja preenchida.
Título da 1ª coluna da listagem
,
Título da 2ª coluna da listagem
,
Título da 3ª coluna da listagem
Estas opções ficam disponíveis se as opções
Permite Cativar Stock
ou
Permite Pré-Cativar Stocks
estiverem activas. Ao configurar estes títulos é possível nas listagens das opções das linhas de dossiers internos "
Pré-Cativar para Encomendas de Clientes
" e/ou "
Pré-Cativar Encomendas a Fornecedores
" consultar a informação relativa aos campos das linhas dos documentos configurados no grupo "Campos das linhas" em
Nome da data nas linhas
,
Nome de data de entrega de:
e
Nome de data de entrega até:
.
Preço utilizado para Preço de Custo
Esta opção de configuração permite selecionar o preço que vai ser utilizado como preço de custo dos artigos introduzidos no dossier. Pode ser selecionado um dos seguintes preços:
Preço de Custo Ponderado
Último Preço de Custo
Preço de Custo Atual
Esta opção só é considerada quando este campo está preenchido, ou seja, sempre que este campo estiver vazio, o valor a ser considerado para Preço utilizado para preço de custo é o definido nos
Parâmetros de Stocks e Serviços
para o Custeio de Stocks.
Esta configuração é também considerada para os cálculos da
estrutura de custos
, para quem possua o PHC CS Projeto desktop.
Relativamente ao preço de custo quando se efetuam copias entre dossiers, para que os artigos copiados mantenham o preço de custo em conformidade com a configuração do dossier, é necessário ativar a opção de cópia
Actualiza o preço de custo com o valor actual
.
Existe ainda uma situação específica cuja influência desta configuração é determinante. Trata-se dos artigos com Lotes. Quando o dossier possui a configuração do preço de custo a utilizar, o preço utilizado na linha do dossier é o que se encontra definido na
ficha do Lote
e não da referência do artigo em si. Assim, por exemplo, num dossier configurado para utilizar o Último Preço de Custo, ao digitar na linha um artigo com lotes, o custo dessa linha irá ser o valor que se encontra no campo Último Preço de Custo do Lote, e não do artigo.
Apenas na gama Enterprise, existe a possibilidade de se efetuarem Lançamentos Rápidos em dossiers internos. Esta funcionalidade também respeita a configuração do preço de custo a utilizar que se encontrar definida no dossier, no qual se vão efetuar os lançamentos rápidos.
Preço que utiliza para preço unitário
Neste local define-se qual o preço que vai ser utilizado para preço unitário: preço de custo, preço de venda, preço médio de custo ou último preço de custo.
Lote a movimentar por defeito
Se o utilizador possuir o módulo PHC CS Lotes desktop, poderá definir neste local o Lote que deve ser utilizado por defeito nas linhas do dossier.
Se o utilizador não pretender definir nenhum lote por defeito, deverá indicar neste local o valor "0" (zero). Se optar por esta opção, ao introduzir um dossier, o utilizador deverá indicar o lote a movimentar nas linhas do mesmo. Se o Lote aqui indicado se encontrar
inativo
ao introduzir um dossier interno e inserir a referência do lote em questão, a aplicação sugere outro Lote que esteja ativo. Não coloca o lote definido no campo por este se encontrar inativo.
Código do movimento 1/2
Estas opções (Código de movimento 1 e Código de movimento 2) permitem definir os códigos de movimento do Dossier, isto é, o código para as saídas e o código para as entradas. Se o Dossier
Movimentar Stock
, o Código de Movimento 1 é de preenchimento obrigatório.
Logística
Esta página está disponível se possuir o Módulo PHC CS Logística desktop e permite efetuar a configuração de dossiers associados ao processo de logística.
Opções Linhas
Mostra o stock atual de cada linha do dossier
Esta opção permite visualizar o Stock atual do artigo nas linhas do Dossier. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop.
Mostra o stock previsto de cada linha do dossier ( exclui a quantidade especial)
Esta opção permite visualizar o stock previsto do artigo introduzido nas linhas do dossier sendo apresentado consoante o artigo, a cor/tamanho ou lote e armazém deste.
Salta do desconto 2 para a referência
Esta opção permite definir que, quando preenche o Desconto 2 no Dossier, é criada uma nova linha e o cursor salta para a coluna referência. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop. Para mais informações é favor consultar o manual do módulo PHC CS Stocks desktop.
Salta da referência para a quant. real/previsional
Permite definir que após preenchimento da referência, se o utilizador clicar na tecla Enter o cursor salta para o campo da quantidade (real ou previsional). De notar que se os campos Quantidade 1 (real) e Quantidade 2 (previsional) estiverem vazios, na configuração, esta opção não faz nada.
Cria linha após digitar referência
Permite ao utilizador, após digitar a referência e clicar na tecla Enter, criar uma nova linha no documento. Esta opção não pode ser escolhida em conjunto com a anterior, ou seja, ao clicar numa e noutra se estiver ativa é desativada automaticamente e vice-versa.
Mostra o campo do utilizador 6 da ficha do artigo
Permite visualizar. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop. Para mais informações é favor consultar o manual do módulo PHC CS Stocks desktop.
Utiliza o campo para satisfação total
Esta opção serve para fornecer sempre na totalidade os artigos do dossier, isto quando se opta por fazer a Faturação Automática. Desta forma o dossier só é emitido se as linhas que possuem esta opção possam ser totalmente satisfeitas. Caso exista uma linha (que tenha esta opção ativa) que não tenha stock suficiente, não será emitido o respetivo documento de faturação para a linha em questão, o Documento de Faturação é emitido apenas com as linhas que tenham stock suficiente, satisfação total. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Gestão desktop. Para mais informações é favor consultar o respetivo manual.
Tem centro Analítico nas linhas
Permite definir por linha um centro analítico diferente. O centro de custo colocado na linha de um dossier passa para o movimento de stock (caso queira integrar na contabilidade).
Mostra unidades nas linhas
Esta opção quando está ativa permite que a coluna unidades se encontre sempre visível nas linhas do dossier mesmo se este não utilizar unidades alternativas.
Mostra quantidade alternativa nas linhas
Permite visualizar a quantidade alternativa nas linhas, ou seja ao emitir um dossier com referências em determinada unidade (por exemplo em caixas) é possível observar outra unidade (por exemplo garrafas). Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop. Para mais informações é favor consultar o manual do módulo PHC CS Stocks desktop.
Na conversão arredonda para a quantidade inteira
Permite arredondar sempre para a quantidade inteira quando se utiliza a quantidade alternativa. Esta opção só se encontra disponível se o utilizador possuir o módulo de Stocks.
Para mais informações é favor consultar o manual do módulo PHC CS Stocks desktop.
Na cópia de dossiers internos esta opção, uma vez ativa, permite que o campo NCUNSUP seja automaticamente atualizado no documento destino.
Não executa a conversão automática de quantidades
Permite definir que a conversão da quantidade alternativa não deve ser feita. Desta forma, quando se altera a quantidade alternativa, não é recalculada a quantidade habitual da referência. Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Stocks desktop. Para mais informações é favor consultar o manual do módulo PHC CS Stocks desktop.
Mostra a versão de produção do artigo (Manufactor) nas linhas
Ao ativar esta opção a aplicação passa a apresentar o campo "Versão" nas linhas das encomendas de clientes do PHC CS que corresponde ao campo de alternativa de produção no PHC Manufactor CS.
Nota
: Esta opção apenas está disponível se tiver o PHC Manufactor CS interligado com o PHC CS.
Mostra o Fornecedor habitual nas linhas
Se este campo estiver ativo, então surgirá nas linhas do Dossier Interno o campo "Forn. Habitual".
O Campo "Forn. Habitual", como o próprio nome indica, irá indicar o Fornecedor Habitual do Artigo de cada linha do dossier. Este campo, nas linhas do Dossier, possibilita a emissão de Dossiers Internos de Fornecedores com os dados das linhas. Este procedimento é efetuado através da opção de Menu
Gerar Enc. Fornecedores
, opção esta que apenas surge disponível, quando o dossier estiver configurado com a opção "Mostra Fornecedor Habitual nas Linhas" ativa.
Procura a referência por 0+nº série
Ao ativar esta opção a procura dos artigos será efetuada através do seu nº de série e não pela sua referência, atualizando assim o ecrã de entrada/saída de
equipamento
. Se pretender efetuar a procura incremental através da referência do artigo terá que desativar esta opção. Só está disponível se possuir os módulos PHC CS Suporte desktop ou PHC CS Equipamento desktop.
Mostra Nºs de Série nas Linhas
Esta opção apenas produz efeitos se possuir o Módulo PHC CS Suporte desktop. Uma vez ativa, esta opção vai permitir que os números de série do documento sejam visíveis nas linhas. Assim, depois de
selecionar o equipamento
e gravar o dossier, poderá visualizar, na linha da referência de stock do equipamento, os respetivos números de série.
Outras configurações
Mostra a coluna "Fornecedor" ao observar as linhas de dossiers internos a partir da ficha do cliente
Na criação de um novo tipo de dossier interno é necessário ativar esta opção caso se queira visualizar a informação do fornecedor nas linhas dos dossiers, a partir da ficha do cliente.
No caso de se encontrar ativa para esta opção é possível determinar níveis de acesso.
Sem controlo de acessos
: A coluna "Fornecedor" fica disponível para todos os utilizadores;
Acesso privado para um utilizador
: nesta modalidade pode escolher-se um determinado utilizador, que será o único a ter acesso à coluna "Fornecedor" nas linhas dos dossiers internos;
Acesso X à Tabela Y
: nesta modalidade pode especificar-se um determinado tipo de acesso a uma determinada tabela (ex: Acesso de Consultar à Tabela FL), ficando apenas autorizados a visualizar a coluna, os utilizadores que possuam o acesso indicado;
Acesso por tipo de Perfil
: nesta modalidade pode escolher-se um perfil existente. Neste caso só os utilizadores que fizerem parte do perfil indicado, terão acesso à coluna "Fornecedor" nas linhas dos dossiers internos.
Se a opção não estiver ativa para um determinado tipo de dossier, ou não se verificar o acesso definido, quando o utilizador observar as linhas do dossier, a partir do botão de
consultar os dossiers internos do cliente
na ficha do cliente, a coluna "Fornecedor" não é disponibilizada.
Controla plafond do cliente ultrapassado
Através desta opção é possível controlar se o cliente já ultrapassou o seu plafond, sendo o utilizador avisado sobre a situação.
Soma o saldo de c/c e de letras para controlar o plafond
Esta opção apenas surge se a opção
Controla plafond do cliente ultrapassado
estiver ativa e permite definir que o saldo total é a soma do saldo da conta corrente mais o saldo de letras, sendo necessário, para tal, ativar a opção anterior. A opção só se encontra disponível se o utilizador possuir o módulo PHC CS Letras desktop.
É um Dossier de refªs e preços de fornecedores
Serve para ter um Dossier que funciona como um preçário individualizado de referências e preços de fornecedores. Desta forma, quando se lança um documento de compra, é utilizado o preço de custo e o IVA do dossier e não os valores indicados na ficha do artigo.
Esta opção só se encontra disponível se o utilizador possui o módulo PHC CS Gestão desktop.
É um Dossier de preços por cliente
Serve para definir um Dossier que funciona como um preçário individualizado de referências e preços para clientes. Desta forma é possível utilizar o preço desse dossier nos documentos de faturação, ignorando o preço de venda da ficha do artigo e ainda atualizar o IVA pelo que está indicado no respetivo dossier.
Esta opção só se encontra disponível se o utilizador possuir o módulo PHC CS Gestão desktop.
Se tiver
PHC ON
poderá aprender um pouco mais sobre como criar um dossier que funcione como um preçário individualizado de referências e preços para clientes, carregando
aqui
.
Utiliza o da sede se não existir do estabelecimento
Ao emitir um documento de compra para um Fornecedor estabelecimento, irá utilizar os preços de custos e tabela de iva do dossier do estabelecimento, caso não exista dossier de preços de estabelecimento e esta opção esteja ativa, irá utilizar o dossier de preços da sede correspondente ao estabelecimento em questão.
Utiliza o da sede se não existir do estabelecimento
Ao emitir um documento de Faturação para um Cliente estabelecimento, irá utilizar os preços de venda e tabela de iva do dossier do estabelecimento, caso não exista dossier de preços de estabelecimento e esta opção esteja ativa, irá utilizar o dossier de preços da sede correspondente ao estabelecimento em questão.
Utiliza os dossiers de refªs e preços de fornecedores
Esta opção permite ao utilizador definir se o dossier em questão utiliza as tabelas de preços definidas ou não. Se o dossier estiver configurado com
É um Dossier de refªs e preços de fornecedores
" esta opção não se encontra disponível.
Utiliza os dossiers de preços por cliente
Esta opção permite ao utilizador definir se o dossier em questão utiliza as tabelas de preços definidas ou não. Se o dossier estiver configurado com
É um Dossier de preços por cliente
esta opção não está disponível.
Esta opção também permite criar dossiers que funcionem como tabelas de preços próprias, para determinados clientes. Estes preços podem ser designados, através da alteração do próprio valor do artigo, de forma manual no dossier de preços, ou através da atribuição de descontos. Assim, os dossiers que utilizam dossiers de preços por cliente, devem ter também a opção "Utiliza desconto nas linhas" ativa, de forma a que a aplicação possa aplicar os descontos encontrados na
tabela de preços
.
Câmbio (Vendas / Compras)
Esta opção permite definir o câmbio que o dossier interno utiliza.
Dossier interno a utilizar por defeito nas opções de cópia
Esta opção permite definir um dossier a ser utilizado por defeito na cópia de dossiers. Assim, quando efetuar uma cópia, a lista de dossiers a copiar aparecerá com o dossier posicionado conforme o definido.
É acessível a partir do Suporte intranet web
Esta opção só está disponível se possuir o Phc CS Web.
Serve para disponibilizar este tipo de dossier na aplicação Suporte intranet web.
É acessível a partir do Crm web
Esta opção só está disponível se possuir o Phc CS Web.
Serve para disponibilizar este tipo de dossier na aplicação Crm web.
Estas opções em conjunto com o acesso "Internet. Consultar", determinam se o dossier está disponível nas listas de seleção que aparecem nos ecrãs de Dossiers Internos, Consulta/Listagem de Dossiers Internos e Cópia de Dossiers Internos.
É acessível a partir do Front Web
Esta opção só está disponível se possuir o Phc CS Web.
Serve para disponibilizar este tipo de dossier na aplicação Front Web, por exemplo para que o cliente possa consultar as suas propostas, as suas encomendas, as tabelas de preços, deve este tipo de dossiers ter esta opção ativa.
Permite criar/alterar no Front Web
Uma vez ativa, esta opção permite que se criem ou alterem dossiers no Front Web e a opção acima descrita fica automaticamente selecionada.
É acessível a partir do Suporte extranet web
Esta opção só está disponível se possuir o Phc CS Web.
Ao clicar esta opção, está a disponibilizar para consulta, este tipo de dossier interno na aplicação Suporte extranet web.
É acessível a partir do Gestão web
Uma vez ativa, esta opção permite que se crie ou altere este tipo de dossier interno no Gestão Web.
É acessível a partir do Pocket Suporte
Uma vez ativa, esta opção permite que este dossier seja sincronizado para o Pocket Suporte.
Utiliza IEC-A
Esta opção serve para ativar ou desativar a utilização de IEC-A, imposto especial de consumo - álcool, no dossier interno.
Pergunta se quer lançar um gasto no Frota
Esta opção só está disponível se o utilizador possuir o módulo PHC CS Frota desktop.
Com esta opção ativa, após a gravação do Dossier, a aplicação pergunta ao utilizador se quer introduzir um gasto no Frota.
Tabela que utiliza
Esta opção permite definir qual a tabela ativa, podendo-se selecionar:
Fornecedores - a tabela é a "FL"
Clientes - a tabela é a "CL"
Entidades - a tabela é a "AG"
Contactos - a tabela é a "EM"
Se tiver
PHC ON
poderá aprender um pouco mais sobre IEC-A, carregando
aqui
.
Nota
: As tabelas disponíveis dependem das aplicações que o utilizador possuir. Assim a tabela de contactos (EM), somente se encontra disponível se o utilizador adquiriu o módulo PHC CS CRM desktop (Customer Relationship Manager) e a tabela fornecedores (FL), só está disponível se possuir o módulo PHC CS Gestão desktop.
Nº de decimais nos preços em Euros
Esta opção permite definir as casas decimais utilizadas nos preços.
Quando se efectuam
cópias
entre dossiers internos, o dossier destino assume as decimais aqui definidas para os preços.
Nº de decimais nas quantidades
Esta opção permite definir as casas decimais nas quantidades.
Nota:
No caso da coluna "Stock" esta apresentará as casas decimais definidas nesta opção.
Nºdecimais Pr. Unit. Moeda Estrangeira
Este campo permite definir o número de decimais, a utilizar no preço unitário em moeda estrangeira.
Podem ser definidas 1 a 6 decimais, e inicialmente o valor deste campo será de 2 decimais.
Os cálculos efetuados para o cálculo do valor unitário em moeda estrangeira, terão em conta a configuração do tipo de dossier.
Guia de Remessa a ser faturada
(executável de Espanha)
Esta opção deve ser ativa para que no XML sejam preenchidos os dados da guia de remessa que deu origem à fatura.
Assim, quando a fatura que é enviada no formato Facturae é criada por cópia de uma guia de remessa são preenchidos os elementos de DeliveryNotesReferences (indice 3.1.6.1.12.) com os dados da Guia de Remessa.
Nota:
Para mais informações consulte por favor o tópico "Facturae".
Outras Integrações
Atualiza os preços de venda de artigos com os parâmetros definidos para atualização via compras
Esta opção permite definir que o Preço de Venda é atualizado da mesma forma que acontece nos documentos de compras, utilizando para esse efeito os parâmetros das compras (na atualização dos preços de venda com os parâmetros definidas nas compras, não devem ser esquecidos os parâmetros de Stocks e Serviços,
Fórmula para o cálculo da margem bruta
).
Esta opção só funciona se:
o utilizador possuir o módulo PHC CS Gestão desktop;
o dossier não se encontrar em
estado de conferência
;
o dossier estiver configurado para
movimentar stocks
;
o dossier tem o
código de movimentos de stocks
preenchido, com um código de entrada que tem ativa a opção
Actualiza o preço de custo ponderado do artigo
.
Para mais informações sobre esta opção, consulte por favor o capítulo dos
Parâmetros de Compras
.
Quando lança atualiza o preço de custo da tabela dos artigos
Esta opção permite atualizar o campo
Preço de Tabela
na ficha do artigo, aquando da gravação do dossier.
Quando lança atualiza o fornecedor habitual nos artigos
Esta opção permite que ao lançar um dossier interno, seja atualizado o fornecedor habitual nas fichas dos artigos incluídos nesse dossier. Para além do fornecedor habitual, são simultaneamente atualizados os descontos (com os 2 primeiros descontos que sejam utilizados pelo dossier) e caso se trate de um dossier em moeda estrangeira, são também atualizados na ficha dos artigos, a moeda e o preço de custo de importação.
Ao ativar esta opção juntamente com a opção
Actualiza o pr.custo em moeda estr. do artigo composto
, permite que sejam atualizados os preços de importação dos componentes. A atualização do preço de custo em moeda estrangeira do artigo composto, representa a soma dos preços de custo de importação registados nas fichas dos seus artigos componentes.
Corrige custo de vendas de artigos quando grava o dossier
Ao gravar um dossier interno que tenha esta opção ativa, para cada artigo desse dossier será corrigido o custo de vendas, à semelhança do que acontece quando se grava um documento de compra e o Parâmetro de Compras
Corrige custo de vendas de artigos comprados quando grava a compra (muito lento)
está ativo.
O processo de correção do custo das vendas dos artigos, aquando da gravação de um dossier, é idêntico ao que é executado aquando da utilização da opção
Corrigir erros no stock atual deste artigo
(opção disponível a partir do Menu da ficha dos artigos), tendo ativa a opção
Atualizar o custo das vendas
e tendo inativas as subopções
atualizar todos os preços de custo ponderados das vendas
e
forçar a atualização de todos os custos das vendas (muito lento)
.
Com esta opção ativa, é também possível configurar para que ao gravar o dossier se executem as seguintes opções:
Corrige o custo de vendas em docs. já contabilizados
Atualiza o pr. custo ponderado do artigo composto
Atualiza o pr. custo em moeda estrangeira do artigo composto
Estas duas últimas opções de configuração, faz sentido, que apenas sejam ativadas em dossiers que utilizem produtos compostos.
Para mais informações acerca destas opções, consulte por favor o capítulo sobre
Gestão de Stocks
.
Corrige o custo de vendas em docs. já contabilizados
Tendo esta opção ativa, então ao gravar o dossier atualizar-se-ão os custos das vendas nos documentos e respetivos movimentos já contabilizados.
Atualiza o preço custo ponderado do artigo composto
Ao gravar um dossier, que tenha esta opção ativa, são atualizados automaticamente os preços de custo ponderado de artigos compostos, se os artigos que os compõem forem lançados no mesmo dossier.
Nota:
Este parâmetro não é considerado no PHC CS Web.
Atualiza o preço custo em moeda estrangeira do artigo composto
Ao gravar um dossier, que tenha esta opção ativa, são atualizados automaticamente os preços de custo em moeda estrangeira de artigos compostos, se os artigos que os compõem forem lançados no mesmo dossier.
Nota:
Este parâmetro não é considerado no PHC CS Web.
Quando um dossier se encontra configurado, com a opção
Corrige custo de vendas de artigos quando grava o dossier
ativa, fica disponível a Opção de Menu
Actualizar o custo nas vendas dos artigos deste dossier
, que permite executar o mesmo que foi indicado nas opções referidas (de acordo com a configuração do dossier adjacente à opção
Corrige custo de vendas de artigos quando grava o dossier
), sem que se tenha que alterar e gravar o dossier.
As seguintes opções só se encontram disponíveis se o utilizador possuir os módulos PHC CS Suporte desktop ou PHC CS Equipamento desktop.
Permite agregar equipamentos ao dossier
Esta opção só está disponível se possuir os módulos PHC CS Suporte desktop ou PHC CS Equipamento desktop. Através dela é possível definir que o dossier movimenta números de série. Desta forma surgirá um novo botão no dossier e que permitirá definir, para além de outras informações, o número de série dos equipamentos. Para mais informações sobre esta opção consulte, por favor, o manual do módulo PHC CS Suporte e ainda o capítulo com a explicação sobre
Agregar equipamentos
.
É possível configurar o dossier para agregar nºs de série sem ser preciso dizer se são documentos de entrada/saída de equipamento. Com esta opção, não há criação de equipamentos, apenas é visualizado o ecrã que permite fazer a agregação, para se digitar os nºs de série que se pretende.
Abre o ecrã para preencher os nºs de série
Quando selecionada, esta opção
preencher os números de série
respetivos à referência/quantidade introduzida na linha do documento.
Abre o ecrã para eliminar os nºs de série
Esta opção permite ao utilizador
selecionar os números de série
que pretende eliminar, pertencentes a determinada referência existente na linha do documento.
Os equipamentos são atualizados como entradas
Com esta opção, se o dossier estiver a movimentar números de série, os respetivos equipamentos darão entrada no ficheiro de equipamentos. Para mais informações sobre esta opção consulte por favor o manual do módulo PHC CS Suporte desktop.
Nota
: Não é possível configurar dossiers internos que utilizem a tabela "AG" ou "EM" para dar entrada de equipamentos.
Os equipamentos são atualizados como saídas
Com esta opção, se o dossier estiver a movimentar números de série, os respetivos equipamentos darão saída do ficheiro de equipamentos. Para mais informações sobre esta opção consulte por favor o manual do módulo PHC CS Suporte desktop.
Dossier de troca de equipamento
Esta opção permite efetuar trocas de equipamento, ou seja, trocar um equipamento no cliente/fornecedor por outro equipamento que esteja em armazém.
Esta configuração depende da tabela utilizada:
Se utilizar a tabela "CL", os equipamentos têm que ser atualizados como saídas;
Se utilizar a tabela "FL", os equipamentos têm que ser atualizados como entradas.
Dossier de retoma de equipamento
Esta opção só se encontra disponível, quando o
Os equipamentos são atualizados como saídas
e a tabela a usar é "CL", ou quando
Os equipamentos são atualizados como entradas
e a tabela a usar é "FL".
Dossier de transf. de equipamento entre armazéns
Com esta opção, se o dossier estiver a movimentar números de série, os respetivos equipamentos darão saída e entrada dos respetivos armazéns. É necessário ter ativa a opção de
transferência
de armazéns e usar a coluna de armazém nas linhas do dossier. Para mais informações sobre esta opção consulte por favor o manual do módulo PHC CS Suporte desktop.
Disponibiliza equipamentos em armazém/fornecedor
Esta opção apenas está disponível para quando
Os equipamentos são atualizados como saídas
e a tabela a usar é "CL".
Se a opção estiver ativa, sempre que se emite um documento de saída, a aplicação confirma se para esse cliente, existe algum equipamento em armazém ou no fornecedor com as mesmas características (ref, modelo e máquina) do novo equipamento utilizado no dossier de saída. Neste caso, existe um equipamento que foi devolvido e se existir um equipamento semelhante, a aplicação pergunta se quer disponibilizar o equipamento em armazém ou no fornecedor para futuras vendas. É visualizado um novo ecrã que mostra todos os equipamentos idênticos, onde é possível escolher qual o que se pretende disponibilizar. Ou seja, limpa os campos
Dados do cliente
no ficheiro de equipamentos.
Assim, quando este equipamento regressar do fornecedor, fica disponível para futuras vendas, (Por exemplo, no caso de ter garantia).
Permite equipamentos de outros clientes
Esta opção permite criar dossiers de equipamentos que permitam a entrega de equipamentos de vários clientes para um determinado cliente. Para disponibilizar esta funcionalidade, deve configurar um dossier interno com as seguintes características:
Tabela que utiliza CL;
Procura a referência por 0+nº de série;
Permite agregar equipamentos ao dossier;
Os equipamentos são actualizados como entradas;
Permite equipamentos de outros clientes.
A introdução do referido equipamento deve ser feito na linha do dossier interno, campo referência, digitando "0+nº de série".
Nota
: Se o utilizador tentar introduzir o equipamento de outra forma, embora o dossier esteja bem configurado, não será possível.
Disponibiliza equipamentos para vendas futuras
Esta opção só se encontra disponível se o dossier utilizar a tabela "CL" e agregar equipamentos e estes são atualizados como entrada.
Esta configuração permite criar dossier para vendas futuras, isto é, entrada de um equipamento em armazém com origem num cliente, o equipamento fica sem o cliente de origem associado, permitindo desta forma que este equipamento esteja automaticamente disponível para uma nova saída de armazém para um outro qualquer cliente.
Dossiers necessários e sua configuração, para correto funcionamento
Dossier do tipo
Devolução de Cliente
, que utilize uma tabela "CL" e que tenha a opção
os equipamentos são atualizados como entrada
.
Dossier do tipo
Devolução para Fornecedor
, que utilize uma tabela "FL" e que tenha a opção
os equipamentos são atualizados como saída
.
Dossier do tipo
Disponibilização de equipamento
, que utilize uma tabela "CL" e que tenha a opção "os equipamentos são atualizados como saída" e a opção de disponibiliza equipamento em armazém/fornecedor ativa.
Dossier do tipo
Retoma de Fornecedor
, que utilize uma tabela "FL" e que tenha a opção "os equipamentos são atualizados como entradas" e a opção de retoma de equipamentos ativa.
Dossier do tipo
Retoma de Cliente
, que utilize uma tabela "CL" e que tenha a opção "os equipamentos são atualizados como saídas" e a opção de retoma de equipamentos ativa.
Nota
: Todos os dossiers criados terão que ter armazém nas linhas.
Dossier de Produção
As seguintes opções só se encontram disponíveis quando o dossier interno se encontra configurado como um dossier de Clientes, de
produção
e que permite agregar
equipamentos
ao dossier.
Atualiza o cliente nos equipamentos produzidos
Uma vez ativa, esta opção faz com que os dados do cliente sejam atualizados na ficha do artigo produzido.
Atualiza o cliente nos equipamentos consumidos
Uma vez ativa, esta opção faz com que os dados do cliente sejam atualizados na ficha do artigo consumido.
Mediante a seleção das opções, os equipamentos
produzidos
ou consumidos vão sendo atualizados com os dados do cliente.
Permite Overbooking
Um dossier de Ocupação que esteja
configurado
para permitir Overbooking, irá permitir a existência de mais que uma estadia ou reserva na mesma data para a mesma unidade de ocupação.
Gestão de ocupação é nas linhas
Esta opção permite usar as unidades de ocupação nas linhas do dossier.
Gestão da Ocupação
Estas opções só se encontram disponíveis se o utilizador possuir a validação de Ocupação.
Este é um dossier de Reservas
Uma vez ativa, esta opção permite que o dossier em questão, na gestão de ocupação, desempenhe o papel de Reserva.
Este é um dossier de Estadias
Uma vez ativa, esta opção permite que o dossier em questão, na gestão de ocupação, desempenhe o papel de estadia.
Este dossier está apenas ligado à gestão de ocupação
Significa que este dossier nem é considerado como estadia, nem como reserva, no entanto tem um funcionamento idêntico.
A única diferença entre um dossier configurado com esta opção ativa e um dossier de "estadias" ou "reservas", relaciona-se com o facto de este tipo de dossier (apenas ligado à gestão de ocupação) não ser tido em conta na Análise Global de Ocupação.
Este dossier não é utilizado na gestão de Ocupação
Esta opção determina que apesar de ser um dossier de ocupação não é utilizado como tal.
A potencialidade destas configurações encontram-se explicadas em pormenor no respetivo manual, nos dossiers de
ocupação
.
Obras
As seguintes opções só estão disponíveis se tiver instalado o módulo PHC CS Obras desktop.
Tipo de Dossier
Esta opção permite ao utilizador organizar/agrupar os seus dossiers por tipo. O tipo é um
campo Tabela do Utilizador
, por isso é o utilizador que escolhe o que pretende.
Avisa quantidade relativamente a dossiers do tipo " X "
Esta opção permite avisar se a referência existe, ou é de quantidade inferior há utilizada no dossier de origem, definido pelo utilizador. A referência introduzida deve de ser exatamente a mesma para que seja possível este aviso.
Utiliza o campo Situação
Ao ativar esta opção na página principal do dossier aparece o campo Situação que permite ao utilizador escolher uma das seguintes opções:
Aberta, Em curso, Parada, Pronta p/mediação, Terminada.
Utiliza os campos "Tabela do utilizador" nas linhas
Ativando esta opção nas linhas do dossier vão aparecer 5 colunas com os nomes que foram configurados nos parâmetros de obras.
Nº níveis de decomposição
Esta opção serve para quando se utilizam produtos compostos, poder definir o nível de decomposição automática do produto durante a introdução, com cálculo automático das quantidades dos componentes via quantidade do produto composto.
Nome do campo Adjudicada
Nas linhas do dossier, poderá aparecer uma coluna com o nome que o utilizador introduzir neste local.
Campo de Família nas linhas
Esta opção permite que no documento exista uma coluna com a informação da família do artigo.
Campo de percentagem de Família nas linhas
Possibilita a distribuição definida pelo valor percentual dos valores pelas linhas cujos artigos pertençam à família indicada.
Processos
Esta página só fica ativa se o utilizador possuir o módulo PHC CS Projeto desktop.
As opções de configuração dos dossiers deste módulo encontram-se explicadas no respetivo
manual
, onde poderá observar os diversos tipos de
dossiers de projecto
e respetivas configurações.
POS
É um dossier de Importação/Exportação
Esta opção permite que um determinado dossier interno possa ser importado ou exportado entre lojas e a sede. Para isso deverá utilizar as
integrações com lojas
.
Opções disponíveis no Menu de Configuração de Dossiers Internos
Ao abrir o ecrã de Configuração de Dossiers Internos fica disponível uma Barra de Ícones de Programas onde existem variadas opções.
Nessa barra existe um ícone
de
opções
com várias ações, algumas delas já disponíveis através de ícones, nomeadamente a
Introdução
e
Eliminação
de registos, bem como
mapas definidos pelo utilizador
.
No menu de opções do ecrã de Configuração de Dossiers Internos, fica também disponível a seguinte opção:
Configurador de D.I. que não tenham SAF-T atribuído
Esta opção serve para configurar Dossiers Internos que ainda não tenham a opção de
Tipo para SAF-T (e para assinatura nos documentos certificados)
atribuído.
Esta opção só aparece disponível se existirem dossiers que ainda não tenham a opção
Tipo para SAF-T (e para assinatura nos documentos certificados)
preenchida e se tiver acesso de supervisão na tabela de Configuração de Dossiers Internos.
