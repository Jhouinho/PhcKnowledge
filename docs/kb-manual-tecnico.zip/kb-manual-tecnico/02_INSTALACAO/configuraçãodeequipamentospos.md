---
title: Configuraçãodeequipamentospos
source: configuraçãodeequipamentospos.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãodeequipamentospos

Configuração de Equipamentos Pos

|  |
| --- |
| Configuração de Equipamentos Pos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Configuração Terminal POS HP**    Este documento visa dar a conhecer de forma simples e rápida, como configurar uma panóplia de equipamentos distribuídos pelo parceiro *Soft Voice*, para a área da venda a retalho, em particular para o nosso *software* **PHC POS CS**.    Os equipamentos, sobre os quais daremos as respetivas considerações de seguida, são:   - **HP RP7 Retail System Model 7800**, com processador *Intel Celeron* G540 a 2.5Ghz HDD disco de 320GB e 2GB *RAM*, ecrã *touch* de 15" totalmente integrado. - **Scanner Unitech MS837**, com ligação *USB* - **Impressora Star TSP143**, com ligação *USB* - **Gaveta de Dinheiro Venus 03 8C/4B** - **HP RP7 Retail System Model 7800HP**    Este *POS*, por estar equipado com um processador Intel G540, é bastante ágil.    Disponível com HDD ou SSD e com possibilidade de fazer *upgrade* de *RAM*, é uma opção que complementada com um *display* de cliente e com uma impressora de talões, fica um *POS* pronto a trabalhar. - **Scanner Unitech MS837**, ligação *USB*                Este *scanner* com ligação *USB*, permite ser um complemento excelente para facilitar o utilizador na introdução de artigos no documento de venda. Lê vários *standards* de códigos de barra e é muito rápido na leitura.    Não carece de nenhuma configuração em especial, pois vem pronto a trabalhar. Este injeta no *buffer* do teclado, o código de barras lido, encarregando-se o **PHC** de transformar o código de barras na referência do artigo em causa. O *scanner* pode no entanto ser configurado para ler outros formatos de códigos de barra. - **Impressora Star TSP143** , com ligação *USB*                Esta impressora imprime 22 RPM (recibos por minuto). Possuindo uma guilhotina de corte integral ou parcial, com a possibilidade de ser configurada com *driver Windows* ou *OPOS*, apresenta-se como uma solução versátil e eficaz.        No que diz respeito à configuração da impressora no sistema operativo recorrendo ao *OPOS*, teremos que numa primeira etapa, instalar os *drivers* da impressora que vem no *CD* de instalação em **Windosws\Installer\Setup**. Após a instalação da impressora, é criado a uma pasta em **Iniciar\Programas**, chamada **StarMicronics** que tem a opção "Utilitário de Configuração".        Quando abrimos esse utilitário selecionamos a opção "Modo Star Line" (predefinição).                Após termos escolhido esssa opção entramos na configuração, escolhemos a opção "*OPOS*" e fazemos "Adicionar Novo", tanto na impressora como na gaveta.                **OPOS EPSON**        O **PHC** quando integra uma impressora de talões, configuradas para modo de texto e/ou *display* configurados para **OPOS**, precisa sempre do *OPOS* da *Epson* instalado para instalar os *driver OPOS* dos pontos anteriores.        Quer a impressora quer a gaveta, aparecem aqui disponíveis com os respetivos nomes lógicos definidos na configuração do *OPOS* da *Star*.                **NOTA IMPORTANTE COMUM A QUALQUER IMPRESSORA DE TALÕES:**    Apenas as impressoras que suportam o *code page wpc1252* são passíveis de imprimirem os caracteres com acentuação cedilhados etc, no **PHC** e em IDUs no modo texto. A ativação do referido *code page* pode ser através de "mnemónica" . - **Gaveta de Dinheiro Venus 03 8C/4B**                A gaveta de dinheiro em causa é de dois conetores, existindo também de 5 conetores. Por regra é ligada através de ficha RJ11 à impressora .    Se optarmos por ligar a gaveta à impressora e esta estiver configurada para ser usada com *driver OPOS*, devemos definir o nome no *OPOS* proprietário da impressora, à qual a gaveta está ligada na configuração de terminal de vendas no **PHC**, no separador *OPOS*.                     Gama de software PHC em que foi testado: Advanced 2014 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração de Equipamentos Pos' ) |