---
title: Configuração de Links para As Categorias
source: configuraçãodelinksparaascategorias.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração de Links para As Categorias

Este artigo pretende demostrar como configurar os links para aparecerem nas categorias da Loja web.
Os links podem aparecer no cabeçalho e rodapé de uma determinada categoria ou em todas as categorias existentes na loja Web.
Para configurar os links para as categorias, deve-se começar com criar os Links que se pretendem que apareçam nas categorias, para isso deve-se aceder ao menu Configurações e depois selecionar a opção Links. No ecrã dos links é importante criar um novo registo para o campo "Local onde será colocado" de forma a ser mais fácil a identificação do link para depois utilizar nas configurações pretendidas. De seguida é exemplificado um link:
Titulo do link:
Link Cabeçalho
O titulo não aparece no link:
ativo
Data de Início:
13-09-2016
Data de fim:
13-10-2016
Descrição completa do link:
&ltdiv style="text-align: center;">
&lth1> Novas Instalações </h1>
&ltp> Iremos mudar de instalações, caso nos pretenda contactar pessoalmente valide a morada nos Contactos</p>
&ltp>&ltb> Estejam atentos às novidades </b></p>
</div>
Local onde será colocado:
Link_header
Package a incluir:
Portal
Após a configuração do link é necessário validar que existe o template básico (Framework " Templates Básicos) "catPage" referente ao tema selecionado. É neste template que se colocam os objetos referentes aos links e que identificam onde estes aparecem. Este template básico por norma é disponibilizado mas caso não existem o template deverá ter os seguintes objetos:
#??#STORECATLINKS1#??#
: objeto onde irá aparecer o link1 configurado nos parâmetros ou na Categoria de Artigos
#??#STORECAT#??#
:objeto que chama os dados das categorias (header, item, grid/list)
#??#STORECATLINKS2#??#
: objeto onde irá aparecer o link2 configurado nos parâmetros ou na Categoria de Artigos
De seguida é exemplificado um template básico catPage:
Titulo:
Catalog page
Código de acesso a este registo:
GMT_catPage
Tipo de template básico:
StoreCatalog
Conteúdo da Página:
<!-- Exemplo dos Links -->
&lth1>#??#STORECATLINKS1#??#</h1>
&ltp>#??#STORECAT#??#</p>
&lth1>#??#STORECATLINKS2#??#</h1>
é HTML puro:
Sim
O template tem Imagens na área do Conteúdo:
Portal
Quando se seleciona o tema o parâmetro da loja "Template para página de catálogo de categorias" é preenchido com o código o template básico. Por exemplo, se selecionarmos o tema Gourmet, o parâmetro é preenchido com o valor GMT_catPage.
Para que os links configurados apareçam em todas as categorias, é necessário colocar nos parâmetros da loja, "Definição da categoria para o links 1" e "Definição da categoria para o links 2" o valor a colocar nestes parâmetros é o valor do campo "Local onde será colocado" que se preencheu no link que se pretende utilizar.
Estes parâmetros podem ser configurados através do "Assistente de configuração do tema" (Configurações" Assistente de configuração do tema) no separador "Opções" ou diretamente nos "Parâmetros" (Framework " Parâmetros).
Caso se pretenda configurar o link apenas para aparecer numa Categoria os parâmetros anteriores deverão estar em branco e deve-se proceder à configuração no ecrã "Configuração de categorias de artigos", acessível a partir do menu Configurações.
No ecrã "Configuração de categorias de artigos" após selecionar a categoria pretendida existem os campos "Categoria de link 1" e "Categoria de link 2" onde se deverá selecionar o link pretendido. Na listagem dos links os valores que aparecem são os valores do campo que "Local onde será colocado" dos vários links existentes deve-se selecionar o valor que se pretende e que foi configurado com esse intuito.
Após estas configurações ao aceder à loja web ao selecionar uma categoria aparecem os links criados e associados à categoria.
Funcionalidade disponível nas gamas PHC CS:
Corporate, Advanced e Enterprise.
Subscrição de PHC On:
Não
Ambiente de teste:
- Versão de software PHC CS Web: 20;
- Versão do browser: Chrome 49.0.2623.110 m
- Versão do Android/IOS: 5.1.1/9.3.1
Configurações da Loja web
