---
title: Configuraçãodoapuramento
source: configuraçãodoapuramento.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãodoapuramento

Configuração do Apuramento

|  |
| --- |
| Configuração do Apuramento |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Inicialmente é necessário configurar o apuramento de CEV para cada conta de movimento de existências. A informação a introduzir será :    **Conta base de existências**  Esta conta tem obrigatoriamente que ser de movimento, e será aquela que possui o saldo inicial de existências e onde será colocado o valor do inventário final.     **Conta de COMPRAS**  Esta conta poderá ser de integração e contem o prefixo de todas as contas utilizadas nas compras de existências daquela conta base. (Exemplo : conta 312)    **Conta de CEV e MC**  Nesta conta será colocado o saldo do movimento : STOCK INICIAL + COMPRAS - STOCK FINAL, como tal deve obrigatoriamente ser de movimento. (Exemplo : conta 612)    **Conta de Regularização**  Aqui deve colocar o prefixo das contas de regularização de existências, o qual pode ser uma conta de integração. (Exemplo : conta 382)    **Conta de Devolução**  Aqui deve colocar o prefixo das contas de devoluções de compras, o qual pode ser uma conta de integração. (Exemplo: conta 3171)    **Conta de Descontos e Abatimentos**  Aqui deve colocar o prefixo das contas de descontos e abatimentos em compras, o qual pode ser uma conta de integração. (Exemplo : conta 3181)    Toda esta configuração já vem definida quando o programa é instalado, no entanto, deve ser alterada se porventura o Plano de Contas que vem com o programa for alterado no que diz respeito ás contas aqui definidas.      **Centro Analítico**  Esta coluna apenas está disponível caso o respectivo [parâmetro](ParâmetrosdoContabilidade.htm#samcev) esteja activo, permitindo assim efectuar o apuramento do CEV por centro analítico. Deve preencher esta coluna com o centro analítico pretendido.          Com todas as configurações correctamente efectuadas, é possível efectuar o Apuramento de Custo de Existências Vendidas / Matérias-Primas Consumidas (CEV/MC) separado por taxa de IVA / mercado. A aplicação transfere todos os saldos das contas 31 para a 32, transfere os saldos das contas 32 para a conta 61 (apura o valor a passar para a conta 61, após o utilizador preencher a informação com as quantidades do saldo final). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração do Apuramento' ) |