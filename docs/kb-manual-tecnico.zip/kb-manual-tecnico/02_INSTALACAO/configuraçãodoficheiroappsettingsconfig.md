---
title: Configuração do Ficheiro Appsettings Config
source: configuraçãodoficheiroappsettingsconfig.htm
tipo: Manual Técnico
idioma: PT
---

# Configuração do Ficheiro Appsettings Config

Para o correto funcionamento das aplicações no PHC CS Web é necessário configurar um ficheiro de nome:
appSettings.config
.
Este ficheiro é muito importante pois é nele que existe muita da informação necessária à aplicação para que esta seja executada.
Nota:
Este ficheiro é Case Sensitive, isto quer dizer que, por exemplo, On é diferente de on e nos casos de enganos as instruções não são lidas.
Explicação das chaves utilizadas para configurar:
Toda a aplicação
(chaves comuns);
Front web
;
Supervisor web
;
Suporte web
;
Ecovalor web
;
BPM web
;
Grelhas extranet web
;
Lotes intranet web
;
Documentos Eletrónicos
;
Loja intranet web
;
Platform intranet web
;
Recrutamento web
;
Portal
.
Multilingua
.
Chaves comuns para toda a aplicação
<add key="DSN" value="server=A;uid=B;pwd=C;database=D;"/>
Esta chave serve para a autenticação da aplicação, ou seja define o servidor, a base de dados, o utilizador e a password se for caso disso:
A
= neste local deve ser colocado o nome do servidor. No caso de ser um servidor local pode ser colocada a expressão
localhost
.
B
= neste local deverá ser colocado o user respetivo para o tipo de aplicação que se está a configurar (Interna, Externa ou Pública)
C
= neste local deverá ser colocada a password (se foi atribuída alguma aquando da criação dos users acima mencionados no SQLServer, que tem a base de dados a ser utilizada pelas aplicações do PHC CS Web)
D
= neste local é colocado o nome da base de dados.
<add key="MAILPARAERROS" value="administrador@empresa.pt"/>
Esta chave define para quem é enviado um
e-mail
no caso de acontecerem erros na execução da aplicação. No caso de existir mais de um endereço estes são divididos por ";".
Por exemplo: administrador@empresa.pt;diretor@empresa.pt
<add key="SMTPSERVER" value="localhost "/>
Esta chave define o nome/localização do servidor de
e-mail
a ser utilizado pela aplicação PHC CS Web. Se estiver configurado o serviço SMTP localmente no Web Server, deve usar-se a variável "localhost" (como indicado acima). Caso se utilize um servidor de
e-mail
remoto deverá a mesma (localhost) ser substituída pelo registo DNS que identifica o servidor de
e-mail
perante a Internet. Por exemplo: mail.phc.pt.
As chaves abaixo indicadas servem para configurar o
e-mail
de forma a que o utilizador, além do envio do
e-mail
localmente, possa também ter a possibilidade de realizar uma configuração com um servidor de
e-mail
remoto.
Para isso, foram criadas quatro chaves a usar no ficheiro
appSettings.config
.
<add key="SMTPUSER value=""/>
Que Permite configurar o utilizador, exemplo: maisritmo@gmail.com
<add key="SMTPPASSWORD" value=""/>
Palavra Chave do utilizador.
<add key="SMTPPORT" value=""/>
Porta de autenticação do servidor de
e-mail
, ex. 587
<add key=""SMTPSSL" value=""/>
Autenticação Segura, se o servidor usa este tipo de autenticação. Esta chave deverá conter o valor de "1" para que se realize a autenticação com segurança e vazio se não se realizar.
<add key="ENOME" value="Mais Ritmo"/>
Esta chave define o nome da empresa. Faz o mesmo efeito que o parâmetro 'nome da empresa' nas aplicações Windows.
<add key="ENUMERO" value="A"/>
<add key="ELICENCIAMENTO" value="C"/>
O significado das letras "A" e "B" é o seguinte:
A
- Representa o Número da Licença. Este número é disponibilizado na "Carta de Aceitação de licenciamento PHC CS Web";
B
- nome da empresa a quem é licenciado o produto.
A licença de Supervisor ficará validada automaticamente se existir alguma aplicação interna validada e caso o utilizador tenha definido, na ficha do Utilizador (PHC CS Desktop), que tem acesso a Supervisor web.
<add key="INS.DENTERPRISE" value="S" />
Para além do PHC CS Web apenas funcionar com o software PHC CS Desktop da mesma versão, também funciona somente por gama. Assim deve ser colocado o valor "S" na chave que valida a gama correspondente à gama na versão PHC CS Desktop.
<add key="INS.DENTERPRISE_SERIE" value="C" />
Esta chave é de preenchimento obrigatório e guarda o número de série da gama. Neste caso a letra C representa o número de série da aplicação.
&ltadd key="INS.DADVANCED" value="S"/>
Para além do PHC CS Web apenas funcionar com o software PHC CS Desktop da mesma versão, também funciona somente por gama. Assim deve ser colocado o valor "S" na chave que valida a gama correspondente à gama na versão PHC CS Desktop.
&ltadd key="INS.DADVANCED_SERIE" value="xxxxx"/>
Esta chave é de preenchimento obrigatório e guarda o número de série da gama. Neste caso a letra C representa o número de série da aplicação.
&ltadd key="INS.DCORPORATE" value="S"/>
Para além do PHC CS Web apenas funcionar com o software PHC CS Desktop da mesma versão, também funciona somente por gama. Assim deve ser colocado o valor "S" na chave que valida a gama correspondente à gama na versão PHC CS.
&ltadd key="INS.DCORPORATE_SERIE" value="xxxx"/>
Esta chave é de preenchimento obrigatório e guarda o número de série da gama. Neste caso a letra C representa o número de série da aplicação.
<add key="TEMHELP" value="S" />
Esta chave permite retirar as opções de help do PHC CS Web. Para tal a chave deve ter o valor "N".
<add key="INS.CRM" value="S" />
Esta chave indica que a aplicação está instalada, no exemplo apresentado a aplicação Crm web está instalada. Deve existir uma para cada aplicação instalada.
<add key="INS.CRM_SERIE" value="C" />
Nesta chave é obrigatório o preenchimento do número de série da aplicação em questão. Neste caso, a letra C representa o número de série da aplicação Crm web.
<add key="ADMINPW" value="password" />
Esta chave serve para alterar a password de administrador para aceder a algumas opções de configuração, como por exemplo limpar a cache.
Quando o utilizador pretender limpar a cache através do comando (../programs/gensel.aspx?opcoes=sim), ser-lhe-á pedida uma password. Essa password é definida nesta chave. No caso de não ter a chave definida a password é PHC em letras maiúsculas.
<add key="WebServerMail_From" value="quem@suaempresa.pt" />
Esta chave serve para alterar o endereço de
e-mail
que as aplicações PHC CS Web utilizam como Remetente para enviar
e-mails
resultantes de eventos. Se esta chave não estiver presente no ficheiro
appSettings.config
das aplicações envolvidas nos eventos o endereço usado é webserverevento@semresposta.pt.
Nas aplicações PHC CS Web é possível registar as interações que as aplicações fazem com o servidor de dados, esta informação fica registada na tabela NLOG.
Para ligar esta funcionalidade têm que ser criadas algumas chaves no no ficheiro
appSettings.config
:
<add key="UsaProfiler" value="S"/>
Esta chave serve para indicar à aplicação que esta funcionalidade está ligada ou não. Pode ter o valor "S" ou outro qualquer para indicar que está ligada ou simplesmente não existir esta chave para que a aplicação ignore esta funcionalidade.
<add key="ExcluiDoProfiler" value="EFK,EHT,PARA1"/>
Esta chave serve para indicar quais as tabelas que o utilizador não pretende registar no NLOG, podem ser indicadas várias tabelas separadas por vírgulas.
Neste exemplo as tabelas Favoritos, Hits e Parâmetros são excluídas.
<add key="IncluiNoProfiler" value="BO,BI"/>
Esta chave serve para indicar quais as tabelas que o utilizador pretende registar no NLOG, podem ser indicadas várias tabelas separadas por vírgulas. Caso exista a chave "ExcluiDoProfiler" e o seu valor não seja vazio esta chave (IncluiNoProfiler) é ignorada.
Neste exemplo só a tabela de Dossiers Internos (cabeçalhos e linhas) são incluídas.
<add key="ProfilerMaxRec" value="500"/>
Esta chave indica o máximo de registos da tabela
NLOG
de que o utilizador pretende guardar em histórico. A partir desses registos, a aplicação irá limpar os mais antigos, de modo a que o total de registos, cujo campo "Descrição" seja igual a "Profiler Interno", não seja superior ao valor indicado por esta chave. Se esta chave não existir, é como se não houvesse qualquer limite para o número de registos guardados no
NLOG
. Os registos excedentes serão limpos sempre que for limpa a cache.
No exemplo está a limitar o número de registos a 500.
<add key="HorasDelProfiler" value="0.5"/>
Esta chave indica o intervalo em horas em que a aplicação irá verificar se os registos da tabela NLOG já são superiores ao valor da chave "ProfilerMaxRec", caso não exista chave "ProfilerMaxRec", então esta chave (HorasDelProfiler) será ignorada.
Neste exemplo verifica o limite (500 no exemplo anterior) a cada 30 minutos.
<authentication mode="Forms"/>
<forms loginUrl="login.aspx" name=".nomecookie" timeout="60"/>
</authentication/>
Esta chave indica o nome do cookie que guarda o login do user.
<add key="USAIDU" value="S"/>
Esta chave serve para quando se tem instalado o IduServer poder imprimir usando um idu, pode ser usado para as tabelas BO, FT, RD, FO, PE, RE, CL, PA, MH e ST.
<add key="SESSIONERROR" value="S" />
Caso tenha a chave do ficheiro
appSettings.config
com "S", quando executa código de utilizador, a aplicação acrescenta no fundo da página o texto "Log de código de utilizador:" seguido de informação respeitante ao código executado, como o tipo, o identificador e o URL.
<forms loginUrl="programs/login.aspx" name=".PHC_Intranet" timeout="300"/>
<sessionState timeout="300"/>
<httpRuntime executionTimeout="900"/>
Todas estas chaves servem para definir o tempo em minutos. As primeiras definem o tempo de inatividade da aplicação até pedir de novo o login, a última serve para definir o tempo de execução por exemplo de uma análise avançada, de uma emissão de uma newsletter, etc.
<add key="EventViewer" value="N"/>
Por defeito, o eventviewer não é utilizado, ou seja, apenas há report de erros para o e-mail configurado na chave do ficheiro
appSettings.config
. Se não tiver o sistema de report por
e-mail
, os erros não são reportados. Assim foi criada esta chave para ativar o eventviewer. É necessário que o utilizador ASPNET seja promovido a administrador de sistema, pelo menos na primeira vez em que entra no software para criar a entrada na categoria "application" e criar no ficheiro
appSettings.config
esta chave.
Quando está ativo os erros são adicionados à categoria "Application", indicando em cada erro em que aplicação é que o erro aconteceu.
Nota:
Esta chave não funciona em Windows Vista.
<add key="COMHITS" value="N"/>
Esta chave permite indicar se a aplicação guarda na tabela EHT as chamadas que cada utilizador faz a cada página.
Por defeito não regista estes dados, mas se pretender que registe pode alterar o valor da chave para: "S", de forma a ativar a gravação dos hits.
A razão da existência desta chave prende-se com a performance, ou seja, a utilização desta funcionalidade com muitos utilizadores torna mais lento o sistema.
<add key="CacheLigado" value="N"/>
Esta chave liga e desliga o cache, o seu valor deve ser S, para que a aplicação seja mais rápida e ainda para que o acesso a imagens que ficam na base de dados (no caso de possuir o módulo PHC CS Documentos web) e o acesso às imagens das notícias, funcionem.
Também é possível ligar ou desligar cache através da própria aplicação.
Para tal, o utilizador ASPNET tem de ter acesso de escrita ao ficheiro ficheiro
appSettings.config
Uma vez na página inicial da aplicação PHC CS Web, o utilizador deve digitar no browser: .../programs/gensel.aspx?opcoes=sim. Este caminho disponibiliza algumas opções, entre as quais se encontra a seguinte:
Desligar o CACHE para configuração (mais lento) - appSettings.config key CacheLigado=N
. Ao premir esta opção, a aplicação retorna uma mensagem a informar que o cache foi ligado ou desligado.
<add key="erroshtml" value="S"/>
Os erros que eventualmente possam ocorrer em PHC CS Web são enviados para o view source da página. Para desabilitar este tipo de report de erros deve colocar esta chave com valor "N".
<add key="Logerr" value="S"/>
É também possível enviar os erros que possam ocorrer no PHC CS Web para a tabela LOGERR. Para habilitar esta funcionalidade deve colocar esta chave atribuindo-lhe o valor "S".
<add key="onerror" value="S"/>
É ainda possível efetuar o report de erros através do ficheiro "onerror.txt" a ser criado na root do site, na mesma diretoria do ficheiro
appSettings.config
.
Esta chave deve encontrar-se com o valor "S" para que qualquer erro que ocorra durante o funcionamento do PHC CS Web possa ficar guardado neste ficheiro. A partir deste momento pode usar as opções de configuração para limpar o ficheiro e para o consultar basta escrever o seu url no browser ou pedir para consultá-lo nas opções de configuração.
<add key="Webpay" value="N"/>
Para serem ativos os pagamentos deve colocar esta chave com o valor "S". Por defeito encontra-se "N".
<add key="WebpayURL" value="URL"/>
O utilizador terá acesso a uma chave WEBPAYURL onde poderá colocar o URL que servirá para efetuar os pagamentos.
&ltadd key="SqlProfiler" value="S"/>
Para ter o profiler sempre ligado e para todos os utilizadores, útil numa fase de configuração inicial.
<add key="ENUMEROSERIE" value="A" />
A
- Corresponde ao número de série dos módulos de uma aplicação Demo. Logo, o preenchimento deste campo é obrigatório apenas quando o utilizador pretende usufruir de uma aplicação Demo;
Com estas chaves usaremos o cache do browser para guardar conteúdos estáticos, como por exemplo, imagens, código de clientes, ficheiros CSS, etc durante vários dias e com determinadas versões de IISs, os dados enviados para o cliente vão comprimidos, poupando largura de banda.
No ficheiro
web.config
passaram a estar todas as configurações necessárias para a performance da aplicação PHC CS Web. Desta forma, quando é feita a atualização da aplicação, este ficherio passará a ter as configurações recomendadas.
key static content e urlcompression
<system.webServer>
<urlCompression doDynamicCompression="true" doStaticCompression="true" dynamicCompressionBeforeCache="false" />
<staticContent>
<clientCache cacheControlMode="UseMaxAge" cacheControlMaxAge="31.00:00:00" cacheControlCustom="public" />
<remove fileExtension=".svg" />
<mimeMap fileExtension=".svg" mimeType="image/svg+xml" />
<remove fileExtension=".woff" />
<mimeMap fileExtension=".woff" mimeType="application/font-woff" />
<remove fileExtension=".woff2" />
<mimeMap fileExtension=".woff2" mimeType="application/font-woff2" />
</staticContent>&ltbr />&ltbr />
Nota: Ao atualizar para a versão mais recente de IIS (Usar o IIS 8 ou superior) aproveita os melhoramentos de gestão de memória do ASP.NET.
Explicação das chaves específicas por aplicação:
Front web
Para que os utilizadores do Front web tenham acesso às opções de configuração do Supervisor web, é necessário configurar as chaves:
<add key="INS.FRONTINTRANET" value=""/>
<add key="INS.FRONTINTRANET_SERIE" value=""/>
Na ficha do Utilizador (PHC CS Desktop) deve estar ativo o módulo
FrontIntranet
.
<add key="DossierEncomendas" value="ndos"/>
Esta chave define qual o dossier que vai servir para o registo de encomendas na aplicação Front Web. Ndos deve ser substituído pelo número interno do dossier.
No ficheiro
appSettings.config
da Extranet é possível indicar qual o dossier interno que vai estar disponível para introdução de encomendas.
Apenas é possível introduzir dossiers internos que se encontram configurados com o tipo para SAF-T (e para assinatura nos documentos certificados),"Não entra para SAF-T " e para DC (Documento de conferência).
Se o utilizador adicionar uma imagem na ficha de um artigo, a mesma estará visível quando o utilizador pretender adicionar um artigo num dossier interno, ou num documento de faturação.
Neste sentido, após adicionar a imagem a um artigo (Na aplicação PHC CS Desktop), gravando-a diretamente na Base de Dados, ou em alternativa numa diretoria dentro da pasta "wwwroot" da aplicação PHC CS Web;
Poderá alterar a dimensão da imagem do artigo através da definição dos pixeis nas seguintes Tags:
1 -
<add key="stimagens_height" value="25"/>
2 -
<add key="stimagens_width" value="25"/>
Supervisor web
<add key="Upload_MinPath_EBN" value="../files/" />
<add key="Upload_MaxPath_EBN" value=" C:\inetpub\wwwroot\supervisor\files\" />
<add key="Upload_MaxPath_EBN_2" value=" C:\inetpub\wwwroot\portal\files\" />
Estas chaves definem o local onde são gravadas as imagens dos banners construídos na aplicação. No caso das imagens dos banners, estas têm que ser gravadas em dois locais, na aplicação em "Configuração" do PHC CS Web, onde são gravadas e na aplicação Portal onde são vistos/consultados os banners.
<add key="Upload_MinPath_ELK" value="../files/" />
<add key="Upload_MaxPath_ELK" value=" C:\inetpub\wwwroot\supervisor\files\" />
<add key="Upload_MaxPath_ELK_2" value=" C:\inetpub\wwwroot\portal\files\" />
Estas chaves definem o local onde são gravadas as imagens dos links construídos na aplicação. No caso das imagens dos links estas têm que ser gravadas em dois locais, na aplicação em "Configuração" do PHC CS Web, onde são gravadas e na aplicação Portal onde são vistos/consultados os links.
<add key="Dir_Upload_DocumentosPartilhados" value="C:\ "/>
Em todas as aplicações do PHC CS Web existe um menu com o nome "Documentos Partilhados". Esta opção permite consultar diversos documentos que são disponibilizados, através da opção com o mesmo nome "Documentos Partilhados" na aplicação em "Configuração" do PHC CS Web, no menu "Informação".
Na aplicação, em "Configuração" do PHC CS Web, é onde se executa a manutenção dos documentos partilhados. O utilizador apenas pode fazer Upload para a base de dados de documentos do tipo: .Zip, .JPG, .Gif, .Bmp., .Doc e .Xls. Assim, estes documentos ficam disponíveis noutras aplicações do PHC CS Web para os utilizadores dessas aplicações possam fazer o download desses documentos.
Existem duas maneiras de fazer o upload para o servidor quando se está a introduzir/alterar um registo, logo abaixo do objeto que pede o nome do ficheiro a fazer o upload, existe um campo com o nome "Faz o Upload do ficheiro para dentro da base de dados" :
- Caso este campo esteja clicado (por defeito está) o ficheiro será gravado dentro da base de dados no servidor, mais propriamente dentro da tabela "EDO".
- Caso o campo não esteja clicado, o ficheiro será guardado dentro duma diretoria do disco rígido no servidor, mas para isso terá que existir a seguinte chave: "Dir_Upload_DocumentosPartilhados" criado no ficheiro
appSettings.config
para indicar qual a diretoria onde será guardado o ficheiro.
Exemplo:
<add key="Dir_Upload_DocumentosPartilhados" value="C:\TesteUpLoad\" />
A diretoria especificada nesta chave, neste caso "C:\TesteUpLoad\" nunca será mostrada no link do documento ao utilizador que desejar fazer o seu download, parecendo ao utilizador que o documento está gravado dentro da base de dados ao invés de estar numa diretoria à parte, aumentando assim o nível de segurança.
Só é necessário criar esta chave no ficheiro
appSettings.config
da aplicação na "Configuração" do PHC CS Web, caso se queira utilizar como opção o upload de documentos para diretorias.
Só será necessário criar no ficheiro
appSettings.config
das outras aplicações caso essas aplicações vejam a diretoria especificada no ficheiro
appSettings.config
da aplicação, em "Configuração" do PHC CS Web de maneira diferente.
Ainda, no que diz respeito ao Upload de ficheiros, é importante salientar o aspeto da segurança no que diz respeito à utilização da largura de banda.
Uma vez que esta se pode tornar muitas vezes abusiva por parte de utilizadores externos, é possível definir e interditar o seu uso através da rejeição de pedidos de upload que se adivinhem demasiado grandes. Para tal, existe o seguinte atributo:
<httpRuntime maxRequestLength >
Este atributo permite limitar o tamanho dos Uploads rejeitando aqueles que excedam o limite definido. Este limite não é mais do que o tamanho total de Uploads do HTTP em Kb, o que se traduz, aproximadamente na soma de todos os ficheiros aos quais se está a fazer upload.
Assim, é possível definir um limite para deter os visitantes externos e mal-intencionados de usar e exceder a largura de banda através do Upload de ficheiros extremamente grandes.
Desta forma, se o tamanho de um upload for muito grande o servidor não vai permitir que este seja efetuado.
Como o servidor está a recusar o pedido de upload, o browser vai disponibilizar uma mensagem a informar que a página não se encontra disponível. Esta é uma mensagem que costuma acontecer quando o erro acontece no lado do cliente e não no do servidor. No entanto, é esta a mensagem que o utilizador vai observar uma vez que não é possível estabelecer uma mensagem própria para os utilizadores que tentam fazer upload de ficheiros muito grandes.
Para definir este limite, deve então criar uma Key como a seguinte:
<maxRequestLength="1048576">
Nota
: Este tamanho representa 1 GB.
Suporte web
Estas chaves definem o local onde são gravados os ficheiros dos Pedidos de Assistência da aplicação. No caso dos anexos aos Pedidos de Assistência estes têm que ser gravados em dois locais, na aplicação Suporte intranet web onde são gravados e na aplicação Suporte extranet web onde são consultados.
- Intranet:
<add key="Upload_MinPath_PA" value="../upfiles/" />
<add key="Upload_MaxPath_PA_1" value="C:\inetpub\wwwroot\suporteintranetweb\ass\" />
<add key="Upload_MaxPath_PA_2" value="C:\inetpub\wwwroot\suporteextranetweb\ass\"/>
- Extranet:
<add key="Upload_MinPath_PA" value="../upfiles/" />
<add key="Upload_MaxPath_PA_1" value="C:\inetpub\wwwroot\suporteextranetweb\ass\" />
<add key="Upload_MaxPath_PA_2" value="C:\inetpub\wwwroot\suporteintranetweb\ass\" />
Ecovalor web
- Intranet -
Para que os utilizadores tenham acesso às opções de configuração do Ecovalor web, é necessário configurar as chaves:
&ltadd key="INS.ECOVALORINTRANET" value="S"/>
&ltadd key="INS.ECOVALORINTRANET_SERIE" value=" "/>
Na ficha do Utilizador deve ter o módulo EcovalorIntranet adicionado.
- Extranet -
Para que os utilizadores do Front web tenham acesso às opções de configuração do Ecovalor web, é necessário configurar as chaves:
&ltadd key="INS.ECOVALOREXTRANET" value="S"/>
&ltadd key="INS.ECOVALOREXTRANET_SERIE" value=" "/>
BPM web
- Intranet -
Para que os utilizadores tenham acesso às opções do BPM web, é necessário configurar as chaves:
&ltadd key="INS.BPMINTRANET" value="S"/>
&ltadd key="INS.BPMINTRANET_SERIE" value=" "/>
Na ficha do Utilizador deve ter o módulo BPMIntranet adicionado.
- Extranet -
Para que os utilizadores do Front web tenham acesso às opções de configuração do BPM extranet web, é necessário configurar as chaves:
&ltadd key="INS.BPMEXTRANET" value="S"/>
&ltadd key="INS.BPMEXTRANET_SERIE" value=" "/>
Grelhas extranet web
Para que os utilizadores do Front web tenham acesso às opções de configuração do Grelhas extranet web, é necessário configurar as chaves:
&ltadd key="INS.GRELHASEXTRANET" value="S"/>
&ltadd key="INS.GRELHASEXTRANET_SERIE" value=" "/>
Na ficha do Cliente, o cliente deve ter acesso o módulo Grelhas extranet web adicionado.
Lotes intranet web
Para que os utilizadores da Intranet web tenham acesso a todas as funcionalidades dos lotes é necessário configurar as chaves:
&ltadd key=" INS.LOTESINTRANET " value=""/>
&ltadd key=" INS.LOTESINTRANET_SERIE " value=""/>
Na ficha do Utilizador (PHC CS Desktop) deve estar ativo o módulo LotesIntranet.
Documentos Eletrónicos
- Intranet -
Para que os utilizadores tenham acesso às funcionalidades dos Documentos Eletrónicos, é necessário configurar as chaves:
&ltadd key=" INS.DOCELETROINTRANET" value=""/>
&ltadd key=" INS.DOCELETROINTRANET_SERIE " value=""/>
Na ficha do Utilizador deve ter o módulo DocEletroIntranet adicionado.
- Extranet -
Para que os utilizadores do Front web tenham acesso às funcionalidades dos Documentos Eletrónicos, é necessário configurar as chaves:
&ltadd key=" INS.DOCELETROEXTRANET" value=""/>
&ltadd key=" INS.DOCELETROEXTRANET_SERIE " value=""/>
Na ficha do Cliente, o cliente deve ter acesso o módulo Documentos Eletrónicos extranet adicionado, assim como os utilizadores do cliente.
Loja intranet web
Para que os utilizadores tenham acesso às opções de configuração da Loja web, é necessário configurar as chaves:
&ltadd key="INS.LOJA" value="S" />
&ltadd key="INS.LOJA_SERIE" value="" />
&ltadd key="INS.LOJAINTRANET" value="S" />
&ltadd key="INS.LOJAINTRANET_SERIE" value="" />
Platform intranet web
Para que os utilizadores tenham acesso às opções de configuração da Platform web, é necessário acrescentar as seguintes chaves ao ficheiro Appsettings. No PHC CS Desktop, deve dar o acesso aos módulos "PlatformIntranet" e "Supervisor" no ecrã "Utilizadores", separador PHC CS Web, e dar acesso ao módulo "Gestão" no ecrã "Grupos de Utilizadores", e ainda ser cliente de PHC CS Manufactor. Desta forma, poderá usufruir dos Monitores OEE e da Framework do PHC CS Web.
&ltadd key="INS.PLATFORMINTRANET" value="S" />
&ltadd key="INS.PLATFORMINTRANET _SERIE" value="" />
Na ficha do Utilizador (PHC CS Desktop) deve estar ativo o módulo PortalIntranet.
Recrutamento web
&ltadd key="INS.RECRUTAMENTOINTRANET" value="S"/>
&ltadd key="INS.RECRUTAMENTOINTRANET _SERIE" value="" />
&ltadd key="INS.RECRUTAMENTOINTERNET" value="S"/>
&ltadd key="INS.RECRUTAMENTOINTERNET _SERIE" value="" />
Nota:
As duas últimas chaves relativas ao package Recrutamento Internet permite que sejam apresentados os parâmetros para serem configurados. Estas chaves também deverão estar no ficheiro appSettings.config da Internet para conseguir aceder a este novo package.
Portal
Para que os utilizadores do Portal tenham acesso às opções de configuração do Supervisor web, é necessário configurar as chaves:
<add key="INS.PORTALINTRANET" value=""/>
<add key="INS.PORTALINTRANET_SERIE" value=""/>
Nota:
Na ficha do Utilizador (PHC CS Desktop) deve estar ativo o módulo
PortalIntranet
.
<add key="Traduz" value="ES" />
Esta chave permite traduzir dados dinâmicos para um determinado idioma, por exemplo, espanhol.
<add key="MultilinguaADD" value="N" />
Esta chave serve para criar as chaves dinâmicas na base de dados "Iditra", por defeito deverá estar desligada por questões de performance.
Multilingua
O utilizador pode configurar o PHC CS Web de forma a que seja apresentado no idioma Espanhol ou inglês.
Ao entrar na aplicação é detetada automaticamente, a nacionalidade do executável utilizado, independentemente de ter ou não a chave "Culture" definida no ficheiro
appSettings.config
. Contudo, esta chave é necessária para que os textos sejam automaticamente traduzidos.
Para visualizar a aplicação em espanhol, no ficheiro
appSettings.config
deverá existir a seguinte chave:
< add key="Culture" value="es-ES"/ >
Para visualizar a aplicação em inglês, no ficheiro
appSettings.config
deverá existir a seguinte chave:
< add key="Culture" value="en-US"/ >
<add key="MultilinguaADD" value="N" />
Esta chave serve para criar as chaves dinâmicas na base de dados "Iditra", por defeito deverá estar desligada por questões de performance.
Nota:
Na tabela ".exev" deve de existir o executável correspondente à localização pretendida, caso contrário, a aplicação será apresentada em Português.
Instalação e Configurações do PHC CS Web
