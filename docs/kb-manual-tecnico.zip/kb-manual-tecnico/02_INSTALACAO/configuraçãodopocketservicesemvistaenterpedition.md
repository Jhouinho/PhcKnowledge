---
title: Configuraçãodopocketservicesemvistaenterpedition
source: configuraçãodopocketservicesemvistaenterpedition.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãodopocketservicesemvistaenterpedition

Configuração do Pocketservices em Vista Enterp. Edition

|  |
| --- |
| Configuração do Pocketservices em Vista Enterp. Edition |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O objetivo deste artigo técnico é mostrar passo a passo como se instala o PocketServices num Windows Vista Enterprise Edition e no fim conseguir comunicar com a base de dados Maisritmo2008.    Antes de iniciar a instalação deverá confirmar se o utilizador é administrador da máquina.    1º - No Windows Vista deveremos aceder ao botão Start, escolher Control Panel, Programs, Programs and Features, Turn Windows Features On /Off e activar as opções relativas ao IIS (Internet Information Services).                2º - De seguida, deverá instalar a Framework.net 1.1 que se encontra no cd de instalação do pocket2006 na pasta DotNet.    3º - A seguir, é necessário correr o setup do Pocket ServicesSetup.msi manualmente por comando DOS ( por ex: c:\pocket2006\pocketservices\pocketservicessetup.msi ).    4º - Depois de finalizado o setup deverá verificar se na directoria c:\Inetpub \wwwroot\ ficou criado o Pocketservices e os respetivos ficheiros.    5º - Aceder ao Control Panel, User accounts, User accounts, Manage User accounts, seleccionar o username Aspnet, Properties, e na página Group Membership colocar este user como Administrador.        6º - O próximo passo será a activação do IIS6, para isso deverá ir ao Add Programs and Features, Turn Windows Features On/Off, abrir a pasta Internet Information Services e:    -na pasta Web Management Tools confirmar se as opções do IIS estão ativas.    -na pasta World Wide Web Services, Application Development Features ativar as opções .net extensibility, ASP, CGI, ISAPI Extensions e ISAPI Filters.    -confirmar se está activa a pasta Indexing Service que se encontra antes da pasta principal do IIS.        7º - Abrir o Internet Information Services (IIS) Manager (que se encontra no Control Panel, Administrative Tools) , escolher a opção ISAPI and CGI Restrictions, e ativar a framework v1.1, ou seja, selecionar Aspnet v1.1xxxx, fazer right click e escolher allow.             8º - Voltar ao ecrã principal do IIS, escolher a opção Websites, Default Web Site, aspnet\_client, Pocketservices, fazer right click e escolher a opção Advanced Settings. Neste ecrã colocar a Application Pool = ASP.NET 1.1 .        9º - Ainda no IIS, na pasta bin do pocket services, duplo click no objecto MIME Types, e verificar se está definida a extensão .asmx. Se não existir então escolher a opção add e configurar como file name extension=.asmx e MIME Type=text/plain.        10º - Configurar o software phc para trabalhar com o pocket services, ou seja, entrar no phc, utilizadores, e na página acessos do phcdigital, incluir o módulo pocketservices e a respetiva password.  Depois deverá entrar nos grupos de utilizadores e incluir os módulos terminais e pocket encomendas. Sair e voltar a entrar no software.  A seguir, no menu Supervisor, opções do phc pocket, dispositivos móveis, deverá criar o novo dispositivo.     11º - Outro passo será configurar o web.config do pocket services com os dados necessários para comunicar com a base de dados, ou seja, indicar qual o servidor de sql, user, password e nome da base dados.    12º - Correr no browser do webserver o seguinte:  "Http://localhost/pocketservices/getdata.asmx  e verificar que retorna o getdata, ou seja, se aparecem as várias opções no ecrã.        13º - Para verificar se existe comunicação com a base de dados, deverá escolher a opção "RetornaDataTable" e neste novo ecrã preencher o utilizador que está no ficheiro de utilizadores preparado para escrever no pocketservices e sua password, no campo cPDAnome indicar o nome do identificador PDA que foi definido nos dispositivos móveis do phc, no cPackage=encomendas e no campo cSelectStatement: select nome,morada,ncont from cl (nolock).        14º - Por fim escolher o botão "invoke" e confirmar se aparecem os dados.        Gama de software PHC onde foi testado: PHC Advanced 2008 (8.10)  Gama de software PHC Digital onde foi testado: Pocket Sevices 2006  Sistema Operativo: Windows Vista Enterprise Edition. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração do Pocketservices em Vista Enterp. Edition' ) |