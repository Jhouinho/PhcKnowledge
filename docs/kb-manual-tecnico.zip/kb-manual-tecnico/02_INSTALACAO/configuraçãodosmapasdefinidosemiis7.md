---
title: Configuraçãodosmapasdefinidosemiis7
source: configuraçãodosmapasdefinidosemiis7.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãodosmapasdefinidosemiis7

Configuração dos Mapas Definidos em Iis 7

|  |
| --- |
| Configuração dos Mapas Definidos em Iis 7 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para trabalhar com mapas definidos nas aplicações de PHC CS Web, usando o IIS 7, é necessário proceder às seguintes configurações no IIS:    1. O IIS7 funciona com Applications Pools e neste momento, a Application Pool fica com pipeline mode integrated, por defeito, como se pode observar na imagem seguinte. O pipeline mode pode ser mudado tanto no default como para uma virtual directory específica.        Para mudar só numa virtual directory, após selecionar a virtual directory pretendida deve fazer clique direito e escolher a opção **Manage Application** e depois **Advanced Settings**, conforme se pode observar na imagem.        Para alterar a Aplication Pool, deve com um clique selecionar a Application Pool. Como se pode observar na imagem abaixo, a Application Pool tem o pipeline mode aparecendo como *DefaultAppPool*. Assim, ao efetuar duplo clique, para além de ser poder visualizar logo o pipeline mode, se o mesmo não corresponder ao pretendido, pode-se, através de um clique em cima do mesmo, aceder a um ecrã onde se altera o Application Pool Pipeline mode para Classic.          Ao proceder à instalação da aplicação PHC CS Web, para usar os mapas definidos, os handlers ficam preenchidos automaticamente da seguinte forma:                E no webconfig passa a existir as seguintes keys, relativas às extensões criadas no IIS:    <handlers>  <add name="ar\_\_rpx-integrated" path="\*.rpx" verb="\*" type="DataDynamics.ActiveReports.Web.Handlers.RpxHandler" resourceType="Unspecified" preCondition="integratedMode" />  <add name="ar\_\_activereport-integrated" path="\*.ActiveReport" verb="\*" type="DataDynamics.ActiveReports.Web.Handlers.CompiledReportHandler" resourceType="Unspecified" preCondition="integratedMode" />  <add name="ar\_\_arcacheitem-integrated" path="\*.ArCacheitem" verb="\*" type="DataDynamics.ActiveReports.Web.Handlers.WebCacheAccessHandler" resourceType="Unspecified" preCondition="integratedMode" />  </handlers> |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração dos Mapas Definidos em Iis 7' ) |