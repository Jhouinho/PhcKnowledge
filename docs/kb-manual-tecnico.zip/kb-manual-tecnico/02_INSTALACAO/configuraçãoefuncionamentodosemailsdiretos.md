---
title: Configuraçãoefuncionamentodosemailsdiretos
source: configuraçãoefuncionamentodosemailsdiretos.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçãoefuncionamentodosemailsdiretos

Configuração e Funcionamento dos Emails Diretos

|  |
| --- |
| Configuração e Funcionamento dos Emails Diretos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este Artigo Técnico tem como objetivo explicar e demonstrar passo a passo o funcionamento do envio de emails sem Outlook a partir do software PHC.    Caso não tenha nenhum cliente de email instalado no seu PC e caso pretenda enviar informação por email diretamente do software PHC para um ou mais destinatários, apenas tem de seguir os seguintes passos:      **1º PASSO - Preencher os Parâmetros do Software**  Nos Parâmetros do Software, no nó "E-Mail" deve preencher os parâmetros "Servidor de E-mail (SMTP)", "Porta para Servidor de E-mail (SMTP)", "Tipo de Ligação Encriptada para Servidor de E-mail (SMTP)", "Utilizador para Servidor de E-mail (SMTP)" e "Password para Servidor de E-mail (SMTP)".    **Por exemplo:**  . Servidor de E-mail (SMTP) --- smtp.gmail.com  . Porta para Servidor de E-mail (SMTP) --- 465  . Tipo de Ligação Encriptada para Servidor de E-mail (SMTP) --- SSL  . Utilizador para Servidor de E-mail (SMTP) --- nome@gmail.com  . Password para Servidor de E-mail (SMTP) --- «palavra passe associada ao email indicado»      **2º PASSO - Preencher a Manutenção Personalizada**  Na Manutenção Personalizada, na página "Opções de Mail" deve ativar a opção [Envia emails diretos](manutençãopersonalizada.htm).  Caso pretenda usar um servidor diferente do que foi definido nos Parâmetros do Software, apenas deve manter ativa a opção "Envia emails diretos", ativar a opção "Sobrepõe Dados dos Parâmetros" e preencher os campos "Servidor de E-Mail (SMTP)", "Porta", "Tipo de Ligação Segura", "Utilizador" e "Password" ignorando desta forma a configuração dos Parâmetros do Software.    **Por exemplo:**  . Servidor de E-Mail (SMTP) --- smtp.sapo.pt  . Porta --- 25  . Tipo de Ligação Segura --- Nenhuma  . Utilizador --- nome@sapo.pt  . Password --- «palavra passe associada ao email indicado»    *Nota:* Para verificar se tudo está corretamente configurado pode testar o envio do email clicando no botão "Testar E-mail". Se o teste da ligação ao servidor de email correr bem, surge a mensagem "O E-Mail de teste foi enviado com Sucesso.", se não surge uma mensagem indicativa do problema.      **3º PASSO - Preencher a Ficha do Utilizador**  Na Ficha do Utilizador, na página "Dados Principais" deve preencher o campo "E-mail" para que a aplicação possa utilizar este email sempre que necessário.  Por exemplo, sempre que na página "Opções de Mail" da Manutenção Personalizada clicar no botão "Testar E-mail" é enviada uma mensagem para o email do utilizador em questão.      **4º PASSO - Enviar emails aos Destinatários**  Agora que tudo está corretamente configurado, pode utilizar esta funcionalidade em ecrãs onde o utilizador edita o email, por exemplo, Assistente de E-mail e Mailing de Recibos de Vencimento.    **Exemplo:** Se pretender enviar emails do Assistente de E-mail a partir de um servidor de email localizado na Internet, pode utilizar:      1- As configurações dos **Parâmetros do Software** bastando para isso:    - Preencher os parâmetros "Servidor de E-mail (SMTP)", "Porta para Servidor de E-mail (SMTP)", "Tipo de Ligação Encriptada para Servidor de E-mail (SMTP)", "Utilizador para Servidor de E-mail (SMTP)" e "Password para Servidor de E-mail (SMTP)";    - Ativar a opção "Envia emails diretos" na Manutenção Personalizada;    - Preencher o email na ficha do respetivo utilizador;    - Aceder ao Assistente de E-mail, editar o email e terminar o Assistente. Ao terminar são enviados os emails para os destinatários e o remetente utilizado no email é o indicado no parâmetro "Utilizador para Servidor de E-mail (SMTP)".      2- As configurações da **Manutenção Personalizada** bastando para isso:    - Preencher os campos "Servidor de E-Mail (SMTP)", "Porta", "Tipo de Ligação Segura", "Utilizador" e "Password";    - Ativar as opções "Envia emails diretos" e "Sobrepõe Dados dos Parâmetros";    - Preencher o email na ficha do respetivo utilizador;    - Aceder ao Assistente de E-mail editar o email e terminar o Assistente. Ao terminar são enviados os emails para os destinatários e o remetente utilizado no email é o indicado na ficha do utilizador em questão.     Se tiver [PHC ON](oqueéophcon.htm) saiba mais como configurar o envio de e-mails a partir do software, [aqui](http://www.phc.pt/portal/programs/ewpview.aspx?codigo=IDIR110126#.VYq2Rfl_NHw) .      **Gama de Software PHC onde foi testado:** PHC Advanced 2012. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configuração e Funcionamento dos Emails Diretos' ) |