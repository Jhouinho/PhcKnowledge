---
title: Configuraçõesdeimpressoraemmododetexto
source: configuraçõesdeimpressoraemmododetexto.htm
tipo: Manual Técnico
idioma: PT
---

# Configuraçõesdeimpressoraemmododetexto

Configurações de Impressora em Modo de Texto

|  |
| --- |
| Configurações de Impressora em Modo de Texto |

|  |
| --- |
| Cada impressora deve estar configurada para imprimir em modo gráfico ou em modo de texto.  A explicação seguinte refere-se à configuração para imprimir em modo de texto.      No ecrã de configurações de impressora definem-se, para cada impressora, os códigos de escape que dão origem a determinadas acções (i.e. formatar o texto com bold (negrito)).  Estes códigos de Escape devem ser consultados no manual da impressora.    O utilizador deve inserir na coluna título a acção desencadeada pelo código de Escape e na coluna Código de escape aquilo que consta no manual da impressora.    Por exemplo, podemos criar uma [mnemónica](mnemónicasdecódigosdeescape.htm) que seja "BOLD ON" para dois tipos de impressora onde numa o "BOLD On" seja .027.069 e outra em que o "BOLD ON" seja .037.069. Quando desenharmos o IDU só temos que introduzir a mnemónica "BOLD ON" sempre que queiramos o texto mais escuro, mesmo sem termos em atenção para que tipo de impressora irá ser impresso o IDU. (Nota : os códigos .027.069 e .037.069 não são reais e só foram dados a título de exemplo. Deve-se consultar o manual de cada impressora para saber os códigos disponíveis).    No ecrão de impressão do IDU existe um campo de escolha que indica qual o tipo de configuração de impressora que iremos utilizar para imprimir o IDU.  O campo destino neste caso, em "IDU de modo texto" só serve para indicar ao sistema onde se situa a impressora , porque a impressão irá ser feita em modo RAW, ou seja, vai ignorar o driver que estiver instalado para essa impressora e mandar a impressão directamente para a impressora sem passar pelo controlo do Windows.     No caso de termos uma impressora que não esteja instalada no Windows, por não termos drivers ou por outra razão qualquer, podemos utilizá-la para imprimir, bastando para tal instalar uma impressora no Windows que seja "Generic text only" e redireccionar para a porta onde a impressora estiver.    Se a impressora é um dispositivo OPOS, na página OPOS, terá que activar o campo **É um dispositivo OPOS** de forma a poder configurar a impressora, preenchendo assim o nome do dispositivo.  Se o OPOS for de versão 1.5 ou superior terá que activar a opção, indicando assim em que stations pretende imprimir.  Quando a impressão é feita através do OPOS é possível controlar se usa blocos de impressão ou se imprime tudo de uma só vez, para isso é necessário configurar o campo **Número máximo de caracteres por bloco de impressão**, se o campo tiver o valor zero, (Por defeito passou a ter esse valor) o IDU imprime só um bloco com todo o texto a imprimir.          Na página Códigos de Escape, nesta página os códigos que são sempre usados, podem ser inseridos automaticamente (códigos de inicialização, finalização, fim de linha, mudança de linha, e fim de ficheiro). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Configurações de Impressora em Modo de Texto' ) |