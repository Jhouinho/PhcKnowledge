---
title: Constituiçãodabasededadostécnica
source: constituiçãodabasededadostécnica.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodabasededadostécnica

Constituição da Base de Dados Técnica

|  |
| --- |
| Constituição da Base de Dados Técnica |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A informação que deve constar na Base de dados técnica e a forma como esta se encontra organizada fica ao critério do utilizador.    É por exemplo possível possuir uma Base de dados, dividida nas **Áreas** de Hardware, Software e Diversos, cujos apoios se dividem nos seguintes **Tipos**: Instalação, Pós-instalação, Configuração, Anomalias, Problemas de impressão e Diversos.    Quando o utilizador cria um novo registo deve depois escrever o **Resumo**, que será utilizado para pesquisar os dados e que no fundo é uma forma sucinta o conteúdo do campo **Descrição**, que contém o texto propriamente dito.    O campo **Data** permite registar a data em que o registo foi inserido.    Os campos **Confidencial** e **Em desenvolvimento** servem para possibilitar a filtragem da informação, podendo o utilizador observar apenas os registos que já não estão em desenvolvimento ou que são confidenciais.    A opção para os **Artigos relacionados** serve para indicar quais os artigos que estão relacionados com este registo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Base de Dados Técnica' ) |