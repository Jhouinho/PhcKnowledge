---
title: Constituiçãodatabeladediários
source: constituiçãodatabeladediários.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladediários

Constituição da Tabela de Diários

|  |
| --- |
| Constituição da Tabela de Diários |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Um diário contabilístico consiste num arquivo de documentos que se pressupõe ordenado numericamente. Os diários a criar deverão ser formatados em função das normas contabilísticas já em vigor na Empresa.    Na tabela de diários deverá ser definida, **obedecendo os requisitos legais em vigor**, a seguinte informação em relação a cada diário a utilizar:    **Designação**  Nome do diário que se pretende definir.    **Número**  O número sugerido segue uma ordem sequencial. No entanto, poderá utilizar qualquer outro, até 9999, desde que o mesmo não se encontre atribuído a um diário anteriormente criado.    **Ano**  Indica o ano a que pertence o diário. Na introdução de um novo diário a aplicação assume automaticamente neste campo, o ano da contabilidade, sendo este campo simplesmente de consulta.  Só se conseguem consultar, criar ou alterar diários do ano da contabilidade, excepto se se utilizar a da opção [Criar Diários](aberturadeexercício.htm).    **Próximo Lançamento**  Este campo só está disponível se os parâmetros da numeração dos [diários anual/mensal](parâmetrosdocontabilidade.htm#cranual) não estiverem activos.   Neste campo define-se o número, por defeito, do primeiro movimento, aquando da sua introdução, neste diário. O programa prevê uma **numeração sequencial dentro de cada diário**, pelo que o novo número é sempre sugerido.  O sistema nunca permite a repetição de números de documento na mesma data e no mesmo diário embora o permita com datas diferentes.    **Partidas Dobradas**  o controlo **débito/crédito** poderá ser realizado através de cada documento ou através do diário. Este controlo consiste no sistema não aceitar a actualização do lançamento contabilístico, se o conjunto dos movimentos não estiver balanceado. Pode ser definido em separado para a contabilidade geral, analítica e de ordem, sendo que, a aplicação retorna os resultados consoante o tipo de contabilidade seleccionado.   * Contabilidade Geral - contas da classe 1 a 8  * Contabilidade Analítica - contas da classe 9  * Contabilidade de Ordem - contas começadas por 0 (zero)    **Documento Pré-Definido a utilizar por defeito**  Este campo permite associar um diário a um documento [pré-definido](documentospredefinidos.htm). Assim ao introduzir manualmente um documento [contabilístico](IntroduçãodeDocumentoscontabilísticos.htm#cndocumento), ao definir o diário preenche automaticamente o documento pré-definido, caso este esteja preenchido.  De notar que, ao seleccionar um registo e efectuar clique direito no mesmo, o ecrã de Documentos Predefinidos é aberto encontrando-se visível o registo seleccionado.    **Totais Movimentados neste Diário**  Estes campos são actualizados automaticamente pelo programa e apresentam constantemente o valor movimentado a débito e a crédito pelo diário. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Diários' ) |