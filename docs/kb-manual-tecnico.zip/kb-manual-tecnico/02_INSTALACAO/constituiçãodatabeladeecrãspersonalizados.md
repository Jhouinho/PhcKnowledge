---
title: Constituiçãodatabeladeecrãspersonalizados
source: constituiçãodatabeladeecrãspersonalizados.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladeecrãspersonalizados

Constituição da Tabela de Ecrãs Personalizados

|  |
| --- |
| Constituição da Tabela de Ecrãs Personalizados |

|  |
| --- |
| Existem dois modos de aceder a esta funcionalidade:     Através do menu dos próprios ecrãs, na opção [Personalizações deste ecrã.](MenudeOpçõesdoEcrã.htm#crpaginas)   - O segundo modo de aceder a esta funcionalidade é através do menu da aplicação, na opção Supervisor - Framework PHC - **Ecrãs Personalizados**.     Aconselha-se vivamente a utilizar este segundo método, porque é o único que garante que o desenho no qual estamos a trabalhar, é aquele que vem do sistema e não está alterado por eventos de utilizador ou propriedades de ecrã de utilizador que possam estar definidas para os ecrãs.    As antigas páginas de utilizador, provenientes de versões anteriores do software PHC, são convertidas em registos neste ecrã com o título "Personalização 1" quando se instala a versão 2006 pela primeira vez.     As opções deste ecrã, que permitem criar personalizações de ecrã, são as seguintes:    **Nome**  Este campo permite atribuir um nome ao ecrã que vai ser criado.    **Inativo**  Este campo permite colocar o registo como inativo para que este deixe de estar disponível, no menu de opções dos ecrãs, aquando da escolha da personalização a aplicar.    **Dados Principais**  Neste local é necessário identificar o ecrã principal, para o qual se vai criar esta nova personalização.    **Desenho a ser usado por defeito**  Uma vez selecionada, esta opção determina que o desenho desta personalização é o que vai ser utilizado por defeito, sempre que se entre no ecrã acima definido.    *Nota*: Se tiver o parâmetro [Usa ecrãs em memória](ParâmetrosGerais.htm#mpsecrãdef)ativo e se fechar o ecrã definido este fica em memória, mudando apenas a sua propriedade visível. Como as personalizações para os ecrãs gerais só se aplicam ao se abrir um ecrã pela primeira vez, deverá assim inicialmente Fechar todas as janelas e só depois abrir o ecrã definido de forma a ver a nova personalização.    **Tipo de documento**  Há ecrãs, como por exemplo o ecrã dos Dossiers Internos e dos Documentos de Facturação para os quais é possível criar ecrãs personalizados por tipo de documento. Este campo permite selecionar o tipo de documento para o qual vai ser disponibilizada a personalização.    **Disponível também nos outros tipos de documentos**  Esta opção apenas se encontra disponível quando se selecionam os ecrãs de Dossiers Internos e de Documentos de Faturação permitindo que o ecrã a desenhar se encontre disponível não só no documento selecionado na opção anterior, mas em todos os documentos destas tabelas.    É ainda possível escrever uma **Descrição** para cada personalização de forma a distingui-las de outras existentes para o mesmo ecrã.   Pode definir-se qual a **Ordem de ativação** acaso exista mais do que uma personalização para o mesmo ecrã, ou seja, qual a ordem pela qual essa personalização irá aparecer no menu "Ativar" acima descrito.    **Acessos**    **Acesso**  Esta opção permite definir acessos para cada personalização criada.  Estes podem ser:   - Sem controlo de acessos  - Acesso privado para um utilizador  - Acesso X à tabela Y  - Acesso por tipo de perfil       **Opções Disponíveis no Ecrã de Ecrãs Personalizados**    O botão  permite efetuar uma impressão com os dados definidos para os ecrãs personalizados.    O botão  permite [desenhar](desenharecrãspersonalizados.htm) o ecrã personalizado.    *Nota:*   Os restantes ícones de carácter geral encontram-se explicados nos [opções globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Ecrãs Personalizados' ) |