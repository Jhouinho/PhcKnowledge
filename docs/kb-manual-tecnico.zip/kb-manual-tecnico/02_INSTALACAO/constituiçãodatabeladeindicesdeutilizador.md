---
title: Constituiçãodatabeladeindicesdeutilizador
source: constituiçãodatabeladeindicesdeutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladeindicesdeutilizador

Constituição da Tabela de Indices de Utilizador

|  |
| --- |
| Constituição da Tabela de Indices de Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela contém a seguinte informação:    **Titulo**  Nome do índice de utilizador.    **Inactivo**  Campo que indica se o índice de utilizador deve ou não ser incluído na base de dados.    **Tabela**  Nome da tabela onde será aplicado o índice de utilizador.    **Expressão do Trigger**  Expressão do índice de utilizador a ser instalado na base de dados do software Manufactor.    **Índice único**  Indica se o índice de utilizador obriga que o campo só aceite valores únicos. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Indices de Utilizador' ) |