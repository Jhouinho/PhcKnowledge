---
title: Constituiçãodatabeladelistasdeverificação
source: constituiçãodatabeladelistasdeverificação.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladelistasdeverificação

Constituição da Tabela de Listas de Verificação

|  |
| --- |
| Constituição da Tabela de Listas de Verificação |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Listas de Verificação contém a seguinte informação:    **Referencial**  A selecção de um referencial é feita recorrendo ao botão  ou por introdução directa no respectivo campo.  Ao escolher um Referencial, são actualizados os Requisitos e Sub-requisitos do Referencial.  Este campo é de preencimento obrigatório.     **Resumo**  Neste campo deve indicar o resumo da lista de verificação.    **Código**  Este campo é numerado e incrementado internamente na respectiva tabela.    **Descrição**   Permite registar observações pertinentes e importantes da Lista de Verificação.    **Perguntas de Lista de Verificação**  Permite a introdução de perguntas, para isso é necessário clicar no botão . Este botão apenas está disponível quando seleccionado um sub-requisito. Ao escolher a opção é aberto o ecrã de Perguntas de Listas de Verificação em modo de introdução com a Lista de Verificação e Sub-requisito previamente preenchidos.     *Nota:*  O ecrã de Perguntas apenas é acessível a partir do ecrã de Listas de Verificação, não existindo opção no menu. Para introduzir nova pergunta, o campo de Referência é obrigatório. Também poderá ser definida uma Pergunta e Instruções em texto livre.      **Opções Disponíveis no ecrã de Listas de Verificação**    Ao abrir o ecrã de Listas de Verificação fica disponível uma Barra de Ícones de Programas, onde existem variadas opções. Nessa barra existe um ícone  de [opções](menudeopçõesdoecrã.htm) com várias acções, algumas delas já disponíveis através de ícones, nomeadamente a [Introdução](introduçãoderegistos.htm) e [Eliminação](apagarouanularregistos.htm) de registos, bem como [mapas definidos pelo utilizador](mapasdefinidospeloutilizador.htm).     Este ícone permite imprimir a ficha que se encontra seleccionada.  Para mais informações sobre esta opção consulte, por favor, o tópico [Impressões Definidas pelo utilizador](impressõesdefinidaspeloutilizador(idu).htm).        Os restantes ícones de carácter geral encontram-se explicados nos [opções globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Listas de Verificação' ) |