---
title: Constituiçãodatabelademovimentosdestocks
source: constituiçãodatabelademovimentosdestocks.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabelademovimentosdestocks

Constituição da Tabela de Movimentos de Stocks

|  |
| --- |
| Constituição da Tabela de Movimentos de Stocks |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Movimentos de Stocks contém a informação de todos os movimentos que dizem respeito aos valores de movimentação de stocks sendo atualizada automaticamente pelos vários programas e é constituída pelos seguintes campos:    **Referência**  Referência do artigo movimentado.    **Designação**  Designação do artigo movimentado.    **Data**  Data efetiva do movimento.  Atenção, que sempre que lançar movimentos de stock diretamente neste ecrã a aplicação tem em conta a data definida no [parâmetro](ParâmetrosGerais.htm#data fechada) **Data fechada nos docs. de faturação, compras, recibos, pagamentos, adiantamentos, processos e docs. de tesouraria**, fazendo com que não seja possível lançar movimentos de stock anteriores a essa data.    **Hora**  Este campo apenas está disponível com a ativação do [parâmetro](ParâmetrosDeStocksEServiços.htm#PLRValoriza) **Utiliza valorização de Stocks por Data e Hora quando o custeio de stock é «Preço de Custo Ponderado» (re-instalar triggers)** e permite registar a hora do movimento de stock.    **Documento**  [Código do movimento](códigosdemovimentaçãodestocks.htm) efetuado, seguido do respetivo número do documento que deu origem ao mesmo.    **Nome**  Aqui será colocado o número e nome do cliente, caso seja uma saída de Stock, ou o número e nome do fornecedor caso seja uma entrada.    **Quantidade**  Será a quantidade, na unidade de medida do artigo, que foi movimentada neste lançamento.    **Valor Unitário**  Será o preço unitário com que foi realizado o lançamento, seja [entrada (custo)](ConstituiçãodaTabeladeStockseServiços.htm#aducusto$) ou [saída (venda)](ConstituiçãodaTabeladeStockseServiços.htm#aduvenda$).    **Total**  Será o valor global deste movimento, ou seja, o preço unitário multiplicado pela quantidade.    **Valor Unitário em ( )**  Será o preço unitário com que foi realizado o lançamento, seja [entrada (custo)](ConstituiçãodaTabeladeStockseServiços.htm#aducusto$imp) ou saída (venda), em moeda estrangeira.    **Total em moeda**  Total do documento em moeda estrangeira.    **Nº e nome do Armazém**  Número e nome do armazém a que se refere o movimento.    **Transferência entre armazéns**  Se o movimento se referir a uma transferência ficará devidamente assinalado neste campo.       Se possuir [PHC ON](oqueéophcon.htm) saiba mais sobre como anular a inversão de armazéns na cópia de dossiers internos>, clicando [aqui](http://on.phc.pt/onphce/programs/nwwwview.aspx?stamp=fcggdc1f8cc.591%3a.2ec5.c1%3a).     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre como poderá criar Dossiers Internos de Transferências entre Armazéns, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=7b17dde1b%3a6.f74c.b115.78f).    **Zona**  Este campo esta disponível se possuir o Módulo Logística e permite definir qual a zona do Armazém deste movimento de stock.  Ao clicar no botão  aparecerá uma listagem de todas as zonas do armazém em causa.    **Alvéolo**  Este campo esta disponível se possuir o Módulo Logística. E permite definir qual o alvéolo deste movimento de stock.  Ao clicar no botão  aparecerá uma listagem de todas os alvéolos do armazém em causa.    **Valor do IVA**  Permite verificar o valor do IVA do movimento.    **Preço de Custo Ponderado**  Permite observar o valor do preço de custo ponderado do [movimento](códigosdemovimentaçãodestocks.htm).    **Lote**  Referência do lote. (Só para quem possui o módulo de Lotes)    **CSNC**  Campo de ligação á contabilidade.     **Tamanho**  Tamanho do artigo envolvido.(Só para quem possui o módulo de Grelhas)    **Cor**  Cor do artigo envolvido.(Só para quem possui o módulo de Grelhas)     **Refª Interna**  Campo para indicação da Refª interna. (já explicada noutros capítulos)    **Centro Analítico**  Campo para indicar o centro de custo do movimento.    **Contabilizado**  Este campo só se encontra disponível se o utilizador possuir o módulo Contabilidade e informa o utilizador se o movimento em questão foi ou não contabilizado. Com um clique direito o utilizador pode visualizar o Diário, Nº e Data de Lançamento resultantes da integração de movimentos de stock na contabilidade.    É possível ver a origem dos movimentos que nos são apresentados, se clicarmos no botão  . |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Movimentos de Stocks' ) |