---
title: Constituiçãodatabelademovimentosdetesouraria
source: constituiçãodatabelademovimentosdetesouraria.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabelademovimentosdetesouraria

Constituição da Tabela de Movimentos de Tesouraria

|  |
| --- |
| Constituição da Tabela de Movimentos de Tesouraria |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de movimentos de tesouraria, ou seja, o local onde são arquivados todos os movimentos que dizem respeito aos valores. A alteração destes movimentos, uma vez [reconciliados](opçõesdisponíveisnoecrãdecontastesouraria.htm), depende do [acesso](AcessosdeTesouraria.htm#mpsmovrec) atribuído ao utilizador. Esta tabela é constituída pelos seguintes campos:    **Classificação**  Este campo permite indicar/observar a classificação de tesouraria do movimento.  Se tiver o parâmetro **Utiliza tesouraria resumida (reinstalar triggers)** ativo e se tiver o parâmetro **Classificação de tesouraria a utilizar quando se utiliza tesouraria resumida** preenchido, este campo vai apresentar a classificação de tesouraria definida neste último parâmetro.  A classificação de tesouraria é importante para as análises de tesouraria e os seus códigos são definidos na tabela de [Códigos de Tesouraria](códigosdetesouraria.htm).    **Data do movimento**  Este campo regista a data em que o movimento foi executado.    **Data valor**  Neste local consta a data do valor do movimento.    **Documento**  Este campo permite identificar o nome e o número do documento que deu origem ao movimento de tesouraria.    **Descrição**  Neste campo é possível registar o nome do cliente ou fornecedor relacionado com o movimento de tesouraria.    **Entrada**  Esta opção permite registar o valor do movimento, caso o mesmo seja uma entrada.    **Saída**  Esta opção permite registar o valor do movimento, caso o mesmo seja uma saída.    **Classificação Estatística**  Neste campo é possível registar o [código de classificação estatística](CódigosdeClassificaçãoEstatistica.htm#camc) associado ao movimento de tesouraria.    **Operações com o exterior**  Esta opção permite indicar que o movimento de tesouraria é referente a uma operação com uma entidade estrangeira.    **Local**  Neste campo fica indicado o local de tesouraria do movimento, ou seja, se é Caixa ou determinado Banco.    **Centro analítico**  Esta opção permite colocar informação adicional no movimento. O preenchimento deste campo é opcional e geralmente é oriundo do documento de origem. A informação contida neste campo pode ser utilizada com diversos fins, tais como: análises, mapas e integração na Contabilidade (caso o utilizador possua o respetivo módulo). Para mais informações sobre este campo consulte por favor o manual de Contabilidade e os [Parâmetros.](Parâmetrosgerais.htm#centro analítico)     **Refª interna**  Esta opção permite colocar informação adicional no movimento. O preenchimento deste campo é opcional e geralmente é oriundo do documento de origem. A informação contida neste campo pode ser utilizada com diversos fins, tais como: análises, mapas e integração na Contabilidade (caso o utilizador possua o respetivo módulo). Para mais informações sobre este campo consulte por favor o manual de Contabilidade e os [Parâmetros.](Parâmetrosgerais.htm#ref interna)     **Identificação interna**  Esta opção permite colocar informação adicional no movimento, que poderá ser utilizado em mapas e listagens, bem como pode ser utilizado na integração para a Contabilidade (caso o utilizador possua este módulo) e na [Reconciliação bancária](opçõesdisponíveisnoecrãdeextratosbancários.htm). A informação deste campo é geralmente proveniente do documento original.    **Veio da contabilidade**  Esta opção só se encontra disponível se o utilizador possuir o módulo de Contabilidade e permite saber se o movimento é originário do módulo de Contabilidade.    *Nota:*  Os seguintes campos só se encontram disponíveis se o utilizador possuir o módulo POS.    **Loja**  Este campo identifica a loja onde foi executada a venda e que originou o movimento de tesouraria.     **Terminais de vendas**  Este campo identifica o terminal onde foi executada a venda e que originou o movimento de tesouraria.    **Responsável de caixa**  Neste campo fica registado o nome do responsável de caixa, relativo ao movimento executado.    **Operador**  Neste campo fica registado o nome do operador de caixa, relativo ao movimento executado.    **Número da caixa**  Este campo permite visualizar a caixa onde foi efetuado este movimento de tesouraria.    **Modos de pagamento**  Estes campos devem ser preenchidos quando os lançamentos de tesouraria forem manuais, ou seja, quando forem inseridos diretamente neste ecrã. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Movimentos de Tesouraria' ) |