---
title: Constituiçãodatabelademovimentosdevaloremstocks
source: constituiçãodatabelademovimentosdevaloremstocks.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabelademovimentosdevaloremstocks

Constituição da Tabela de Movimentos de Valor em Stocks

|  |
| --- |
| Constituição da Tabela de Movimentos de Valor em Stocks |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Movimentos de Valor em Stocks contém a informação dos movimentos de todos os documentos que lancem stocks em valor ***([Códigos de Movimentação de Stocks](códigosdeconta-corrente.htm))*** e todas as alterações introduzidas directamente.    **Referência**  Referência do artigo movimentado.    **Designação**  Designação do artigo movimentado.    **Data**  Data efectiva do movimento.  Atenção, que sempre que lançar movimentos de valor em stock directamente neste ecrã a aplicação tem em conta a data definida no [parâmetro](ParâmetrosGerais.htm#data fechada) **Data fechada nos docs. de facturação, compras, recibos, pagamentos, adiantamentos, processos e docs. de tesouraria**, fazendo com que não seja possível lançar movimentos de valor em stock anteriores a essa data.    **Hora**  Este campo apenas está disponível com a activação do [parâmetro](ParâmetrosDeStocksEServiços.htm#PLRValoriza) **Utiliza valorização de Stocks por Data e Hora quando o custeio de stock é «Preço de Custo Ponderado» (re-instalar triggers)** e permite registar a hora do movimento de valor em stock.    **Documento**  [Código do movimento](códigosdemovimentaçãodestocks.htm) efectuado, seguido do respectivo número do documento que deu origem ao mesmo.    **Nome**  Aqui será colocado o número e nome do fornecedor, caso seja um documento que movimente valor de stocks.    **Total**  Será o valor global deste movimento, ou seja, o valor a dividir pela quantidade de stock existente alterando o Preço de custo ponderado. Cada novo registo soma ao anterior e divide pela quantidade actual.     **Total em moeda**  Total do movimento em moeda estrangeira.    **Nº e nome do Armazém**  Número e nome do armazém a que se refere o movimento.    **Lote**  Referência do lote. (Só para quem possui o módulo de Lotes)    É possível ver a origem dos movimentos que nos são apresentados, se clicarmos no botão  .     Para esta opção funcionar correctamente, é necessário executar alguns passos:    1- No ficheiro de Códigos de Conta-Corrente (nas tabelas de códigos), é necessário criar um código para os movimentos de valores em stock. Para esse efeito define-se a opção **Lança como valor em stocks com o código...**    2- No documento (por exemplo Nota de crédito) deve ser indicado qual o **código de Conta-Corrente** a utilizar. Desta forma, quando é registado o documento, é executado o respectivo movimento de valor.    *Nota*: Só é possivel configurar documentos de modo a que lançem automaticamente em valor nas Compras e Pagamentos. Também a Nota de Crédito, como já foi referido, pode lançar como valor em stocks. Os restantes documentos de facturação não possuem esta funcionalidade. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Movimentos de Valor em Stocks' ) |