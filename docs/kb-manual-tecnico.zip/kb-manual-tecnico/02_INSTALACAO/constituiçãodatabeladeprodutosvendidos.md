---
title: Constituiçãodatabeladeprodutosvendidos
source: constituiçãodatabeladeprodutosvendidos.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladeprodutosvendidos

Constituição da Tabela de Produtos Vendidos

|  |
| --- |
| Constituição da Tabela de Produtos Vendidos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Movimentos de Produtos Vendidos contém a informação de venda dos artigos e é constituída pelos seguintes campos:    **Referência**   [Referência](ConstituiçãodaTabeladeStockseServiços.htm#aduref) do artigo que foi vendido.    **Designação**  [Designação](ConstituiçãodaTabeladeStockseServiços.htm#adudesig) da referência.    **Cliente e nº do cliente**  Identificação do cliente.    **Estabelecimento**  Identificação do estabelecimento.    **Documento e nº do documento**  Permite observar os dados do documento original.    **Vendedor**  Neste campo fica registado o nome do vendedor do cabeçalho do documento ou se por opção das linhas do documento, que prevalece ao cabeçalho.    **Área**  Permite classificar os registos por área.  Se o utilizador tiver [controlo de acessos à área](GestãodeUtilizadores.htm#mpsaddmailarea), apenas conseguirá consultar e criar registos para a sua área bem como consultar os registos de área vazia.    **Quantidade**  Informa o número de unidades que foram vendidas.    **Valor unitário**   Este campo informa o [preço unitário](ConstituiçãodaTabeladeStockseServiços.htm#aducusto$) do artigo.    **Base sem descontos**  Este campo informa do valor antes de descontos    **Total**   Valor pelo qual o artigo foi vendido.    **Total de custo**  Indica o total do custo para venda deste artigo.    **Data**  Informa a data do movimento.    **Movimento já pago em ( )**  Permite saber se o cliente já pagou este movimento.    **Exemplo**:  Quando se introduz um documento de facturação, que lança e regulariza automaticamente os movimentos de c/c, se este documento lançar em produtos vendidos, os campos **Data** e **Movimento já pago em ( )** ficam automaticamente preenchidos.    **Tabela de comissões**  Serve para indicar a [tabela de comissões](ConstituiçãodaTabeladeStockseServiços.htm#adudescvend) que foi utilizada.    **Valor extra comissão**  Informa o valor da comissão extra do vendedor. Este valor é cálculado nas linhas dos documentos de facturação que lancem em Produtos Vendidos e é colocado automaticamente neste campo.   Quando se [processam as comissões](ConstituiçãodoCálculodeComissões.htm#mpsforma1) do vendedor este valor é igualmente processado.  Caso não se utilize o [parâmetro](Parâmetrosdefaturação.htm#mpsextracom) relativo aos documentos de facturação este campo não entra no cálculo do valor extra comissão nem nunca é preenchido com qualquer outro valor proveniente de outra [forma de cálculo](ConstituiçãodoCálculodeComissões.htm#mpsforma2).    **Valor já processado para comissão**  Permite observar o valor das comissões processadas.    **Movimento já totalmente processado para comissões**  Quando validado informa a totalidade da comissão processada. Se o movimento for desprocessado o valor já processado para comissões fica a zero, no entanto, se o movimento em causa tiver sido ciado nos Produtos vendidos, ao desprocessar o mesmo movimento, o valor processado para comissões fica alterável, podendo o utilizador introduzir este valor.    **Classificação**  Indica a classificação de documentos de facturação do cliente.    **Segmento**  Indica o Segmento de mercado do cliente.    **Data de instalação**  Informa a data de instalação.    **Tabela Livre**  Informa do campo definido do [artigo](ConstituiçãodaTabeladeStockseServiços.htm#adutabliv) pelo utilizador    **Marca**  Informação opcional que poderão ou não ser utilizados na tabela do [artigo](ConstituiçãodaTabeladeStockseServiços.htm#adumarca).    **Modelo**  Informação opcional que poderão ou não ser utilizados na tabela do [artigo](ConstituiçãodaTabeladeStockseServiços.htm#adumarca).    **Linha de produto**  Informação opcional que poderão ou não ser utilizados na tabela do [artigo](ConstituiçãodaTabeladeStockseServiços.htm#adumarca).    **Tipo de produto**  Informação opcional que poderão ou não ser utilizados na tabela do [artigo](ConstituiçãodaTabeladeStockseServiços.htm#adumarca).    **Refª interna**  Informa aqui qual a referência interna a que está associado o artigo.  (campo de renomeação nos [Parâmetros Gerais](parâmetrosgerais.htm))    **Centro Analítico**  Informa neste campo, a que centro analítico pertence o artigo.  (campo de renomeação nos [Parâmetros Gerais](parâmetrosgerais.htm))      É possivel ver a origem dos movimentos que nos são apresentados, se clicarmos no botão  . |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Produtos Vendidos' ) |