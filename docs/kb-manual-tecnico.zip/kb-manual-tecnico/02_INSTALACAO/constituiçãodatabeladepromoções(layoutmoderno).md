---
title: Constituição da Tabela de Promoções (layout Moderno)
source: constituiçãodatabeladepromoções(layoutmoderno).htm
tipo: Manual Técnico
idioma: PT
---

# Constituição da Tabela de Promoções (layout Moderno)

Se tiver o
parâmetro
Usa o ecrã de promoções clássico (versão 18)
inativo, o ecrã de "Promoções" apresenta a seguinte informação:
Tipo
Este campo permite escolher a " Promoção definida pelo utilizador" configurada ou um tipo de promoção predefinida criada no ecrã
Tipos de Promoções Pré-definidas
.
Se optar pela promoção predefinida, são apresentadas as variáveis configuradas no ecrã
Tipos de Promoções Pré-definidas
para que possa substituir automaticamente as mesmas no campo
Descrição
com a "Descrição para o utilizador".
Além disso, os campos
Resumo
,
Descrição
,
Condição XBASE para aplicar a esta promoção
e
Tipo de promoção a aplicação
são automaticamente preenchidos com a informação configurada no ecrã
Tipos de Promoções Predefinidas
.
Por exemplo:
No campo
Descrição
apresenta a expressão:
#3#% nos #1# com #2# dias ou menos para atingir o prazo de validade
.
O resultado final é uma promoção 30% nos produtos frescos durante 2 dias.
Resumo
Denominação da promoção.
Descrição
Permite atribuir uma descrição à promoção.
Validade de DD.MM.AAAA a DD.MM.AAAA
Permite definir entre que datas a promoção estará em vigor.
Ordem
Índice que serve de base para ordenar as promoções por prioridade. Quanto mais baixo for este número, maior a prioridade da promoção.
Loja Web
Este campo apenas está disponível se possuir o módulo
PHC CS Loja web
e permite indicar se a promoção é para a loja web.
Código
Este campo apenas está disponível se possuir o módulo
PHC CS Loja web
e deve ser preenchido com o código da promoção que será utilizado posteriormente na loja web quando se pretender utilizar a promoção em questão.
Apenas para POS
Este campo apenas está disponível se tiver o
parâmetro
Usa o ecrã de promoções clássico (versão 18)
inativo e se tiver o módulo PHC CS POS desktop.
Este campo permite indicar as promoções que são exclusivas para o ecrã de Faturação em POS (Touch ou não Touch).
Quando são criados registos com a opção
Apenas para POS
ativa, ao entrar apenas com o módulo PHC CS Gestão desktop (sem POS validado), não serão apresentados os registos das promoções que tenham essa opção ativa.
Nota:
Aquando do upgrade da versão, este campo é automaticamente atualizado marcando todos os registos de promoções que tenham XBASE - para não impedir que promoções que antes só eram executadas com POS, sejam agora avaliadas nos Dossiers Internos e Faturação.
Critérios
Neste separador constam as condições da aplicabilidade da promoção: artigos, clientes e outras condições que sejam implementadas via XBASE.
Artigos ou serviços aos quais se aplica esta promoção:
Todos os artigos
Esta opção apenas está disponível nas gamas Advanced e Enterprise, para utilizadores com PHC On ativo e permite que seja aplicada a promoção a todos os artigos à venda, sem qualquer limitação.
Uma família
Permite definir a
família
de artigos para a qual a promoção é válida.
Um intervalo de referências
Permite definir quais as
referências
para qual a promoção é válida, especificando um dado intervalo.
Um tipo de artigo
Esta opção apenas está disponível nas gamas Advanced e Enterprise, para utilizadores com PHC On ativo e permite definir que a promoção apenas se aplica a artigos com um determinado tipo para descontos.
Uma referência específica
Serve para definir a promoção apenas para determinada
referência
.
Clientes aos quais se aplica esta promoção:
Todos os clientes
Define que a promoção é válida para todos os clientes.
Um tipo de cliente
Define que a promoção é apenas válida para determinado
tipo de cliente
.
Um cliente específico
Define que a promoção é apenas válida para determinado
cliente
, independentemente do estabelecimento.
Condição XBASE para aplicar esta promoção
Neste campo pode adicionar código de utilizador, cuja condição será adicionada às que a aplicação já considera. Ou seja, uma promoção que seja válida para todos os clientes, do tipo
Desconto fixo
e que se aplique a uma determinada
família
, pode ter em conta uma outra variável que seja resultado da avaliação da expressão XBASE (que deve retornar um valor lógico).
Neste campo pode utilizar a variável "m.cTabela" para verificar a origem da chamada da rotina das promoções. Esta variável pode ter os seguintes valores: "BO", "FT" e "FPOSC".
Por exemplo:
"return iif(m.cTabela = 'BO',.f.,.t.)".
Notas:
- Este campo está disponível com o módulo PHC CS POS desktop e/ou PHC CS Gestão desktop, nas gamas Advanced e Enterprise;
- As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo;
- Esta opção XBASE é válida para os documentos de faturação e dossiers internos.
é um programa em XBASE (deve retornar um valor lógico: Verdadeiro ou Falso)
Esta opção está disponível com o módulo PHC CS POS desktop e/ou PHC CS Gestão desktop, na gama Enterprise com PHC On ativo ou inativo e deve estar ativa quando a condição xbase definida no campo
Condição XBASE para aplicar esta promoção
é um programa.
Promoção
Neste separador define-se o tipo de promoção a aplicar:
Quantidade oferecida do mesmo artigo
Esta opção permite definir que por cada
x
unidades vendidas, são oferecidas
y
unidades do mesmo artigo.
Quantidade oferecida de um determinado artigo
Esta opção permite definir que por cada
x
unidades vendidas, são oferecidas
y
unidades de outro artigo.
Desconto fixo
Com esta opção é possível definir diversos descontos (até 6). Recomenda-se que os documentos de destino (Compras, Dossiers internos e Faturação) também possuam os descontos definidos, permitindo desta forma que os utilizadores compreendam os valores patentes nos documentos.
Redução de preço unitário
Desta forma define-se que a promoção consiste numa redução de preço. Esta redução é afixada em percentagem.
Preço fixo
Esta promoção permite definir um preço fixo do artigo.
Emissão de vale de desconto (apenas para POS)
Quando está validado o módulo PHC CS POS desktop, passa a ser possível definir a série do tipo de vales a partir da qual será criado o vale de desconto (apenas nos documentos de faturação em modo Touch POS). Ou seja, depois de gravado o documento de faturação do tipo "Fatura" são criados o(s) vale(s) de acordo com a promoção/promoções aplicada(s).
Nota:
A opção surge no ecrã independentemente do parâmetro
Utiliza vales de descontos/cheques oferta (reinstalar triggers)
estar ativo ou inativo, mas o utilizador é alertado no sentido de o ativar.
XBASE
Caso estejam reunidas as condições para se aplicar a promoção, a aplicação vai executar apenas o código aqui definido (é da total responsabilidade do utilizador a manipulação dos dados onde é despoletada a promoção).
Este campo pode utilizar a variável "m.cTabela" para verificar a origem da chamada da rotina das promoções. Esta variável pode ter os seguintes valores: "BO", "FT" e "FPOSC".
Por exemplo:
Se tiver o módulo PHC CS Gestão desktop, aceder ao ecrã de "Promoções" e criar um novo registo com a seguinte configuração:
- "Todos os artigos";
- "Todos os clientes";
- Na "Condição XBASE para aplicar esta promoção" colocar o seguinte código: "return iif(m.cTabela = "BO",.f.,.t.)";
- No separador "Promoção", selecionar o tipo de promoção "XBASE" e colocar o seguinte código:
Do Case
Case m.cTabela = "FT"
m.cLinha = "FI"
Case m.cTabela = "FPOSC"
m.cLinha = "FPOSL"
Case m.cTabela = "BO"
m.cLinha = "BI"
ENDCASE
if not m.cLinha == "BI"
select (cLinha)
replace &cLinha..epv with 11
endif
- Aceder ao ecrã de Faturação, inserir o artigo "A001" e verificar que o preço é atualizado para o valor de 11€.
- Nesta promoção em particular, a condição está a verificar se a origem não é a tabela "BO", ou seja, num Dossier Interno apenas a condição vai ser avaliada, nem sequer chega a executar o código XBASE do tipo de promoção.
Notas:
- Este campo está disponível com o módulo PHC CS POS desktop e/ou PHC CS Gestão desktop, nas gamas na gama Advanced e Enterprise;
- As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo;
- Esta opção XBASE é válida para os documentos de faturação e dossiers internos.
é um programa em XBASE
Esta opção apenas está disponível com o módulo PHC CS POS desktop e/ou PHC CS Gestão desktop, nas gamas Advanced e Enterprise, sendo que a promoção é aplicada se tiver na gama Advanced com PHC On ativo ou na gama Enterprise com e sem PHC On ativo e deve estar ativa quando a condição xbase definida no campo
XBASE
é um programa.
Loja
Este separador apenas está disponível se possuir o módulo PHC CS POS desktop e tem como finalidade indicar se a promoção em questão se aplica a todos as lojas ou a uma loja específica.
Se se tratar de uma promoção a aplicar apenas a uma loja específica, essa loja deve ser selecionada no campo
Loja
, se se tratar de uma promoção a aplicar a todas as lojas deve ser ativa a opção
Todas as Lojas
.
Depois de definir a promoção é necessário configurar os documentos de faturação e os dossiers internos para utilizar as promoções. Para mais informações sobre as configurações consulte por favor os capítulos sobre
Configuração de Dossiers Internos
e
Configuração de Documentos de Faturação
.
Promoções
