---
title: Constituiçãodatabeladereferenciais
source: constituiçãodatabeladereferenciais.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladereferenciais

Constituição da Tabela de Referenciais

|  |
| --- |
| Constituição da Tabela de Referenciais |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O ecrã Referenciais permite as seguintes opções:     **Tipo**  Identifica o tipo referencial. Este campo é configurado na tabela Tipos de Referenciais.  Este campo é de preenchimento obrigatório.     **Situação**  Um referencial tem uma situação que poderá ter um dos seguintes valores: Em elaboração, Em aprovação, Aprovado e Inativo.    **Referência**  Permite identificar a referência do referencial.    **Resumo**  Permite descrever de uma forma sucinta o resumo do seu referencial.     **Descrição**  Este campo é de texto livre e será útil para descrever o referencial.     **Requisitos de Referenciais**  Permite introduzir um requisito através do botão . Ao clicar Introduzir Requisito é aberto o ecrã de Requisitos de Referenciais em modo de introdução com o referencial previamente preenchido.     *Nota:* O ecrã de Requisitos de Referenciais apenas é acessível a partir do ecrã de Referenciais, não existindo opção para ele no menu.   Para introduzir novo requisito, os campos de Referência e Resumo são obrigatórios. Também poderá ser definida uma Descrição em texto livre.  Ao gravar o Requisito a informação é inserida na árvore do ecrã "Referenciais".       **Sub-requisitos de Referenciais**  Permite introduzir um sub-requisito através do botão . Ao clicar Introduzir Sub-requisito é aberto o ecrã de Sub-requisitos de Referenciais em modo de introdução com o referencial previamente preenchido.  Para que esta opção esteja disponível é necessário ter selecionado um requisito.  O ecrã de Sub-requisitos de Referenciais apenas é acessível a partir do ecrã de Referenciais. Para introduzir novo requisito, os campos de Referência e Resumo são obrigatórios. Também poderá ser definida uma Descrição em texto livre.  Ao gravar o Sub-requisito a informação é inserida na árvore do ecrã "Referenciais    *Nota:* Ao duplicar um Referencial, os Requisitos e os Sub-requisitos também são duplicados. Poderá introduzir novos registos através do botão , ou então consultar e/ou alterar os já existentes ao fazer duplo-clique num registo. Se alterar um requisito ou sub-requisito a informação da árvore do ecrã "Referenciais" é atualizada com os novos registos.      **Atenção** que se o utilizador em causa tiver a [opção](GestãoDeUtilizadores.htm#PLRQualidade) **Este utilizador é administrador do package Qualidade** inativa na sua ficha e se o Referencial tiver a situação igual a "Aprovado", este:  - não pode alterar nem apagar dados no ecrã de Referencial;  - não tem a possibilidade de introduzir requisitos e sub-requisitos na árvore;  - não tem a possibilidade de ao fazer duplo clique no Requisito ou Sub-requisito navegar para o respetivo ecrã.        **Opções Disponíveis no ecrã de Referenciais**    Ao abrir o ecrã de Referenciais fica disponível uma Barra de Ícones de Programas, onde existem variadas opções. Nessa barra existe um ícone  de [opções](menudeopçõesdoecrã.htm) com várias ações, algumas delas já disponíveis através de ícones, nomeadamente a [Introdução](introduçãoderegistos.htm) e [Eliminação](apagarouanularregistos.htm) de registos, bem como [mapas definidos pelo utilizador](mapasdefinidospeloutilizador.htm).     Este ícone permite imprimir a ficha que se encontra selecionada.  Para mais informações sobre esta opção consulte, por favor, o tópico [Impressões Definidas pelo utilizador](impressõesdefinidaspeloutilizador(idu).htm).      Os restantes ícones de carácter geral encontram-se explicados nos [opções globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Referenciais' ) |