---
title: Constituiçãodatabeladetriggersdeutilizador
source: constituiçãodatabeladetriggersdeutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladetriggersdeutilizador

Constituição da Tabela de Triggers de Utilizador

|  |
| --- |
| Constituição da Tabela de Triggers de Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela contém a seguinte informação:    **Titulo**  Nome do Trigger.    **Inactivo**  Campo que indica se o trigger deve ou não ser incluído na base de dados.    **Tabela**  Nome da tabela onde será aplicado o Trigger de utilizador.    **Tipo de Trigger**  Este campo indica qual o tipo de Trigger.    **Expressão do Trigger**  Expressão do Trigger de utilizador a ser instalado na base de dados do software Manufactor.    **Trigger encriptado**  Indica se o trigger deverá ser instalado, na base de dados, de forma encriptada. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Triggers de Utilizador' ) |