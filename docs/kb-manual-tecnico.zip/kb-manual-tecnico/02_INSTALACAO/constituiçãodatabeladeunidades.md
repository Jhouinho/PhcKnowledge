---
title: Constituiçãodatabeladeunidades
source: constituiçãodatabeladeunidades.htm
tipo: Manual Técnico
idioma: PT
---

# Constituiçãodatabeladeunidades

Constituição da Tabela de Unidades

|  |
| --- |
| Constituição da Tabela de Unidades |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Unidades é constituída pela seguinte informação:    **Unidade**  Permite indicar o código da unidade.    **Nº Horas**  Permite indicar o número de horas necessárias para a execução da unidade.    **Nº de Formandos Permitidos**  Permite indicar um número limite de formandos que possam frequentar a unidade.  Por exemplo: A sala de formação tem capacidade para 50 pessoas, mas existem apenas 20 PCs, logo terá que preencher este campo de forma a ser feito um controle para este efeito.    **Título**  Permite indicar o título da unidade.    **Curso**  Permite indicar o curso da unidade. Tabela criada pelo utilizador.    **Exame**  Tendo esta opção activa, significa que esta unidade irá ser utilizada para um exame.    **Inactiva**  Tendo esta opção activa, a unidade fica desactivada, ou seja, não será possível efectuar [módulos](constituiçãodatabelademódulos.htm) com base nesta unidade.    **Dados Principais**  Este campo serve para registar informação adicional respeitante à unidade em questão.    **Conteúdo Programático**  Campo de texto que serve para inserir informação relacionada com o conteúdo programático da unidade.    **Pré-requisitos**  Campo de texto onde são mencionados os pré-requisitos necessários à unidade.    **Referências**  Esta página só está disponível se tiver o módulo de Gestão.  Através desta página é possível fazer-se a ligação ao ficheiro de stocks. Os campos **Referência para Horário Normal** e **Referência para Horário Pós-Laboral** servem para a facturação, como os nomes indicam o seu preço será diferente conforme o horário escolhido. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Constituição da Tabela de Unidades' ) |