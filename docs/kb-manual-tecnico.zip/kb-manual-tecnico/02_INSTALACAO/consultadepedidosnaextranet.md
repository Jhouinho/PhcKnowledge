---
title: Consultadepedidosnaextranet
source: consultadepedidosnaextranet.htm
tipo: Manual Técnico
idioma: PT
---

# Consultadepedidosnaextranet

Consulta de Pedidos na Extranet

|  |
| --- |
| Consulta de Pedidos na Extranet |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Na consulta de pedidos de assistência técnica existem as seguintes opções:    **Apenas os meus pedidos**  Permite consultar os pedidos do utilizador.    **Não encerrados por mim**  Permite consultar todos os pedidos encerrados por terceiros.    **Encerrados pelo departamento de assistência técnica**  Permite consultar apenas os pedidos encerrados pelo departamento de assistência técnica.    **Sob controlo de**   O utilizador pode consultar os pedidos sob o seu controlo, controlo da assistência técnica ou ter como indiferente esta prorrogativa, pelo que, selecionando esta última, vai poder consultar todos os pedidos independentemente de quem os controlar.    **Quem abriu**  Permite procurar pelo nome da pessoa que abriu o PAT.     **Cliente final**  Permite procurar pela identificação do cliente final.    **N/Referência**  Permite introduzir a referência do utilizador relativa ao PAT que deseja consultar.    **Tipo de pedido**  O utilizador pode selecionar um dos tipos de pedidos existentes nesta tabela.    **Entre as datas**  Permite selecionar uma data inicial e final, estabelecendo assim um limite de tempo para a procura dos registos.    **Pedido Nº**  Permite procurar pelo nº do PAT.    **Instalação**  Permite procurar pelo nº da instalação referente ao PAT.    **Marca**  Neste campo o utilizador pode identificar o equipamento com a respetiva marca.    **Modelo**  Permite identificar o equipamento com o respetivo modelo.    **Ordenar por**  Este campo ordena os registos encontrados na pesquisa da forma escolhida pelo utilizador. Por exemplo, pode ordenar por data, nº de pedido, utilizador, *status* e data de alteração ao *status*.    **Pedidos por página**  Através deste campo é possível configurar quantos registos são visíveis por página.    Por fim, depois das opções de procura se encontrarem devidamente preenchidas e selecionadas, ao clicar em  é apresentada uma listagem ao utilizador com os respetivos pedidos de assistência, ordenados conforme o estabelecido.    Na lista apresentada, poderá, através da opção  selecionar o [PAT](meuspedidosdeassistência.htm) pretendido.         Poderá ainda, através do botão "Imprimir", imprimir o respetivo documento. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Consulta de Pedidos na Extranet' ) |