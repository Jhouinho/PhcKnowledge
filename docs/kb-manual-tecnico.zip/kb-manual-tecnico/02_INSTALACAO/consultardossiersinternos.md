---
title: Consultardossiersinternos
source: consultardossiersinternos.htm
tipo: Manual Técnico
idioma: PT
---

# Consultardossiersinternos

Consultar Dossiers Internos

|  |
| --- |
| Consultar Dossiers Internos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Consultar os Dossiers Internos**  Esta opção está disponível em diversos ecrãs, como por exemplo, nos ecrãs de Clientes, Fornecedores e Instalações.    Este botão permite observar todos os Dossiers Internos emitidos para o registo presente no ecrã.  Ao clicar neste botão fica disponível a lista de Dossiers Internos, a grelha de Documentos emitidos e a grelha de Linhas. Assim que seleccionar o Dossier pretendido na lista de Dossiers Internos, as grelhas de Documentos e Linhas são automaticamente actualizadas se tiver o [parâmetro](ParâmetrosGerais.htm#mpsobservar1) **Observar lista de documentos apenas quando pressiona o botão «Observar» nos ecrãs de cópia entre documentos** inactivo. Se tiver este parâmetro activo, terá de seleccionar o dossier que pretende observar e depois clicar no botão  ou dar duplo clique no tipo de dossier para a aplicação mostrar os dossiers emitidos.        Neste ecrã ficam disponíveis:    A opção **consultar apenas os abertos** verifica se existem dossiers que estejam em aberto. Quando esta opção está activa, na grelha de Documentos ficam disponíveis todos os dossiers emitidos e que ainda se encontrem em aberto.    A opção **observar apenas linhas não satisfeitas** verifica se existe diferença entre a Quantidade e a Quantidade 2 (previsional). Quando esta opção está activa, na grelha de Linhas ficam disponíveis todos os artigos onde a diferença entre a Quantidade e a Quantidade 2 (previsional) do dossier seja maior que zero.    O botão  permite aceder ao Dossier Interno original.    O botão  permite introduzir um Dossier Interno.  Deve primeiramente seleccionar o tipo de dossier e depois clicar neste botão, para introduzir um dossier do tipo seleccionado. A vantagem, por exemplo, de introduzir uma Encomenda de Cliente a partir deste botão, é o facto do cabeçalho do mesmo ser preenchido de forma automática.    *Nota:* O tamanho das colunas é guardado por tipo de dossier. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Consultar Dossiers Internos' ) |