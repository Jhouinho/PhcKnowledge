---
title: Contabilização de Letras a Receber
source: contabilizaçãodeletrasareceber.htm
tipo: Manual Técnico
idioma: PT
---

# Contabilização de Letras a Receber

O objetivo deste
artigo técnico é mostrar os vários cenários possíveis de contabilização
de letras a receber consoante os vários parâmetros da contabilidade.
Cenário
n.º 1:
Parâmetro
"Integra movimentos de envio a desconto de letras, na Contabilidade"
– ATIVO
Parâmetro "Integra movimentos de envio a desconto de letras, na
Contabilidade, utilizando contas fixas" – INATIVO
Parâmetro "A letra recambiada fica em aberto (vs. efectua automaticamente
a opção Débito em C/C) - (re-instalar triggers)" – ATIVO
No exemplo que se
segue vamos lançar uma fatura no valor de 13.818,60 que será debitada na c/c
do cliente originando o saldo inicial. A seguir, serão lançados os diversos
movimentos de contabilização da letra:
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
Movimento
Saldo Inicial
13.818,60
0
0
0
0
0
1. Emissão da Letra
13.818,60
13.818,60
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
0
0
0
0
0
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
2. Envio a desconto
13.818,60
13.818,60
Saldo
0
0
0
0,00
13.818,60
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
0
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
3. Desconto Letra
Saldo
0
0
0
0,00
13.818,60
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
13.818,60
13.818,60
0
13.818,60
13.818,60
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
4. recâmbio
13.818,60
13.818,60
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
13.818,60
13.818,60
0
0
0
0
A seguir, vamos efectuar
 a amortização parcial da letra no valor de 1.000€
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
5. Amortização
1.000,00
Saldo
0
0
12.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
1.000,00
0
0
1.000,00
0
Por último, será
 efectuada a reforma da letra na totalidade originando uma nova letra no
 valor final de 12.818,60€
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
6. Reforma
12.818,60
12.818,60
12.818,60
12.818,60
Saldo
0
0
12.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
1.000,00
0
Contabilisticamente,
 todas as contas de clientes estão saldadas excepto a conta 212 pois a
 nova letra fica em carteira a debito no valor de 12.818,60€ pois já
 tinha sido amortizado anteriormente 1.000€
Cenário n.º 2:
Parâmetro "Integra
 movimentos de envio a desconto de letras, na Contabilidade" –
 inativo
Parâmetro "Integra
 movimentos de envio a desconto de letras, na Contabilidade, utilizando
 contas fixas"
- inativo
Parâmetro "A letra
 recâmbiada fica em aberto (vs. efectua automaticamente a opção Débito
 em C/C) - (re-instalar triggers)"
- ativo
Neste cenário vamos
 utilizar os mesmos valores pelo que o saldo inicial será novamente de
 13.818,60 resultado da emissão da fatura.
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
Movimento
Saldo Inicial
13.818,60
0
0
0
0
0
1. Emissão da Letra
13.818,60
13.818,60
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
0
0
0
0
0
0
O envio a desconto não
 existe pelo que os saldos das contas mantêm-se inalterados.
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
2. Envio a Desconto
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
0
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
3. Desconto Letra
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
13.818,60
13.818,60
0
13.818,60
13.818,60
0
Ao contrário da situação
 n.º 1, este movimento de recâmbio apenas vai movimentar a debito a conta
 215(ou 214) por contrapartida da 12 a credito.
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
4. Recâmbio
Saldo
0
0
13.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
13.818,60
13.818,60
0
0
0
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
5. Amortização
1.000,00
Saldo
0
0
12.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
1.000,00
0
0
1.000,00
0
2111xxxx
2121xxxx
2131xxxx
Debito
Credito
Debito
Credito
Debito
Credito
6. Reforma
12.818,60
12.818,60
12.818,60
12.818,60
Saldo
0
0
12.818,60
0,00
0
0
215xxxx (ou 214)
12zzz
Debito
Credito
Debito
Credito
0
0
1.000,00
0
O saldo final é
idêntico ao exposto na situação n.º 1 , ou seja,
contabilisticamente, todas as contas de clientes estão saldadas exceto
a conta 212 pois a nova letra fica em carteira a débito no valor de 12.818,60€
pois já tinha sido amortizado anteriormente 1.000€.
Gama de software
PHC a que se aplica: PHC Corporate, Advanced e Enterprise 2008.
