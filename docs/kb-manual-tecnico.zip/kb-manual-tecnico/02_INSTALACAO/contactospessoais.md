---
title: Contactospessoais
source: contactospessoais.htm
tipo: Manual Técnico
idioma: PT
---

# Contactospessoais

Contactos Pessoais

|  |
| --- |
| Contactos Pessoais |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A opção Contactos permite a gestão dos contactos pessoais do utilizador.    Em modo de consulta, o utilizador pode efetuar o *upload* de uma imagem no contacto pessoal, para isso deverá clicar no botão .    **Nome**  Nome do contacto. Este campo permitirá a rápida consulta de contactos.  O preenchimento deste campo é obrigatório.    **Número**  Este número é sequencial e não controlado pelo utilizador. Poderá ser utilizado em posteriores consultas.    **Categoria**  Permite a organização dos contactos pessoais por categoria/tipo de contacto. Assim, o contacto a introduzir poderá ser de um *Amigo*, de um *Cliente*, de um membro da *Família*, *pessoal*, de um *colega*, um contacto de *Trabalho*, ou um contacto *VIP*.     **Contacto público**  Ao validar esta opção, o contacto passa a ser público, ou seja, está acessível a qualquer utilizador da aplicação.    **Contacto frequente**  A validação desta opção possibilita posteriormente a uma fácil pesquisa dos contactos frequentes.    **Morada de casa**  Deverá corresponder à morada do contacto.    **Nome da Empresa**  Deverá ser preenchido com o nome da empresa à qual pertence o contacto.     **Telefone de Casa**  Permite a introdução do número de telefone de casa do contacto.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Telemóvel**  Permite a introdução do número de telemóvel do contacto.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Telefone da Empresa**  Permite a introdução do número de telefone da empresa à qual pertence o contacto.   Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **e-mail 1**  Permite a introdução do endereço principal de *e-mail* do contacto.    **e-mail 2**  Permite a introdução do segundo endereço de *e-mail* do contacto.    **Data de nascimento**  Data de nascimento do contacto. Esta data originará o registo automático do aniversário do contacto na [Agenda](agenda.htm).    **Página Pessoal**  Permite a introdução do *URL* de uma página de *internet* relacionada com o "Contacto Pessoal".    **Observações**  Permite a introdução de quaisquer informações que o utilizador considere relevantes.      Na barra de ferramentas de "Contactos" existem [variadas opções](opçõesdabarradeferramentas.htm). Algumas destas opções são comuns a todos os ecrãs, nomeadamente, a "Procura", a "Introdução" e a "Eliminação de registos".    Em "Contactos" estão também disponíveis as seguintes opções: - **Listagem:**  - [**Notas:**](blocodenotas.htm)   (Ao clicar neste botão são apresentadas todas as notas nas quais está referenciado) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Contactos Pessoais' ) |