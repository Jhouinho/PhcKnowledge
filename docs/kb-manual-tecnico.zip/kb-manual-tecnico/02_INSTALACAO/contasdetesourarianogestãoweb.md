---
title: Contasdetesourarianogestãoweb
source: contasdetesourarianogestãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Contasdetesourarianogestãoweb

Contas de Tesouraria no Gestão Web

|  |
| --- |
| Contas de Tesouraria no Gestão Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de contas de tesouraria é extremamente simples e permite registar as diversas contas de tesouraria.    Na barra de ferramentas deste ecrã existem várias opções. Algumas são comuns a todos os ecrãs, nomeadamente a **Procura de registos**.    **Banco**  Neste campo fica registado o nome do banco.    **Conta**  Este campo regista o número da conta bancária.    **Saldo de c/c neste momento**  Total do saldo existente em Conta de Tesouraria.   Ao entrar na Conta de Tesouraria, em modo de consulta, através deste campo existe a possibilidade de aceder mais rapidamente e de forma intuitiva ao respetiva "Extrato da Conta de Tesouraria".     **Saldo já reconciliado**  Este campo indica o valor do saldo que já foi reconciliado, na moeda definida.     **Tipo de conta**  Este campo permite identificar o tipo da conta, ou seja, à ordem, a prazo, etc.    **Moeda do Documento**  Este campo permite definir a moeda da conta bancária, Euro ou moeda estrangeira.    **N.I.B.**  Neste campo fica registado o Número de Identificação Bancária.    **Data de movimento**  Este campo guarda a data do saldo.    ``` Informação ```     **Gestor Conta**  Neste local pode-se indicar o nome do gestor da conta.    **Telefone**  Este campo permite guardar o número de telefone do gestor de conta.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Fax**  Neste campo é possível indicar o número do fax do gestor de conta.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Email**  Neste campo é possível indicar o Email do gestor de conta.    **Estabelecimento**  Neste campo é possível registar o código do estabelecimento.    **Juro**  Taxa de Juro utilizada na respetiva conta de Tesouraria.     ``` Integração ```     **Código da conta na Contabilidade**  Neste campo fica registada a conta da contabilidade referente a esta conta bancária.    **Plafond de Letra**  Este campo permite indicar um plafond máximo nesta conta de tesouraria.       Em modo de consulta é disponibiliza ainda a seguinte opção:    **Extrato Bancário**  Esta opção permite consultar um extrato bancário da conta selecionada.  Através do botão  pode selecionar-se qualquer outra conta para a consulta do extrato.  Esta consulta pode ser efetuada entre datas e o utilizador pode definir quantos registos pretende visualizar por página. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Contas de Tesouraria no Gestão Web' ) |