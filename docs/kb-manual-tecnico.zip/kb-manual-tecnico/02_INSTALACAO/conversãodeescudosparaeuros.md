---
title: Conversãodeescudosparaeuros
source: conversãodeescudosparaeuros.htm
tipo: Manual Técnico
idioma: PT
---

# Conversãodeescudosparaeuros

Conversão de Escudos para Euros

|  |
| --- |
| Conversão de Escudos para Euros |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção tem como objetivo fixar a taxa de reconversão e encontra-se disponível nas **Tabelas de Códigos**.    Para executar este procedimento basta indicar a taxa de câmbio, clicar em **Selecionar todos** e por fim clicar em **Avançar**.    Depois de confirmar duas vezes esta operação, respondendo SIM às perguntas que o sistema coloca, serão convertidos os Escudos em Euros.     Esta opção poderá demorar alguns minutos, sendo que o tempo de conclusão depende da velocidade do computador e da quantidade de informação contida no programa.     *Nota*:  Esta opção só deve ser utilizada quando o sistema é instalado e NUNCA durante a sua utilização. Se o fizer, poderá alterar dados já contabilizados (se possuir o módulo PHC CS Contabilidade desktop). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Conversão de Escudos para Euros' ) |