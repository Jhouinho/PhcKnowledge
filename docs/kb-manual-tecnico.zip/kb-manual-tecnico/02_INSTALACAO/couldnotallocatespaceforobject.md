---
title: Could Not Allocate Space For Object
source: couldnotallocatespaceforobject.htm
tipo: Manual Técnico
idioma: PT
---

# Could Not Allocate Space For Object

Problema:
Could
 not allocate space for object 'fn' in database 'xpto' because the 'PRIMARY'
 filegroup is full
Solução:
Este
 erro significa que já não existe espaço suficiente para o crescimento da
 Base de Dados. Deve ser verificado o espaço em disco do servidor onde está a
 base de dados.
Fazer
 ainda desfragmentação das tabelas via Instalação e Manutenção e diminuir
 o tamanho das bases de dados no Sqlmanager.
Este
 erro é mais comum no caso do Corporate em que o limite da Base de Dados é de
 2GB por causa do MSDE.
