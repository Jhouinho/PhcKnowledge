---
title: Criaranexo
source: criaranexo.htm
tipo: Manual Técnico
idioma: PT
---

# Criaranexo

Criar Anexo

|  |
| --- |
| Criar Anexo |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| É neste ecrã que se define qual o anexo a associar ao registo e qual a forma de ligação.    Existem três formas de ligação dos anexos com os registos:   * Gravar o ficheiro dentro da tabela   Quando se escolhe esta opção, o ficheiro fica guardado na base de dados e, como tal, acessível a todos os utilizadores.   * Gravar o ficheiro na Cloud (Dropbox)   Selecionando esta opção, o ficheiro será guardado no Dropbox, na pasta indicada no respetivo [parâmetro](ParâmetrosdoDocumentosdesktop.htm#RCTPasDrop).    Em relação a qualquer destas duas opções, pode-se optar por *apagar o ficheiro na origem depois de ter sido gravado* e, em caso afirmativo, ainda é possível optar por *enviá-lo para a Reciclagem* do computador.  Para além disso, pode-se optar por *gravar o ficheiro compactado*: esta opção compacta o ficheiro e grava-o no formato .zip, de modo a ocupar menos espaço na base de dados. Na manipulação do anexo este é descompactado para o seu formato original antes de ser utilizado. Para o utilizador é sempre visível o formato original do ficheiro.    Existe também a possibilidade de restringir as opções a apenas uma destas., mediante ativação de um [parâmetro](parâmetrosdodocumentosdesktop.htm). Se assim for, o utilizador não terá a hipótese de escolher na altura de gravar o anexo e este será gravado no destino predefinido.   * Criar apenas uma ligação na tabela para o ficheiro na origem   Com esta opção o ficheiro não é gravado na base de dados e só é feita uma ligação para a localização do ficheiro. Esta opção é preferível em instalações monoposto.      Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação, de forma a aumentar a capacidade do seu arquivo digital, carregando [aqui](http://on.phc.pt/onphce/ass/egaview.aspx?stamp=d327962fd%3a8.12cc.d965.c93).      Para indicar qual o ficheiro a anexar deve clicar no botão  e será aberta uma janela onde escolherá o ficheiro pretendido.    A opção  permite-lhe iniciar a digitalização do documento que será anexado.    Também é possível criar um anexo a partir de outro anexo existente na tabela devendo-se para isso clicar no botão . Este abre o ecrã de Gestão Documental que mostra os vários anexos existentes, o que permite que um mesmo anexo esteja associado a várias pastas e tabelas.     Se possuir [PHC ON](oqueéophcon.htm) saiba mais sobre o Monitor "Gestão Documental", carregando [aqui](https://www.phc.pt/portal/programs/ewpview.aspx?codigo=IDIR110928).    *Notas*   * Antes de utilizar a opção do scanner deve, no botão , configurar o scanner a utilizar:    Aqui deve ser escolhido:    o **Formato de ficheiro criado para mono página** (quando se pretende digitalizar apenas uma folha) onde as opções disponíveis são: PDF, TIF, BMP, JPG, PNG e GIF        e o **Formato de ficheiro criado para multi página** (quando se pretende digitalizar um documento com mais de uma folha) onde as opções disponíveis são PDF e TIF.        No botão  aparece uma lista com os scanners instalados para que possa escolher qual o scanner a utilizar.        Quando escolher a opção para usar um Scanner, o software pergunta se pretende mono folha ou multi folha e de seguida abre o ecrã do próprio scanner para que execute a digitalização.    Após a digitalização do documento é criado um ficheiro na diretoria temporária com o nome do ficheiro começando por: scan\_phc\_. Esse ficheiro poderá então ser adicionado ao Documentos desktop.    * Os cliques que ficam por defeito após utilizar esta opção são para apagar o ficheiro na diretoria - deve ter pois atenção antes de clicar na opção **OK**. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Criar Anexo' ) |