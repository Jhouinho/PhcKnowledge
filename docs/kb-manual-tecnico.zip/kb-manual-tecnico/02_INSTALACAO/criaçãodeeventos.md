---
title: Criação de Eventos
source: criaçãodeeventos.htm
tipo: Manual Técnico
idioma: PT
---

# Criação de Eventos

Os
"Eventos"
servem para executar reações a determinadas situações que ocorrem na utilização da aplicação.
Na elaboração do evento o utilizador poderá usufruir do
Editor de Código
sempre que encontre junto de um campo o botão
.
De seguida vai ser explicado como dar uma mensagem ao utilizador que abre um pedido de assistência, no seguimento da apresentação dos campos existentes em modo de
introdução
.
Se o utilizador assim o desejar, poderá interagir com o registo do evento, quando o aceder ao ecrã em modo de
consulta
.
Ecrã em modo de introdução/alteração
Para criar um evento o utilizador dispõe dos seguintes campos:
Resumo do evento
Serve para introduzir um pequeno resumo do evento e é de preenchimento obrigatório.
Número
Este número é sequencial e não controlado pelo utilizador. Poderá ser utilizado em posteriores consultas.
Inativo
Esta opção permite marcar o evento como inativo, indicando que deixa de ser executado.
Ecrã
Define qual o ecrã onde vai ser feito o evento.
Por exemplo:
boform
;
encform
;
fminform
;
foform
;
ftform
;
ftview
;
login
;
opcoesdomenu
;
paform
;
regfpform
.
Nota:
De acordo com o ecrã definido neste campo, a aplicação disponibiliza no campo
Nome do evento
a lista com os eventos passíveis de serem utilizados.
Reação ao evento
Neste campo, o utilizador pode escolher a reação que pretende efetuar quando o evento correr na aplicação:
eMail
Programa Interno
Nome do evento
Extistem eventos gerais que são disponibilizados independentemento da indicação que o utilzador der no campo
Ecrã
. São eles:
AoAlterar
AoIntroduzir
- Este evento corre no momento da introdução de um registo. Consulte o
exemplo
deste evento.
AposAlterar
AposApagar
AposAssinatura
AposCancelar
- O evento corre depois do utilizador cancelar um registo. Consulte o
exemplo
deste evento.
AposCriarGrelha
- Corre logo a seguir a ser criada a grelha nas páginas que têm esse objecto. Veja um
exemplo
deste evento;
AposGravarDialogo
;
AposIntroduzir
- O evento corre depois do utilizador cancelar um registo. Consulte o
exemplo
deste evento;
AposOnInit
- Quando os objetos ainda não estão criados;
AposOnLoad
- Quando os objetos já estão no ecrã, por exemplo para torná-los invisíveis. Consulte o
exemplo
deste evento;
AposPreRender
- Este evento, disponível em todos os ecrãs de
PHC CS Web
, corre a seguir aos eventos
AposOnInit
e/ou
AposOnLoad
de forma a permitir configurar globalmente todos os objetos do ecrã. Consulte o
exemplo
deste evento.
AposRefrescar
;
AposUpload
;
Mas se no campo
Ecrã
o utilizador especificar um dos ecrãs que se indicam, poderá usufruir de eventos especificos, dedicados a esses ecrãs. Como por exemplo:
-
boform
(Dossiers Internos - intranet ou extranet) ou
encform
(Encomendas - extranet), terá também especificamente acesso ao(s) evento(s):
BoAposActualizarRef
- Consulte o
exemplo
deste evento.
BoAposAlterarValorEmLinha
(apenas para utilizadores com gama Advanced ou Enterprise) Consulte o
exemplo
deste evento.
-
fminform
(Inscrição - intranet ou extranet), terá também especificamente acesso ao(s) evento(s):
AposCancelarInscricao
-
foform
(Compras), terá também especificamente acesso ao(s) evento(s):
FoAposAlterarValorEmLinha
(apenas para utilizadores com gama Advanced ou Enterprise) Consulte o
exemplo
deste evento.
-
ftform
(Documentos de faturação - intranet), terá também especificamente acesso ao(s) evento(s):
FtAposActualizarRef
- Consulte o
exemplo
deste evento.
FtAposAlterarValorEmLinha
(apenas para utilizadores com gama Advanced ou Enterprise) Consulte o
exemplo
deste evento.
-
ftview
(Documentos de Faturação - extranet), dedicado à extranet, terá também especificamente acesso ao(s) evento(s):
AoPagarPaypal
AoPagarUnicre
- Consulte o
exemplo
deste evento.
AoSubscreverPaypal
-
login
, terá também especificamente acesso ao(s) evento(s):
AposLogin
-
opcoesdomenu
, terá também especificamente acesso ao(s) evento(s):
AposDefinirMenu
- Consulte o
exemplo
deste evento.
-
paform
(Pedidos de Assistência - Intranet ou extranet), passará também especificamente acesso ao(s) evento(s):
AposAdicionarDialogo
(intranet)
AposClassificarPAT
(extranet)
AposFechar
(intranet) - Consulte o
exemplo
deste evento.
AposReabrirPAT
(extranet)
-
regfpform
, terá também especificamente acesso ao(s) evento(s):
AposMarcarFerias
Ordem do evento
No caso de existirem vários eventos para o mesmo ecrã, estes são executados mediante a ordem definida neste campo.
Condição
Este campo é utilizado para colocar o programa que vai validar o evento. Este tem de retornar um valor lógico (TRUE ou FALSE). Este campo tem
intellisense
, ou seja, quando é colocada uma letra na caixa de texto é aberta uma caixa com todas as sugestões de código disponíveis para completar aquela palavra, à medida que se vai escrevendo as opções mostradas começadas pelas letras introduzidas vão reduzindo e aproximando do que se pretende. Também se pode pressionar as teclas ctrl + espaço ou ctrl + seta baixo para aparecer essa mesma caixa mas com todas as opções de código disponíveis, sendo que ao escrever texto as opções na caixa vão sendo filtradas.
Podendo o utilizador, numa primeira abordagem à condição, compilar a expressão com recurso ao botão
para validar a existência de eventuais erros.
Nota:
Se este campo (condição) estiver vazio o evento corre sempre.
Caso o utilizador opte por efetuar nalgum destes campo um programa, terá que ter em atenção que o mesmo deverá ter a opção
é um programa
ativa e deve devolver um texto para ser interpretado como "string". Caso esta opções esteja ativa os campo tem
intellisense
, ou seja, quando é colocada uma letra na caixa de texto é aberta uma caixa com todas as sugestões de código disponíveis para completar aquela palavra, à medida que se vai escrevendo as opções mostradas são filtradas e vão reduzindo até se aproximando do que se pretende.
Após o desenvolvimento do código, o utilizador poderá recorrer ao botão
Para
Serve para colocar os endereços de
e-mail
dos destinatários. No caso de serem mais do que um, devem ser separados por ponto e vírgula.
C/c
Serve para colocar os endereços de
e-mail
. No caso de serem mais do que um, devem ser separados por ponto e vírgula.
Assunto
Local onde é colocado o assunto do
e-mail
.
Conteúdo
Define o texto do
e-mail
.
É em formato HTML
Permite ao utilizador indicar à aplicação se o texto introduzido no campo
Conteúdo
deve ser interpretado como código
HTML
.
Expressão
É possível construir um programa em VB.NET. Este campo tem
intellisense
, ou seja, quando é colocada uma letra na caixa de texto é aberta uma caixa com todas as sugestões de código disponíveis para completar aquela palavra, à medida que se vai escrevendo as opções mostradas começadas pelas letras introduzidas vão reduzindo e aproximando do que se pretende. Também se pode pressionar as teclas ctrl + espaço ou ctrl + seta baixo para aparecer essa mesma caixa mas com todas as opções de código disponíveis, sendo que ao escrever texto as opções na caixa vão sendo filtradas.
O utilizador tem disponíveis:
A variável
MPAGE
do tipo "page" - contém a página onde o evento está a correr;
A variável
MSTAMP
- string com o stamp do registo que está a fazer correr o evento;
E o objeto
MAINFORMDATASET
- contém todos os dados do registo e respetivas tabelas associadas do ecrã de onde está a correr o evento.
Um evento pode estar disponível nos diversos
packages
que o cliente tiver instalado, pode neste local definir onde aparecerá o evento criado.
Poderá optar pelos seguintes packages:
Portal
Intranet
PocketServices
Extranet
Frontwebservice
Internet
Por exemplo, se o utilizador quiser que o evento da aplicação ocorra com o módulo
PHC CS Suporte extranet web
, deve configurar este campo da seguinte forma:
Clique aqui para visualizar diversos
Exemplos de Eventos
.
Ecrã em modo de consulta
Ao consultar o registo do evento, o utilizador poderá:
Aceder diretamente ao ecrã de
Log de Código de Utilizador
E usufruir das
opções de registo
, bem como procurar um registo,
alterar
e/ou apagar o mesmo.
Framework Phc Cs Web
