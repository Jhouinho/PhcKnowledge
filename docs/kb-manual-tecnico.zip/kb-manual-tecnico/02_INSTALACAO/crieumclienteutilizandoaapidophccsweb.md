---
title: Crie um Cliente Utilizando a Api do Phc Cs Web
source: crieumclienteutilizandoaapidophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Crie um Cliente Utilizando a Api do Phc Cs Web

Para criar programaticamente um cliente, de forma rápida e fácil, poderá recorrer à API do PHCS CS Web, com o intuito de executar o código de um registo a partir de um Script da Framework PHC.
Por motivos de segurança, a API apenas pode ser utilizada na máquina local, onde a aplicação se encontra instalada.
Em primeiro lugar, é necessário configurar um
script
com os seguintes dados:
Resumo:
Criar um cliente programaticamente
Código:
CLAPI
Programa Interno:
' Montar funcionalidade de leitura das variáveis recebidas por API
mstamp = "&ltroot>" & mstamp & "</root>"
Dim stream As New System.IO.MemoryStream(Encoding.UTF8.GetBytes(mstamp))
Dim reader As System.Xml.XmlReader = New System.Xml.XmlTextReader(stream)
' Criação das variáveis
Dim nome As String = ""
Dim morada As String = ""
Dim ncont As String = ""
Dim column As String = ""
' obter estrutura de dados da tabela cl e cl2 a usar
Dim clTable = PhcCommandBuilder.
CreateSelect("*").
From("cl").
GetSqlResultOnlySchema(Of SqlChangedRow)(False)
Dim cl2Table = PhcCommandBuilder.
CreateSelect("*").
From("cl2").
GetSqlResultOnlySchema(Of SqlChangedRow)(False)
' Para cada elemento recebido
Do While (reader.Read())
Select Case reader.NodeType
Case System.Xml.XmlNodeType.Element 'Início do elemento.
column = reader.Name.ToLower
Case System.Xml.XmlNodeType.Text 'texto/valor em cada elemento.
Dim value As String = reader.Value
Select Case column
Case "nome"
nome = value
case "morada"
morada = value
case "ncont"
ncont = value
End Select
End Select
Loop
' Gerar novo stamp
Dim stamp = xcfox.u_stamp
Dim clRow = clTable.GetNewRow
Dim cl2Row = cl2Table.GetNewRow
Dim cl As New ClFormClass(clRow.ToWrapper, cl2Row.ToWrapper)
' Criar os valores por defeito para a tabela. Esta função utiliza o parâmetro do desktop: Procura furos na numeração dos clientes
cl.ValoresPorDefeitoAoIntroduzir(Normalform.EstadoDoMainForm.Adicionando)
clRow("clstamp") = stamp
cl2Row("cl2stamp") = stamp
clRow("nome") = nome
clRow("morada") = morada
clRow("ncont") = ncont
' Validar Nº contribuinte
If Not XcUtil.CheckNCont(clRow.ItemToString("ncont")) Then
Throw New PhcException("O {0} está mal preenchido. O check-digit não condiz. Verifique se o número que está a introduzir está correto e não se esqueça que o número deverá possuir 9 dígitos e não pode conter espaços.".FormatWith(cparas.ge_NomeparaNIFextenso()), cEnums.TipoDeMensagem.Info)
End If
' Gerar transação e inserir em ambas as tabelas
Using tran = SqlHelp.GetNewConnection.BeginPhcTransaction("CreateNewCL")
clRow.Insert(True)
cl2Row.Insert(True)
tran.Commit()
End Using
return "O registo do cliente foi criado programaticamente. "
Após gravar o registo do script na aplicação, é necessário limpar o cache da aplicação.
Para melhor entender o código apresentado, fica uma breve explicação:
Trata-se da introdução de um simples registo de cliente, recorrendo à API da aplicação PHC CS Web, indicando por parâmetros na API, as seguintes informações do Cliente:
Nome do cliente: "NOME";
Morada do cliente: "MORADA";
Nº de Contribuinte: "123456789" (sendo este validado por Check-Digit).
Quando é efetuada a introdução do registo, o código verifica e utiliza o parâmetro "Procura furos na numeração dos clientes" do PHC CS Desktop.
De modo a utilizar a API para executar o Código do Utilizador (Scripts), deverá aceder ao webservice através do seguinte caminho:
../Intranet/ws/wscript.asmx
Ao aceder à API, apenas disponível nas gamas Advanced e Enterprise e para subscritores do PHC On, através do caminho indicado, terá de clicar em
RunCode
para que possa facultar à API o acesso à aplicação, bem como definir os parâmetros desejados para o preenchimento desses campos na introdução do registo do cliente, através da API.
De acordo com a imagem, devemos preencher os campos que permitem o acesso à aplicação:
userName - ID de utilizador para login;
password - Palavra-passe do utilizador para login.
E os parâmetros a configurar no webservice, que vão interagir com o Script:
code: Código do registo de Scripts do Utilizador a executar; Este código tem sempre que retornar uma string;
parameter: Parâmetro para o código Script. Neste caso específico, indicar-se-ia os seguintes parâmetros:
&ltnome&gtNOME</nome>&ltmorada&gtMORADA</morada>&ltncont&gt123456789</ncont>
Em que:
&ltnome&gtNOME</nome>: Corresponde ao nome do cliente;
&ltmorada&gtMORADA</morada>: Corresponde à morada do cliente;
&ltncont&gt123456789</ncont>: Corresponde Nº de contribuinte do cliente.
Uma vez com os campos devidamente preenchidos, basta clicar em Invoke e o registo do cliente é criado, surgindo no ecrã a mensagem:
Por fim, retorna um texto que indica que a operação foi finalizada corretamente.
Funcionalidade disponível nas gamas PHC CS:
Advanced e Enterprise.
Subscrição de PHC On:
Sim
Ambiente de teste:
Versão de software PHC CS Web: 22;
Browser: Chrome (Version 61.0.3163.100)
