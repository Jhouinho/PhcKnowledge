---
title: Crie um Dossier Interno Utilizando a Api do Phc Cs Web
source: crieumdossierinternoutilizandoaapidophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Crie um Dossier Interno Utilizando a Api do Phc Cs Web

Para criar programaticamente um Dossier Interno assinado digitalmente, de forma rápida e fácil, poderá recorrer à API do PHCS CS Web, com o intuito de executar o código de um registo a partir de um Script da Framework.
Por motivos de segurança, a API apenas pode ser utilizada na máquina local, onde a aplicação se encontra instalada.
Para iniciar este procedimento, é necessário a elaboração do Script por exemplo:
Resumo:
Como criar um Dossier Interno programaticamente.
Código:
CriaDossierProg
Programa Interno:
' Transformação da string recebida pelo webservice em XML
mstamp = "
" & mstamp & "
"
Dim stream As New System.IO.MemoryStream(Encoding.UTF8.GetBytes(mstamp))
Dim reader As System.Xml.XmlReader = New System.Xml.XmlTextReader(stream)
' Criação das variáveis, doctype é nº interno do documento, clno é nº do cliente
Dim docType, clNo As Integer
Dim column As String = ""
Dim ref As String
Dim CreateBosDocWs As bizlib.boclass.CreateBODoc
Do While (reader.Read())
Dim newrowWithRefeQtt As DataRow
Select Case reader.NodeType
Case System.Xml.XmlNodeType.Element 'Início do elemento.
column = reader.Name.ToLower
Case System.Xml.XmlNodeType.Text 'texto/valor em cada elemento.
Dim value As String = reader.Value
Select Case column
Case "doctype", "no"
If column = "no" Then
Integer.TryParse(value, clNo)
Else
Integer.TryParse(value, docType)
End If
If docType > 0 AndAlso clNo > 0 Then
Try
' Criação do dossier interno
CreateBosDocWs = New bizlib.boclass.CreateBODoc(docType, clNo)
' Preencher o campo da data do dossier na tabela BO, com mais 3 dias em relação à hora atual
CreateBosDocWs.MainformDataset.Tables(0).Rows(0).Item("dataobra") = Date.Now.AddDays(8)
' Preencher o campo: Observações, na tabela BO
CreateBosDocWs.MainformDataset.Tables(0).Rows(0).Item("obs") = "Documento criado programaticamente"
' Preencher o campo: Data de expedição, na tabela do BO2
CreateBosDocWs.MainformDataset.Tables(1).Rows(0).Item("xpddata") = Date.Now.Date
' Preencher o campo: Hora de expedição, na tabela BO2
CreateBosDocWs.MainformDataset.Tables(1).Rows(0).Item("xpdhora") = Date.Now.ToShortTimeString
' Preencher o campo Data efetiva de entrega dos bens ou da prestação do serviço ao adquirente
CreateBosDocWs.MainformDataset.Tables(2).Rows(0).Item("taxpointdt") = Date.Now.AddDays(5)
Catch ex As System.Exception
ex.AddError("Não foi encontrado o documento ou o cliente")
Exit Do
End Try
End If
Case "ref"
If CreateBosDocWs IsNot Nothing Then
ref = value
' Criar uma linha em branco
Dim NewRow As DataRow = CreateBosDocWs.Addnewline()
' Adicionar a referência
NewRow.Item("ref") = ref
' Atualizar os dados da referência
CreateBosDocWs.actLinha(NewRow)
' Preencher o campo: Quantidade, em 10 unidades
NewRow.Item("qtt") = 10
' Preencher o campo: Valor da Venda, com valor unitário de 100 euros
NewRow.Item("edebito") = 100
' Criar mais uma nova linha
NewRow = CreateBosDocWs.Addnewline()
' Preencher o campo: Designação, da linha criada em branco
NewRow.Item("design") = "Linha do Dossier criada programaticamente"
Else
Sistema.adderror("Script do Utilizador", "Não foi possível adicionar a referência pois o documento não foi criado")
End If
' Validação do Parâmetro: descar, em relação à morada da Tabela de moradas de carga e descarga
Case "descar"
If CreateBosDocWs IsNot Nothing Then
CreateBosDocWs.MainformDataset.Tables(1).Rows(0).Item("descar") = value
Else
Sistema.adderror("Script do Utilizador", "Não foi possível configurar o local de descarga pois o documento não foi criado")
End If
Case Else
End Select
End Select
Loop
If CreateBosDocWs IsNot Nothing Then
' Gravação o dossier
CreateBosDocWs.Save()
Else
Return "Não foi possível gravar o documento"
End If
Explicação do código apresentado:
Trata-se da introdução de um Dossier do
Tipo para SAFT
= "GR" (assinado digitalmente), dirigido ao cliente 01 - "Albertino Maciel", que tem o registo da sua Morada na "Tabela de Moradas de Carga e Descarga". Assim sendo, o campo
Local habitual de descarga de mercadorias
no Dossier, será preenchido automaticamente.
Caso o cliente não tenha nenhuma morada introduzida na "Tabela de Moradas de Carga e Descargas" e o Dossier esteja configurado como
Tipo para SAFT
= "--"(não entra para saft), o valor do campo
Local habitual de descarga de mercadorias
é preenchido com a informação existente no parâmetro
Local de descarga habitual
.
De modo a utilizar a API para executar o Código do Utilizador (Scripts), deverá aceder ao webservice através do seguinte caminho:
../Intranet/ws/wscript.asmx
Ao aceder à API, disponível nas Gamas Advanced e Enterprise com PHC On ativo, através do caminho indicado, terá de clicar em
RunCode
para que possa facultar à API o acesso à aplicação, bem como definir os Parâmetros desejados para o preenchimento desses campos na introdução do Dossier Interno através da API.
De acordo com a imagem, devemos preencher os campos que permitem o acesso à aplicação:
userName
- ID de utilizador para login;
password
- Palavra-passe do utilizador para login.
E os parâmetros a configurar no
webservice
, que vão interagir com o Script:
code
- Código do registo de Scripts do Utilizador a executar; Este código tem sempre que retornar uma
string
;
parameter
- Parâmetro para o código Script. Neste caso específico, indicar-se-ia os seguintes parâmetros:
&ltno&gt1</no>&ltdoctype&gt919</doctype>&ltref&gtA001</ref>
Em que:
&ltno&gt1</no>
- Corresponde ao número do cliente;
&ltdoctype&gt919</doctype>
- Corresponde ao número da série do Dossier;
&ltref&gtA001</ref>
- Corresponde à referência do artigo.
Uma vez com os campos devidamente preenchidos, basta clicar em
Invoke
e o Dossier é criado, surgindo no ecrã a mensagem:
Por fim, retorna um texto que indica que a operação foi finalizada corretamente.
Ao gravar o Dossier, a informação retornada pode ser personalizada pelo implementador.
Nota:
Se o documento emitido pela API esteja configurado para movimentar stocks e se o cliente utilizar o módulo PHC CS Logística desktop, a aplicação não irá gerar os movimentos de stock para o documento, uma vez que atualmente o PHC CS Web ainda não está preparado para a utilização deste módulo.
Gama e versão de software PHC em que foi testado: PHC CS Web 19 na gama Advanced.
