---
title: Cs - outros Requisitos a Observar
source: cs-outrosrequisitosaobservar.htm
tipo: Manual Técnico
idioma: PT
---

# Cs - outros Requisitos a Observar

3. Outros requisitos a observar pela aplicação.
A aplicação deve:
Ponto 3.1.3
Controlar direta ou indiretamente a base de dados que utiliza, e o registo do n.º de reposições de cópias de segurança (backup) efetuadas, por exemplo, através de sistemas de controlo que validem a base de dados no fecho e arranque da aplicação, de forma a evidenciar eventuais manipulações ou alterações de dados na base de dados, por outra via que não a aplicacional.
PHC
Devido à complexidade técnica deste ponto, estamos atualmente a analisar qual a melhor solução a aplicar.
Ponto 3.2.7
O controlo de emissão de notas de crédito parciais face às quantidades e valores das respetivas faturas a retificar.
PHC
No presente ponto efetuamos alterações na aplicação de forma a controlar não apenas o valor mas também a quantidade na emissão de uma Nota de Crédito com origem em Fatura.
Ao efetuar o registo de uma nota de crédito, para além de a mesma dever ser emitida com origem em uma fatura, é necessário garantir que quer os valores, quer as quantidades inseridas não sejam superiores ao documento de origem.
Ponto 3.2.8
Que os descontos, quando existam, devam situar-se no intervalo entre 0 e 100 %.
PHC
No PHC Gestão CS, a partir da Versão 16, a aplicação passa a controlar os valores inseridos nos campos de descontos (comercial e Financeiro), deixando os mesmos de permitir a inserção de valores de percentagem abaixo de 0% e acima de 100%.
Ponto 3.2.9
Que a parametrização e desenho dos formulários de impressão dos documentos seja efetuada pelo produtor de software, ou caso seja facultado ao utilizador a possibilidade de criação de novos tipos de documentos, estes sejam validados pelo produtor de
software
, como por exemplo, através de assinatura digital. Em circunstância alguma, podem ser utilizados formulários sem a referida validação e respeito pelo descrito no ponto 3.3.1.
PHC
Para que o PHC Gestão CS cumpra com este ponto efetuamos diversas alterações ao nível do desenho de IDUS, a partir da Versão 16.
A aplicação passa a obrigar à existência de determinados campos sem os quais não é possível a impressão do documento.
Para saber em relação a este ponto aconselhamos a leitura do tópico
FAQS-Formulários de Impressão (IDUS)
.
Ponto 3.2.10
A manutenção da informação relativa a todos os documentos emitidos no seu repositório de dados, nomeadamente os constantes das tabelas existentes na estrutura 4. - Documentos comerciais (
SourceDocuments
) do ficheiro SAF-T (PT). Deve possuir mecanismos de controlo que, quando atingido o limite da capacidade da base de dados ou do suporte físico da mesma, forcem a produção externa de cópias de arquivo, por forma a garantir a capacidade de exportação do SAF-T (PT) com os requisitos da portaria da certificação e o cumprimento do prazo estabelecido no n.º 1 do artigo 52.º do CIVA.
PHC
Devido à complexidade técnica deste, ponto estamos atualmente a analisar qual a melhor solução a aplicar.
Ponto 3.2.12
O averbamento da data em que os bens foram colocados à disposição do adquirente ou em que os serviços foram prestados, por forma a permitir o correto preenchimento do campo
TaxPointDate
.
PHC
Para dar resposta a este ponto de Despacho, no PHC Gestão CS, a partir da Versão 16, passa a existir um novo campo no ecrã de faturação: "Data Efetiva de Entrega".
Para além da inclusão do campo no ecrã de faturação, passa também a ser obrigatório a inserção do mesmo no Desenho do IDU.
Para saber mais em relação à inserção de campos obrigatórios no desenho de IDUS aconselhamos a leitura do tópico
FAQS-Formulários de Impressão (IDUS)
.
Ponto 3.3.2
O processamento de qualquer cálculo sobre documentos recolhidos ou resultantes de integração de outros sistemas. Por exemplo, se existir uma incorreta determinação de imposto, esse erro deve ser evidenciado na base de dados integradora, por resultar de um documento já entregue.
PHC
Devido à complexidade técnica deste ponto, estamos atualmente a analisar qual a melhor solução a aplicar
Ponto 3.3.6
A reutilização de códigos de utilizador (
SourceID
) após o respetivo utilizador ter procedido à realização de movimento
PHC
A partir da Versão 16 a aplicação passa a não permitir a alteração ou eliminação de um código de utilizador desde que o mesmo já tenha efetuado registos na aplicação.
Passa ainda a não ser possível a existência de dois ID´s de utilizador iguais..
Para regressar à pagina principal
clique aqui
.
