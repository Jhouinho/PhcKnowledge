---
title: Cuidadosaternainstalaçãodophccsxlv19
source: cuidadosaternainstalaçãodophccsxlv19.htm
tipo: Manual Técnico
idioma: PT
---

# Cuidadosaternainstalaçãodophccsxlv19

Cuidados a Ter na Instalação do Phc Cs Xl V19

|  |
| --- |
| Cuidados a Ter na Instalação do Phc Cs Xl V19 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Instalação do PHC CS XL 19**      Como instalar o novo XL?       Para Clientes com PHC CS XL v17 ou v18 instalado    Aconselhamos a leitura integral desde documento antes de proceder à instalação do produto, para ficar a saber num todo o que é necessário fazer.     **1) Desinstalação do PHC CS XL v17 ou v18**    Para os utilizadores que já possuem o PHC CS XL na v17 ou v18 instalado no computador, é necessário efetuar o seguinte:     **1.1)**Aceder à pasta "PHCXL" e desinstalar o produto através do ficheiro "unins000.exe".            *Nota:* Se a empresa utilizar um Mapeamento Contabilístico deverá guardar o mesmo pois, ao desinstalar o produto, também é eliminado.     **1.2)** Depois de desinstalar o PHC CS XL, fica na pasta de instalação os ficheiros: **\_AppData**; **\_Data**; **\_Include**.            Estas pastas devem ser eliminadas por completo, visto não possuírem a tabela dos Centros Analíticos. As mesmas serão criadas após a instalação da v19 do PHC CS XL.         **2) Instalação do PHC CS XL v19**     **1.1.** Instalar o novo setup do PHC CS XL v19, este *setup* designa-se "PHCXLsetup19.exe".    **1.2.** Depois de instalar o setup, é necessário efetuar o seguinte:     **1.2.1.** Aceder ao ecrã "Configurar Ligação" e criar todas as ligações para as Base de Dados do Software PHC.   **1.2.2.** Depois das configurações de ligação, é necessário aceder ao ecrã "Configurar Empresas" e criar todas as Empresas necessárias. Depois, no mesmo ecrã, é necessário associar a Empresa à ligação de configuração criada no ponto **1.2.1.** .       Para Clientes que vão proceder à instalação do PHC CS XL v19 pela primeira vez      Para os utilizadores que nunca tiveram instalado o PHC CS XL na máquina é necessário efetuar o seguinte:      **1.** Instalar o novo setup do PHC CS XL 19;  **2.** Depois da instalação é necessário abrir a folha de excel com ligado à *internet*;   **3.** Aceder ao separador "PHC XL 19" e selecionar a opção **Ativar produto**. No seguinte ecrã é necessário preencher todos os campos:             + O campo **Nº de Instalação** deve ser preenchido com o número de instalação do cliente;  + O campo **Password de acesso** deve ser preenchido com a Password para o Calendário/ PHC On;  + O campo **Código** deve ser preenchido com o código da ficha. Este código está presente na Comunidade dos Parceiros;  + Depois de preencher todos os campos indicados é necessário clicar no botão **OK** para que o PHC CS XL fique ativo e válido;  + Depois do PHC CS XL validado é necessário efetuar novamente as respetivas **Configurações de ligação**. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Cuidados a Ter na Instalação do Phc Cs Xl V19' ) |