---
title: Cuidadosaterquandoseinstalasoftware
source: cuidadosaterquandoseinstalasoftware.htm
tipo: Manual Técnico
idioma: PT
---

# Cuidadosaterquandoseinstalasoftware

Cuidados a Ter Quando Se Instala Software

|  |
| --- |
| Cuidados a Ter Quando Se Instala Software |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O objectivo deste artigo técnico é alertar o instalador do software PHC para um conjunto de situações que podem passar despercebidas mas que devem ser tidas em conta pois são consideradas importantes:    *Antes de efectuar a instalação do software PHC:*    Deve verificar se a máquina tem os updates do windows actualizados, se o cliente tem activo algum sistema de protecção de dados (firewall) e se o utilizador que vai efectuar a instalação da aplicação tem acessos de administração sobre a máquina em questão pois estes factores podem condicionar ou não a instalação da aplicação.    No caso de ter uma firewall deve garantir que as portas de comunicações para o SQL Server e para a ficha de protecção não estão bloqueadas.  Se tiver problemas de comunicações com o SQL consulte o apoio [Como Aceder a um Sql Server Express em Rede](comoacederaumsqlserverexpressemrede.htm)  Relativamente ás fichas de protecção consulte o apoio [Problema / Solução para Problemas com Fichas](problemasoluçãoparaproblemascomfichas.htm) onde são feitas diversas explicações sobre comunicações, erros com fichas e no final é explicado como usar a variável nsp\_host de forma a fixá-la nas máquinas.    É conveniente verificar se o sistema operativo da máquina é de 32 ou 64 bits porque a aplicação PHC funciona em ambientes com sistema operativos 64 bits, mas existe a particularidade de o odbc ter de ser criado a 32bits.  Se for o caso recomendamos que consulte previamente o tópico [Windows Vista 64 Bits Vs Odbc](windowsvista64bitsvsodbc.htm) disponível na EnciclopédiaPHC.        *Depois de efectuar a instalação do software PHC:*    Ao entrar pela primeira vez na aplicação PHC, é pedido o código de licenciamento. Este código vai impresso num documento que acompanha o cd de instalação. Depois de digitar esse código é criado na directoria do PHC o ficheiro lic.win. Para evitar ter de digitar o mesmo código de licenciamento nas restantes máquinas (em caso de ter uma instalação de rede) basta copiar esse ficheiro lic.win para a directoria do PHC nas restantes máquinas.    Se ao entrar na aplicação PHC surgir a mensagem " Cannot update the cursor" quer dizer que a aplicação está a tentar escrever em determinados ficheiros mas não tem acesso a tal. Deve verificar em primeiro lugar se o utilizador tem previlégios de escrita e posteriormente se a pasta de instalação do PHC está como "Read-Only" nas suas propriedades, pois a aplicação está a tentar escrever nessa pasta e não consegue.    O setup da aplicação PHC poderá não conter a base de dados default mais actual. Em virtude de poderem existir alterações frequentes à legislação em vigor que provoquem actualizações nas tabelas de configurações, depois de instalada a aplicação PHC nas máquinas é conveniente ir ao FTP da PHC e fazer o download da base de dados csdefault mais recente.    O setup da aplicação PHC não instala o executável mais actualizado. Como a PHC disponibiliza novos executáveis semanalmente, depois de instalada a aplicação PHC nas máquinas é conveniente ir ao FTP da PHC e fazer o download do executável mais recente.    Se o cliente vai começar agora a trabalhar com o módulo PHC Contabilidade recomendamos que tenha os mapas de gestão actualizados.  Caso o cliente tenha VantagemGarantida então poderá no ecrã de "Desenho de IDU (Mapas de Gestão)" efectuar a importação automaticamente dos Mapas de Gestão via webservice fiscal.  Caso o cliente não tenha VantagemGarantida então poderá fazer o download dos mapas de gestão mais actuais através do FTP PHC.    Depois de instalar a aplicação PHC, se o cliente vai começar agora a trabalhar com o módulo PHC Projecto recomendamos que faça download dos vários tipos de dossiers internos específicos desta área de negócio que se encontram disponíveis no FTP PHC na pasta Configurações Dossier Internos, CS, Projecto e das tabelas de revisão de preços que se encontram disponíveis no FTP PHC na pasta Tabelas específicas, Revisão de preços.    Se possuir o módulo PHC ecovalor deve proceder à actualização das tabelas "Tipo de Pilhas e Acumuladores","Pilhas e Acumuladores","Materiais de Embalagens" no FTP PHC na pasta Tabelas específicas, Ecovalor pois geralmente estes valores sofrem alterações de ano para ano. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Cuidados a Ter Quando Se Instala Software' ) |