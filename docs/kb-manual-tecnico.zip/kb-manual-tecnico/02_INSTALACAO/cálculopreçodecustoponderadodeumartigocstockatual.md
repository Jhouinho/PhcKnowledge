---
title: Cálculopreçodecustoponderadodeumartigocstockatual
source: cálculopreçodecustoponderadodeumartigocstockatual.htm
tipo: Manual Técnico
idioma: PT
---

# Cálculopreçodecustoponderadodeumartigocstockatual

Cálculo Preço de Custo Ponderado de um Artigo C/ Stock Atual

|  |
| --- |
| Cálculo Preço de Custo Ponderado de um Artigo C/ Stock Atual |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico tem como objetivo explicar como é calculado o Preço de Custo Ponderado de um artigo, a partir do uso do parâmetro:    **Calcula o pr.custo ponderado com stock atua (reinstalar triggers)**        Este procedimento possui algumas regras, as quais vamos recordar abaixo:    * Só os movimentos de stock de entrada, podem afetar o Preço de Custo Ponderado de um artigo;  * Para que um código de movimento de stock de entrada afete o Preço de Custo Ponderado de um artigo, deverá ter na sua configuração, a opção **Atualiza o preço de custo ponderado do artigo** ativa.            - Havendo vários movimentos com a mesma data, é estabelecida a ordem por que são considerados os movimentos:   1º - Movimentos de entrada em Valor;  2º - Movimentos de entrada em Quantidade;  3º - Saídas em valor sem ligação a documentos de faturação;  4º - Saídas provenientes de documentos de faturação (Movimentos em quantidade e valor).     - Havendo, na mesma data, movimentos de stock de entrada com códigos diferentes, a ordem por que são considerados corresponde ao seu número interno. O mesmo é válido para os códigos de saída.    - Tendo este parâmetro ativo, não deverá na cronologia de movimentos, passar por stock negativo, pois a valorização de existências negativas influenciam os cálculos podendo resultar em valores absurdos.    Para identificar o conjunto de movimentos poderá usar:   - Compra de 10 unidades por 10  - Venda de 3 unidades  - Venda de 1 unidade  - Compra de 10 unidades por 20  - Nota de crédito a cliente de 1 unidade (faz saída negativa)  - Movimento em valor de 5  - Venda de 5 unidades  - Venda de 12 unidades  - Compra de 10 unidades a 18         Tendo em conta os cálculos:    Quando de uma entrada que afete o Preço de Custo Ponderado, é feita a valorização de stock existente, somada a valorização da nova entrada, e dividido o resultado pelo stock.     - Com a primeira compra o Preço de Custo Ponderado fica a **10**, pois valorizando as existências temos **(0 x 0 ) = 0**, valorizando a entrada temos **( 10 x 10 ) = 100**, somando as duas valorizações temos **( 0 + 100 ) = 100**, e dividindo o resultado pelo stock obtemos **( 100 / 10 ) = 10**.  - Com a segunda compra o Preço de Custo Ponderado fica a **16,25**, pois valorizando as existências temos **( 6 x 10 ) = 60**, valorizando a entrada temos **( 10 x 20 ) = 200**, somando as duas valorizações temos **( 60 + 200 ) = 260**, e dividindo o resultado pelo stock obtemos **( 260 / 16 ) = 16,25**.  - Com a Nota de Crédito a Cliente de 1 unidade, é gerado um movimento de stock em valor de **-6,25**, correspondente à diferença entre o Preço de Custo Ponderado actual, e o Preço de Custo Ponderado á data da fatura creditada **( 16,25 -10 ) = 6,25**.   O valor é negativo pois as Notas de Crédito fazem saídas negativas de stock.   Assim este valor é dividido pelo stock existente **( -6,25 / 17) = -0,36765**, arredondado **(-0,37)** e somado ao preço de custo ponderado do artigo **( 16,25 + (-0,37) = 15,88**, ficando então este a ser o preço de custo ponderado do artigo neste momento.   - Com as duas vendas seguintes ficamos sem Stock. (Stock do artigo = 0).  - Comprando pela terceira vez, o Preço de Custo Ponderado fica a **18,00**, pois valorizando as existências temos **( 0 x 15,88 ) = 0**, valorizando a entrada temos **( 10 x 18 ) = 180**, somando as duas valorizações temos **( 0 + 180 ) = 180**, e dividindo o resultado pelo stock obtemos **( 180 / 10 ) = 18,00**, que é o que temos neste momento na ficha do artigo.             Gama de Software PHC onde foi testado: Corporate, Advanced, e Enterprise na versão 17. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Cálculo Preço de Custo Ponderado de um Artigo C/ Stock Atual' ) |