---
title: Códigodeutilizadorrelacionadocomvaloresdevendas
source: códigodeutilizadorrelacionadocomvaloresdevendas.htm
tipo: Manual Técnico
idioma: PT
---

# Códigodeutilizadorrelacionadocomvaloresdevendas

Código de Utilizador Relacionado com Valores de Vendas

|  |
| --- |
| Código de Utilizador Relacionado com Valores de Vendas |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Um dos requisitos da Certificação de Software regulamentada através da Portaria n.º 363/2010, de 23 de Junho, Série I, n.º120, consistiu na alteração do funcionamento dos documentos anulados no software PHC.     Em consequência todos os documentos de facturação anulados passam a manter as linhas e os totais com os respectivos valores contrariamente à filosofia anterior, de acordo com a qual estes valores eram apagados dos mesmos sendo acrescentada uma linha identificativa de **Documento Anulado**.    Agora a identificação do documento anulado posicionada no cabeçalho do documento coexiste com todos os valores originais dos documentos de faturação obrigando a que todo o código de utilizador criado para obter valores de venda, rentabilidade ou quantidades vendidas, que incida sobre as tabelas FT e/ou FI compreenda mais uma condição. Os códigos de utilizador em Análises Avançadas do Utilizador, Valores por Defeito, Regras do Utilizador, entre outros devem prever esta alteração.     *Nota:* Para mais informação consulte os tópicos **Análises Avançadas do Utilizador**, **Valores por defeito** e **Regras de Utilizador**.    Exemplificando, um código de Utilizador que retorne o Valor das Vendas por Segmento de Mercado como o seguinte:    select total=sum((case when fi.ivaincl='1' and fi.iva<>0 then (fi.etiliquido/(fi.iva/100)+1) else fi.etiliquido end)), (case when sl.segmento='' then 's/Segmento' else sl.segmento end) as segmento,qtt=sum(case when ft.tipodoc=3   then -fi.qtt else fi.qtt end)from sl (nolock)   inner join fi (nolock) on fi.fistamp=sl.fistamp  inner join ft (nolock) on ft.ftstamp=fi.ftstamp   inner join st (nolock) on st.ref=sl.ref  where sl.origem='FT' and st.ref='A001' and year(ft.fdata)='2010' and (ft.tipodoc=1 or ft.tipodoc=3)   group by (case when sl.segmento='' then 's/Segmento' else sl.segmento end)    Deve conter a condição **ft.anulado='0'** para que os valores tidos em conta para a análise sejam os que respeitam apenas os documentos não anulados.  Assim, o código final deve ser o seguinte:    select total=sum((case when fi.ivaincl='1' and fi.iva<>0 then (fi.etiliquido/(fi.iva/100)+1) else fi.etiliquido end)), (case when sl.segmento='' then 's/Segmento' else sl.segmento end) as segmento,qtt=sum(case when ft.tipodoc=3   then -fi.qtt else fi.qtt end)from sl (nolock)   inner join fi (nolock) on fi.fistamp=sl.fistamp  inner join ft (nolock) on ft.ftstamp=fi.ftstamp   inner join st (nolock) on st.ref=sl.ref  where sl.origem='FT' and st.ref='A001' and year(ft.fdata)='2010' and (ft.tipodoc=1 or ft.tipodoc=3) and **ft.anulado='0'**  group by (case when sl.segmento='' then 's/Segmento' else sl.segmento end)    Todo o código criado sobre a tabela FI deve passar a conter um **inner join** à tabela FT de forma a que se possa inserir esta condição e assim contemplar apenas os valores dos documentos de faturação não anulados.    *NOTA*: Este requisito observa-se em todo o software PHC, nos módulos que contemplem estas tabelas, em qualquer gama, nas plataformas Client Server e Digital.    Gama e Versão onde foi testado: Advanced 2011 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Código de Utilizador Relacionado com Valores de Vendas' ) |