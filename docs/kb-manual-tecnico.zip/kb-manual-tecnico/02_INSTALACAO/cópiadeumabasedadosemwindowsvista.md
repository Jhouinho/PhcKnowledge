---
title: Cópiadeumabasedadosemwindowsvista
source: cópiadeumabasedadosemwindowsvista.htm
tipo: Manual Técnico
idioma: PT
---

# Cópiadeumabasedadosemwindowsvista

Cópia de uma Base Dados em Windows Vista

|  |
| --- |
| Cópia de uma Base Dados em Windows Vista |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| No software PHC podemos facilmente criar uma nova base de dados a partir de uma existente (cópia da base de dados actual).   Atenção: este processo só é possível quando a base de dados está no servidor local.  Podemos aceder através de *supervisor* - *Tratamento de base de dados* - *criação de base de dados*.   Basta Indicar o nome que se pretende dar à nova base de dados e o local onde vão ser criados os ficheiros físicos da base de dados.          Ao seleccionar a opção Criar Base Dados será efectuado o dettach da base de dados actual.  Se o sistema operativo que está instalado no servidor é o Windows Vista e tem o "*User Account Control (UAC)* " ligado poderá não conseguir executar esta funcionalidade. **O que é o UAC do vista?**   User Account Control (UAC) é uma característica nova de segurança do Vista que tem como finalidade reduzir a exposição do sistema operativo. Com esta limitação minimiza-se os danos causados por alguns utilizadores, diminui-se também a vulnerabilidade dos vírus e dos malwares que infectam os nossos Pc'S diariamente. Quando o usuário se encontra numa tarefa que requer privilégios de administrador, tais como instalar uma aplicação, o SO vista notificará o usuário que requer a autorização do Administrador.     Existem 3 formas de ultrapassar esta situação:   1- Através do shortcut da aplicação  2- Através de Comandos de DOS  3- Através do Painel de Controlo   **Para ultrapassar através do Shortcut da aplicação, deve efectuar o seguinte:**     1º Passo - Clicar em Advanced no separador SHORTCUT e colocar o visto em Run as Administrador         2º Passo - Ir ao separador COMPATIBILITY e no Privilege Level colocar o visto em Run this program as an administrator.        3º Passo - Show settings for all users e no Privilege Level colocar o visto em Run this program as an Administrator        **Para ultrapassar através de Comandos de DOS, deve efectuar o seguinte:**    *Desactivar o UAC*   C:\Windows\System32\cmd.exe /k %windir%\System32\reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG\_DWORD /d 0 /f    *Activar o UAC*   C:\Windows\System32\cmd.exe /k %windir%\System32\reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG\_DWORD /d 1 /f  Depois de efectuar o on / Off deverá reiniciar o computador.    **Para ultrapassar através do Painel de Controlo, deve efectuar o seguinte:**    Aceder a   Start - Control Panel - User Account - Turn User Account Control (UAC) on or off.        No ecrã seguinte deverá seleccionar a opção pretendida (on/off) click em OK.        Depois de activar/desactivar deverá reiniciar o seu computador. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Cópia de uma Base Dados em Windows Vista' ) |