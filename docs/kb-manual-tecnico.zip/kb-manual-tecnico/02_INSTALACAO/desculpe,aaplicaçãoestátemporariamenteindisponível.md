---
title: Desculpe,Aaplicaçãoestátemporariamenteindisponível
source: desculpe,aaplicaçãoestátemporariamenteindisponível.htm
tipo: Manual Técnico
idioma: PT
---

# Desculpe,Aaplicaçãoestátemporariamenteindisponível

Desculpe, a Aplicação Está Temporariamente Indisponível

|  |
| --- |
| Desculpe, a Aplicação Está Temporariamente Indisponível |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O objectivo deste artigo técnico é demonstrar quais os procedimentos a tomar quando, ao tentar entrar na aplicação PHC Digital, surge a mensagem "Desculpe, mas a aplicação está temporariamente indisponível. Por favor, tente mais tarde.".    Quando surge essa mensagem no browser deverá seguidamente efectuar clique direito no rato e seleccionar a opção **View Source**, de forma a aceder ao código fonte da página.         As mensagens mais comuns são:   - "Não possui nenhuma aplicação autenticada" - nesta situação deverá primeiramente verificar se o utilizador de windows tem acessos de escrita à pasta C:\Windows\Temp (ficheiros de classes). Posteriormente, no ficheiro Webconfig respectivo, deverá confirmar a existência da key relativa à gama do software e o respectivo número de série;     *Exemplo*    add key="INS.DADVANCED" value="S"/  add key="INS.DADVANCED\_SERIE" value="xxxxxx"   - "Não possui nenhuma gama autenticada" - nesta situação deverá verificar se a versão que está indicada na key do Webconfig corresponde à informação que está registada na tabela Exev da base de dados no SQL Server.     Por exemplo, se no Webconfig estiver indicada a key relativa ao Dadvanced e, se na tabela Exev da base de dados estiver o registo relativo ao PHC Enterprise, é o suficiente para que não sejam compatíveis e apresente a respectiva mensagem. Nesta situação deverá apagar a informação da tabela Exev (por exemplo, executar a query "delete from exev") e entrar no PHC CS com o executável relativo à gama Advanced, de forma a ficar com o respectivo registo na tabela Exev;    - "Excedeu o nº de utilizadores" - nesta situação deverá verificar no ecrã de Utilizadores (US) do PHC CS, presente no Menu Sistema, se existem utilizadores que não tenham a opção activa **Tem acesso via PHC DIGITAL**, mas que tenham packages do PHC Digital incluídos, vão entrar em consideração para a lista dos **Utilizadores Pedidos** e provocar esta mensagem. Se tal acontecer, deve retirar esses programas da lista dos Packages incluídos;        - "IP Negado. O IP deste sistema não coincide com o IP autorizado." - o PHC Digital pressupõe a existência de um IP fixo. Ao entrar pela primeira vez na aplicação digital ficará registado internamente nas nossas instalações o respectivo IP de acesso. Esta mensagem surge quando se tenta aceder ao PHC Digital com um IP diferente do inicial. Nesta situação deverá aceder com o IP correcto (inicial), ou solicitar ao Departamento de Suporte Online via Pedido de Assistência Técnica, o respectivo reset do IP.     Gama do Software PHC em que foi testado: PHC Digital 2011. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Desculpe, a Aplicação Está Temporariamente Indisponível' ) |