---
title: Dicasparamigrardedigital2Paradigital3
source: dicasparamigrardedigital2paradigital3.htm
tipo: Manual Técnico
idioma: PT
---

# Dicasparamigrardedigital2Paradigital3

Dicas para Migrar de Digital2 para Digital3

|  |
| --- |
| Dicas para Migrar de Digital2 para Digital3 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico pretende explicar alguns dos pontos que devem ser tratados quando o cliente muda de Digital 2 para Digital 3.    Ao contrário do habitual, ao instalar o Digital 3 as tabelas não são alteradas automaticamente para ficarem a funcionar no novo sistema. Esta característica prende-se com o facto de se pretender permitir que os dois sistema Digital 2 e Digital 3 se mantenham a funcionar sobre a mesma base de dados, permitindo ao utilizador migrar as aplicações, verificar se está tudo bem e testar, sem ter que parar a utilização de Digital 2.    **Principais diferenças**    ***Packages***  Com a filosofia de aplicação única, ou seja, com o facto de terem acabado os módulos independentes e passar a existir uma aplicação única para as aplicações internas, externas e portal, todos os locais onde se indicava qual o package, vão estar a apontar para o módulo e não para o package, ou seja, por exemplo, vão estar a apontar para dFront em vez de Extranet.  O que recomendamos nestes casos, para que mantenha os dois sistema a funcionar é duplicar todos os registos que quer disponíveis em Digital 3, alterando o package do módulo em que estava para a aplicação. Se não pretender duplicar, mas sim atualizar tudo de seguida, então poderá executar o seguinte código na aplicação Windows PHC, em xbase :    Com a seguinte tabela pode ver que módulos estão incluídos no novo package :  Extranet:  - dFront  - dSuporteexterno  - dFormação    Intranet:  - dCrm  - dContabilidade    Portal:  - dPortal    Para passar de seguida nas seguintes tabelas :   chs,ebn,ebrule,ecam,edo,eeventos,efu,elk,eme,enld,epagc,etl,etpl,eudefs,nwww.  Basta executar o seguinte código colocando nas respetivas variáveis a transformação que pretende:  Mpack1="Extranet"  Mpack2="dFront"  Mtabela="eme"  For f=1 to 9  Mvar="Update "+mtabela+" set nc"+astr(f)+"='"+mpack1+"' where nc"+astr(f)+"='"+mpack2+"'"  U\_sqlexec(mvar)  Next f    Pelas razões apontadas na restante parte deste documento deve ter em atenção se basta alterar os packages, ou se é necessário duplicar e alterar registo e registo.    **Caminhos**  Os caminhos para cada ecrã, ou seja, os links, também são afetados pela aplicação única, ou seja, já pode usar caminhos relativos (por exemplo ../directoria/ecra.aspx) para chegar a qualquer ecrã da mesma aplicação.    **Página e "master"**  As páginas do PHC Digital 3, passaram a ter mais um objeto entre a página e o seu conteúdo : a definição "master".   Esta alteração afeta todo e qualquer código de utilizador que faça referência a um objeto na página, pois enquanto que dantes poderia usar o código :  mpage.findcontrol("conteudo")....    Agora tem que passar a usar :  mpage.master.findcontrol("conteudo")...    Esta alteração, que não pode ser feita automaticamente, mas sim pelo implementador em todo o código do utilizador criado, é imprescindível para colocar o PHC Digital 3 a funcionar com código feito para PHC Digital 2.    **Na extranet e ficha do cliente com packs que pode aceder**  Ao juntar todos os módulos externos, nomeadamente o dFront, o dSuporteExterno e o dFormação num mesmo package, ou seja, na aplicação "Extranet", ficou necessário definir, para cada cliente a que módulos exatamente é que ele pode aceder. Para definir deve na ficha do cliente na versão 2008 do software PHC para windows, no menu de opções diversas, escolher a opção - utilizadores de clientes e opções PHC Digital - e aqui definir exatamente a que módulos o cliente poderá aceder, independentemente dos módulos a que cada utilizador do mesmo poderá aceder.    **Mudar o IIS para ASP.NET 2**  Ao instalar o PHC Digital 3 num sistema que tinha PHC Digital 2, pode-se dar o caso da aplicação instalada, na configuração do IIS ficar a apontar para a framework ASP:NET antiga. Para mudar, basta ir ao IIS, escolher a aplicação instalada, ver as "properties", na página "ASP.NET", definir que a framework para PHC Digital 3 é a ASP.NET 2. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Dicas para Migrar de Digital2 para Digital3' ) |