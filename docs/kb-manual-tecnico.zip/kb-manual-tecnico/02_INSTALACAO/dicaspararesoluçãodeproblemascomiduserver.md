---
title: Dicaspararesoluçãodeproblemascomiduserver
source: dicaspararesoluçãodeproblemascomiduserver.htm
tipo: Manual Técnico
idioma: PT
---

# Dicaspararesoluçãodeproblemascomiduserver

Dicas para Resolução de Problemas com Iduserver

|  |
| --- |
| Dicas para Resolução de Problemas com Iduserver |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para ajudar na resolução de alguns problemas que possam surgir em torno do IDUserver, veja-se os seguintes pontos:    **Registo do IDUserver**   O iduserver comunica com asp.net através de um componente COM. O componente COM para funcionar tem que ser registado no Windows.  Este registo deve ser efetuado via setup fornecido pela PHC.  Antes de executar o setup do iduserver ou registo manual deve fazer o comando **iisreset** a partir da linha de comandos do Windows.    Após o setup do IDUserver, para verificar se o mesmo ficou bem registado deve-se confirmar o CLSID do componente registado.  O CLSID é uma chave única que identifica um componente COM. Estas chaves encontram-se no registo do Windows em \HKEY\_CLASSES\_ROOT\CLSID.  O CLSID do iduserver para a versão 2008 é {938FB663-07ED-4F58-B720-B17D17FDEE2D} e para a versão 2009 é {938FB663-07ED-4F58-B720-B17D17FDEE2D}.      **Erros comuns** - Após instalação do setup do iduserver se ocorrer um erro na aplicação, ao imprimir, idêntico a este:   *Erro IDU: Falha ao obter a class factory COM para o componente com CLSID {938FB663-07ED-4F58-B720-B17D17FDEE2D} devido ao seguinte erro: 80040154.;*    Significa que o componente COM do iduserver não ficou bem instalado ou que ficou instalado o da versão errada.     Se se encontrar instalada a versão correta pode procurar no registry do Windows se o CLSID existe, se está registado e se está na diretoria correta, como se encontra explicado acima.  Se tiver ficado registado na diretoria errada, este deve ser desregistado o que pode ser efetuado com a seguinte linha de comando do Windows:   **regsvr32 /u /s c:\directorias\iduserver.dll**    Se o componente COM não for encontrado pode fazer-se o registo manual com o comando **regsvr32 c:\inetpub\wwwrootiduserver\iduserver.dll**      *Nota*: No Windows Vista para utilizar o comando regsvr32 deve entrar na linha de comandos do Windows como Administrador. Para fazer isso é carregar no botão direito do rato e escolher a opção Abrir como Administrador.     - Depois do iduserver estar bem registado ainda podem surgir outros problemas. Esses erros podem ser vistos num ficheiro de texto com o nome **IduServer\_Err.Txt** que se encontra na diretoria onde o iduserver foi instalado.   Se um desses erros for:    *Base table fields have been changed and no longer match view fields. View field properties cannot be set.*;    Devem apagar-se os ficheiros: **vision.dbc**; **vision.DCT**; e **vision.DCX** que se encontram em *C:\Documents and Settings\[utilizador]\ASPNET\Local Settings\Temp\phcworkingdir\db\_[nome da base de dados]*.  No entanto, sempre que o utilizador obtenha um erro na impressão de um IDU, a aplicação elimina automaticamente estes ficheiros. Contudo, serão novamente criados aquando da impressão de um IDU com sucesso.   *Nota:* Este comportamento garante que os ficheiros **visions** tenham sempre o conteúdo atualizado como por exemplo, os campos das tabelas utilizadas na aplicação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Dicas para Resolução de Problemas com Iduserver' ) |