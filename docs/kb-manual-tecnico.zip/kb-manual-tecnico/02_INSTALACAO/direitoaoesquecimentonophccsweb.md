---
title: Direito ao Esquecimento no Phc Cs Web
source: direitoaoesquecimentonophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Direito ao Esquecimento no Phc Cs Web

Neste artigo técnico é apresentado um exemplo de como pode facilmente configurar o direito ao esquecimento para facilitar as obrigações do Regulamento Geral para Proteção de Dados, tendo em conta os dados registados na tabela "Clientes" do PHC CS Gestão.
Em primeiro lugar, no PHC CS Desktop, é necessário configurar um Aviso legal, a definição das tabelas e campos para os dados pessoais.
No ecrã "Configuração do Aviso Legal" preencha os seguintes campos:
Título:
Aviso Geral
Âmbito:
Geral
Dados Principais
Resumo:
Este aviso tem toda a informação relativa aos processos gerais do software que não estejam definidos nos processos temáticos
Texto para aviso legal:
Este aviso tem toda a informação relativa aos processos gerais do software que não estejam definidos nos processos temáticos.&ltbr>
&ltbr>
É um aviso de aceitação implícita ao abrigo do qual estarão os dados pessoais identificados na aplicação, para os cliente, contactos, funcionários e outros.&ltbr>
&ltbr>
Este aviso não é apresentado ao proprietário destes dados visto o âmbito do mesmo ser interno e não será por esse motivo apresentado em portais e sites da empresa.&ltbr>
&ltbr>
Este aviso legal é de aceitação implícita
: ativa.
Dados Pessoais
Tabela
AG - Entidades
CL - Clientes
CLB - Colaboradores
CTS - Pessoas
EM - Contactos
PA - Pedidos de Assistência
PE - Funcionários
PE2 - Funcionários - Outros Dados
SN - Instalações
No ecrã "Tabelas e campos para os dados pessoais deve configurar os seguintes campos:
Nome da tabela:
CL - Clientes
Aviso legal:
Aviso legal
Dados principais
Nesta grelha deverá selecionar quais os campos da tabela CL que pretende que estejam abrangidos pelo RGPD e selecionar quais são os identificadores e o tipo de dados desses campos, isto é, se Pessoal, Pessoal (Sensível) ou Legal.
Em segundo lugar, é necessário configurar uma página de internet na Intranet, acessível no Portal e que tenha a opção para o esquecimento dos dados através da seguinte expressão onde já estará a indicação do script que irá ser criado posteriormente:
'Link para o utilizador clicar
&lta href="#" id="linkesquecimento" onclick="esquecimento(); ">&ltb&gtDireito Ao Esquecimento</b></a>&ltbr />
Ao escolher esta opção, vai limpar os seus dados na base de dados da MaisRitmo.&ltbr />
&ltbr />
'Javacript para validar que o email é valido e chamar o script
&ltscript type="text/javascript">
function esquecimento(){
var lblnome = document.getElementById("idname").value;
var lblemail = document.getElementById("idemail").value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
if (reg.test(lblemail) == false || lblemail=="")
{
alertify.error("Endereço de email inválido",10000);
return false;
}else{
window.location.href = "../programs/gensel.aspx?cscript=RGPD_SEsq&email="+lblemail+"&nome="+lblnome+""
}
}
</script>
Após configurá-la terá este aspeto:
O exemplo demostrado tem como base fazer o seguinte circuito:
O utilizador acede a uma página no Portal;
Coloca os seus dados (nome e email) e seleciona a opção do "Direito ao esquecimento";
É enviado um email com o link para que o utilizador proceda com o esquecimento dos seus dados;
Ao clicar no link os seus dados são esquecidos e é apresentada uma mensagem a informar que o processo correu com sucesso.
Aceda ao ecrã "Script", através do menu "Framework" e crie dois scripts.
O primeiro script faz o processamento dos dados, ou seja, o esquecimento, para isso, preencha os seguintes dados:
Resumo:
Processamento de Esquecimento
Código:
RGPD_SCon
Reação após executar:
Mensagem
Conteúdo da mensagem:
' Mensagem de sucesso
&lth1>*** Processamento executado com sucesso***</h1>
&ltp> </p>
&ltp>&ltbr />
&lta href="http://localhost/portal23/programs/ewpview.aspx?codigo=rgpd">&ltbutton class="btn btn-success" type="button"&gtVoltar</button></a></p>
&ltp> </p>
Expressão:
'Script do processamento
'Cria um object do tipo datatable que contem os dados da tabela principal
Dim ListaPdc As DataTable = mainFormdataSet.Tables(0)
'Verifica se a lista do tipo datatable contem registos
If ListaPdc.HaveRows Then
'Vai percorrer cada linha existente na datatable
For Each drows As DataRow In ListaPdc.Rows
Dim tsql = PhcCommandBuilder.CreateUpdate(drows.ToStrTrim("Tabela"))
'Verifica se o tipo que aparece em formulário é diferente de 4(Pessoal Legal) e ainda se o valor não é nulo ou se não está vazio
'tpdado 1 - Vazio (Identificador) // tpdado 2 - Pessoal // tpdado 3 - Pessoal (Sensivel) // tpdado 4 - Pessoal (Legal)
If drows.ItemToString("tpdado") <> 4 AndAlso drows.ItemToString("valor").IsNotNullOrEmpty Then
'Por cada linha que existir na datatable, vai verificar de que tipo é e executar o update"
Select Case drows("tipo")
Case "C"
tsql.AddUpdateColValue(drows("Campo").ToString.Trim, "**")
Case "N"
tsql.AddUpdateColValue(drows("Campo").ToString.Trim, 0)
Case "D"
tsql.AddUpdateColValue(drows("Campo").ToString.Trim, xcfox.ctod("01.01.1900"))
Case "L"
tsql.AddUpdateColValue(drows("Campo").ToString.Trim, False)
Case "M"
tsql.AddUpdateColValue(drows("Campo").ToString.Trim, "**")
End Select
End If
If tsql.Where(drows.ToStrTrim("Tabela") &"stamp = @stamp").
AddSqlParameter("@stamp", drows.ItemToString("Stamp")).ExecuteNonQuery() < 0 Then
sistema.adderror("Erro", "Verifique se está tudo corretamente configurado.")
End If
Next
Else
'Retorna uma mensagem ao utilizador do tipo informação se não existirem registos
Throw New PhcException("Desculpe, mas a tabela não retornou quaisquer resultados.", cEnums.TipoDeMensagem.Info)
End If
O segundo script envia o email inicial ao utilizador com o link para o esquecimento. Para isso, preencha os seguintes dados:
Resumo:
Script para envio de email com link para Esquecimento
Código:
RGPD_SEsq
Reação após executar:
Mensagem
Conteúdo da mensagem:
' Mensagem que aparece ao utilizador no portal
&lth2&gtNo seguimento do pedido efetuado ao abrigo do Regulamento Geral Proteção de Dados, &ltbr&gtfoi enviado um email para o endereço indicado. &ltbr&gtConsulte p.f. o e-mail enviado de forma a concluir o processo escolhido. Obrigado.</h2>
Qual o URL para onde vai o utilizador:
../programs/ewpview.aspx?codigo=RGPD
Expressão:
'Verifica qual foi o email inserido no portal
Dim passemail = HttpContext.Current.Request.QueryString("email").ToString
If passemail.IsNotNullOrEmpty Then
'coloca o Tipo de processamento criado no PHC CS Desktop para o esquecimento
Dim TipoDeProcessamentodeDados = xcfox.u_scrypt("Direito ao ESQUECIMENTO_Web")
Dim emailRGPD = xcfox.u_scrypt(passemail) 'encripta o email (identificador)
dim avisolegal = xcfox.u_scrypt("Aviso GERAL")'encripta aviso legal
'Verifica qual foi o nome de utilizador inserido no portal
Dim passname = HttpContext.Current.Request.QueryString("nome").ToString
'Vai enviar um email para o utilizador que efetuou o pedido do esquecimento (passname)
XcUtil.sendmail(XcUtil.email_remetente, passemail, "RGPD - Envio de email com link para Esquecimento",
XcUtil.FormatEmailComoNotification("RGPD",
"", "", "",
"Olá " & passname & "! Foi enviado um email para o endereço indicado para procedermos ao esquecimento dos seus dados. O Regulamento Geral de Proteção de Dados confere direitos aos titulares dos dados por forma a que estes, de uma forma simples, possam ter controlo sobre os mesmos.&ltbr>&ltbr>",
"", True,
"http://localhost/Portal23/api/rgpd/run?identificador=" & emailRGPD & "&PDadosId=" & TipoDeProcessamentodeDados & "&alegalID=" & avisolegal, "Clique aqui para proceder ao Esquecimento dos seus Dados Pessoais"), True)
End If
Deverá ainda ser configurado o tipo de processamento de dados com o processo "Personalizado", desta forma, aceda ao ecrã "Tipo de tratamento de dados" e preencha os seguintes campos:
Resumo
: Direito ao esquecimento web
Processo
: Personalizado
Grupo
: Geral
Script (CS Web)
Script do utilizador
: Processo de Esquecimento
Após todas as configurações ao executar o pedido no Portal, irá ser desencadeado um email, como o exemplo seguinte, que irá ter o link para o esquecimento de dados.
Depois de clicar no link e o processamento do esquecimento ser executado os dados do cliente aparecerão com "*" como mostra o exemplo seguinte.
Funcionalidade disponível nas gamas PHC CS: Advanced e Enterprise
Subscrição de PHC On: Sim
Ambiente de teste:
- Versão de software PHC CS Web: 23
- Versão do browser: Chrome 61.0.3163.100
- Versão do Android (ou IOS): 6.0
