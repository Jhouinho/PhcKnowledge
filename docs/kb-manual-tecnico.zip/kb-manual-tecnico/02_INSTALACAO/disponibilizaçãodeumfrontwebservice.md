---
title: Disponibilizaçãodeumfrontwebservice
source: disponibilizaçãodeumfrontwebservice.htm
tipo: Manual Técnico
idioma: PT
---

# Disponibilizaçãodeumfrontwebservice

Disponibilização de um Frontwebservice

|  |
| --- |
| Disponibilização de um Frontwebservice |

|  |
| --- |
| Existe um Web Service disponível para quem tem a aplicação PHC CS Front Web.   Este Web Service possibilita aos clientes do utilizador do Front Web, enviarem encomendas para o Front Web utilizando o Web Service em vez do site Front Web e ainda poderem criar/atualizar de forma automática os seus artigos com os artigos do utilizador (fornecedor).  Para utilizar este Web Service, é necessário instalá-lo, a instalação é feita da mesma forma que as outras aplicações de PHC CS Web.  O Frontwebservice é no fundo uma aplicação com páginas asmx que interage com qualquer Software PHC CS Desktop, que permite enviar encomendas do lado do cliente e sincronizar o catálogo de produtos entre o fornecedor e o cliente.    Este Web Service tem métodos:     * Para enviar as encomendas utilizando Datatables da Framework .NET (docimpbo.asmx) e outro para enviar as encomendas em formato XML (docimpbostring.asmx).    Em qualquer um dos métodos, as encomendas devem ser enviadas como duas tabelas (Uma com o cabeçalho e outra com as linhas). A estrutura das tabelas é idêntica às tabelas BO e BI da aplicação PHC e devem ser preenchidos todos os campos necessários para introduzir uma encomenda.    No método que utiliza parâmetros em XML, cada tabela deve ser enviada como uma string XML com as tabelas no formato de XSD da W3C para datatables.    * Para retornar os stocks utilizando Datatables da Framework .NET (genexp.asmx) ou (expst.asmx) e outro para retornar os stocks em formato XML (expststring.asmx). As tabelas que este Web Service retorna são:    Stocks e Serviços - ST    Observações dos Stocks - STOBS    Artigos Compostos - SC    Códigos de Barras - BC    Referências Alternativas - RT        No caso de utilizar Grelhas:    Grelhas de Tamanhos - SGT    Grelhas de Cores - SGC     Stock por cor e tamanho - SX - (neste caso só será atualizado os registos do armazém 1, pois são estes que contém a informação referente a preços por cores e tamanhos.        No caso de utilizar Lotes:    Lotes - SE      Em conclusão:  Um cliente PHC que tenha instalada a aplicação Frontwebservice pode receber encomendas de clientes de duas formas:  - Uma pelo seu site da aplicação Front Web  - Outra pela aplicação Frontwebservice se os seus clientes tiverem software PHC CS Desktop.      A grande vantagem é que o cliente do fornecedor apenas tem que parametrizar o Software PHC CS Desktop, para enviar, apenas com um clique, as suas encomendas para o fornecedor.    Do lado do fornecedor também existem [configurações](configuraçõesdofornecedor.htm) a fazer. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Disponibilização de um Frontwebservice' ) |