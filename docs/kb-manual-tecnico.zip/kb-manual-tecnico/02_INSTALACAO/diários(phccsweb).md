---
title: Diários(Phccsweb)
source: diários(phccsweb).htm
tipo: Manual Técnico
idioma: PT
---

# Diários(Phccsweb)

Diários (phc Cs Web)

|  |
| --- |
| Diários (phc Cs Web) |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Um diário contabilístico consiste num arquivo de documentos que se pressupõe ordenado numericamente.     Existem alguns parâmetros definidos na aplicação Contabilidade em PHC CS Desktop, que interagem com os diários do Contabilidade Web.  **São eles:**   **A numeração dos diários é mensal**   Este parâmetro permite definir se a numeração dos diários é mensal. Para cada diário, em cada mês, a numeração começa no número 1.  Quando não se ativa nenhum dos parâmetros A numeração dos diários é anual ou A numeração dos diários é mensal, a numeração é sequencial por diário, independentemente do ano do lançamento.  Se este parâmetro se encontrar ativo, o Contabilidade Web coloca no nº de lançamento do documento contabilístico o nº a seguir ao último documento existente para o diário em causa.    **Se a numeração dos diários é mensal, o nº do diário é o prefixo**   Permite, caso utilize numeração mensal dos diários, que o mês seja o prefixo do número. Por mês, poderão ser lançados 999999 documentos para o mesmo diário.  A numeração dos lançamentos nos diários terá a seguinte estrutura: MMNNNNNN em que M corresponde ao n.º do mês e N corresponde à numeração sequencial.  Assim, com este parâmetro ativo a aplicação Contabilidade Web coloca no prefixo do nº de lançamento do documento contabilístico o número do respetivo diário.     Na opção de diários poderá ser definida, obedecendo os requisitos legais em vigor, a seguinte informação em relação a cada diário a utilizar:    **Designação**  Nome do diário que se pretende definir.    **Número**  O número sugerido segue uma ordem sequencial. No entanto, poderá utilizar qualquer outro, até 9999, desde que o mesmo não se encontre atribuído a um diário anteriormente criado.    **Partidas Dobradas**  O controlo débito/crédito poderá ser realizado através do diário. Este controlo consiste no sistema não aceitar a atualização do lançamento contabilístico, se o conjunto dos movimentos não estiver balanceado. Pode ser definido em separado para a contabilidade *geral, analítica e de ordem*, sendo que, a aplicação retorna os resultados consoante o tipo de contabilidade selecionado.   * Contabilidade Geral - contas da classe 1 a 8  * Contabilidade Analítica - contas da classe 9  * Contabilidade de ordem - contas começadas por 0 (zero)     **Documento Pré-Definido a utilizar por defeito**  Este campo permite associar um diário a um documento pré-definido. Assim, ao introduzir manualmente um documento contabilístico, ao definir o diário preenche automaticamente o documento pré-definido, caso este esteja preenchido.    **Totais movimentados a débito / a crédito**  Estes campos são atualizados automaticamente pela aplicação e apresentam constantemente o valor movimentado a débito e a crédito no diário. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Diários (phc Cs Web)' ) |