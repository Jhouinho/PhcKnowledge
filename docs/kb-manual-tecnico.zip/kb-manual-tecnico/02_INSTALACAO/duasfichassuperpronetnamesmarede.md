---
title: Duasfichassuperpronetnamesmarede
source: duasfichassuperpronetnamesmarede.htm
tipo: Manual Técnico
idioma: PT
---

# Duasfichassuperpronetnamesmarede

Duas Fichas Superpronet na Mesma Rede

|  |
| --- |
| Duas Fichas Superpronet na Mesma Rede |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo explica os procedimentos necessários para que possa fixar o IP da ficha SuperproNET.  Para facilitar grupos de empresas com licenciamentos diferentes, passa a ser possível, a partir da versão 2011, definir fixamente qual o IP da ficha Superpronet a utilizar.    Neste momento, com o este desenvolvimento, o procedimento da aplicação é o seguinte:  Ao entrar no software, é verificado se existe um ficheiro na directoria de instalação da aplicação com o nome "PHCIP.TXT". Se existir é usado o IP lá indicado.  Ou seja, se pretende utilizar esta funcionalidade deverá criar o ficheiro supracitado, colocando apenas como conteúdo do mesmo, o IP da máquina onde se encontra fisicamente a ficha protecção do software(SuperproNET).    Se na entrada da aplicação não for possível aceder ao IP em questão, será dada uma mensagem a avisar que é necessário proceder à alteração do IP no ficheiro.    A mensagem fornecida é a seguinte:    "Atenção. O IP encontra-se fixo.  Deve editar(colocando um IP) ou eliminar o ficheiro "PHCIP.TXT"."    Se necessitar em algum momento, proceder à alteração do IP, pode efectuar essa modificação através do menu Sistema, opção "Manutenção Personalizada".  Nesse local, devem editar o campo "IP Fixo a usar", conforme é ilustrado pela imagem abaixo:        Ao alterar o campo referido, colocando o novo IP, este será gravado no ficheiro "PHCIP.TXT".    Gama de software PHC em que foi testado: Todas as gamas da versão 2011 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Duas Fichas Superpronet na Mesma Rede' ) |