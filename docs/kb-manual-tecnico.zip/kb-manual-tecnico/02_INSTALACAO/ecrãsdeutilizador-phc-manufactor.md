---
title: Ecrãsdeutilizador Phc Manufactor
source: ecrãsdeutilizador-phc-manufactor.htm
tipo: Manual Técnico
idioma: PT
---

# Ecrãsdeutilizador Phc Manufactor

Ecrãs de Utilizador - Phc-manufactor

|  |
| --- |
| Ecrãs de Utilizador - Phc-manufactor |

|  |
| --- |
| Os ecrãs de utilizador, são estruturas relacionadas com o interface da aplicação e o utilizador, criados por este com um objectivo específico.     Estes permitem servir de base à criação de novas funcionalidades, o que revela a capacidade do PHC Manufactor CS ser muito mais que uma aplicação, ou seja, também é uma **Framework.**    Estes ecrãs são desenhados pelo utilizador, o qual possui ferramentas que lhe possibilitam associar objectos normais de um ecrã (botões, caixas de texto entre outros).      Sobre cada um destes objectos, podem ser programadas as mais diversas funcionalidades, de modo a colmatar as necessidades de visualização da informação por parte do utilizador.      Visto que após a sua criação, estas estruturas comportarem-se como se de ecrãs "built-in" na aplicação se tratassem, as restantes funcionalidades de costumização e configuração do interface encontram-se presentes.     É assim possível a um implementador criar um ecrã para um determinado objectivo, realizar a instalação deste na base de dados do cliente, e o responsável de sistemas do cliente criar costumizações a esse mesmo ecrã. Cada uma destas personalizações será uma aproximação de um ecrã genérico, às necessidades específicas do utilizador final.  É de notar que as funcionalidades referentes ao uso de [Teclas](teclasdeutilizador.htm) e [Eventos](eventosdeutilizador.htm) de utilizador poderão ser usadas sobre estes ecrãs, tal como estes fossem nativos na aplicação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Ecrãs de Utilizador - Phc-manufactor' ) |