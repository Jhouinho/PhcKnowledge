---
title: Emissãoautomáticadedocumentoseletrónicos
source: emissãoautomáticadedocumentoseletrónicos.htm
tipo: Manual Técnico
idioma: PT
---

# Emissãoautomáticadedocumentoseletrónicos

Emissão Automática de Documentos Eletrónicos

|  |
| --- |
| Emissão Automática de Documentos Eletrónicos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A emissão automática de documentos eletrónicos só se encontra disponivel se o módulo de Documentos Eletrónicos se encontrar instalado.  Esta opção permite processar vários documentos eletrónicos ao mesmo tempo contribuindo para que a emissão de documentos de faturação eletrónicos seja mais rápida.    **Documentos de Faturação**  Permite selecionar a partir de uma combobox o tipo de documento que deseja emitir.    **Todos os documentos configurados como Documento Eletrónico**  Ao ativar esta opção a aplicação ignora o tipo de documento escolhido na opção anterior e vai contar com todos os tipos de documentos de faturação que estão configurados com as opções de documento eletrónico.    **Reprocessar já produzidos e/ou enviados**  Permite processar documentos eletrónicos que já foram produzidos e/ou enviados. Esta opção não contempla os documentos que já tenham pedido o Certificado de Entrega.    Pode ainda definir um filtro aos documentos de faturação.    As opções de produção e envio de documentos eletrónicos encontram-se explicadas no [Funcionamento do Documento Eletrónico](funcionamentododocumentoeletrónico.htm).    Depois de definidas as opções deve clicar no botão de preparar e se existirem documentos eletrónicos nas condições indicadas estes são mostrados ao utilizador. Após este passo pode clicar no botão de emitir onde os documentos eletrónicos serão produzidos e enviados (se a opção de enviar for selecionada).    Para que esta opção funcione é necessário que a ficha do cliente esteja devidamente [configurada](ConstituiçãodaTabeladeClientes.htm#LFOFTDOCDIGAUTO).  Caso a ficha do cliente tenha configurado o país de origem como "Outros", não será exigido o número de contribuinte na emissão automática do documento eletrónico. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Emissão Automática de Documentos Eletrónicos' ) |