---
title: Enviodeemailviatriggerdeutilizador
source: enviodeemailviatriggerdeutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Enviodeemailviatriggerdeutilizador

Envio de Email Via Trigger de Utilizador

|  |
| --- |
| Envio de Email Via Trigger de Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Através dos Triggers de Utilizador existentes na gama Enterprise é possível criar um trigger com a finalidade de enviar emails.     O trigger utiliza o Database Mail do SQL Server. Esta funcionalidade não está ativa por defeito e é necessário ativá-la no SQL Server Management Studio, pasta Management opção Database Mail, fazer clique direito e escolher "Configure Database Mail" ou utilizando a stored procedure sp\_configure.    A stored procedure responsável pelo envio do email é sp\_send\_dbmail. A sua documentação pode ser encontrada na página da [Microsoft](http://msdn.microsoft.com/en-us/library/ms190307%28v=SQL.100%29.aspx)    Como exemplo de utilização, temos um trigger para a tabela BO (Dossiers Internos), que envia um email quando é introduzida uma encomenda no dFront. O dossier é identificado pelo seu nº interno. É feita uma pesquisa à ficha do Cliente para retornar o email a utilizar.    O tipo do trigger é Inserted e a expressão T-SQL é:    declare @tableHTML as varchar(max)  declare @cemail char(100)  if (select count(\*) from inserted (nolock) where inserted.ndos=10) > 0 and ((SELECT trigger\_nestlevel()) &lt 2 )   begin  SELECT @cemail = cl.email FROM cl INNER JOIN inserted ON inserted.no = cl.no and inserted.estab=cl.estab    set @tableHTML =   N'&ltcenter&gt' +  N'&lttable width=546 border=0 cellspacing=0 cellpadding=0 class=email-body-wrap id=email-body align=center&gt&gt' +  N'&lttr&gt' +  N'&lttd width=20 background=bg\_pattern.jpg&gt ' +  N'&lt/td&gt' +  N'&lttd width=506&gt&lttable width=506 cellspacing=0 cellpadding=0&gt' +  N'&lttd width=506 border=0 bgcolor=#f4f4f4 class=top-png&gt&lttable width=506 border=0 cellpadding=0 cellspacing=0&gt' +  N'&ltfont face="Lucida Sans Unicode" size=3&gt' +  N'&lttd width=45&gt &lt/td&gt&lttd align="left" border=10&gt' +  N'Olá,&ltbr&gt&ltbr&gt' +  N'A sua encomenda foi registada com sucesso. Será enviada no prazo máximo de 3 dias. &ltbr&gt' +  N'Obrigado,&ltbr&gt' +  N'Mais Ritmo&ltbr&gt&ltbr&gt&lt/font&gt&lt/td&gt&lt/tr&gt' +  N'&lt/td&gt' +  N'&lt/font&gt' +  N'&lttd width=45&gt &lt/td&gt' +  N'&lt/td&gt' +  N'&lt/tr&gt' +  N'&lt/table&gt' +  N'&lt/center&gt';    EXEC msdb.dbo.sp\_send\_dbmail   @profile\_name = 'maisritmo',  @recipients= @cemail,  @subject = 'Confirmação de Encomenda',  @body = @tableHTML,  @body\_format = 'HTML' ;  END  Depois de criar o trigger, deve ir à Instalação e Manutenção e reinstalar triggers para a tabela de Dossiers Internos.  O corpo do email enviado por este código será algo como:           Testado em dFront 2012 e Enterprise 2012. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Envio de Email Via Trigger de Utilizador' ) |