---
title: Enviodemensagenssms
source: enviodemensagenssms.htm
tipo: Manual Técnico
idioma: PT
---

# Enviodemensagenssms

Envio de Mensagens Sms

|  |
| --- |
| Envio de Mensagens Sms |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Uma das formas mais rápidas e eficazes de comunicar com clientes, fornecedores e/ou colaboradores, é através do envio de mensagens SMS.  O Módulo de Mensagens SMS está disponível em todas as gamas do software, integrado nos restantes módulos PHC, e é uma forma muito eficaz de enviar SMS individuais ou para múltiplos destinatários (de uma só vez), através da aplicação PHC.  Este artigo técnico visa explicar a forma de configurar a aplicação para utilizar todo o potencial dos sms's na aplicação, assim como despistar possíveis problemas com ligações.  Antes de mais, nos grupos de utilizadores, deve validar o módulo SMS:        Após reentrar a aplicação, o passo seguinte é preencher corretamente os parâmetros, que se encontram na pasta Mensagens SMS:        **Envio fica em stand-by**  Significa que ao enviar mensagens SMS, as mesmas ficam guardadas no ecrã de mensagens em stand-by, não sendo enviadas de imediato. Este ecrã vai sendo o repositório das mensagens que ficam em stand-by. Quando o utilizador pretender, poderá enviá-las de forma individual ou todas de uma só vez.        **Identificador para a Mensagem SMS**  Este campo é definido nos parâmetros com o identificador que foi solicitado à operadora e não pode ser modificado. O identificador nos SMS destina-se a cumprir as leis anti-spam.    **Password para SMS**  Neste campo deve ser colocada a password fornecida pela PHC, aquando da activação desta opção.     **URL para SMS**  Neste campo deve ser colocado o url fornecido pela PHC, aquando da ativação desta opção.    **Utiliza envio de mensagens SMS**  Uma vez habilitada, esta opção ativa as funcionalidades de envio de mensagens SMS. Quando activo, devem também ser preenchidos os restantes parâmetros aqui explicados com os dados fornecidos pela PHC.     **Utilizador para SMS**  Neste local deve ser colocado o url fornecido pela PHC, aquando da ativação desta opção.    Depois de corretamente preenchidos os parâmetros e após reentrar na aplicação, ficam disponíveis todas as opções relacionadas com o envio de mensagens SMS.    **Status do WebService**  Neste ecrã, temos informação sobre o identificador, o N.º de SMS enviados, o N.º de SMS por enviar e a data de validade.  Quando acede a esta opção, poderá surgir uma mensagem semelhante a esta:  "Não foi possível aceder ao serviço de SMS. Verifique se tem os dados do SMS corretamente preenchidos".  Caso isso aconteça, deve instalar o Microsoft Soap Toolkit 3.0, que se encontra disponível para download na página da microsoft.     Caso pretenda enviar mensagens SMS, poderá fazê-lo através do ecrã Enviar mensagens SMS.        Neste local, pode aceder ao botão Repetir Última e desta forma, irá surgir no ecrã a última mensagem sms enviada. Se escolher a opção Gravar e Continuar, a mensagem será guardada nas mensagens em Stand-by para ser posteriormente enviada. Ao selecionar Gravar e sair, a mensagem será guardada nas mensagens em Stand-by para ser posteriormente enviada, e o ecrã será encerrado.    **Framework**  Também é possível combinar o envio de Mensagens SMS à Framework PHC, nomeadamente nos Eventos de Utilizador (disponíveis nas gamas Advanced e Enterprise).  Este exemplo mostra como criar um evento de emissão de sms para um cliente, quando lhe é emitida uma fatura:                Outra possibilidade é a criação de uma tecla que exibe um botão que efectua o envio de sms, a partir de qualquer ecrã.  Para tal, é necessário criar uma tecla de utilizador para esse ecrã, neste caso o ecrã de formadores do módulo de Formação:            Ao clicar no botão, surge o ecrã para envio de mensagem SMS:        **Múltiplos Destinatários**  A opção "Assistente de e-mails e sms" permite enviar sms's a múltiplos destinatários de uma só vez.  Antes de mais, deve configurar as tabelas que pretende ver incluídas no assistente.  Para isso deve aceder à Framework PHC, Configuração de tabelas do assistente de e-mails e sms e selecionar as tabelas.  Posteriormente, deve-se iniciar a configuração do envio de sms, através do assistente.                        Caso possua a gama Enterprise, é possível criar um alerta que envia um SMS para um destinatário à escolha.    Nota: Em cada CD de instalação da aplicação PHC, segue um PDF com as Condições de Utilização SMS PHC. Deve ler atentamente este documento antes de utilizar esta funcionalidade.    Este artigo técnico foi elaborado com base na gama PHC Advanced versão 2010. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Envio de Mensagens Sms' ) |