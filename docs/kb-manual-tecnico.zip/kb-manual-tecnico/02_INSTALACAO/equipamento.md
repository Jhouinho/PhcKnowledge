---
title: Equipamento
source: equipamento.htm
tipo: Manual Técnico
idioma: PT
---

# Equipamento

Equipamento

|  |
| --- |
| Equipamento |

|  |
| --- |
| A tabela de equipamento irá realizar a gestão do equipamento instalado, bem como as análises estatísticas do equipamento, histórico e técnicos.     Esta tabela poderá ser, por parametrização, usada isoladamente ou agregada à tabela de instalações, aparecendo neste caso um campo adicional onde se irá recolher qual a instalação a que este equipamento pertence.    Neste capítulo vai ser explicado todo o funcionamento dos equipamentos, começamos por explicar os [campos](constituiçãodatabeladeequipamento.htm) e [ícones](opçõesdisponíveisnoecrãdeequipamento.htm) desta tabela, assim como, as [opções específicas de menu](opçõesdisponíveisnomenudeequipamento.htm).    Aqui serão explicados também os [parâmetros](parâmetrosdosequipamentos.htm) e os [acessos](acessosdosequipamentos.htm) dos equipamentos. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Equipamento' ) |