---
title: Equipamentopróprio
source: equipamentopróprio.htm
tipo: Manual Técnico
idioma: PT
---

# Equipamentopróprio

Equipamento Próprio

|  |
| --- |
| Equipamento Próprio |

|  |
| --- |
| Na área de equipamento pode encontrar os registos sobre os seus [equipamentos](meusequipamentos.htm) e suas [instalações](instalaçõesdesuporteweb.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Equipamento Próprio' ) |