---
title: Erro no Objecto de Gráficos
source: erronoobjectodegráficos.htm
tipo: Manual Técnico
idioma: PT
---

# Erro no Objecto de Gráficos

Problema:
OLE error code 0x8002801d: Library not registered.
programa GRAFICO.DESENHA
Solução:
O objecto dos gráficos não está correctamente registado. Pode ser uma de várias razões.
Uma causa muito comum deste problema é ter-se instalado um Setup de uma aplicação PHC de uma versão anterior à versão 2006 posteriormente à instalação da 2006.
Neste caso basta re-instalar o Setup da Versão 2006 para resolver o problema.
Se não for este o problema O PC em questão tem algum problema no sistema operativo que o impede de registar correctamente o ActiveX.
Para esta situação, podem existir duas soluções:
1: Re-instalar o Sistema operativo
2: Se não pretender re-instalar o sistema operativo, pode tentar a seguinte solução:
Registar manualmente os Active X para isso deve executar os seguintes comandos na opção Run do Menu start do Windows (um de cada
 vez):
regsvr32 /u c:\phc2006\cfx32.ocx
regsvr32 c:\phc2006\cfx32.ocx
regsvr32 /u c:\phc2006\cfx4032.ocx
regsvr32 c:\phc2006\cfx4032.ocx
regsvr32 /u c:\phc2006\sfxbar.dll
regsvr32 c:\phc2006\sfxbar.dll
nota: deve substituir a directoria c:\phc2006, no exemplo acima, pela directoria para onde instalou a aplicação PHC
.
