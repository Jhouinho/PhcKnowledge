---
title: Exemplosdefiltrosdeentidadesemadd Ons
source: exemplosdefiltrosdeentidadesemadd-ons.htm
tipo: Manual Técnico
idioma: PT
---

# Exemplosdefiltrosdeentidadesemadd Ons

Exemplos de Filtros de Entidades em Add-ons

|  |
| --- |
| Exemplos de Filtros de Entidades em Add-ons |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Através da Framework Drive FX é possível criar **Filtros de Entidade**.    Os Filtros de Entidade permitem restringir o acesso a determinados registos na aplicação, com um critério pré-definido no filtro.  Esta restrição na consulta de registos nas entidades é impercetível para o utilizador, uma vez que ao aceder a uma entidade, apenas visualiza a informação que é o resultado do filtro aplicado.    Os critérios dos filtros podem ser diversos, e dependem maioritariamente do tipo de restrição que se pretende aplicar aos registos, que muitas vezes varia consoante o perfil do utilizador.    Exemplos de restrições de acesso que podem ser alvo de um Filtro de Entidade  O utilizador que fez login está associado ao Vendedor "Manuel" (p.e.). Quando acede ao ecrã de clientes, apenas visualiza os clientes associados ao vendedor "Manuel".   O utilizador que fez login apenas visualiza os artigos da família "Pilhas" (p.e.).  O utilizador que fez login apenas visualiza 3 séries de faturação.  O utilizador que fez login é Supervisor dos utilizadores "A" e "B". Os utilizadores "A" e "B" apenas visualizam as suas próprias vendas, mas o Supervisor visualiza as vendas de ambos.  Numa instalação está instalado um Add-on de Gestão de Projetos (p.e.). Cada projeto está associado a uma área e diversas tarefas. O utilizador que fez login apenas vê as tarefas de determinadas áreas/projetos.        **EXEMPLO COMPLETO DE FILTRO: VENDEDOR APENAS VISUALIZA OS SEUS CLIENTES**   . Na ficha do utilizador deve estar associado o vendedor respetivo.  . Aceder à Framework Drive FX (através do kitparceiro), e criar um novo Filtro de Entidade.  . Preencher a entidade "Clientes".  . No campo "Clausula WHERE do comando SQL" preencher:   *cl.vendedor = {CurrentUser.Vendedor}*     - Pode ser preenchido o campo **Identificador único** caso se pretenda usar este filtro na Configuração de Análises.   Ao gravar o registo, é adicionado um prefixo ao nome escolhido, que corresponde ao ID do parceiro que desenvolve o Add-on / Filtro de Entidade.         **EXEMPLO COMPLETO DE FILTRO: VENDEDORES SÓ CONSULTAM AS SUAS FATURAS E O SUPERVISOR CONSULTA AS FATURAS DE AMBOS**´  . Na ficha dos utilizadores devem estar associados os vendedores respetivos.  . Aceder à Framework Drive FX, e escolher as Personalizações de Entidade.  . Nas Personalizações de Entidade criar uma nova tabela com o nome "CM3EXT".   . Na tabela, criar um campo de texto simples, com o nome "REFINT".  . Ainda na Personalização de Entidade, ligar a tabela criada à tabela de Vendedores.  . Na consulta de um registo do ecrã de Vendedores (ou em modo de introdução), tendo ativo o modo de desenho de um Add-on que esteja em construção, adicionar ao ecrã o campo de texto previamente criado, com o nome "REFINT".    Agora, a lógica é preencher este campo de uma forma a definir as hierarquias entre os 3 utilizadores intervenientes - os utilizadores A, B e o seu supervisor.  Exemplo: A Maria é supervisora dos vendedores Carlos e Paulo.  . Na ficha de vendedor "Maria", o campo deve ser preenchido com o valor "A".  . Na ficha dos vendedores "Carlos" e "Paulo" devem ser preenchidos os valores "A1" e "A2", respetivamente.  (se o Carlos fosse por sua vez supervisor da vendedora Andreia, a Andreia teria na sua ficha preenchido o valor "A11", e por aí em diante).  . Criar um novo Filtro de Entidade, preenchendo a entidade "Documentos de Faturação".  . No campo "Clausula WHERE do comando SQL", preencher:   *(ft.vendedor = {CurrentUser.Vendedor}) or (u1\_cm3ext.refint like '{CurrentUser.Cm3VO.U1\_CM3EXT.REFINT}%')*  . No campo "Clausula JOIN do comando SQL" preencher:   *Inner Join cm3 on cm3.cm = ft.vendedor left join u1\_cm3ext on u1\_cm3ext.cm3stamp = cm3.cm3stamp*  No caso de se pretender aplicar o mesmo filtro numa análise associada aos documentos de faturação (na Configuração de análises), teriam de ser utilizados os códigos  *{EntityJoin}* e *{EntityFilter}* nos respetivos locais da análise, mencionando o campo o valor do campo "Identificador único". Por exemplo:   *Select ft.nmdoc,ft.fno,ft.nome,ft.etotal from ft {EntityJoin.u1\_01} where draftRecord=0 and ({EntityFilter.u1\_01})* |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Exemplos de Filtros de Entidades em Add-ons' ) |