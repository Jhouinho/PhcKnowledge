---
title: Expressãoxbase
source: expressãoxbase.htm
tipo: Manual Técnico
idioma: PT
---

# Expressãoxbase

Expressão Xbase

|  |
| --- |
| Expressão Xbase |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta propriedade permite definir uma expressão em Xbase.  No ecrã de Construção de uma expressão está disponível o campo **Eventos** onde pode selecionar um [evento](eventos.htm). Ao selecionar aqui o evento, não precisa de sair do ecrã de Construção de uma expressão e selecionar o evento pretendido para o codificar, porque o ecrã de edição de código é o mesmo. Estes eventos apenas estão disponíveis na gama Enterprise.    Por exemplo, numa página de utilizador se colocar uma grelha e efetuar o seguinte:        Na grelha aparecerão todos os artigos que tenham definido na sua ficha que o fornecedor do ecrã é o seu habitual.       Nos Painéis de Informação e Ecrãs Personalizados esta propriedade está disponível nos seguintes objetos:  [Botão de eMail](botãodeemail.htm)  [Botão de URL da Internet](botãodeurldainternet.htm)   [Campos em Árvore](campoemárvore.htm)   [Campos de Ligação](campodeligação.htm)   [Campos de Tabelas](camposdetabelas.htm)  [Campos com Listas](camposcomlistas.htm)  [Campos com Tabelas](camposcomtabelas.htm)  [Campos Memos](camposmemos.htm)  [Campos Lógicos](camposlógicos.htm)  [Gráfico](gráfico.htm)  [Grelha](grelha.htm)  [Imagem](imagem.htm)  Objeto Indicador   *Nota:* Para obter mais informação consulte o tópico "Objeto Indicador", caso possua o Módulo PHC Dashboard CS , apenas disponível nas gamas PHC Enterprise CS e PHC Advanced CS.    *Nota:* esta funcionalidade está disponível nas três gamas: PHC Corporate CS (apenas para os objetos Grelha, Gráfico, Campo em árvore, Indicador, Indicador Phc Cs Web e Indicador em Barra), PHC Advanced CS e PHC Enterprise CS, caso o número de instalação já exista.  Se for uma instalação nova, a partir da versão 17, esta funcionalidade existe nas gamas PHC Advanced CS, apenas com o PHC On ativo, e na gama PHC Enterprise CS, com ou sem PHC On ativo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Expressão Xbase' ) |