---
title: Facturaçãoperiódicadeinstalaçõesporpagar
source: facturaçãoperiódicadeinstalaçõesporpagar.htm
tipo: Manual Técnico
idioma: PT
---

# Facturaçãoperiódicadeinstalaçõesporpagar

Facturação Periódica de Instalações por Pagar

|  |
| --- |
| Facturação Periódica de Instalações por Pagar |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite obter uma listagem com os contratos facturados e que ainda não foram pagos pelo cliente.    Para esta opção funcionar são necessários dois pressupostos:  Em primeiro lugar é necessário possuir o módulo de Gestão, sem o qual não é possível executar a facturação automática.  Em segundo lugar é obrigatório utilizar o ficheiro de instalações, sem o qual não é possível registar a respectiva informação. Para mais informações sobre a activação do ficheiro de instalações consulte por favor o capítulo dos [Parâmetros](parâmetrosdasinstalações.htm).    Para obter a análise basta clicar em **Calcular**, sendo então apresenta o ecrã com a informação das diversas instalações e seus contratos.         Os documentos de facturação que se apresentam nestas listagens serão retirados assim que se emitir um Recibo no módulo de Gestão.    Para mais informações sobre esta opção consulte por favor o capítulo de facturação automática do manual de Gestão e o capítulo das [Instalações.](ConstituiçãodatabeladeInstalações.htm#facturação automática)    *Nota:*  Todos os botões deste ecrã estão explicados nas [Opções das Análises](opçõesdasanálises.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Facturação Periódica de Instalações por Pagar' ) |