---
title: Faqs - Ajustamento à Estrutura do Ficheiro Saf-t (pt)
source: faqs-ajustamentoàestruturadoficheirosaf-t(pt).htm
tipo: Manual Técnico
idioma: PT
---

# Faqs - Ajustamento à Estrutura do Ficheiro Saf-t (pt)

No dia 2 de dezembro foi publicada a
Portaria n.º 302/2016
, no Diário da República, 1.ª série - N.º 231.
Esta portaria aprovou o novo formato de ficheiro normalizado de auditoria tributária para exportação de dados SAF-T (PT) a vigorar no exercício de 2017.
Deste modo, altera a
Portaria n.º 321-A/2007
, de 26 de março, e a estrutura de dados do ficheiro referido no n.º 1 da mesma portaria.
Foram também criadas duas tabelas de taxonomias, Anexos II e III, a utilizar no preenchimento dos campos respetivos do ficheiro SAF-T (PT). O Anexo II apresenta a tabela S - SNC base e Normas Internacionais de Contabilidade e o Anexo III apresenta a tabela de taxonomia M - SNC Microentidades.
Para auxiliá-lo, preparámos um conjunto de perguntas frequentes para clarificá-lo sobre a incidência destas alterações:
(1)	O que entra em vigor a 1 de janeiro de 2017?
O plano de contas que tenha correspondência às tabelas de taxonomia, respeitando a Portaria n.º 302/2016.
(2)	O que entra em vigor a 1 de julho de 2017?
A nova estrutura de dados do ficheiro SAF-T (PT), respeitando a Portaria n.º 302/2016.
(3)	A quem se aplica esta Portaria?
Aplica-se a todos os sujeitos passivos ao abrigo do n.º 1 do artigo 123.º do CIRC, ou seja, a todas as entidades que são obrigadas a dispor de contabilidade organizada.
(4)	A 1 de janeiro tenho de atualizar executável para conseguir atualizar o plano de contas?
Não. Apenas terá de efetuar a importação do plano de contas através da instalação e manutenção de tabelas, conforme o indicado no artigo técnico
Alterações ao Ficheiro SAFT-T (PT) pela Portaria nº 302/2016
.
(5)	O que são as taxonomias?
As taxonomias são códigos que têm correspondência a uma ou mais contas do plano de contas do SNC e que vão permitir o preenchimento de campos na estrutura de dados do ficheiro SAF-T (PT), com o intuito de simplificar o preenchimento dos Anexos A e I da IES.
(6)	A quem se aplica a tabela de taxonomia S, anexo II?
A tabela de taxonomia S - SNC base e Normas Internacionais de Contabilidade aplica-se às entidades que façam a apresentação de contas de acordo com as normas contabilísticas NCRF-PE (Norma Contabilística e de Relato Financeiro para Pequenas Entidades), NCRF (Norma Contabilística e de Relato Financeiro que se aplica às médias e grandes entidades) e NIC (Normas Internacionais de contabilidade).
(7)	A quem se aplica a tabela de taxonomia M, anexo III?
A tabela de taxonomia M - SNC Microentidades aplica-se às entidades que fazem apresentação de contas de acordo com a norma contabilística NC-ME (Norma Contabilística para Microentidades).
(8)	Que implicações tem esta portaria na aplicação PHC CS Desktop?
Esta portaria implica a adaptação do plano de contas no módulo PHC CS Contabilidade desktop, a disponibilização das tabelas de taxonomia e a respetiva ligação às contas do plano de contas, e a alteração e disponibilização do ficheiro SAF-T (PT) de acordo com a nova estrutura.
(9)	Tenho de ter o plano de contas atualizado no dia 1 de janeiro de 2017?
Sim. Todos os documentos contabilísticos do exercício de 2017 terão de estar de acordo com as tabelas de taxonomia, pelo que terá de ter um plano de contas apto a fazer essa correspondência.
(10)	Ao efetuar a importação do novo plano de contas vou perder os planos de contas dos anos anteriores?
Não. É muito importante a ativação da opção
não apagar os dados que já existem
, no ecrã "Instalação e Manutenção" de tabelas, no momento da importação do novo plano de contas. Com esta opção ativa, os registos desta tabela referentes aos anos anteriores não serão perdidos.
(11)	Posso criar manualmente novas contas no plano de contas?
Sim. Os utilizadores podem criar novas contas manualmente no plano de contas. No entanto, devem ter atenção para não criarem contas de integração que não tenham um código de taxonomia definido em portaria.
(12)	Posso criar o meu próprio plano de contas?
Sim. As entidades podem criar o seu próprio plano de contas, devendo ter por base as tabelas de taxonomias referidas nos Anexos II e III da Portaria n.º 302/2016, de modo a que a partir de 1 de julho de 2017 consigam comunicar o ficheiro SAF-T (PT) com a nova estrutura de dados.
(13)	Quais os cuidados a ter na aplicação após a alteração do plano de contas?
a)	Com a alteração do plano de contas será necessário rever os códigos SNC definidos para garantir o sucesso das integrações na contabilidade.
b)	Será necessário efetuar correções às fórmulas das Demonstrações Financeiras para que estas produzam informação viável e fidedigna. Estamos a desenvolver estes mapas de gestão PHC para estarem disponíveis no mês de janeiro de 2017.
c)	Terá de ter preenchido o campo "Norma Contabilística" no ecrã "Ficha Completa da Empresa".
(14)	O Cliente utiliza a integração automática para a contabilidade. Até quando poderá ser feita a atualização do plano de contas?
Até ao dia 31 de dezembro de 2016, uma vez que todos os documentos que forem gerados serão automaticamente contabilizados. Caso não seja efetuado atempadamente será necessário ir manualmente efetuar a correção dos documentos contabilísticos.
(15)	Já tenho um plano de contas em 2017. Como efetuo a atualização do meu plano de contas?
Não é possível efetuar a atualização automática de um plano e contas já existente. Caso pretenda atualizar o plano de contas terá de criar manualmente as novas contas ou, optar por eliminar o plano de contas existente de modo a conseguir efetuar a atualização automática.
(16)	O Cliente é uma microentidade. Pode utilizar todas as contas do novo plano de contas?
Não. O plano de contas disponibilizado prevê todas as contas que existem para as empresas ao abrigo das normas contabilísticas NCRF. As microentidades não devem lançar documentos contabilísticos nas contas que não lhes estão disponíveis, de acordo com o estabelecido na Portaria n.º 218/2015, de 23 de julho.
Verifique a
listagem
com o resumo das contas que não devem ser utilizadas na contabilização de documentos pela Microentidades.
(17)	Tenho que atualizar o executável para ter acesso ao novo SAF-T (PT)?
Sim. A nova estrutura do SAF-T (PT) irá ser disponibilizada na V21 pelo que terá de efetuar o upgrade da base de dados para um executável da V21.
(18)	Quais as implicações deste novo SAF-T (PT) nos clientes?
A primeira implicação direta será a necessidade de ter um plano de contas que faça a correta correspondência às tabelas de taxonomia publicadas.
A partir de julho, terá de disponibilizar o novo ficheiro SAF-T (PT) sempre que a AT - Autoridade Tributária solicitar.
(19)	Esta alteração ao SAF-T (PT) afeta todos os ficheiros SAF_T (PT) (comunicação mensal de faturas, comunicação de documentos de transporte e SAF-T (PT) de auditoria)?
A principal alteração afeta o SAF-T (PT), ao qual denominamos de SAF anual, uma vez que estas alterações são ao nível das contas SNC da contabilidade que passa a ser parte integrante da sua estrutura. Estamos a analisar as restantes alterações na estrutura do ficheiro a ser gerado de modo a efetuar as alterações necessárias.
(20)	É necessário ter algum cuidado adicional na emissão de faturas? É necessário preencher algum campo adicional?
De momento estamos a analisar todas as alterações na estrutura do ficheiro SAF-T (PT) de modo a averiguar se existe a necessidade de adicionar campos que sejam preenchidos pelos utilizadores ou pela aplicação.
Ao nível da contabilidade a aplicação irá efetuar a correspondência entre as contas SNC e os códigos de taxonomia.
(21)	A nova estrutura do SAF-T (PT) afeta apenas o módulo de PHC CS Contabilidade desktop ou afeta também o módulo PHC CS Gestão desktop?
As alterações na estrutura do SAF-T (PT) são extensas e afetam muitas tabelas. Estamos neste momento a analisar todas as implicações da mesma na aplicação.
(22)	Que implicações é que poderão existir se não fizer a migração para a V21 para ter acesso a estas novidades?
Caso opte por não efetuar o upgrade para a V21, não será possível emitir o ficheiro SAF-T (PT) de acordo com a nova estrutura publicada, pois não serão desenvolvidos os códigos de taxonomia nas versões anteriores nem será possível gerar o ficheiro SAF-T no formato em vigor a partir de 1 de julho de 2017.
(23)	Tenho uma versão anterior da aplicação PHC CS Desktop, posso atualizar para o novo plano de contas?
Sim. Pode efetuar a atualização para o novo plano de contas, no entanto, após 1 de julho de 2017, não conseguirá emitir o ficheiro SAF-T (PT) de acordo com a nova estrutura publicada.
(24)	Está prevista alguma rotina que possa afetar as várias bases de dados dos gabinetes de contabilidade?
Não. A atualização do plano de contas terá de ser feita individualmente para cada base de dados.
(25)	O que é a Grelha de transição? E como se utiliza?
A grelha de transição é uma ferramenta desenvolvida no âmbito da passagem do POC para o SNC, que permite a conversão de contas e abertura de saldos iniciais de uma forma única ou faseada.
Pode visualizar o conteúdo disponível sobre
Contabilidade - Grelha de Transição
.
Para utilizar neste momento a grelha de transição terá de considerar que a coluna "Conta POC" é a correspondente à Conta SNC de 2016 e a Conta SNC corresponde à Conta SNC de 2017.
De forma a permitir a utilização desta ferramenta, também foi disponibilizado o ficheiro
ContasSNC2017.CSV
, no seguinte caminho do FTP:
../Pub/TabelasEspecificas/PHC CS Contabilidade desktop/Plano_Contas_SNC/
(26)	Em fevereiro de 2017 sou inspecionado pela AT e é-me solicitado o ficheiro SAF-T (PT) relativo ao exercício de 2015, qual o ficheiro que tenho de entregar?
Tem de entregar o ficheiro de acordo com a Portaria n.º 274/2013, de 21 de agosto.
(27)	Em setembro de 2017 sou inspecionado pela AT e é-me solicitado o ficheiro SAF-T (PT) relativo ao exercício de 2015, qual o ficheiro que tenho de entregar?
Tem de entregar o ficheiro de acordo com a Portaria n.º 274/2013, de 21 de agosto.
(28)	Em agosto de 2017 sou inspecionado pela AT e o inspetor pede-me o ficheiro SAF-T (PT) relativo ao exercício de 2017, qual o ficheiro que apresento?
Tem de entregar o ficheiro de acordo com a Portaria n.º 302/2016, de 2 de dezembro.
(29)	Se efetuar a integração para a aplicação proveniente de softwares externos, quais são as implicações?
Se efetuar a integração de documentos contabilísticos provenientes de outros softwares deverá garantir que o plano de contas utilizado nesse software externo é coincidente com o plano de contas que utiliza na aplicação.
(30)	Só tenho o PHC CS Gestão desktop e estou a ter uma inspeção ao exercício de 2017, qual é o formato do ficheiro SAF-T (PT) que devo entregar?
Tem de entregar o ficheiro de acordo com a Portaria n.º 302/2016, de 2 de dezembro.
(31)	Tenho um ano fiscal diferente do ano civil. Tenho de ter o plano de contas atualizado a 1 de janeiro de 2017?
Não. O plano de contas tem de estar atualizado no primeiro dia do exercício que inicia em 2017.
(32)	Tenho o PHC CS XL. Quais são as implicações destas alterações?
Vai ser necessário efetuar alterações no mapeamento para o PHC CS XL. Estamos neste momento a analisar as alterações necessárias a desenvolver.
Alterações ao Ficheiro SAFT-T (PT) pela Portaria nº 302/2016
