---
title: Faqs - Formulários de Impressão (idus)
source: faqs-formuláriosdeimpressão(idus).htm
tipo: Manual Técnico
idioma: PT
---

# Faqs - Formulários de Impressão (idus)

No passado dia 03 de julho, a AT - Autoridade Tributária e Aduaneira publicou o
Despacho nº 8632/2014
, o qual veio introduzir um vasto conjunto de alterações aos requisitos de certificação de
software
.
Entre as obrigações apresentadas, foram introduzidas alterações ao nível da impressão de documentos, que vieram modificar a estrutura atual de criação e edição de desenhos de formulários de impressão (IDUS).
Para ajudar a configurar os relatórios de impressão, preparamos um conjunto de perguntas e respostas que consideramos serem relevantes para configurar todas as impressões já existentes, assim como apoiar na criação de novos IDUS.
Se tiver
PHC ON
poderá aprender alguns truques para facilitar o desenho dos IDUs, clicando
aqui
.
