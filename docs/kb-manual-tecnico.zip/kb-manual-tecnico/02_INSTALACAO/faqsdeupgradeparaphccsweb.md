---
title: Faqsdeupgradeparaphccsweb
source: faqsdeupgradeparaphccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Faqsdeupgradeparaphccsweb

Faqs de Upgrade para Phc Cs Web

|  |
| --- |
| Faqs de Upgrade para Phc Cs Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico procura responder a algumas questões que possam surgir ao atualizar o PHC CS Web.    Poderão surgir questões como:    **Onde é que agora se configura os números de série para autenticação no PHC CS Web?**  No ficheiro appSettings.config, que se encontra na pasta de instalação do PHC CS Web, dentro do INETPUB.    **O que é o ficheiro appSettings.config?**  O ficheiro appSettings.config contém todas as keys que estavam presentes no ficheiro web.config.    **Porque continua a existir o ficheiro web.config?**  Todas as configurações necessárias para o bom funcionamento da aplicação continuam a estar no ficheiro web.config, apenas foi colocada a informação no ficheiro appSettings.config, à parte, para distinguir o que são configurações que podem ser alteradas pelo utilizador.  Desta forma, o utilizador, aquando da atualização da aplicação, passa a ter no web.config todas as opções atualizadas automaticamente para garantir o bom uso da aplicação.     **Deixa de ser necessário fazer um backup do ficheiro web.config?**  No caso de efetuar a atualização da aplicação Web para a nova versão 18, é necessário salvaguardar o ficheiro web.config.  Se pretender atualizar o PHC CS Web, dentro da versão 18, basta garantir que, ao efetuar via Web Deploy, o ficheiro appSettings.config , do ecrã "Select the Contents of the Package" se encontre inativo. Caso efetue a atualização via CMD, este ficheiro não será mexido.    **Não é necessário alterar nada no ficheiro web.config?**  Correto, deixa de necessário o utilizador alterar o ficheiro web.config.    **No ficheiro appSettings.config, as keys referentes ao módulo deixaram de ter o "d" no início?**  Sim, para novos clientes que estão a adquirir a versão 18 do PHC CS Web, o licenciamento já vem com a nova nomenclatura.  Para clientes que já utilizem a aplicação Web, as keys são iguais, ou seja mantém-se com os "d" no início dos módulos.    **Como proceder na atualização dos ficheiros Web.config e appSettings.config?**  Nos clientes que estavam a trabalhar com o PHC CS Web, deverá abrir o ficheiro web.config da versão anterior e copiar tudo o que estiver dentro do &ltappSettings&gt, ou seja as keys referentes aos módulos e colar no novo ficheiro appSettings.config mantendo a nomenclatura anterior. Este novo ficheiro tem que continuar a ter os nomes dos módulos antigos.     Aquando da nova instalação deve ser mantido o ficheiro web.config que é criado no momento da instalação e não colocar o da versão anterior.    *Nota*: Ao copiar as keys para dentro do novo ficheiro appSettings.config estas devem ser eliminadas do web.config.    **Se adquirir um novo módulo na versão 18, no appSettings.config, devo colocar com o nome antigo ou o nome novo?**   Caso o cliente adquira um módulo novo, esse módulo deve estar no appSettings.config com o novo nome. Os antigos não devem ser alterados.    **Após configurar o ficheiro appSettings.config está a ocorrer o erro "Desculpe, mas a aplicação está temporariamente indisponível. Por favor, tente mais tarde. (02)"**  Este erro pode ocorrer por várias situações, uma delas é no appSettings.config ter os nomes errados nos módulos. Deve preencher no appSettings.config a key "MAILPARAERROS" e "SMTPSERVER" e verificar se no e-mail se está a receber notificações com o assunto "Autenticação Falhada", caso esteja, deve corrigir os nomes dos produtos.    **Não encontro a key dSupervisor no appSettings.config**  Esta key deixa de existir pois o acesso ao menu de Supervisor, na Intranet, passa a ser controlado pelo produto Supervisor, definido na ficha de utilizador, no separador PHC CS Web. Apenas é possível aceder ao Supervisor se tiver com outro módulo definido para o utilizador.    **Como posso ter a certeza qual o nome do módulo que tenho de colocar?**  Na Comunidade existe um ecrã [Consulta de Instalações](http://comunidade.phc.pt/parceiros/programs/gensel.aspx?eusql=119), que pode ser acedido no menu "Parceiros" e que permite visualizar os números de série de cada um dos seus clientes e os respetivos nomes dos módulos.    **Apenas tenho o Front, que é um produto da Extranet, como acedo ao Supervisor?**  Para os clientes que não tenham nenhum produto no Intranet e para que possam aceder ao Supervisor, iremos oferecer uma licença de Front Intranet. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Faqs de Upgrade para Phc Cs Web' ) |