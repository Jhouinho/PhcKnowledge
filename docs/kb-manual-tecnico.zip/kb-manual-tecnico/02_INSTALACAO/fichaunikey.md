---
title: Fichaunikey
source: fichaunikey.htm
tipo: Manual Técnico
idioma: PT
---

# Fichaunikey

Ficha Unikey

|  |
| --- |
| Ficha Unikey |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Em substituição das atuais fichas de validação do Software encontram-se disponíveis as novas fichas Unikey, que só poderão ser usadas a partir da versão 2013, que dispõe de um novo método de configuração e com este artigo técnico pretendemos dar a conhecer a forma de como o poderá fazer.    Como anteriormente, agora continuam a existir dois tipos de ficha, a monoposto (cinzenta) e as fichas de rede (avermelhada/rosa).  No caso de ser uma ficha ser monoposto, basta existirem as dlls UniKey.dll, UniKeyfrmt.dll (que são colocadas aquando do setup da aplicação PHC) e o ficheiro de controlo unikey.dbf (que pode ser criado aquando da escolha do tipo de ficha no arranque da aplicação).    Esta ficha não necessita de qualquer outro tipo de instalação uma vez que é "driverless", ou seja, não necessita da instalação de qualquer driver.    Relativamente às fichas Rede, além de ser necessário as dlls UniKey.dll, UniKeyfrmt.dll (que são colocadas aquando do setup da aplicação PHC) e o ficheiro de controlo unikeypro.dbf (que pode ser criado aquando da escolha do tipo de ficha no arranque da aplicação) é necessário efetuar os seguintes passos:    - Copiar a diretoria "64 Modules Server" (a partir do DVD de instalação do PHC e/ou a partir do FTP) para o local pretendido no computador que servirá de servidor de ficha;    - Nessa diretoria, executar "Install.exe" - é apresentada uma janela com a shell de DOS, onde devem escrever a letra "A" (assim mesmo, em maiúsculas) - isto vai fazer com que seja instalado e executado o serviço Unikey;    Este ficheiro, assim como os restantes ficheiros referentes à instalação desta ficha, encontram-se disponíveis no nosso FTP em Outros/Utils/Ficha/Unikey.    Alertamos para uma questão IMPORTANTE que tem a ver com o facto de a instalação ter de ser executada a partir do disco (físico) da máquina em que se pretende efetuar a instalação do serviço da ficha, devendo por isso ser copiado o ficheiro do DVD ou da PEN para a máquina em que se vai proceder á instalação do serviço da ficha e NÃO deve ser executado a partir dos suportes acima mencionados.    A fim de permitir a comunicação com a ficha entre o servidor e os clientes (postos), poderá ser necessário incluir regras de entrada e saída, nos computadores clientes e também no servidor, nas respectivas firewalls, para a porta 5680.  Para além das regras in e out para a porta 5680, criar regras in e out para os seguintes ficheiros (localizados na directoria 64 Modules Server):  - NetUnikeyServer.exe;  - NetUnikeyService.exe.    Tratando-se de uma ficha de rede, por defeito, o ficheiro NetUniKey.ini (que pode encontrar por exemplo, no nosso FTP, na pasta acima referida) vai configurado para efetuar broadcasts à rede, no entanto e para que se possa especificar o IP da máquina onde se encontra a ficha, deveremos editar este ficheiro e "descomentar" a seguinte linha, ou seja, onde está:    #ServerIP =###.###.###.###    deverá ficar:    ServerIP =XXX.XXX.XXX.XX    em que XXX.XXX.XXX.XX corresponde ao IP da máquina em que se encontra instalada a ficha de rede.    Gama e versão de Software PHC em que foi testado: todas as gamas da versão 2013. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Ficha Unikey' ) |