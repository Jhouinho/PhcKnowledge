---
title: Frameworkphc
source: frameworkphc.htm
tipo: Manual Técnico
idioma: PT
---

# Frameworkphc

Framework Phc

|  |
| --- |
| Framework Phc |

|  |
| --- |
| Nesta área do software poderá encontrar diversas opções que lhe permitem acrescentar/alterar algumas funcionalidades da framework, são elas:    [Listagens Rápidas de Utilizador para ecrãs](listagensrápidasdeutilizadorparaecrãs.htm)  [Questionários](questionários.htm)  [Instruções Internas](instruçõesinternas.htm)  [Teclas do Utilizador](teclasdoutilizador.htm)  [Configuração do Assistente de E-mails](configuraçãodoassistentedee-mails.htm)  [Campos do Utilizador](camposdoutilizador.htm)  [Regras do Utilizador](regrasdoutilizador.htm)  [Valores por Defeito](valorespordefeito.htm)       Intellisense no código xbase.  A framework phc apresenta um conjunto de funções xbase e outras funções internas da phc. O intellisense é uma funcionalidade presente nos ecrãs de código xbase que auxilia o utilizador a programar xbase dentro do software. Permitindo editar o seu código em xbase, assim se escrever uma função da framework PHC ou mesmo uma função nativa do xbase, aparecer-lhe-á um texto de ajuda com os nomes dos parâmetros que essa função utiliza, facilitando assim o uso das mesmas.    O Intellisense é uma base de dados que contém Funções de Fox, Funções PHC e os comandos necessários à criação de código.    A Instalação desta funcionalidade é automática e ocorre no momento da instalação do setup da versão 2008. É nesse momento que são criados automaticamente na directoria do executável os seguintes ficheiros:   - Foxcode.dbf  - Foxcode.fpt  - Foxcode.app     O Intellisense está pronto a funcionar.    Quando se pretende desenvolver código, ao premir o botão de intellisense, a aplicação abre uma janela **Editi1.prg**, onde o código deve ser gerado.   O software cria por seu turno um ficheiro temporário com os dados que está a editar e ao sair, o utilizador deve gravar o código criado para que o software PHC o coloque no respectivo campo.     Esta ferramenta assume três características principais:  O Poder de Sugestão que se apresenta consoante o utilizador vai escrevendo o código. O intellisense vai sugerindo numa pequena tooltip as diversas possibilidades de código que podem complementar o anterior já escrito.        O Reconhecimento de código abreviado - O Intellisense reage a comandos Predefinidos que não são mais do que código abreviado. Assim, o programador escreve de forma abreviada um determinado comando e o Intellisense completa com o que falta, formatando o código correctamente e deixando o cursor no local exacto para que se possa começar a escrever.  Por exemplo, comandos como:  IFEND, IFELSE; DOCASE; DOWHILE, FOREACH, FOREND, SCANEND e TEXTEND, ao se escrever IFEND, o Intellisense vai automaticamente colocar o comando formatado da seguinte forma:    IF    ENDIF    A função de manual que documenta todas as funções existentes em memória, sejam elas funções de FOX ou Funções PHC.    Exemplos de Intellisense:  Esta ferramenta faz *syntax coloring*, pelo que coloca: - As Keywords a azul;  - As Variáveis, tabelas e restante código a preto;  - E os comentários ao código a verde.     Quando se pretende efectuar cálculos com o código que se está a escrever, muitas vezes é necessário efectuar fórmulas por extenso como por exemplo: *TOTAL=TOTAL+fi.ecusto*  Para que não seja necessário escrever tudo, basta digitar:   *TOTAL+=* que o intellisense coloca *TOTAL=TOTAL+* depois é só escrever o nome do campo cujo valor se pretende adicionar.  Ou por exemplo, para declarar que *TOTAL=TOTAL+1*, basta escrever *TOTAL++*. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Framework Phc' ) |