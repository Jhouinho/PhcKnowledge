---
title: Funcionalidadesexclusivascomphcon
source: funcionalidadesexclusivascomphcon.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionalidadesexclusivascomphcon

Funcionalidades Exclusivas com Phc On

|  |
| --- |
| Funcionalidades Exclusivas com Phc On |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Ao subscrever o acordo PHC On terá à sua disposição as seguintes funcionalidades exclusivas para [PHC CS Desktop,](#mchcs) [PHC CS Web](#mchdigital), [PHC CS XL](#mchxl) e [PHC CS Manufactor.](#mchmanu)    É de notar que, ao atingir a data limite de cessação da subscrição ao PHC On, o utilizador que tiver o licenciamento por internet deixa de ter disponíveis as funcionalidades específicas do PHC ON.      **PHC CS Desktop**     [Desktop - Gerais](#mchfunger)   Módulos:     [PHC CS Gestão desktop](#mchfunges)   [PHC CS Contabilidade desktop](#mchfuncont)  [PHC CS Pessoal desktop](#mchfunpes)   [PHC CS Recursos Humanos desktop](#mchfunRH)  [PHC CS CRM desktop](#mchcfuncrm)   [PHC CS Equipa desktop](#mchcfunequ)  [PHC CS POS desktop](#mchfunpos)   [PHC CS Sincro POS desktop](#mchcfunspo)   [PHC CS Documentos Eletrónicos desktop](#mchcfundoe)   [PHC CS Clínica desktop](#mchcfuncli)   [PHC CS Multilingua desktop](#mchcfunmul)       **PHC CS Web:**     [Web - Gerais](#mchwebgerais)     Módulos:     [PHC CS Gestão web](#mchgesweb)  [PHC CS Contabilidade web](#mchcontweb)  [PHC CS Equipa web](#mcheqweb)  [PHC CS Front web](#mchfrontweb)  [PHC CS Recrutamento web](#mchrecweb)  [PHC CS Colaborador web](#mchcolweb)  [PHC CS Vencimentos web](#mchvenweb)  [PHC CS Recrutamento web](#mchrecweb)  [PHC CS Supervisor web](#mchcsupweb)  [PHC CS Loja web](#mchcslojaweb)       **PHC CS XL**     [XL - Gerais](#mchxl)     **PHC CS Manufactor**     [Manufactor - Gerais](#mchmanu)     Módulos:     [PHC CS Platform manufactor web](#mchplatmanu)  [PHC CS Planning manufactor](#mchplamanu)  [PHC CS Touch manufactor](#mchtoumanu) |
  
  
  
**Para o PHC CS Desktop:**  
  
**Gerais**  

  
  
**Visualização de Horas na Agenda de Marcações**  
A opção de ativação e inativação da visualização de horas está presente no menu de "Opções Diversas" do ecrã [Agenda de Marcações](constituiçãodaagendademarcações.htm), sendo necessário, após feita a alteração, efetuar o "Refresh" do ecrã, para que possa visualizar as horas no navegador.  
  
  
**Agenda em modo "Diário", "Mensal", "Semana Completa" ou "Semana de trabalho"**  
Esta opção permite visualizar o dia específico (Diário), os dias úteis (Semana de trabalho), a "Semana completa" ou as marcações mensais (Mensal) na [Agenda de Marcações](constituiçãodaagendademarcações.htm), desta forma apenas estará visível a informação que o utilizador pretende encontrar.  
  
  
**Alteração ou eliminação de registos criados a partir do Multiplicador de Registos**  
Esta funcionalidade permite que as alterações feitas a um registo sejam repercutidas para a série desse mesmo registo em determinados [ecrãs](Multiplicadorderegistos.htm#mchecra) e [campos](Multiplicadorderegistos.htm#mchcampo). O mesmo ocorre quando pretende eliminar um registo e que seja repercutido nos seguintes registos da série.  
  
  
**Acesso à Configuração dos Parâmetros**  
Este acesso está disponível a partir da versão 17 nas gamas Advanced e Enterprise, caso possua o PHC On ativo e permite definir acesso à tabela de Parâmetros, bem como definir acessos por parâmetro.  
  
  
**Propriedade "Expressão Xbase"**  
Esta propriedade permite definir uma [expressão Xbase](expressãoxbase.htm) nos seguintes objetos disponíveis nos Painéis de Informação e Ecrãs Personalizados:  

  
Botão de email  
Botão de URL da Internet   
Campos em Árvore   
Campos de Ligação   
Campos de Tabelas  
Campos com Listas  
Campos com Tabelas  
Campos Memo  
Campos Lógicos  
Gráfico  
Grelha  
Imagem  
Objeto Indicador (Apenas disponível se possuir o módulo PHC CS Dashboard desktop):  
  
Esta funcionalidade está disponível nas três gamas: Corporate, Advanced e Enterprise, caso o número de instalação já exista.  
Se for uma instalação nova, a partir da versão 17, esta funcionalidade existe nas gamas Advanced, apenas com o PHC On ativo, e na gama Enterprise, com ou sem PHC On ativo.
  
  
  
**Visualização das análises avançadas em formato Tag Cloud**  
Esta funcionalidade encontra-se disponível a partir da versão 17 nas gamas Advanced e Enterprise caso possua o PHC On ativo e permite visualizar análises avançadas em formato Tag Cloud.   
  
*Nota:* Para saber mais, caso possua as gamas Advanced ou Enterprise, por favor, consulte o tópico "Análises Avançadas do Utilizador".  
  
  
**Criação de filtros em modo básico**  
Esta funcionalidade encontra-se disponível a partir da versão 19 do PHC CS Desktop caso possua o PHC On ativo e permite criar um filtro de uma forma simples. Neste tipo de filtro apenas é possível inserir cinco linhas.   
Para mais informações, por favor, consulte o tópico [Filtros](filtros.htm).  
  
  
**Configurar título em análises avançadas com listagem HTML**  
A partir da v19 com as Gamas Advanced e Enterprise com PHC On ativo, passa a ser possível definir um título dinâmico ao criar uma Análise avançada do tipo "Listagem em HTML".  
  
Para mais informações, por favor, consulte o tópico "Análises Avançadas do Utilizador".  
  
  
**Previsão meteorológica na Agenda de Marcações**  
Com a v19 passa a ter a possibilidade de [visualizar a meteorologia](ConstituiçãodaAgendadeMarcações.htm#mchprevisãometeo) do próprio dia e dos dois dias seguintes na Agenda de Marcações, caso possua o PHC On ativo. Para que esta funcionalidade esteja visível, o parâmetro **Usa previsão meteorológica** deverá estar ativo no nó "Agenda de Marcações".  
  
**Criar Análises Multidimensionais a partir de Análises de Utilizador**   
A partir da v21, com o assistente de análises multidimensionais pode criar uma análise multidimensional tendo por base uma análise avançada.  
  
O assistente de análises multidimensionais apresenta dois tipos de origem de dados:  

  
+ Análise Avançada, que permite selecionar uma análise avançada existente, permitindo configurar no assistente a análise multidimensional (dimensões e medidas) com base nesta origem de dados;
  
+ Tabela.

  
  
Ao aceder ao ecrã de "Análise de utilizador" tem ao seu dispor o botão "Multidimensional" que permite aceder ao ecrã de "Análises Multidimensionais".  
No separador "Ecrã", do ecrã "Análise de utilizador", tem a caixa de seleção "No ecrã executa a análise multidimensional (se tiver uma associada)". Caso essa opção seja ativada, ao clicar no botão "Multidimensional", é executada a análise multidimensional, caso o utilizador tenha permissões para executar análises multidimensionais.  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Parâmetros de ecrã**   
A partir da v21, poderá associar a um ecrã os parâmetros do utilizador e os parâmetros da aplicação, através do qual pode consultar e alterar de forma direta.  
No ecrã "Parâmetros do Utilizador", separador "Outros dados", poderá encontrar o campo sobre o "Ecrã relacionado ao parâmetro" onde poderá selecionar o ecrã onde pretende que apareça e possa selecionar diretamente. Assim como, no ecrã "Parâmetros", ao selecionar um parâmetro, tem disponível o separador "Ecrã" com o mesmo campo e com a mesma funcionalidade.  
Ao aceder ao ecrã selecionado, irá encontrar, na barra superior, o botão "Parâmetros deste ecrã", através do qual os parâmetros associados ao ecrã.  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.
  
  
  

**Nome de IDU contextualizado quando se exporta para ficheiro**   
A partir da v21, o nome para o ficheiro exportado das impressões de utilizador (IDU) passa a ser contextualizado variando de acordo com o registo impresso.  
Na gama Advanced, no ecrã de Desenho de IDU, passa a estar disponível a [opção](ConfiguraroDesenhodaImpressão.htm#PLRContADV) **Nome dinâmico** associado ao campo **Nome para ficheiro**. Ao ativar esta opção, o utilizador pode prever o nome que irá ficar o ficheiro produzido.   
Na gama Enterprise, no ecrã de Desenho de IDU, passa a estar disponível a [opção](ConfiguraroDesenhodaImpressão.htm#PLRContENT) **Expressão Xbase** associado ao campo **Nome para ficheiro**. Quando ativa esta opção, a aplicação preenche automaticamente o campo **Nome para ficheiro** com uma expressão que pode ser editada.   
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Melhorias nos gráficos dos dashboards**  
De forma a otimizar o uso do objeto de gráficos (foxchart), que pode ser associado no Painel de Informação, bem como na personalização do ecrã, a partir da v23, foram adicionadas propriedades e um método que vai permitir aplicar personalizações ao gráfico. Esta funcionalidade está disponível nas gamas Advanced ou Enterprise e apenas se for subscritor do PHC On, mediante a ativação do parâmetro "Apresenta gráficos modernos (Tem que reiniciar a aplicação)".  
As propriedades criadas podem ser divididas em dois grupos, o grupo de propriedades, que vão permitir alterar definições associadas ao tipo letra, e o grupo de legendas que vão permitir alterar as definições associadas as legendas.  
De forma a permitir uma maior liberdade, foi criado um método onde poderá criar código xBase e definir as propriedades que pretende que sejam aplicadas ao gráfico. A designação do método é "Evento após criar Gráfico". Neste método, terá acesso a três parâmetros: "Referência ao Ecrã", Referência ao Objeto" (gráfico) e "Referência aos MeusDados", que neste caso é o cursor que está associado ao gráfico, definido na propriedade "Expressão TSQL".
  
  
  
**PHC CS Gestão desktop**  

  
**Reporte Estatístico de Operações e Posições com o Exterior ao Banco de Portugal**  
Esta funcionalidade apenas se encontra disponível a partir da versão 14.2, se possuir o PHC On ativo e o módulo PHC CS Gestão desktop. Esta opção permitir produzir o [ficheiro mensal de reporte das operações e posições com o exterior](funcionamentodoficheirodacope.htm) para submeter no site do Banco de Portugal.  
  
  
**Comunicação de Inventários de Existências à AT**  
Esta funcionalidade apenas se encontra disponível a partir da versão 16 e com o PHC On ativo. Esta opção permitir produzir o [ficheiro anual de comunicação de inventários](comunicaçãodeinventáriodeexistênciasàat.htm) à AT.  
  
  
**Promoções com possibilidade de escolha de "todos os artigos" e "tipo de artigo"**  
De forma a aumentar o leque de opções na definição de promoções, foram criadas duas novas opções no ecrã "[Promoções](constituiçãodatabeladepromoções(layoutmoderno).htm)": "Todos os artigos" e "Apenas para os artigos do tipo \_\_". A primeira permite aplicar a promoção a todos os artigos, sem distinção. Já a segunda, possibilita associar os dados da promoção apenas aos artigos com determinado tipo de desconto - campo disponível no ecrã "Stocks e serviços" com o nome "Tipo para descontos". Funcionalidade disponível para as gamas Advanced e Enterprise, a partir da versão 17.  
  
  
**Monitor de Promoções e Descontos**  
Este [Monitor](monitordepromoçõesedescontos.htm) concentra num só ecrã todas as promoções, descontos e tabelas de preços, quer atribuídas pela empresa a Clientes, quer atribuídas à empresa pelos seus Fornecedores. A partir do Monitor é possível, sem ter de abrir e fechar vários ecrãs, navegar para consultar cada informação, verificar promoções ativas, inserir novos descontos, etc.  
Esta funcionalidade está disponível a partir da versão 17 para as gamas Advanced e Enterprise.  
  
  
**Envio de SMS com código de documento de transporte para o motorista**  
Esta funcionalidade encontra-se disponível a partir da versão 17 se possuir a gama Enterprise, o PHC On ativo e os módulos PHC CS Gestão desktop e PHC CS SMS desktop e permite enviar (ou gravar em standby) um SMS para o telemóvel do motorista com o código de identificação do documento de transporte quer o documento criado seja um [documento de faturação](ConfiguraçãoDeDocumentosDeFaturação.htm#camenviasms) ou um [dossier interno](ConfiguraçãoDeDossiers.htm#camenviasmsbo).  
  
  
**Os artigos não inventariados ficam com stock a 0 (zero)**  
Quando esta opção está ativa, a aplicação introduz linhas no inventário que ainda não existem, mas que existem nas seguintes tabelas de Stock por armazém, mesmo que tenham [stock 0 (zero)](ConstituiçãodeInventárioFísico.htm#mch stock2):  

  
+ Stock por armazém (tabela sa),
  
+ Stock por lote/armazém (tabela sal),
  
+ Stock por cor e tamanho (tabela sx).

  
  
Para esses artigos, o stock é preenchido com o valor 0 (zero) na linha do inventário. Desta forma, permite colocar o stock a 0 (zero) para os restantes artigos existentes nos armazéns e que não foram introduzidos pelo utilizador, exceto para os artigos do tipo serviço ou que tenham stock 0 para o armazém identificado nas linhas do inventário.  
  
  
**Detalhe do tipo de artigo na análise de Inventários de Stocks**  
A partir da versão 18, encontra-se disponível nas três gamas: Corporate, Advanced e Enterprise, exclusivamente para quem tenha PHC ON ativo, esta funcionalidade, que permite detalhar na análise de **Inventários de Stocks** o tipo de artigo que se pretende visualizar, conjuntamente com outros critérios, dando melhor rigor nas análises dos produtos existentes e a sua classificação que será importante ter corretamente configurada porque irá influenciar a informação transmitida à Autoridade Tributária ao fazer a **Comunicação de Inventários à AT**.  
No tópico [Inventários de Stocks](inventáriosdestocks.htm) poderá encontrar mais informação acerca desta funcionalidade.  
  
  
 **Monitor de Relatório de Crédito**   
Esta funcionalidade encontra-se disponível a partir da versão 18 nas gamas Advanced e Enterprise caso possua o PHC On ativo e o módulo PHC CS Gestão desktop e ou PHC CS CRM desktop e permite as empresas importar Relatórios de Crédito da Ignios para a aplicação. Estes Relatórios permitem Relatórios de Crédito   
  
  
 **Monitorização pela Ignios**  
Esta funcionalidade encontra-se disponível a partir da versão 18 nas gamas Advanced e Enterprise caso possua o PHC On ativo e o módulo PHC CS Gestão desktop e ou PHC CS CRM desktop e permite as empresas manter-se informada sobre alterações de situações de risco ou oportunidades dos seus [Clientes](ConstituiçãodaTabeladeClientes.htm#tgr ignios4); [Fornecedores](ConstituiçãodaTabeladeFornecedores.htm#tgr ignios4); [Cliente Potencial](ConstituiçãodaTabeladeClientesPotenciais.htm#tgr ignios4); [Contactos](ConstituiçãodaTabeladeContactos.htm#tgr ignios4) e [Entidades](ConstituiçãodaTabeladeEntidades.htm#tgr ignios4).  
  
  
**É um programa em Xbase** (Apenas disponível no executável do Peru)  
Esta funcionalidade encontra-se disponível a partir da versão 18 no módulo PHC CS Gestão desktop, na gama Enterprise e caso possua o PHC On ativo e permite indicar um programa em xbase que irá definir o nome do livro eletrónico.  
  
*Nota:* Para mais informações sobre os Livros Eletrónicos, consulte por favor o tópico "Configuração de Livros Eletrónicos".  
  
  
**Pesquisa de documentos por códigos de barras**  
A partir da v20, com o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise, e com a subscrição de PHC On ativa, passa a estar disponível um botão de pesquisa por Códigos de Barras nos ecrãs "Faturação a Clientes", "Emissão de Recibo de Adiantamentos para Clientes" e "Dossiers Internos". Esta pesquisa poderá ser feita através de inserção manual ou utilizando o leitor de códigos de barras.   
  
  
**Pesquisa por código de barras de documentos de faturação a regularizar**   
A partir da v20, com o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise, e com a subscrição de PHC On ativa, passa a ser possível a regularização de documentos de faturação através do botão de código de barras que vai permite a inserção na grelha o respetivo adiantamento pelo código de barras.  
  
  
**Pesquisa por código de barras de cópias de linhas de Dossier**   
A partir da v20, com o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise, e com a subscrição de PHC On ativa, passa a ser possível pesquisar uma série de Dossiers Internos a partir do ecrã "Cópia de Dossier" pelo seu código de barras ficando automaticamente selecionada para copiar o registo.  
  
  
**Pesquisa de código de barras em qualquer série**  
A partir da v22, nas gamas Advanced e Enterprise passa a ser possível pesquisar documentos em todas as séries existentes nos ecrãs "Cópia de documentos de faturação" e "Cópia de dossiers internos". Ao encontrar o documento, a aplicação seleciona-o na listagem de documentos existentes.  
  
Para que seja possível a pesquisa de documentos em todas as séries, a criação do código de barras é composta por:  

  
+ Prefixo - constituído por quatro carateres, sendo que o primeiro é referente ao documento (1- documentos de faturação; 2 - recibos de adiantamento para clientes; 3 - dossiers internos) e os restantes 3 para a série do documento;
  
+ Ano - constituído apenas pelos dois dígitos do ano, por exemplo, para o ano 2017, os números a entrar para o código de barras serão 17);
  
+ Número do documento - constituído por nove carateres, é o número atribuído automaticamente ao documento.

  
  
  
**Acessos de Recibos de Clientes**  
Esta funcionalidade só disponível a partir da gama Advanced e só com PHC ON ativo, dá a possibilidade de retirar e dar acessos de apagar, consultar editar entre outras opções, por tipo de séries de recibos de c/c para clientes.   
Com esta funcionalidade os utilizadores passam a ter acessos por utilizadores ou grupos de utilizadores para aumentar a produtividade e privacidade no software.  
  
**Descontos por Tipo de Artigo/ Tipo de Fornecedor**  
A partir da v21, nas gamas Advanced e Enterprise e com a subscrição de PHC On ativa, passa a estar disponível o ecrã "Descontos por Tipo de Artigo/ Tipo de Fornecedor" que permite que sejam definidos os descontos associados a um tipo de artigo e tipo de fornecedor.  
  
Nota: Para mais informações consulte o tópico "Descontos por Tipo de Artigo/ Tipo de Fornecedor".   
  
  
**Condição XBASE no ecrã de Promoções**  
A partir da versão 21, no ecrã de "Promoções" está disponível o [campo](ConstituiçãoDaTabelaDePromoções(layoutmoderno).htm#PLRcondicao) **Condição XBASE para aplicar esta promoção** quando o [parâmetro](ParâmetrosDeFaturação.htm#PLRpromocao) **Usa o ecrã de promoções clássico (versão 18)** está inativo e se possuir o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise. As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo.  
  
  
**Tipo de Promoção XBASE no ecrã de Promoções**  
A partir da versão 21, no ecrã de "Promoções", no tipo de promoção a aplicar, está disponível a [opção](ConstituiçãoDaTabelaDePromoções(layoutmoderno).htm#PLRXBASE) **XBASE** quando o [parâmetro](ParâmetrosDeFaturação.htm#PLRpromocao) **Usa o ecrã de promoções clássico (versão 18)** está inativo e se possuir o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise. As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo.  
A opção **é um programa em XBASE** deve estar ativa quando a condição xbase definida no campo **XBASE** é um programa e está disponível com o módulo PHC CS Gestão desktop, nas gamas Advanced e Enterprise, sendo que a promoção é aplicada se tiver na gama Advanced com PHC On ativo ou na gama Enterprise com e sem PHC On ativo.  
  
  
**Tabela de Descontos por tipo de artigo/tipo de fornecedor**  
A partir da v21, tem a possibilidade de definir descontos associados a um tipo de artigo e tipo de fornecedor, a partir do ecrã "Descontos por Tipo de Artigo/Tipo de Fornecedor" ou através do ecrã "Fornecedor", menu de opções diversas.   
Acedendo ao ecrã "Descontos por tipo de artigo/tipo de fornecedor" pode definir descontos associados a um tipo de artigo e a um tipo de Fornecedor.   
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Acessos do utilizador para cada série de recibos para clientes**   
A partir da v21, pode associar novos acessos ao utilizador associado a uma série de recibos para clientes, por exemplo, para controlar as séries disponíveis no ecrã "Recibos a Clientes".  
Também é possível definir se a série tem acesso aos IDUs, desenhar, imprimir, eliminar etc..  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Parâmetro de IDU para assumir por defeito a 2ª via se o documento já foi impresso**   
A partir da v21, quando reimprime um documento a aplicação seleciona automaticamente a opção "2ª Via".   
Para isso, deverá ativar o parâmetro "Ao imprimir assume por defeito a 2ª via se o documento já foi impresso", no nó "I.D.U. Impressões Definidas pelo Utilizador".  
Este comportamento só é válido para documentos impressos através do botão "Imprimir" do ecrã "Impressão do IDU (Faturação)", proveniente dos ecrãs Faturação (FT), Dossiers Internos (BO) e Recibos (RE).  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Livro 3.10 Inventarios y Balances - Detalle del Saldo de la Cuenta 40 - tributos por pagar** (apenas disponível no executável do Peru)   
A partir da versão 21, se tiver o PHC CS Gestão desktop, PHC CS Contabilidade desktop e PHC On pode produzir o livro " Detalle del Saldo de la Cuenta 40 - tributos por pagar" formato "Hojas Sueltas" ao abrigo do Resolução de Superintendência N° 361-2015/SUNAT. Este livro consiste numa lista de saldos da conta 40 do livro maior, que se criaram depois da preparação dos documentos contabilísticos do livro diário a valores históricos.   
  
  
**Livro 3.2 Inventarios y Balances - Saldo de la cuenta 10 - Caja y Banco** (apenas disponível no executável do Peru)   
A partir da versão 21, se tiver o PHC CS Gestão desktop, PHC CS Contabilidade desktop e PHC On pode produzir o livro "Saldo de la cuenta 10 - Caja y Banco" formato "Hojas Sueltas" ao abrigo do Resolução de Superintendência N° 361-2015/SUNAT. Este livro consiste numa lista de saldos da conta 10 do livro maior, que se criaram depois da preparação dos documentos contabilísticos do livro diário a valores históricos.   
  
  
**Ordenação dos resultados da Agenda de dívidas de clientes pelo número de cliente**   
A partir da v21 com o PHC CS Gestão desktop, passa a poder ordenar os resultados da análise "Agenda de dívidas de clientes" pelo número de cliente. Ao ativar a opção **ordenar por número do cliente** a listagem é ordenada pelo número de cliente, ficando assim definida nas seguintes vezes que aceder a esta análise.  
  
**Ordenação dos resultados da Agenda de dívidas a fornecedores pelo número do fornecedor**    
A partir da v21 com o PHC CS Gestão desktop, passa a poder ordenar os resultados da análise "Agenda de dívidas de fornecedores" pelo número de cliente. Ao ativar a opção **ordenar por número do fornecedor** a listagem é ordenada pelo número de fornecedor, ficando assim definida nas seguintes vezes que aceder a esta análise.  
  
  
**MAPA G50** (apenas disponível no executável de Argélia)  
  
A partir da v21 com o PHC CS Gestão desktop nas gamas Advanced e Enterprise, passa a ser possível produzir o Mapa G50 que reporta vários tipos de impostos que as empresas têm de entregar na Argélia:  

  
+ Taxe sur l'activité professionnelle
  
+ Acomptes IBS
  
+ IRG salaires et autres retenues à la source IRG / IBS
  
+ Droit de timbre sur état
  
+ Impôts et taxes non repris ci-dessus
  
+ TVA

  
  
  
**Suministro Inmediato de Información - Monitor de comunicação SII (via webservice)**  (apenas disponível no executável de Espanha)  
O Real Decreto 596/2016 de 02 de dezembro, publicado pelo Boletim oficial do Estado, trouxe consigo um novo mecanismo de forma a controlar e prevenir a fraude fiscal, o SII - Suministro Inmediato de Información.  
  
O SII é um novo sistema de gestão do IVA no qual as empresas devem proceder à comunicação online de faturas de vendas e de compras.   
Neste novo sistema são reportados à Agência Tributária de forma eletrónica os seguintes livros:   

  
+ Libro registro de facturas expedidas.
  
+ Libro registro de facturas recibidas.
  
+ Libro registro de bienes de inversión.
  
+ Libro registro de determinadas operaciones intracomunitarias.

  
Esta informação é enviada de forma eletrónica por XML via Webservice da AEAT, pelo que é necessário um certificado digital a fim de comunicar as faturas.  
  
Livros suportados pelo PHC CS Desktop:  

  
+ Libro registro de facturas expedidas;
  
+ Libro registro de facturas recibidas;
  
+ Libro registro de determinadas operaciones intracomunitarias;

  
  
Modalidades suportadas pelo PHC CS Desktop:  
  
Faturas de Venda:   

  
+ 01 Operación de régimen común;
  
+ 02 Exportación;
  
+ 03 Operaciones a las que se aplique el régimen especial de bienes usados, objetos de arte, antigüedades y objetos de colección (135-139 LIVA);
  
+ 04 Régimen especial oro de inversión - 05 Régimen especial agencias de viajes;
  
+ 06 Régimen especial grupo de entidades en IVA (nivel avanzado).

  
  
Faturas de Compra:   

  
+ 01 Operación de régimen común
+ 03 Operaciones a las que se aplique el régimen especial de bienes usados, objetos de arte, antigüedades y objetos de colección (135-139 LIVA);
  
+ 04 Régimen especial oro de inversión;
  
+ 05 Régimen especial agencias de viajes;
  
+ 06 Régimen especial grupo de entidades en IVA (nivel avanzado);
  
+ 09 Adquisiciones intracomunitarias de bienes y prestaciones de servicios.

  
  
  
**Assistente de importação a partir do ficheiro SAF-T (PT)**  
A partir da v22, passa a existir o Assistente de Importação do SAF-T (PT) que permite importar clientes, artigos, contas, importação de documentos de vendas a partir de um ficheiro SAF-T (PT) de qualquer aplicação. Através deste assistente pode também efetuar a importação de um ficheiro de SAF-T (PT) de Autofaturação rápida e facilmente.   
Em situações de migração de outros softwares, aquisição de uma empresa ou mesmo em casos de fusão de empresas, através deste assistente será possível a importação dos clientes, fornecedores, artigos, plano de contas e de documentos de faturação tudo a partir de um ficheiro SAF-T (PT) gerado de qualquer aplicação, tornando assim a passagem desta informação um processo ágil e descomplicado.  
Os gabinetes de contabilidade, através dos módulos PHC CS Gestão desktop e modulo PHC CS Contabilidade desktop irão ter a possibilidade de importar os documentos de venda dos seus clientes e registar diretamente na contabilidade essa informação num processo simples e imediato.  
Este assistente permite também a importação de um ficheiro de SAF-T (PT) de autofaturação para empresas de prestação de serviços em regime de autofaturação.  
  
  
**Gestão de títulos de tesouraria emitidos a fornecedores**   
A partir da v22, nas gamas Advanced e Enterprise, a partir do ecrã "Títulos emitidos" passa a ser possível definir o fornecedor, o número do título, local de tesouraria, data de emissão e de vencimento, assim como o respetivo valor. No separador "Movimentos" é possível consultar o histórico da alteração de estados, assim como é possível navegar para o título que substituiu o registo atual.   
Tem três operações possíveis neste ecrã, sendo elas:  

  
+ Quando o registo se encontra no estado "Emitido" são possíveis as operações: "Liquidar", "Cancelar", "Substituir";
  
+ Quando o registo se encontra no estado "Anulado" não é possível qualquer operação;
  
+ Quando o registo se encontra no estado "Substituído" não é possível qualquer operação;
  
Por forma a criar a gestão de títulos de tesouraria emitidos a fornecedores, passa a ser também possível associar títulos emitidos nos seguintes documentos:   
+ "Compras";
  
+ "Adiantamentos a fornecedor"; e
  
+ "Pagamentos".

  
  
  
**Gestão de tesouraria previsional com movimentos confirmados**   
A partir da v22, nas gamas Advanced e Enterprise, passa a ser possível identificar os movimentos que são confiáveis (boa cobrança). No ecrã "Códigos de Movimento de Conta Corrente" passa a ter o campo "Na previsão de tesouraria estes movimentos são por defeito considerados como movimentos confirmados" que identifica se o registo vai ser de pagamento confirmado. Passa a ter também o campo "Na previsão de tesouraria estes movimentos são por defeito considerado como confirmado" que identifica se o registo é de movimento confirmado.   
  
  
**Alterar o saldo inicial no "Monitor de Gestão Previsional de Tesouraria" e na "Simulação de Saldos de Contas"**   
A partir da v22, nas gamas Advanced e Enterprise, tem a possibilidade de alterar o saldo inicial das contas de tesouraria nos ecrãs "Simulação de Saldos de Contas" e "Monitor de Gestão Previsional de Tesouraria".  
  
  
**Melhoramentos das ferramentas de previsão de tesouraria**  
As funcionalidades referentes à previsão de tesouraria foram alvo de melhorias na v23 de forma a torná-la, cada vez mais, eficiente.  
As melhorias estão dependentes da subscrição do PHC On e pode encontrá-las nos seguintes locais da aplicação:  
  
- No ecrã "Parâmetros", ao ativar o parâmetro "Títulos de Tesouraria geram previsões de tesouraria automáticas", o parâmetro "Não usa previsões de tesouraria automáticas" é desativado, e vice-versa.  
- Nos ecrãs "Recibos de c/c de clientes" e "pagamentos a fornecedores" foi criado o campo "Nº de Cheque" para ser utilizado na impressão dos recibos de clientes e pagamentos de fornecedores, respetivamente.  
- No ecrã de "Simulação de saldos de Contas" passa a poder pesquisar registos através do campo "Pesquisa". Além disso, foi adicionada a coluna "Nº Títulos" ao ecrã.  
- Foi criada a coluna "Título de tesouraria" onde passam a ser apresentados os diferentes títulos associados aos pagamentos ou recibos. O nome da coluna pode ser alterado nos parâmetros "Palavra no plural para Título de tesouraria" nos nós "Clientes" e "Fornecedores".  
- No Monitor de tesouraria foram criadas duas colunas: "Nº de documento" e "Nº Títulos".  
- No ecrã "Monitor Gestão Previsional de Tesouraria" foram adicionadas duas novas colunas, uma associada ao número do documento (igual a coluna que já existia no ecrã de simulação de tesouraria) e outra associada aos diferentes títulos, referentes a pagamentos ou recibos (idêntica a nova coluna criada no ecrã de simulação de saldos).  
  
  
**Rastreabilidade das cobranças via banco a partir do histórico de c/c** (apenas disponível no executável de Espanha)   
A partir da v22, ao aceder ao ecrã "Histórico de operações de c/c" poderá ter indicação do número da cobrança associado ao registo no campo "Cobrança", bem como também filtrar pelo número da cobrança. Ao fazer duplo clique no campo "Cobrança" navegará para o respetivo registo de cobrança.  
  
  
**Possibilidade de ver valores com e sem IRPF nos Clientes** (apenas disponível no executável de Espanha)   
A partir da v22, nas gamas Advanced e Enterprise, para que seja possível ter uma taxa personalizada por cada cliente e situação, no ecrã de "Clientes", passa a existir dois novos campos com o seguinte comportamento:  

  
+ Caso o cliente tenha retenção na fonte, é necessário ativar a opção "Retém IRPF à taxa";
  
+ Se isso não se verificar, é necessário ativar a opção "Não retém IRPF".

  
  
Assim, ao faturar um documento passa a ser possível saber o valor a pagar ao cliente com e sem IRPF, acedendo pelo botão "Totais".  
  
  
**Opção "Condições de Pagamento" na Emissão Automática de Faturação** (apenas disponível no executável de Espanha)   
A partir da v22, nas gamas Advanced e Enterprise, ao aceder à "Emissão Automática de Faturação", na opção "agrupado por cliente", passa a existir a possibilidade de emitir documentos utilizando a opção "Condição de pagamento". Ao emitir faturas, agrupa os documentos por cliente, separando-os conforme a condição definida, no caso "condição de pagamento".  
  
Caso tenha uma fatura com condições de pagamento de multipagamento e, no separador "Outros Dados" do ecrã de "Dossiers Internos", clicar no botão "Faturar este Documento", a nova fatura fica com a opção "Multipagamento" ativa.  
  
**Painel Central disponível na gama Corporate** (apenas disponível no executável de Espanha)  
A partir da v23, o Painel Central está agora também disponível na gama Corporate e se for subscritor do PHC On. Desta forma, poderá associar atalhos de ecrãs, em modo de consulta ou em modo de introdução, ao Painel Central.  
  
  
**Impressão dos extratos de c/c e de doc. não regularizados para vários clientes**  
A partir da v23, com o módulo PHC CS Gestão desktop e se for subscritor do PHC On, tem a possibilidade de imprimir extratos de conta-corrente ou extratos de documentos não regularizados para vários clientes com apenas um clique.  
Nos ecrãs Extrato de conta corrente e Extrato de Documentos não regularizados passa a existir a opção Apenas para o cliente selecionado e o campo para filtrar dados, que permite definir o filtro de clientes para imprimir de uma vez só.   
  
  
**Dossiers internos da mesma série em "rascunho"**  
A partir da v23, no PHC CS Gestão desktop, nas gamas Advanced e Enterprise e se for subscritor do PHC On, tem a possibilidade de criar registos de dossiers internos em rascunho com base em séries certificadas.  
  
  
**Emitir pagamentos a fornecedores desde o ecrã "Compras"**  
Para agilizar o processo de regularização de documentos de compra no PHC CS Contabilidade desktop, a partir da v23, tem a possibilidade de emitir pagamentos a fornecedores a partir do ecrã "Compras".  
No ecrã de "Compras" foi adicionado o botão "Emitir Pagamento" que permite emitir um pagamento de um documento de compra.   
  
  
**e-GAR: Monitor de gestão e comunicação de guias de resíduos** (apenas disponível no executável de Portugal)  
A Portaria n.º 145/2017, de 26 de abril, aprovou as regras aplicáveis ao transporte rodoviário, ferroviário, fluvial, marítimo e aéreo de resíduos em território nacional e cria as guias eletrónicas de acompanhamento de resíduos (e-GAR), a emitir no Sistema Integrado de Registo Eletrónico de Resíduos (SIRER), disponível na plataforma eletrónica da Agência Portuguesa do Ambiente, I. P. (APA, I. P.).   
A Guia Eletrónica de Acompanhamento de Resíduos (e-GAR) substitui os atuais impressos em papel n.º 1428 e 1429 da Imprensa Nacional-Casa da Moeda (INCM) e as Guias de Acompanhamento de Resíduos de Construção e Demolição e que permite a integração, de forma automática, dos dados anuais no Mapa Integrado de Registo de Resíduos (MIRR) e do Registo de Emissões e Transferências de Poluentes (PRTR).  
Nos módulos PHC CS Gestão desktop e PHC CS Documentos Eletrónicos desktop, e se for subscritor do PHC On, tem a possibilidade de comunicar as guias eletrónicas de acompanhamento de resíduos (e-GAR) via webservice entre o PHC CS e SILiAmb.  
O PHC CS, como software certificado pela A.P.A., passa a dispor de um conjunto de parâmetros e funcionalidades para a emissão, acompanhamento e receção das guias e-GAR, quer seja emitir uma guia, corrigir, confirmar, anular ou autorizar, entre outras opções.
  
  
  
  
**PHC CS Contabilidade desktop**  
  

  
**Importação de Mapas de Gestão via Webservice**  
Esta funcionalidade apenas se encontra disponível se possuir o PHC On ativo e o módulo PHC CS Contabilidade desktop. Em qualquer altura pode atualizar, de forma automática, os Mapas de Gestão via Webservice.  
  
  
**Simplificação da criação e edição de Mapas de Gestão**  
A partir da v20, com o módulo PHC CS Contabilidade desktop e subscrição do PHC On ativa, passa a estar disponível, no ecrã "Edição de IDU" dos Mapas de Gestão, o novo separador "Configuração", com a seguintes opções:  

  
+ Uma área de grupos e subgrupos através de um esquema em árvore de modo a permitir a edição dos mapas à semelhança dos quadros dos modelos oficiais que se pretendem reproduzir no sistema;
  
+ Uma grelha onde se editam os campos de cada subgrupo;
  
+ Acesso direto através do botão "Função" ao ecrã "Edição de fórmulas";
  
+ Associação de fórmulas de IVA para Mapas de Gestão através do botão "Imposto"
  
+ Preenchimento automático do "Campo", "Nome", "Grupo" e "Subgrupo ao gravar as alterações efetuadas no ecrã "Edição de fórmulas";
  
+ Eliminação automática do "Campo", "Nome", "Grupo" e "Subgrupo" ao desassociar uma fórmula de um campo no ecrã "Edição de fórmulas"

  
*Nota:* Esta funcionalidade só está disponível no executável de Espanha e Peru.  
  
  
**Configuração do Livro Diário Eletrónico**  
A partir da v20 com os módulos PHC CS Gestão desktop e PHC CS Contabilidade desktop e com a subscrição do PHC On ativa, passa a ser possível registar por ordem cronológica todas as operações e acontecimentos mercantis que são efetuadas na empresa, de acordo com a Resolução de Superintendência N° 361-2015/SUNAT.  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Configuração do Registo de Compras em Suporte Informático 8.1 e 8.3**   
A partir da v20 com o módulo PHC CS Gestão desktop e com subscrição do PHC On ativa, passa a estar disponível o Registo de Compras, de acordo com a Resolução de Superintendência N° 361-2015/SUNAT, para os contribuintes do regime geral ou regime especial de renda, com volume de faturação igual ou superior a 75 UIT durante o ano 2015. Este livro auxiliar obrigatório de caráter fiscal permite preencher as aquisições de bens e serviços que a empresa efetua.  
  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Configuração do Registo de Vendas em Suporte Informático**  
A partir da v20 com o módulo PHC CS Gestão desktop e com subscrição do PHC On ativa, passa a estar disponível o Registo de Vendas e Ingressos, de acordo a Resolução de Superintendência N° 361-2015/SUNAT, para os contribuintes do regime geral ou regime especial de renda, com volume de faturação igual ou superior a 75 UIT durante o ano 2015. Este livro auxiliar obrigatório de caráter fiscal permite arquivar os comprovativos de pagamentos emitidos pela empresa.  
  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Criação e Impressão de IDU dos Livros em Suporte Informático**    
A partir da v20 com o módulo PHC CS Contabilidade desktop e com subscrição do PHC On ativa, passa a ser possível configurar a impressão definida pelo utilizador dos livros em suporte informático, através de código TSQL ou xBase e de acordo com os formatos legais.  
  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Configuração do Livro Maior em suporte informático**   
A partir da v20 com o módulo PHC CS Gestão desktop e com subscrição do PHC On ativa, passa a ser possível produzir o Livro Maior, de acordo a Resolução de Superintendência N° 361-2015/SUNAT. Este livro assenta na rigorosa ordem dos débitos e créditos das contas utilizadas nos documentos contabilísticos.  
  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Criação do Campo "Mapa PHC" nas Configurações dos Livros em Suporte Informático**  
A partir da v20, com o módulo PHC CS Contabilidade desktop, nas gamas Advanced e Enterprise, e com a subscrição de PHC On ativa, a PHC passou a disponibilizar livros no menu "Configuração de livros eletrónicos" de forma a providenciar livros legais para realizar melhores análises fiscais para as empresas. Embora estes livros sejam atualizados pela PHC, os utilizadores que possuírem a gama Enterprise podem duplicá-los e adaptá-los ao seu negócio.  
  
  
*Nota:* Esta funcionalidade apenas está disponível no executável do Peru.  
  
  
**Informação do documento original no descritivo da integração do documento contabilístico de recibos e pagamentos**   
A partir da v21, com o módulo PHC CS Contabilidade desktop, nas gamas Advanced e Enterprise, e com a subscrição de PHC On ativa, ao efetuar a integração para a contabilidade, passa a poder incluir a informação do documento original no descritivo dos "Recibos para Clientes" e "Pagamentos a Fornecedores".   
Quando efetuar a integração para a contabilidade dos "Recibos para Clientes" e "Pagamentos a Fornecedores", o campo **Descrição do movimento** tem a informação do documento integrado com o texto "ref. a", e a informação do documento que originou a linha do recibo.  
Esta funcionalidade também está disponível para documentos que sejam integrados automaticamente na contabilidade.  
  
  
**Integração online do Histórico de Operações de C/C com origem nas Cobranças via Banco** (apenas disponível no executável de Espanha)   
  
A partir da v22, passa a poder integrar agora automaticamente os registos do "Histórico de Operações de C/C", se tiver o parâmetro "Usa Gestão Avançada de Operações de C/C (reinstalar triggers)", com origem nas "Cobranças via Banco".   
No ecrã "Operações de C/C", separador "Contabilidade", passam a estar disponíveis os campos "Documento a ser integrado na contabilidade assim que é gravado", "Diário" e "Documento". Ao estar ativa a primeira opção, serão usados o diário e documento especificados nos restantes campos, para criar o registo nos documentos contabilísticos.   
  
No ecrã "Monitor de Integração Contabilística" passa a estar disponível a integração do "Histórico de operações de C/C". A contabilização dos registos pressupõe que, associado ao "Histórico de operações de C/C" exista uma configuração nas operações de C/C, com o formato de exportação igual do da cobrança.  
  
  
**Nível exclusivo de conta no balancete de Somas e Saldos** (apenas disponível nos executáveis de Espanha e Peru)   
A partir da versão 21 com o PHC CS Contabilidade desktop, no ecrã "Balancete de Somas e Saldos" passa a ter a opção **exclusivamente nestes dígitos** que mostra exclusivamente o número de dígitos inscritos no campo **Nº de dígitos**.   
  
  
**Inclusão de informação do documento original no descritivo da integração do documento contabilístico de recibos e pagamentos**   
A partir da versão 21, com o módulo PHC CS Contabilidade desktop nas gamas Advanced ou Enterprise, nos ecrãs "Integração de Recibos de Clientes" e "Integração de Pagamentos a Fornecedores" passa a ter a opção **Documento original no descritivo** que permite incluir informação do documento original no descritivo dos documentos contabilísticos "Recibos para Clientes" e "Pagamentos a Fornecedores", respetivamente, na integração para a contabilidade.   
Esta opção está dependente da ativação das opções **Descrimina o valor da conta de clientes pelo valor regularizado**, no caso de recibos de clientes, ou da opção **Descrimina o valor da conta de fornecedores pelo valor regularizado**, no caso de pagamentos a fornecedores, permitindo que, em ambos os documentos, conste a informação do documento integrado no campo **Descrição do movimento**, adicionando o texto "ref. a" e, por fim, a informação do documento que originou a linha do recibo.  
  
*Nota*: Esta funcionalidade não se aplica quando se efetua a integração para a contabilidade de documentos gerados em software externo. Embora esteja disponível a descrição não terá a inclusão da informação do documento que originou o recibo.  
  
  
**Visualização do saldo contabilístico da conta no ecrã "Introduzir novos documentos"**    
A partir da versão 21 com o PHC CS Contabilidade desktop, no ecrã "Introduzir novos documentos" passa a poder visualizar a informação do saldo total da conta introduzida nas linhas dos movimentos. A informação do saldo obtido é referente ao ano contabilístico atual e ao último mês com registos associados.   
Por exemplo, ao inserir um documento contabilístico referente ao mês passado, o saldo apresentado terá em conta os registos do mês atual, caso eles existam. Para poder usufruir desta funcionalidade deverá ter o acesso "Visualizar o saldo da conta na introdução" no nó "Documentos Contabilísticos" referente à Contabilidade.   
  
O saldo da conta pode ser apresentado numa das seguintes formas:  

  
Conta com saldo a crédito: "O saldo da conta XXX é de -1 000,00 euros (ref. a YYY/nnnn)"  
Conta com saldo a débito: "O saldo da conta XXX é de 1 000,00 euros (ref. a YYY/nnnn)"  
Conta com saldo nulo: "O saldo da conta XXX é de 0,00 euros (ref. a YYY/nnnn)"  
Conta sem movimentos contabilísticos: "Conta sem saldo"
  
  
  
**Emissão de Balancete por Taxonomias** (apenas disponível no executável de Portugal)  
Com a publicação da Portaria n.º 302/2016, de 02 de dezembro, foram criadas as taxonomias a utilizar no preenchimento dos respetivos campos na estrutura de dados do ficheiro SAF-T(PT).   
A pensar na necessidade do contabilista poder extrair a informação contabilística de extratos e balancetes por taxonomia e efetuar a confirmação dos dados contabilísticos que serão pré-preenchidos na submissão da IES (Informação Empresarial Simplificada), a partir da v23, tem agora disponível a análise Balancetes  Taxonomias no nó "Contabilidade", se possuir o módulo PHC CS Contabilidade desktop e for subscritor do PHC On.  
  
  
**Opção de 12 meses ou 16 meses na Contabilidade** (apenas disponível nos executáveis de Espanha e Peru)  
A partir da v23, no PHC CS Contabilidade desktop, se for subscritor do PHC On, tem a possibilidade de escolher se a sua contabilidade tem 12 ou 16 meses. Para configurar a aplicação para este período, foi criado o parâmetro "Utiliza 12 meses na contabilidade no PHC CS Desktop.   
  
**Monitor de Obrigações Declarativas**  
A partir da v23, no PHC CS Contabilidade desktop, se for subscritor do PHC On, tem disponível o novo ecrã "Obrigações declarativas para o Monitor que permite configurar o ecrã "Monitor de obrigações declarativas". No ecrã "Obrigações declarativas para o Monitor poderá definir que mapas vão estar associados ao monitor.   

  
  
  
**PHC CS Pessoal desktop**  
  

 **Importação das Tabelas de IRS via WebService PHC**  
Esta funcionalidade apenas se encontra disponível a partir da versão 17 se possuir o PHC On ativo e o módulo PHC CS Pessoal desktop. Permite a importação automática das [Tabelas de IRS](tabelasdeirs.htm) consoante a localização da empresa (Continente; Madeira e Açores), esta importação é efetuada via WebService PHC.
  
  

 **Banco de saída de subsídios de refeição em cartão**   
A partir da v21, pode associar um banco de saída diferente para as transferências do subsídio de refeição por cartão, não sendo necessário executar este processo várias vezes, isto é, o utilizador ao introduzir os dados para efetuar a transferência do vencimento poderá também configurar a transferência do subsídio de refeição, efetuando este processo uma única vez.   
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
  
**Processamento automático de remunerações em espécie - viaturas**  
A partir da v21, tem a possibilidade de [processar remunerações em espécie](processamentoderemuneraçõesemespécie-viaturas.htm), através da atribuição de viaturas a funcionários, cumprindo as obrigações legais aquando da entrega da Declaração Mensal de Remunerações à Autoridade Tributária e do ficheiro para a Segurança Social. Para que seja possível este processamento é necessário algumas configurações, começando por preencher a respetiva percentagem nos seguintes parâmetros no nó Pessoal:  

  
+ **Percentagem para cálculo do valor sujeito a IRS sobre o valor de mercado da viatura**;
  
+ **Percentagem para cálculo do valor sujeito a Segurança Social sobre o valor de aquisição da viatura**.

  
  
No ecrã "Gestão de funcionários" é necessário ativar a opção "Tem viatura atribuída" e preenchendo os campos:  

  
+ **Matrícula**;
  
+ **Valor de aquisição**;
  
+ **Valor de mercado**.

  
  
Após o processamento, através da "Emissão Automática de Recibos de Vencimento", no ecrã "Vencimentos" poderá verificar que remunerações referentes às viaturas atribuídas são incluídas automaticamente:  

  
+ Em espécie (no separador "Dados principais");
  
+ IRS Viatura(no separador "Outros dados").

  
  
No envio da Declaração Mensal de Remunerações à AT é incluído o valor do desconto para a Segurança Social, assim como o valor sujeito a IRS mas isento de retenção das viaturas - código A5. O ficheiro enviado para a Segurança Social passa a incluir o valor da remuneração sujeita a SS com o tipo "B".  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise.  
  
  
**Gestão de Penhoras e Pensões de Alimentos**   
A partir da v21, tem a possibilidade de [gerir rapidamente e facilmente Penhoras de Vencimento e de Pensões de Alimento](gestãodepenhorasepensõesdealimentos.htm) cumprindo todas as exigências legais.   
Para que seja possível, na "Ficha Completa da Empresa", o campo **Valor da pensão social do regime não contributivo** deve estar preenchido para que seja efetuado o correto cálculo do valor máximo penhorável.  
Depois, no ecrã "Penhoras de Vencimentos" preencher os seguintes campos:  

  
+ **Funcionário ao qual esta associada a penhora**;
  
+ Valor **inicial**;
  
+ **Data de início da penhora**;
  
+ Valor a penhorar **Um fator** ou **Valor fixo**;
  
+ **Para pensão de alimentos**: se a penhora esta associada a pensão de alimentos;
  
+ O campo **Observações** para detalhar outras informações.

  
  
Para efetuar a penhora através da "Emissão automática de Recibos de Vencimento" apenas será necessário ativar a opção **processar penhoras**.   
Quando produz a Declaração Mensal de Remunerações, o valor reportado à AT não inclui a penhora.  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise.  
  
  
**Pagamento do Subsídio de Refeição no "Caixa Break" - Caixa Geral de Depósitos** (apenas disponível no executável de Portugal)  
O banco Caixa Geral de Depósitos tem o formato Break CGD para o pagamento de subsídio de refeição em cartão.   
  
A partir da v23, no PHC CS Pessoal desktop, nas gamas Advanced e Enterprise, e se for subscritor do PHC On, acedendo ao ecrã "Transferência Bancária", ao clicar no botão "Novo" será apresentado o ecrã "Processamento de transferência bancária", onde associado ao campo "Formato de exportação sub. Refeição", tem a opção "Break CGD" que possibilita a criação do ficheiro com os dados referentes ao pagamento do subsídio de refeição para o cartão associado à Caixa Geral de Depósitos.   
  
  
  
  
**PHC CS Recursos Humanos desktop**  
  

  
**Estado da candidatura no ecrã "Seleções de Recrutamento"**   
A partir da versão 22, nas gamas Advanced e Enterprise, no ecrã "Seleções de Recrutamento passa a ser possível saber qual o estado da candidatura através do campo com a mesma designação, além disso, poderá adicionar novos estados, assim como, selecionar estados já existentes.   

  
  
**PHC CS CRM desktop**  
  

  
**Envio de campanhas através do MailChimp**  
Esta funcionalidade encontra-se disponível a partir da versão 17 nas gamas Advanced e Enterprise com o módulo PHC CS CRM desktop e caso possua o PHC On ativo e permite enviar campanhas através da ferramenta [MailChimp](configuraçãoeenviodecampanhasatravésdomailchimp.htm).  
  
  
**Importar Ficheiro XML da Ignios**  
Esta opção permite ao utilizador a importação de uma Base de Dados de contactos inseridos num ficheiro XML. Esta funcionalidade está dependente da interação com a empresa [Ignios](http://www.ignios.pt/).   
*Nota:* A PHC não se responsabiliza pelos dados fornecidos no [ficheiro XML da Ignios](OpçõesDisponíveisnoMenudeContactos.htm#mch ignios4).
  
  
  
  
**PHC CS Equipa desktop**  
  

  
**Precedências de tarefas**  
Esta funcionalidade apenas se encontra disponível se possuir o PHC On ativo e o módulo PHC CS Equipa desktop v17.   
Através desta funcionalidade poderá criar tarefas com precedências, possibilitando assim a sua interligação no ecrã de  [Planeamento](planeamentodetarefas.htm) e no ecrã de [Tarefas](ConstituiçãodaTabeladeTarefas.htm#mch prece). As precedências encontram-se visíveis em ambos os ecrãs, mas no ecrã de "Planeamento" é possível ver visualizar as setas de ligação entre tarefas.  
 *Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise.  
  
  
**Registo de Tratamento de Dados no Equipa**  
A partir da v22, nas gamas Advanced e Enterprise, passa a poder ter um maior controlo dos seus processos de tratamento de dados bem como a capacidade analítica dos dados tratados. Assim, se tiver o parâmetro "Suporta Registo de Tratamento de Dados no Equipa" e ativar a opção "Registo de tratamento de dado" na configuração de um projeto, pode, posteriormente, aceder ao ecrã "Tabelas com Registo de Tratamento de Dados" e identificar as tabelas que devem fazer o registo de tratamento de dados, bem como, definir o tipo de acesso necessário para a consulta de registos na referida tabela. Desta forma, sempre que um registo daquela tabela é acedido, pode identificar o motivo pelo qual acedeu. No Monitor do Registo de Tratamento de dados pode verificar todos os registos efetuados nas tabelas que configurou para fazer o registo de tratamento de dados.  

  
  
  
**PHC CS POS desktop**  
  

  
**Ligação ao Dropbox**  
A ligação ao Dropbox foi desenvolvida para permitir aos utilizadores do software PHC alojarem ficheiros fora da aplicação de forma mais cómoda, rápida, segura e económica, evitando sobrecarregar as bases de dados.  
  
Esta funcionalidade, disponível para utilizadores com subscrição PHC On válida, possibilita:  
- proceder a importação e/ou exportação de ficheiros entre Sede e Lojas (para utilizadores dos módulos de PHC CS POS desktop - disponível a partir da versão 16)  
- gerir [anexos](pastadeanexos.htm) do módulo PHC CS Documentos desktop (nas gamas Advanced e Enterprise - a partir da versão 17).  
  
  
**Condição XBASE no ecrã de Promoções**  
A partir da versão 19, no ecrã de "Promoções" está disponível o [campo](ConstituiçãoDaTabelaDePromoções(layoutmoderno).htm#PLRcondicao) **Condição XBASE para aplicar esta promoção (apenas para POS)** quando o [parâmetro](ParâmetrosDeFaturação.htm#PLRpromocao) **Usa o ecrã de promoções clássico (versão 18)** está inativo e se possuir o módulo PHC CS POS desktop, nas gamas Advanced e Enterprise. As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo.  
  
  
**Promoções - Gestão de Prioridades**  
Com a [Gestão de Prioridades nas Promoções](Promoções-GestãodePrioridades.htm#RCPrioGest), o utilizador pode definir, entre várias Promoções em vigor no mesmo intervalo de datas, qual a sequência de prioridade com que serão aplicadas, arrastando o registo para a posição pretendida.  
Esta funcionalidade está disponível a partir da versão 18 para as gamas Advanced e Enterprise.  
  
  
**Tipo de Promoção XBASE no ecrã de Promoções**  
A partir da versão 19, no ecrã de "Promoções", no tipo de promoção a aplicar, está disponível a [opção](ConstituiçãoDaTabelaDePromoções(layoutmoderno).htm#PLRXBASE) **XBASE (apenas para POS)** quando o [parâmetro](ParâmetrosDeFaturação.htm#PLRpromocao) **Usa o ecrã de promoções clássico (versão 18)** está inativo e se possuir o módulo PHC CS POS desktop, nas gamas Advanced e Enterprise. As promoções que tiverem este campo preenchido, apenas serão aplicadas na gama Advanced com PHC On ativo e na gama Enterprise com e sem PHC On ativo.  
A opção **é um programa em XBASE** deve estar ativa quando a condição xbase definida no campo **XBASE (apenas para POS)** é um programa e está disponível com o módulo PHC CS POS desktop, nas gamas Advanced e Enterprise, sendo que a promoção é aplicada se tiver na gama Advanced com PHC On ativo ou na gama Enterprise com e sem PHC On ativo.  
  
  
  
**Preço Fixo por Quantidade**  
Para utilizadores que possuem as gamas Advanced ou Enterprise com subscrição PHC On válida, passou a existir a possibilidade de definir uma [tabela](tabeladedescontosporqttouvalor.htm) por escalões de quantidades, em que é possível atribuir preços fixos em função das quantidades adquiridas pelo cliente.  
No caso do PHC CS POS desktop, quando está ativa a configuração "Desc. Qtt/valor automáticos ao gravar (POS)" são aplicados os descontos/preços fixos apenas quando o documento é gravado, uma vez que podem existir várias linhas com o mesmo artigo.   
  
  
**Confirmar dados do cliente ao dar pagamento de fatura em PHC CS POS Touch desktop**  
Se tiver uma subscrição PHC On válida e o parâmetro "Lembra o preenchimento do NIF no ato de pagamento (Apenas para Touch ligado)" ativo, o utilizador terá automaticamente acesso ao ecrã dos dados do cliente quando clicar no botão "Pagar" do PHC CS POS Touch desktop.  
  
  
**Pagamento através de Mobile Wallet**  
Esta funcionalidade encontra-se disponível a partir da versão 18 nas gamas Advanced e Enterprise caso possua o PHC On ativo e o módulo PHC CS POS desktop e permite efetuar pagamentos numa loja através de uma aplicação no smartphone.  
  
*Nota:* Para saber mais, caso possua as gamas Advanced ou Enterprise, por favor, consulte o tópico "Como efetuar um pagamento com o SEQR Mobile Wallet".  
  
  
**Gestão de vales de Desconto e Cheques de Oferta**  
No PHC CS POS Touch desktop v19 com PHC On, tem disponível a funcionalidade que possibilita a gestão de vales de desconto e cheques oferta a partir dos dois novos ecrãs "Tipos de vales" e "Vales". Para que tenha esta funcionalidade deve ter os parâmetros seguintes configurados:  

  
- **Utiliza vales de descontos/cheques oferta (reinstalar triggers)** - Condiciona o funcionamento ou não da gestão de vales de desconto e cheques oferta;
  
- **Modo de pagamento a utilizar cheques oferta.** - Define qual o modo de pagamento via cheques oferta;
  
- **Prefixo do número do vale de desconto/cheque oferta** - Possibilitar a definição do prefixo do número do vale/cheque oferta quando é criado um novo registo.

  
  
  
[Assistente de emissão de Vales de Reembolso](assistentedeemissãodevalesdereembolso.htm)  
  
A partir da v20 com o módulo PHC CS POS desktop em modo Touch POS, com a subscrição do PHC On ativa e os parâmetros **Usa modo simples para Vales de Reembolso na opção de zona do ecrã de venda** ou **Usa modo simples para Vales de Reembolso no ecrã de entrada do POS (TOUCH)** ativos, o ecrã "Vales de Reembolso" foi melhorado de forma a que o processo de devolução seja mais simples e intuitivo, passando a ter apenas três separadores com as seguintes ações:  

  
- Separador 1: Pesquisa de documento pelo código de barras ou pelo número de documento tendo em conta a serie em uso e ao ano corrente;
  
- Separador 2: Possibilidade de devolver através das opções: Pesquisa pelo código de barras ou referência do artigo; Selecionar o artigo pela coluna "Sel?"; Selecionar artigo da grelha e marcar a quantidade comprada e a devolver; E selecionar a quantidade existente na coluna "Devolver";
  
- Separador 3: Confirmação da quantidade a devolver.

  
Para gerar os Vales de Reembolso tem ainda a possibilidade de optar pela devolução a dinheiro ou por nota de crédito através dos botões com a respetiva designação.  
  
  
**Possibilidade de alterar a descrição de "Vales de reembolso"**    
A partir da v20 com o PHC CS POS desktop e com a subscrição do PHC On ativa, passa a ter a possibilidade de alterar a descrição dos [parâmetros](parâmetrosdopos.htm) para o termo mais adequado ao seu negócio. Desta forma, foram criados os parâmetros:   

  
- **Designação a usar em vez de Vales de Reembolso no singular com o valor por defeito: Vale de Reembolso**
  
- **Designação a usar em vez de Vales de Reembolso no plural com o valor por defeito: Vales de Reembolso**

  
A alteração da designação irá incidir nos seguintes locais:  

  
- Ecrã de fundo em modo Touch;
  
- Ecrã "Vales de Reembolso" em modo não Touch;
  
- Emissão de vales sem ter séries de vales de reembolso para o Terminal;
  
- Emissão de vales com o ecrã "Documentos de faturação" aberto;
  
- Menu da aplicação;
  
- Ecrã "Opções de zona" na zona relativa a vales de reembolso.

  
  
  
**Pesquisa e introdução de documentos de regularização na faturação em modo POSTOUCH**    
A partir da v20 com o PHC CS POS desktop e com a subscrição do PHC On ativa, passa a ter a possibilidade de regularizar documentos através da leitura do código de barras associado aos documentos, desta forma, ao abrir o ecrã "Faturação" no modo Touch, a aplicação verifica se o código de barras é referente a um documento, e se for, o documento é passado para a secção dos documentos regularizados.  
  
  
**Promoções predefinidas em código x-Base**   
Se pretender repetir a promoção com base num código x-Base, alterando apenas alguns dos critérios.  
A partir da v21, poderá criar tipos de promoções com critérios dinâmicos para utilizar na criação de novas promoções.  
Com o campo **Tipo de promoções predefinidas** poderá criar promoções x-base com recurso a variáveis.   
No ecrã de "Promoções", ao criar um novo registo, apresenta o campo **tipo** preenchido com "Promoção definida pelo utilizador" onde pode configurá-la ou, pode selecionar um tipo de promoção predefinida criada.  
No caso de indicar o tipo de promoção predefinida, a aplicação pergunta pelos valores das variáveis, para que possa substituir as mesmas na descrição, na expressão do critério e/ou na expressão da promoção.  
  
*Nota:* Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On.  
  
**Integração com várias balanças ou periféricos via xBase**  
A partir da v23, o PHC CS POS desktop pode integrar com balanças que utilizem o protocolo TISA.  
No ecrã "Configuração dos Terminais de Vendas", separador "Config.Porta Série", tem os dois campos que permitem a introdução de código xBase para que sejam feitas as alterações exigidas pelo protocolo TISA:  
- O campo "Expressão XBASE para pedir peso à balança" refere-se ao envio de informação para a balança para solicitar a pesagem. Está disponível a variável "m.objetoRecebido.cPreco" para os casos em que as balanças suportam o envio desta informação.  
- O campo "Expressão XBASE para receber o peso da balança" refere-se à resposta que é enviada pela balança após a pesagem. Está disponível a variável "m.objetoRecebido.cPeso", que contém a totalidade da resposta da balança ao pedido de pesagem.   
Caso não sejam preenchidos os campos de xBase, a aplicação interage com as balanças através do formato Dibal, protocolo TISA.
  
  
  
**PHC CS Sincro POS desktop**  
  

  
 **Importação dos dados na sede via ligação direta à instância da loja**  
Permite a integração dos dados sede/loja dispensando a exportação e importação de ficheiros. Este processo de replicação de dados está disponível apenas com o módulo PHC CS SINCRO POS desktop com subscrições PHC ON. Saiba mais sobre esta funcionalidade consultando os tópicos: [Importação de Dados de Lojas](importaçãodedadosdelojas.htm) e [Exportação de dados para a sede](exportaçãodedadosparaasede.htm).  
  
  
**Sincronização sede/lojas via SQL por pull/push dos dados a partir da sede**  
No PHC CS SINCRO POS desktop, nas gamas Advanced e Enterprise da v19 e com subscrição ao PHC On, tem a possibilidade de fazer o [intercâmbio de dados num cenário Sede/Loja](ExportaçãodeDadosparaLojas.htm#mchligadireto), através de uma ligação direta à instância SQL Server da Loja.  
  
*Nota*: Se possuir o executável de Espanha, esta funcionalidade está também disponível na gama Corporate.
  
  
  
  
**PHC CS Documentos Eletrónicos desktop**  

  
  
**Comunicação de Documentos de Transporte via Webservice**  
Esta funcionalidade encontra-se disponível a partir da versão 2014, se possuir o PHC On ativo e o módulo PHC CS Documentos Eletrónicos desktop. Esta opção permite o envio por transmissão eletrónica em tempo real de documentos de faturação e dossiers internos no momento em que são certificados.   
  
  
**Comunicação de Faturas para a Autoridade Tributária (AT)**   
Esta funcionalidade apenas se encontra disponível se possuir o PHC On ativo e o módulo PHC CS Documentos Eletrónicos desktop. Esta opção permite o envio por transmissão eletrónica em [tempo real](comunicaçãodedocumentosdetransporteviawebservice.htm) de envio de faturas e recibos de adiantamento no momento em que são certificados.   
  
  
**Comunicação de Contratos de Arrendamento e Emissão de Recibos (AT)**  
Esta funcionalidade apenas se encontra disponível se possuir o PHC On ativo e o módulo PHC CS Documentos Eletrónicos desktop na v19. Esta opção permite o envio por transmissão eletrónica em tempo real de contratos de arrendamento e a respetiva emissão dos recibos.
  
  
  
  
**PHC CS Clínica desktop**  
  

  
**Logs de atividade** (executável de Espanha)  
A partir da versão 16 no executável de Espanha para além da gama Enterprise, passam a estar disponíveis os logs de atividade também na gama Advanced, desde que tenha o módulo PHC CS Clínica desktop e com o PHC ON ativo.  
  
*Nota:* Esta funcionalidade apenas está disponível no executável de Espanha.
  
  
  
  
**PHC CS Multilíngua desktop**  
  

  
**Atualização de traduções via webservice**  
A partir da v20, com o módulo PHC CS Multilíngua desktop e com a subscrição de PHC On ativa, os utilizadores com acesso de administradores passam a ter a possibilidade de atualizar o iditra via Webservice. Assim, o Cliente só terá de configurar a periocidade que pretende para que a aplicação verifique e atualize se necessário, não necessitando de passos adicionais ou de descarregar manualmente ficheiros.  
  
*Nota:* Esta funcionalidade apenas está disponível nos executáveis de Espanha e do Peru.
  
  
  
[![](images/wtop.gif)](#top)   
  
**Para PHC CS Web:**  
  
  
**Web - Gerais:**  

  
**API Interface de Programação de Aplicações**  
Esta funcionalidade encontra-se disponível a partir da versão 17 nas gamas Advanced e Enterprise, caso possua o PHC On ativo e permite invocar e executar código de um registo de "script do utilizador", tanto da Intranet como da Extranet.  
  
*Nota:* Para saber mais, caso possua as gamas Advanced ou Enterprise, por favor, consulte o tópico: "Scripts".  
  
  
**Dashboards de PHC CS Web**  
A partir da versão 19 com as Gamas Advanced e Enterprise, se tiver o PHC On ativo, tem a possibilidade de centralizar as Análises Avançadas e os Snapshots de forma a ter uma visão global da atividade da empresa e da produtividade da mesma.  
  
Para mais informações, por favor, consulte o tópico [Dashboards de Phc Cs Web](dashboardsdephccsweb.htm).  
  
  
**Análise Multidimensionais em PHC CS Web**    
A partir da v20, com o módulo PHC CS Supervisor web com a subscrição de PHC On ativa, as análises multidimensionais de PHC CS Desktop passam a ganha mobilidade com o PHC CS Web, onde poderá criar, consultar de análises e snapshots, e poderá expandir/esconder, arrastar dados, filtrar a informação pretendida, recalcular os dados da análise e ainda exportar um ficheiro com extensão .xls.  
  
  
**Geolocalização**   
  
A partir da v21, pode verificar a localização dos seus clientes, contactos, fornecedores com vista a facilitar o planeamento e gestão das suas visitas e intervenções pela proximidade das localizações, por exemplo.  
  
Para usufruir desta funcionalidade deverá ter o parâmetro "Geolocalização: Utiliza geolocalização" ativo e definir os campos "latitude" e "longitude" nos seguintes ecrãs:  

  
+ Entidades
  
+ Contactos
  
+ Clientes
  
+ Clientes Potenciais
  
+ Fornecedores

  
  
Nos seguintes ecrãs "Visitas", "Intervenções técnicas", e "Equipamentos", em modo de consulta, terá o botão **Por perto** que lhe apresentará os clientes, por exemplo, próximos da localização onde se encontra.  
  
O botão **Por perto** apresenta uma listagem de entidades, clientes, clientes potenciais ou contactos (consoante o ecrã posicionado) associadas ao registo, que se encontrem por perto.   
Ou seja, no caso de estar posicionado no ecrã "Visitas", por exemplo, mostra os contactos e clientes potenciais que se encontram por perto da visita onde o utilizador se encontra posicionado.  
Na listagem apresentada, encontra-se uma caixa de seleção, onde poderá selecionar a distância pretendida e onde se encontram apresentadas quatro opções "100 m", "500 m", "1000 m" e "Outro valor  
A distância que surge por defeito é "100m" mas também esta distância é configurável no parâmetro "Geolocalização: Distância por defeito, em metros, utilizada para a procura de dados de GPS" da sua aplicação.  
  
  
**Apresentação de localização em Mapa**    
A partir da v21, foi criada a possibilidade no PHC CS Web de apresentar a localização em mapa relativa à morada de um registo.  
  
Para ter acesso a esta funcionalidade terá de configurar de dois parâmetros no PHC CS Desktop:  

  
+ **Tem ligação para mapas**;
  
+ **Endereço de mapa**, preenchido com o URL do motor de mapa a ser utilizado para apresentar o mapa. A construção deste URL deve ser feita usando as especificidades do motor em causa.

  
  
Após estas configurações será possível observar no PHC CS Web um botão de localização junto ao campo de **Morada** do registo.  
  
  
**Explorador de dados**    
A partir da v21, nas gamas Advanced e Enterprise, em todos os ecrãs de tabela do PHC CS Web passa a existir o "Explorador de dados" à semelhança da funcionalidade de PHC CS Desktop, permitindo assim também criar explorações a partir do PHC CS Web. O "Explorador de dados" permite a pesquisa criteriosa, filtrada e agrupada de dados, dando-lhe uma maior liberdade de escolha e uma maior rapidez e consistência de dados.  
  
O explorador de dados é compatível com o PHC CS Desktop, ou seja, as explorações efetuadas no PHC CS Web aparecem no PHC CS Desktop e vice-versa.  
  
  
**Sistema de Avisos**   
A partir da v21, tem um sistema de avisos que permite informar os utilizadores dos acontecimentos dentro do sistema, podendo reagir aos mesmos prontamente.   
  
O sistema de avisos estão dividos por quarto tipos predefinidos e que indicam a importância do mesmo:  

  
+ Alerta - são avisos que necessitam de atenção imediata do utilizador pela sua importância;
  
+ Ação - são avisos que exigem a reação do utilizador, como por exemplo, ações do workflow, tarefa atribuídas, entre outras;
  
+ Redes - são avisos relacionados com a atividade na rede colaborativa, como por exemplo, gostos ou comentários;
  
+ Informação - são avisos para dar conhecimento ao utilizador, sem necessidade de reação rápida, apesar de poderem ter reação.

  
  
Para ativar o sistema de avisos é necessário ativar o parâmetro **Usa sistema de avisos**. Caso se pretenda substituir as mensagens internas por avisos pode-se também ativar o parâmetro "Substituir mensagem interna por aviso", desta forma todas as notificações são enviadas por avisos.  
  
É possível também configurar os registos a seguir através do ecrã "Configuração de avisos automáticos" existente no menu "Configurações", desta forma o supervisor poderá configurar os avisos para todos utilizadores da aplicação, assim como visualizar todos os avisos configurados pelos utilizadores.  
  
Quando é lançado um aviso na página principal aparece o separador "Avisos" com a indicação da quantidade total de avisos que o utilizador tem para visualizar. O separador encontra-se dividido pelos tipos de aviso, e em cada tipo apenas aparecem os últimos quatro avisos. Para visualizar os restantes basta clicar sobre o tipo de aviso ou no canto superior direito no monitor que irá para o ecrã do "Monitor de avisos".  
  
No "Monitor de Avisos" é possível consultar todos os avisos, também separados pelos vários tipos.   
  
O supervisor, no menu "Framework" pode lançar avisos automaticamente através do "Assistente de envio de Avisos Automáticos", preenchendo os seguintes campos:  

  
+ Título - descrição do aviso;
  
+ Url de destino - caminho do aviso para o registo que se pretende enviar;
  
+ Tipo de aviso - o tipo do aviso, por defeito aparece Informação;
  
+ Utilizadores - listagem de todos os utilizadores possíveis de selecionar, com a possibilidade de pesquisa;
  
+ Lançar Avisos - botão que lança o aviso configurado para os utilizadores selecionados;
  
+ Simular Avisos - simula o lançamento do aviso com a indicação dos utilizadores selecionados, não é lançado nenhum aviso neste botão.

  
  
Nos ecrãs "Datas", "Marcações", "Notas" e "Artigos de rede" pode enviar um registo pelo "Assistente de envio de Avisos Automáticos", através da opção de registo "Enviar registo por aviso".   
  
Nas "Tarefas" e "Datas", se tiver o parâmetro "Substituir mensagem interna por aviso" ativo, ao criar um registo e selecionar as opções "Notifica o responsável e quem abriu por sistema interno" e "notifica participantes por sistema interno", respetivamente, envia avisos de ação para os utilizadores em vez das mensagens internas.  
  
Também nos Workflows, nas atribuições, delegações e deadlines das ações são enviados avisos desde que se tenham ativos os seguintes campos nas ações **ao delegar envia um aviso por sistema interno**, **avisa por sistema interna o deadline**, **ao escalar envia aviso por sistema de deadline** e nos parâmetros no PHC CS Desktop **Envia avisos automáticos (tem que reiniciar a aplicação)** e **Substituir mensagem interna por aviso**.   
  
Ao seguir um projeto vai ser avisado de todas as alterações ao projeto, incluindo as alterações ou introduções efetuadas em:  

  
+ Fases
+ Itens de Projeto;
  
+ Ligações de Projetos;
  
+ Notícias de Projeto;
  
+ Áreas de projetos;
  
+ Utilizadores de projetos;
  
+ Redes;
  
+ Tarefas;
  
+ Passos de tarefas.

  
  
  
**Personalização de Análises Avançadas com CSS**  
A partir da v22, pode personalizar ainda mais as análises avançadas na aplicação com os novos campos no ecrã "Edição dos registos das Análises Avançadas", que permitem de forma acessível e rápida, o aumento da experiência quer na construção, quer na leitura destas análises.  
Os novos campos no ecrã "Edição dos registos das Análises Avançadas" são:  

  
+ "Tipo de dados de cada coluna da análise" que permite indicar a respetiva formatação para as colunas;
  
+ "Títulos das colunas da análise" que permite que os textos apareçam pela mesma ordem, no cabeçalho das respetivas colunas da análise;
  
+ "Tooltips das colunas da análise" ue permite que os textos apareçam pela mesma ordem, como texto de ajuda, no cabeçalho das respetivas colunas da análise;
  
+ "Css das colunas" permite que o utilizador possa personalizar a análise avançada com código CSS;
  
+ "Css das linhas" permite que o utilizador possa personalizar a análise avançada com código CSS;
  
+ Também pode utilizar o editor de código, onde tem a opção "Gerador de CSS" para o auxiliar nas implementações com código CSS.

  
  
  
**Novos itens na área de próximas ações**   
Para tornar os processos mais fluídos do seu dia a dia, foram adicionados novos itens na área de próximas ações nos seguintes ecrãs:  
  
Módulo PHC CS Gestão web:  

  
Ecrã "Clientes"  

  
- Introduzir Documento Faturação
  
- Introduzir Dossier Interno
  
- Introduzir Recibo
  
- Criar Estabelecimento

  
  
Ecrã "Faturação"   

  
- Emitir Recibo

  
  
Ecrã "Compras"  

  
- Emitir Pagamento

  
  
Ecrã "Fornecedores"  

  
- Introduzir Compra
  
- Introduzir Dossier Interno
  
- Criar Pagamento
  
- Criar Estabelecimento

  
  
Módulo PHC CS CRM web:  

  
Ecrã "Clientes Potenciais"  

  
- Criar Contacto

  
  
Ecrã "Pessoas"  

  
- Introduzir uma Visita

  
  
Módulo PHC CS Suporte Intranet web  

  
Ecrã "Pedidos de Assistência"  

  
* Criar Nova Intervenção

  
  
  
**Melhoramentos Agenda**   
A partir da v22, a Agenda de Marcações passa a apresentadar as marcações diárias e, por defeito, com a opção "Utilizadores" selecionada. Ao abrir a Agenda de Marcações é validado se é subcritor do PHC On e, se for, na lista de utilizadores, aparece o botão "Minha Agenda" seguida da lista de utilizadores recentemente pesquisados. Desta forma, se for a primeira vez do utilizador a entrar na agenda, serão carregadas as marcações diárias e apresentada a opção "Minha Agenda" acima lista de utilizadores do sistema, separados por uma barra horizontal. Ao clicar na agenda de um utilizador diferente, serão carregadas as marcações diárias do mesmo. No entanto, na listagem de utilizadores, será apresentado o histórico do último elemento consultado. À medida que se vai consultando outras agendas de utilizador, vai ser guardado um histórico dessas consultas na listagem de utilizadores até ao máximo de 5.   
  
  
**Importação de tabelas via WebService**  
A partir da v23, no PHC CS Desktop, se for subscritor do PHC On, tem a possibilidade de importar automaticamente as tabelas das seguintes áreas via Webservice PHC:  
- Intrastat;  
- Revisão de Preços;  
- Relatório Único;  
- Correções Monetárias.  
  
  
**Disponibilização de documentos através do Workflow Operacional**  
A partir da v23, no PHC CS Web tem agora a funcionalidade Workflow Operacional que permite configurar, por utilizador, por perfil de acesso ou por acesso específico, quais os documentos disponibilizados na lista de diversos ecrãs. Esta funcionalidade está disponível nas gamas Advanced e Enterprise, e para subscritores do PHC On. Pode usufrui-la com os módulos PHC CS Gestão web, PHC CS CRM web e PHC CS Suporte web.  
  
  
**Dashboard em modo de consulta e de edição**  
A partir da v23, ao aceder a um dashboard no PHC CS Web passa a ter a possibilidade de ter o dashboard em modo consulta e em modo de edição. Assim, garantirá que, apenas quando o dashboard está em modo de edição, conseguirá mover, redimensionar e eliminar os snapshots do mesmo.  
  
  
**Personalizar a página inicial do PHC CS Web**  
A partir da v23, no PHC CS Web pode arrastar os objetos da página inicial da aplicação para adaptá-los à sua necessidade. Ao clicar no botão "Editar Homepage", todos os objetos da página inicial vão ficar em modo de edição e poderá arrastá-los, trocando os elementos de posição e esticar ou encolhê-los. Ao fazer uma alteração da posição e tamanho dos objetos, esta alteração irá manter-se até à próxima alteração.  

  
  
  
**PHC CS Gestão web**  

  
  
**Criar um Dossier Interno utilizando a API**  
Na v19 a partir das gamas Advanced e Enterprise com PHC On ativo, poderá criar um Dossier Interno assinado digitalmente recorrendo à API do PHCS CS Web. Desta forma, a partir de um Script da Framework, poderá executar o código de um registo de forma rápida e fácil.  
  
Para mais informações, por favor, consulte o tópico **Crie um Dossier Interno Utilizando a Api do Phc Cs Web**.  
**Sincronização entre a aplicação e o Exchange**   
A partir da v20, com os módulos PHC CS Gestão web, PHC CS CRM web ou PHC CS Equipa web e com a subscrição do PHC On ativa passa a poder sincronizar com o Exchange os dados relativos a:  

  
+ Marcações
  
+ Visitas
  
+ Pessoas
  
+ Contactos
  
+ Tarefas de Equipa
  
+ Datas de Equipa

  
  
**Dossiers de Entidades**   
A partir da v20, com os módulos PHC CS Gestão web ou PHC CS CRM web, e com a subscrição de PHC On ativa, passa a poder criar séries de dossiers para entidades.  
Esta funcionalidade estava disponível com o PHC CS Gestão desktop e passa a ganhar mobilidade com PHC CS Gestão web ou PHC CS CRM web.  
  
  
**Importar Excel para linhas**    
A partir da v20, com o módulo PHC CS Gestão web, passa a existir a opção para cópia de dados de um ficheiro com extensão .xls, por exemplo Excel, para os ecrãs "Dossiers Internos", "Faturação" e "Compras". Desta forma, passa a existir uma maior agilização na inserção de dados na aplicação.  
  
  
**Catálogo de produtos no Gestão**  
A partir da v21, com o PHC CS Gestão web, é possível adicionar artigos às encomendas, através do botão Catálogo de artigos. Ao clicar no botão Catálogo de artigos é apresentada uma listagem de artigos agrupados por categoria, onde poderá filtrar, ver os artigos em grelha ou lista e, também, ordená-los de acordo com os campos existentes.  
  
Para usufruir desta funcionalidade é necessário:  

  
+ Ter o parâmetro **Tem catálogo de artigos** existente no nó "Gestão" ativo;
  
+ Criar as categorias que pretende mostrar através do ecrã "Configuração de categorias de artigos";
  
+ Criar os templates básicos para o catálogo de produtos no Gestão web;
  
+ Preencher os parâmetros relativamente aos templates e catálogos de produtos no Gestão web.

  
  
  
**Monitor de Comunicação de Documentos de Faturação via Webservice à AT**    
A partir da v22, já pode comunicar faturas via webservice à AT, a partir do Monitor de Comunicação de Documentos de Faturação via Webservice à AT, à semelhança do monitor já existente no PHC CS Desktop.  
  
  
**Regularização de recibos de adiantamento nas faturas**   
A partir da v22, no ecrã "Faturação" passa a ter o separador "Regularizações" que, ao clicar para adicionar uma nova linha, apresenta uma lista dos documentos que se pode regularizar e relativos à moeda do documento de faturação, caso o documento de faturação permita regularizar documentos de adiantamentos.  
  
  
**Integração de títulos a fornecedores**  
A partir da v23, no PHC CS Web, se for subscritor do PHC On, passa a ter possibilidade de fazer a integração dos documentos com títulos emitidos associados, assim como os movimentos de liquidação dos respetivos títulos.   
  
A movimentação na gestão dos títulos pressupõe que se movimente a tesouraria previsional, sendo que, na contabilidade, deve estar espelhado qual é o respetivo movimento através de uma conta de títulos de fornecedores. Quando um título emitido é dado como liquidado passa da tesouraria previsional para a real e movimenta a conta de títulos de fornecedores por contrapartida da conta do banco.  
  
  
**Documentos de faturação em rascunho**  
A partir da v23, no PHC CS Web passa a ter a possibilidade de criar documentos de faturação em rascunho. Para isso, é necessário criar uma série no ecrã "Configuração de Documentos de Faturação" com as opções "série está disponível no Gestão web" e "é uma série em rascunho" ativadas no PHC CS Desktop. Desta forma, ao criar um documento de faturação no PHC CS Web, este fica com uma numeração provisória, não ficando assinado como no caso de séries certificadas. O documento de faturação gravado fica com a indicação "Documento em rascunho" e permite alterar dados com relevância fiscal.   
Para certificar um documento em rascunho, basta clicar na opção "Finalizar". Nesse momento, a aplicação verifica se existe stock, caso esteja configurado para isso, verifica a data do documento de acordo com as regras de faturação, numera e certifica. Caso pretenda certificar vários documentos, nas opções do ecrã, está disponível a opção "Finalizar vários", que ao clicar, abre um novo ecrã onde é possível escolher as datas de intervalo dos documentos a finalizar, um filtro e indicar se a data dos documentos deve ser atualizada. Para finalizar, basta clicar em "Finalizar selecionados".  

  
  
  
**PHC CS Contabilidade web**  

  
**Lançamento de documentos predefinidos**  
A partir da v22, foram adicionadas opções ao separador "Dados do documento", dependentes da subscrição ao PHC On, de forma a otimizar o ecrã "Documentos Pré-Definidos", sendo elas:  

  
+ Documento com dados para a relação de clientes anexa à declaração periódica de IVA;
  
+ Documento com dados para a relação de fornecedores anexa à declaração periódica de IVA;
  
+ Documento com dados para a relação de regularizações anexa à declaração periódica de IVA;
  
+ Entra para modelo intracomunitário de IVA;
  
+ Documento com dados de Provisões e Acréscimos de Custos.

  
  
**Integração online de clientes**  
A partir da v23, no PHC CS Contabilidade web, se for subscritor do PHC On, tem agora a possibilidade de criar ou atualizar contas no Plano de Contas quando é criado ou editado o registo de um cliente.   
Se tiver os parâmetros "Atualiza automaticamente as contas da contabilidade" e "Guarda o estabelecimento na conta corrente" e o cliente tenha o estabelecimento 0 (sede) são verificadas as seguintes contas:  
- Conta-corrente;  
- Títulos de Dívida;  
- Títulos de Dívida Descontadas;  
- Envio a Desconto de Títulos de Dívida;  
- Dívidas tituladas;  
- Adiantamentos c/ preço incerto;  
- Adiantamentos c/ preço certo.  
  
**Integração online de fornecedores**  
A partir da v23, no PHC CS Contabilidade web, se for subscritor do PHC On, tem agora a possibilidade de criar ou atualizar contas no Plano de Contas quando é criado ou editado o registo de um fornecedor.   
Se tiver os parâmetros "Atualiza automaticamente as contas da contabilidade" e "Guarda o estabelecimento na conta corrente" no PHC CS Desktop ativos e o fornecedor tenha o estabelecimento 0 (sede) são verificadas as seguintes contas:  
- Conta-corrente;  
- Títulos de Dívida;  
- Títulos de Dívida Descontadas;  
- Envio a Desconto de Títulos de Dívida;  
- Dívidas tituladas;  
- Adiantamentos c/ preço incerto;  
- Adiantamentos c/ preço certo.  

  
  
**PHC CS Equipa web**  

  
**Botão para visualizar a ocupação das áreas e dos utilizadores**    
A partir da v20, no ecrã "Datas de Projetos"( disponível com o módulo PHC CS Equipa web) ou no ecrã "[Marcações](marcaçõesnophccsweb.htm)" da sua Agenda, poderá visualizar a ocupação das [áreas](DatasdeProjetos.htm#vbeocupareas) ou dos [utilizadores](DatasdeProjetos.htm#vbeocuputulizadores) através do botão "Ver ocupação" posicionado nos separadores "Utilizadores" ou "Áreas".   
Ao clicar irá abrir o ecrã com as áreas/utilizadores tendo em conta a data inicial e data final, e um gráfico pelo dia de semana e hora da ocupação. Poderá navegar rapidamente pelos dias e semanas. Assim, rapidamente saberá a disponibilidade do utilizador / área com que pretende interagir.  
  
  
**Melhorias na importação de tarefas através de um ficheiro Excel**    
A partir da v21, com o módulo PHC CS Equipa web, tem disponível, através do ecrã "Monitor de Projeto", a possibilidade de copiar uma ou várias tarefas a partir de um ficheiro Excel através do botão "Importar várias tarefas". Assim, deverá copiar todas as linhas com as tarefas pretendidas incluindo o cabeçalho de um ficheiro Excel e colar na respetiva caixa disponível para o efeito, ficando imediatamente disponível na grelha para posteriormente serem importadas todas as tarefas para o monitor de projeto.  
  
  
**Tarefas em cartão para melhorar a gestão de tarefas de Projeto**   
A partir da v21, com o PHC CS Equipa intranet web, passa a poder visualizar as tarefas de um projeto em formato de cartão. O ecrã "Tarefas em cartão" é acedido através do Monitor de Projeto a partir do botão "Outras opções" na opção "Tarefas em cartão", ou no final da listagem das tarefas do projeto a partir do "Tarefas em cartão".  
Esta funcionalidade permite agrupar as tarefas por:  

  
+ Grupo;
  
+ Tipo;
  
+ Status;
  
+ Classificação;
  
+ Utilizador responsável;
  
+ Fase (caso o projeto esteja configurado para ter fases);
  
+ Prioridade;
  
+ Urgência;
  
+ Importância.

  
  
Sendo que poderão ficar agrupadas por vários níveis de priorização.  
  
Os Cartões de tarefas permitem várias ações:  

  
1) No cartão da tarefa é mostrado o resumo da tarefa no tipo, a data de fecho, e a imagem associada ao utilizador responsável pela tarefa, ao passar o cursor do rato por cima da imagem, é mostrado o nome do utilizador;  
2) Poderá arrastar o cartão de uma tarefa de um grupo para outro, de acordo com o tipo de agrupamento selecionado, o campo ficará alterado de imediato no sistema;  
3) No botão com o símbolo de um cadeado permite que, ao clicar, identifique se uma tarefa se encontra fechada ou aberta;  
4) No botão com um símbolo circular e uma seta a apontar para baixo permite que, ao clicar, apresenta um sub-menu com várias opções:  

  
- Consultar: redireciona o utilizador para o ecrã da tarefa, em modo de consulta;
  
- Alterar: redireciona o utilizador para o ecrã da tarefa, em modo de alteração;
  
- Adiar 1 dia: A data de fim da tarefa é adiada em 1 dia;
  
- Adiar 1 semana: A data de fim da tarefa é adiada em 1 semana;
  
- Adiar 1 mês: A data de fim da tarefa é adiada em 1 mês;

  
5) No canto inferior direito existe ainda um botão com o símbolo (i) que, ao clicar, apresenta a informação constante do cartão inicial com a adição da seguinte informação:  

  
- Urgência;
  
- Prioridade;
  
- Importância;
  
- Data de início;
  
- Descrição da tarefa. A descrição da tarefa pode ser alterada diretamente neste ecrã.
  
- Utilizador responsável. O utilizador responsável, poderá também ser alterado diretamente neste ecrã.

  
  
**Fechar tarefas e passos de tarefas através de uma próxima ação**   
A partir da v22, para fechar tarefas e passos de tarefas tem uma próxima ação nos ecrãs "Tarefas" e de "Passos de tarefas". Ao introduzir, alterar ou duplicar uma tarefa, ao gravar a mesma terá no topo do registo uma próxima ação em que poderá fechar a tarefa. O mesmo acontece no ecrã "Passos de tarefas", sendo apenas fechado o passo da tarefa.   
  
  
**Registo de Tratamento de Dados no Equipa**  
A partir da v22, nas gamas Advanced e Enterprise, à semelhança da funcionalidade no PHC CS Desktop, passa a poder ter um maior controlo dos seus processos de tratamento de dados bem como a capacidade analítica dos dados tratados no PHC CS Web. Tendo a configuração efetuada no PHC CS Desktop, ao aceder à tabela que escolheu para fazer o registo de dados, ao clicar na opção diversa "Registo de tratamento de dados" pode identificar o motivo pelo qual acedeu a um determinado registo.  
  
  
**Rede para conversação em tempo real**  
A partir da v23, no PHC CS Equipa web e no PHC CS Colaborador web, se for subscritor do PHC On, tem disponível um novo tipo de rede que permite conversar em tempo real. Desta forma, ao criar uma nova rede é necessário preencher a opção "É rede do tipo Sala de Chat". Ao aceder à rede, poderá inserir mensagens e ter a indicação à quanto tempo esta mensagem foi publicada. Quando está a digitar uma mensagem, os membros dessa rede têm a indicação de que está a escrever uma mensagem. Quando a mensagem é enviada, se o membro estiver a seguir a rede, é apresentado o aviso de que o membro tem mensagens por ler que, ao clicar, navega para a respetiva conversação. No separador "Membros", são apresentados os utilizadores que se encontram inseridos na rede com a indicação se se encontram online (a verde) ou não (a cinzento).  
  

  
  
**PHC CS Recrutamento web**  

  
**Ecrã "Colaboradores" no PHC CS Recrutamento web**  
No PHC CS Recrutamento web, nas gamas Advanced e Enterprise, e se for subscritor do PHC On, tem o ecrã Colaboradores que permite criar, alterar e apagar registos de colaboradores.  

  
  
**PHC CS Colaborador web**  

  
**Aprovação de Férias**   
A partir da v21, para completar o processo de marcação de férias tem o ecrã "Aprovação de férias", onde rapidamente poderá aprovar férias de funcionários.  
  
Este ecrã apenas está disponível se, no PHC CS Desktop, tiver ativa a opção **Aprova Férias** no ecrã "Funcionário", bem como o campo **Quem aprova** preenchido com o nome do responsável na respetiva ficha dos outros funcionários.   
  
Neste ecrã é apresentada uma grelha, onde tem a possibilidade de aprovar o registo de férias dos seus colaboradores, selecionar como admissão, e alterar o campo **Observações**. Além disso, pode validar os conflitos entre as marcações de férias e verificar o cálculo do "Total de Dias" marcados pelos funcionários.  
  
*Nota*: Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise.  
  
**Aprovação de Faltas**   
A partir da v21, no ecrã "Classificação de faltas" terá uma grelha onde poderá classificar faltas de funcionário. Esta grelha contém a seguinte informação:  
A coluna "Verificada" só vai estar disponível se se tratar de um abate de férias. Se não for esse o caso, a coluna só será preenchida depois de escolher o tipo de falta que está associado a essa falta.   
Na classificação da falta, ao escolher o tipo de falta, a coluna da quantidade é preenchida com o n.º de dias, caso a falta seja em dias. Na coluna "motivo" constará a informação da justificação da falta e na coluna "Anexos" poderá anexar o devido comprovativo.  
  
*Nota*: Esta funcionalidade apenas está disponível nas gamas Advanced e Enterprise.  
  
  
**Campo "Apresenta no organograma" no ecrã "Gestão de Funcionários"**    
A partir da v22, nas gamas Advanced e Enterprise tem a opção "Apresenta no organograma" no ecrã "Gestão de funcionários", de forma a poder decidir quais os funcionários a aparecerem no mesmo.
  
  
  
**PHC CS Vencimentos web**  

  
  
**Ecrã "Pagamento de Contribuições"**  
A partir da v23, no PHC CS Vencimentos web, se for subscritor do PHC On, tem o ecrã "Pagamento de contribuições" que permite visualizar a informação de todos os pagamentos à Segurança Social. O registo tem a informação da data em que o pagamento foi efetuado, o local de tesouraria de onde deu saída do pagamento ou se o pagamento já foi lançado na tesouraria. No separador "Valores" apresenta as contribuições pagas à Segurança Social, o pagamento da Retenção dos Serviços Públicos ou algum acordo de pagamento e as deduções por créditos em conta. No separador "Outros dados" tem a informação relativa ao centro analítico, a referência interna do pagamento, e se o pagamento já foi integrado na Contabilidade.  
  
  
**Ecrã "Transferências Bancárias"**  
A partir da v23, o ecrã "Transferências Bancárias" está disponível no módulo PHC CS Vencimentos Web e se for subscritor do PHC On. Neste ecrã, ao carregar no botão "Introduzir", navega para o ecrã "Processamento de Transferências Bancárias" onde pode exportar e lançar as transferências bancárias para os recibos diversos, de outros rendimentos e de vencimentos, com os dados referentes de tesouraria, da transferência bancária e da transferência dos ordenados. Poderá exportar os vencimentos para o ficheiro SEPA (XML) e, poderá exportar os subsídios de refeição pagos em cartão para ficheiro SEPA, "Euroticket à la card" em XML ou Free refeição (Millenium BCP) em TXT. No lançamento de transferências de recibos de vencimentos, o recibo de vencimento e o subsídio de refeição, se pertencerem ao mesmo banco, são divididos em duas transferências bancárias distintas. Após serem efetuadas as transferências bancárias, o recibo é atualizado com a transferência e são atualizados os valores de tesouraria.  
  
  
**Emissão automática de recibos de vencimento no PHC CS Vencimentos web** (apenas disponível no executável de Portugal)  
A partir da v23, no PHC CS Web tem agora disponível o ecrã "Emissão Automática de Recibos de Vencimento" que permite criar recibos de vencimento para um determinado mês e para vários funcionários. Esta funcionalidade apenas está disponível se for subscritor do PHC On, e poderá processar os vencimentos base tendo em conta os valores obtidos dos seguintes cálculos:  
- Faltas;  
- Férias;  
- Horas extra;  
- Despesas;  
- Subsídios de turno e refeição;  
- Subsídios e remunerações diversas;  
- Divisões de Centro Analítico.  
  
Neste ecrã tem as seguintes opções:  
- "Processar Retroativos": esta opção tem em conta as datas inseridas para o seu cálculo, verificando apenas as remunerações entre as datas referidas.  
- "Lançar duodécimos": caso no ecrã "Funcionários" esteja configurado para duodécimos de subsídio de Natal ou de férias, a aplicação cria os valores para os meses desde janeiro até ao mês do recibo;  
- "Processar Ajustes IRS: esta opção deve ser utilizada após a alteração de tabelas de IRS.  
  
  
**Guia de pagamento de IRS, IRC e Imposto de Selo**  
A partir da v23, no PHC CS Vencimentos web, se for subscritor do PHC On, passa a ter o ecrã "Declaração de Retenção na Fonte" que permite produzir a guia de pagamento de retenções de IRS/IRC em conjunto com guia de pagamento de Imposto de Selo (se possuir o módulo PHC CS Contabilidade web). Caso possua o módulo PHC CS Gestão web, também são tidos em conta os rendimentos retidos de fornecedores, sendo considerados os valores retidos e sujeitos a IRS de compras a fornecedores que não lançam em conta-corrente, pagamentos a fornecedores relativos às compras que lançam em conta-corrente, e adiantamentos a fornecedores que não são tidos em conta os rendimentos da categoria H.  
  
  
**Declaração Mensal de Remunerações para a Segurança Social**(apenas disponível no executável de Portugal)  
A partir da v23, no PHC CS Vencimentos web, se for subscritor do PHC On, tem a possibilidade de produzir o ficheiro da Segurança Social, assim como o registo do pagamento das contribuições para essa entidade. No ecrã "Segurança Social" pode definir o mês e ano que pretende para processar os dados. No separador "Dados de registo do pagamento de Contribuições" é possível definir os dados para lançar o registo na respetiva tabela.  
  
  
**Declaração Mensal de Remunerações para a Autoridade Tributária**(apenas disponível no executável de Portugal)  
A partir da v23, no PHC CS Vencimentos web, se for subscritor do PHC On, pode produzir o ficheiro da Declaração Mensal de Remunerações. No ecrã "Declaração Mensal de Remuneração AT" poderá fazer as configurações necessárias para que a informação dos rendimentos de cada funcionário seja apresentada a grelha. Para produzir o ficheiro da DMR apenas terá de clicar em "Produzir".  
  
  
**Processamento e emissão do ficheiro para o FCT e FGCT** (apenas disponível no executável de Portugal)  
A partir da v23, para fazer face à recente imposição decretada pela Lei n.º 70/2013, de 30 de agosto, com o módulo PHC CS Vencimento web, e se for subscritor do PHC On, a aplicação passou a calcular e registar os valores de contribuição para o FCT/ME e FGCT, Fundo de Compensação do Trabalho e o Fundo de Garantia de Compensação do Trabalho, respetivamente.  
  
No ecrã Gestão de Funcionários é possível registar um valor anterior de saldo FCT/ME e FGCT que resulte, por exemplo, de uma transmissão de funcionários, de acordo com o Artigo 13º da Lei n.º 70/2013, de 30 de agosto, sempre que a data de admissão seja superior a 01 de outubro de 2013.  
  
No ecrã "Fundos de Compensação do Trabalho" é possível aceder à análise "Mensal ou Listagem de Processamentos Mensais" que apresentam os movimentos que as contas de FCT e FGCT tiveram em determinado mês e ano e o respetivo detalhe como o número de recibo de vencimento, o número de funcionário, o nome, a data de processamento, a conta FCT, o saldo anterior, o valor de FCT/ME e o valor de FGCT.  
  
A partir do ecrã "Fundos de Compensação do Trabalho" tem disponíveis os ecrãs Reembolsos e Anular Reembolsos, que permitem emitir reembolsos e anulá-los, respetivamente.  
  
  
**Produzir ficheiro do Mapa de Seguros**(apenas disponível no executável de Portugal)  
A partir da v23, no PHC CS Vencimentos web, se for subscritor do PHC On, poderá criar o ficheiro eletrónico do Mapa de Seguros cumprindo as obrigações legais aprovadas na Portaria n.º 256/2011, de 05 de julho.  
No ecrã "Folha de Férias Seguradoras", ao definir o período - "Mês" e "Ano", são apresentadas as remunerações associadas aos recibos dos funcionários, onde poderá consultar o detalhe de toda a informação necessária para preenchimento na aplicação online da APS - Associação Portuguesa Seguradores.  
Ao clicar em "Produzir ficheiro", este é criado com base na estrutura do ficheiro de segurança social, que contém o valor completo do subsídio de refeição (valor sujeito e não sujeito a Segurança Social). É criado um ficheiro por número de apólice e número de segurança social, ou seja, vão existir tantos ficheiros quando as conjugações de dados existentes de apólices diferentes e números de segurança social que existirem.  
  
**Emitir Recibos Diversos a partir do ecrã "Despesas"**  
A partir da v23, no ecrã "Despesas" do PHC CS Colaborador web, se for subscritor do PHC On, e tiver o módulo PHC CS Vencimento web passa a ter a possibilidade de emitir recibos diversos para várias linhas da despesa.
  
  
  
**PHC CS Front web**  

  
**Catálogo de produtos no Front**    
  
A partir da v21, é possível adicionar artigos às encomendas, através do botão **Catálogo de artigos**. Ao clicar no botão **Catálogo de artigos** é apresentada uma listagem de artigos agrupados por categoria, onde poderá filtrar, ver os artigos em grelha ou lista e, também, ordená-los de acordo com os campos existentes.  
  
Para usufruir desta funcionalidade é necessário:  

  
+ Ter o parâmetro **Tem catálogo de artigos** existente no nó "Front" ativo;
  
+ Criar as categorias que pretende mostrar através do ecrã "Configuração de categorias de artigos";
  
+ Criar os templates básicos para o catálogo de produtos no Front;
  
+ Preencher os parâmetros relativamente aos templates e catálogos de produtos no Front.

  
  
  
  
**PHC CS Recrutamento web**  

  
**Monitor de Recrutamentos em aberto**    
A partir da v22, nas gamas Advanced e Enterprise, passa a ter disponível o Monitor de recrutamentos em aberto, que permite ter a informação centralizada de todas as candidaturas efetuadas aos recrutamentos que se encontram em aberto, assim como, as entrevistas aos candidatos.
  
  
  
**PHC CS Supervisor web**  

  
  
**Posição da caixa de seleção "Ver outro Dashboard"**    
A partir da v21, com o módulo PHC CS Supervisor web nas gamas Advanced e Enterprise, passa a ter na caixa de seleção a opção **Ver outro Dashboard** que permite visualizar outros dashboards.  
  
**Limpar avisos antigos a partir do monitor de sistema**    
A partir da v22, nas gamas Advanced e Enterprise, tem no "Monitor de sistema", o separador "Performance de código" que permite controlar a aplicação e apagar informação antiga da mesmatem. Agora tem a possibilidade de apagar avisos antigos de todos os utilizadores, tendo em conta também o parâmetro do "Número de dias de antiguidade", que apaga os avisos de todos os utilizadores com mais dias que os apresentados no parâmetro.
  
  
  
**PHC CS Loja web**  

  
**Ordenação das categorias de artigos**   
A partir da v22, nas categorias de artigos, tanto na loja web como nos catálogos na intranet e na extranet, tem agora a possibilidade de ordenar as mesmas. Deste modo, foi criado o campo "Ordem da categoria" no ecrã "Configuração de categorias de artigos", para poder ordenar as várias categorias conforme pretendido.
  
  
  
[![](images/wtop.gif)](#top)   
  
**Para o PHC CS XL:**  

  
**Gestão por Centro de Custos**   
Na v19 de PHC CS XL, em todas as Gamas com PHC On ativo, tem a possibilidade de fazer a Gestão por Centro de Custos, centralizando a informação de modo a garantir a responsabilização por setor ou gestor, identificar em tempo oportuno os gastos elevados, permitir um controlo periódico regular, servir de base à tomada de decisões pelos gestores, e verificar o Resultado individualizado de cada secção.  
  
Desta forma passará a ter as seguintes funcionalidades disponíveis:  

  
+ Importar um ou vários Balancete por Centro Analíticos e com a classe 9;
  
+ Utilizar Funções Principais e de Contabilidade por Centros de Custos (cerca de 250 Funções disponíveis);
  
+ Construir Mapas por Centros Analíticos, através do Assistente de Mapas;
  
+ Detalhar funções que utilizem os Centros Analíticos.

  
  
Para mais informações, por favor, consulte o tópico "Tabela de Funções".  
  
  
**Detalhar Funções de Utilizador**  
A partir da v19 com PHC On ativo, passa a ter a possibilidade se possuir a Gama Enterprise de Detalhar as Funções de Utilizador, ou seja, poderá visualizar a composição da fórmula, bem como cada um dos valores que compõem a fórmula do utilizador.   
E com a Gama Corporate passa a poder Detalhar Funções Principais e de Contabilidade de forma a que possa verificar a composição de cada função.  
  
Para mais informações, por favor, consulte os tópicos "Detalhar Função" e "Tabela de Funções".  
  
**Contabilidade Orçamental no PHC CS XL**   
A partir da v20, nas gamas Advanced e Enterprise do PHC CS XL passa a ser possível a importação de dados da contabilidade orçamental do PHC CS Desktop.  
O utilizador passa a ter disponibilizadas as seguintes funções para contabilidade orçamental:  

  
+ Orçamental - Acumulado a débito
  
+ Orçamental - Acumulado a crédito
  
+ Orçamental - Movimento do mês a débito
  
+ Orçamental - Movimento do mês a crédito
  
+ Orçamental - Valor em Ordem de Compra

  
Ao efetuar detalhe de qualquer uma das funções o utilizador poderá visualizar os dados relativos a acumulados, saldos, valor em ordem de compra e transferências.  
  
  
**Uso de várias empresas em simultâneo no PHC CS XL**  
A partir da v20, com o PHC CS XL, passa a ser possível apresentar dados em simultâneo de diferentes bases de dados na mesma folha de cálculo. Desta forma, o utilizador tem a possibilidade de escolher a base de dados onde pretende calcular a função, tanto a partir do ecrã "Assistente de mapas", como a partir do ecrã "Inserção de função, sendo o detalhe apresentado na coluna com o nome da base de dados que foi selecionada.
  
  
  
[![](images/wtop.gif)](#top)   
  
**Para PHC CS Manufactor:**  
  
  
**Manufactor - Gerais**  

  
**Processamento e custeio de Diário de trabalho via alerta (assíncrono)**  
Este parâmetro está disponível a partir da versão 17 para a gama Executive do PHC CS Manufactor e permite guardar os dados do diário de trabalho (custeio, consumos e movimentos de stock) como não processados, tornando a gravação do diário num processo muito mais rápido, sendo depois possível processar posteriormente os diários de trabalho.  
  
  
**Ao criar novo diário fecha automaticamente o diário de trabalho anterior**  
Este parâmetro está disponível a partir da versão 18 para a gama Executive do PHC CS Manufactor e permite que ao criar um novo diário de trabalho a aplicação feche o diário de trabalho anterior, permitindo a sua alteração apenas se o utilizador reabrir manualmente o diário de trabalho.  
  
**Com acesso de editar qualquer perfil de planeamento**  
Esta opção está disponível a partir da versão 18 para a gama Executive do PHC CS Manufactor e permite ao utilizador planeador global editar qualquer perfil de planeamento.  
Quando o planeador acede ao planeamento (seja o Gráfico de Gantt ou o planeamento de ordens de fabrico) passa a ser apresentado no canto superior direito o campo "Perfil de planeamento" para o planeador escolher o perfil que deseja utilizar.
  
  
  
  
  
**PHC CS Platform manufactor web**  

  
**Análise OEE (Overall Equipment effectiveness)**  
No PHC CS Platform manufactor web intranet na v19 com PHC On ativo, passa a ter disponível a Análises OEE - Overall Equipment effectiveness - que permite monitorizar e melhorar a eficiência dos seus processos de manufatura, é o chamado "best practices"(melhores práticas), o conjunto de ações que definem a melhor forma de gerenciar uma fábrica. OEE é simples e prático, divide as mais comuns e importantes fontes de perdas da produtividade industrial em três categorias primárias:   

  
+ **OEE Availability** - Corresponde ao rácio tempo ocupado vs tempo disponível;
  
+ **OEE Performance** - Corresponde ao rácio número de peças produzidas dia vs número de peças máximo teórico dia;
  
+ **OEE Quality** - Corresponde ao rácio de total de peças produzidas vs rácio de peças boas produzidas ou total peças produzidas vs peças rejeitadas.

  
  
  
  
**PHC CS Planning manufactor**  

  
**Análise de cargas**  
No PHC CS Planning manufactor v19 com PHC On ativo, passa a existir a opção "Análise de Cargas" com os separadores "Análise de Cargas" e "Análise Individual" (correspondente ao antigo ecrã "Análise de Capacidades"), que permitem analisar, em simultâneo, a disponibilidade e capacidade total da fábrica e ter um maior poder sobre o planeamento dos Centros de Trabalho dentro de um período de tempo.  
  
  
**Exportar e Importar Cenários de Planeamento e Planeamento**  
No PHC CS Planning manufactor v19 com PHC On ativo, passa a conseguir nos ecrãs "Cenários de Planeamento" e "Planeamento", exportar e importar dados recebidos de outro sistema de escalonador externo em 3 formatos possíveis:  

  
+ XML padrão;
  
+ DBF;
  
+ xBase.

  
  
  
  
**PHC CS Touch manufactor**  

  
**Painéis de Assistente para Touch**  
A partir da v20, na gama Executive, passa a ter disponíveis os Painéis de Assistente para Touch. Algumas das suas funcionalidades estão dependentes da subscrição do PHC On ativa, sendo elas:   

  
+ No ecrã "Passos" passa a ser possível definir as cores específicas para o passo;
  
+ As propriedades:
  

  
- O campo "xcorfundo" com uma cor para que esta seja apresentada depois como fundo;
  
- O campo "xcortexto" com uma cor para que esta seja apresentada depois como cor da letra;
  
- O campo "ximagem" com um caminho para que esta seja apresentada depois como imagem do dado;

  
+ Efetuar uma pesquisa através da leitura de um código de barras.
  
+ No ecrã Desenhar Painéis de Assistente para Touch, Passos, na configuração da grelha, são executadas as seguintes colunas:
  

  
- Nº colunas
  
- Nº linhas
  
- Tipo condição
  
- Condição

  
  
  
**Passos com origem de dados por tabela, lista ou expressão**   
A partir da v21 com o PHC CS Touch manufactor na gama Executive, no ecrã "Passos e Variáveis para Painéis de Assistente Touch", no separador "Dados", passa a poder definir três tipos de origem de dados do passo, sendo os primeiros dois dependentes da subscrição do PHC On:  

  
+ Tabela: os dados serão obtidos em função da tabela escolhida pelo utilizador;
  
+ Lista: os dados serão obtidos em função de uma lista de valores definida pelo utilizador;
  
+ Expressão: poderá definir uma expressão TSQL ou uma expressão XBASE.

  
No campo **Origem de Dados** ao escolher a opção Expressão, será apresentado ao utilizador o novo campo **Expressão**. Neste campo poderá definir uma expressão TSQL ou uma expressão XBASE, que será utilizada para obter os dados a serem apresentados no passo. Caso seja uma expressão XBASE deve ativar a opção **é um programa XBASE**.  
  
Os tipo de origem por Tabela e Lista apenas estão disponíveis com PHC On.   
  
  
**Modelos para Painéis de Assistente**  
A partir da v21, no PHC CS Touch manufactor, tem disponível o botão **Modelos** nos ecrãs "Desenhar Painéis de Assistente para Touch" e "Passos e Variáveis para Painéis de Assistente Touch" que, ao clicar, navega para o assistente que irá auxiliá-lo na criação de passos. Através desta funcionalidade, poderá escolher o tipo de painel que pretende e depois escolher um conjunto de passos com configuração já predefinida.  
  
No assistente acedido através do ecrã "Desenhar Painéis de Assistente para Touch", a aplicação acrescenta os passos selecionados ao painel que estiver a consultar. Se aceder ao assistente através do ecrã "Passos e Variáveis para Painéis de Assistente Touch", a aplicação vai criar os passos selecionados e associá-los ao painel correspondente do passo que estiver a consultar.  
  
  
**Password nos Passos e Variáveis para Painéis de Assistente Touch**    
A partir da v22, no PHC CS Touch manufactor, na gama Executive", no ecrã de "PassosparaPainéisdeAssistenteparaTouch", no separador "Execução" passa a existir a opção Pede password, que permite associar uma senha aos passos e variáveis. Ao ativar esta opção, pode definir de seguida se vai utilizar uma password fixa (opção "Fixa") ou uma password associada a um campo (opção "Campo") do cursor que foi definido no separador "Dados".  
  

  
  
  
[![](images/wtop.gif)](#top)   
**Módulos oferecidos:**  

  
**PHC CS Manufactor**  
A subscrição do PHC On tem agregado uma série de mais-valias, ou seja, se possuir o PHC On ativo com o PHC CS Manufactor passa a contar com os seguintes módulos:  

+ PHC CS Qualidade manufactor
  
+ PHC CS Recursos manufactor
  
+ PHC CS Orçamentos manufactor
  
+ PHC CS Multilingua manufactor
  
+ PHC CS Configurador manufactor
  
+ PHC CS Packing manufactor
  
+ PHC CS Tarefas manufactor
  
+ PHC CS Dashboard manufactor

  
  
**PHC CS Desktop**  
Se possuir o PHC On ativo passa a contar com as seguintes funcionalidades adicionais no PHC CS Desktop:  

+ PHC CS InterOP desktop para quem possuir o módulo PHC CS Contabilidade desktop;
  
+ PHC CS Factoring desktop, para quem possuir o módulo PHC CS Gestão desktop;
  
+ Para quem possuir as gamas Advanced e Enterprise tem direito à validação do módulo PHC CS Dashboard desktop.

  
  
*Nota:* Os módulos adicionais só estarão disponíveis durante o período de subscrição do PHC ON. Quando termina a validade do PHC On, o utilizador deixa de poder trabalhar com estes módulos - independentemente da data do executável.  
  
**PHC CS Web**  
Se possuir a aplicação PHC CS Web terá acesso ao módulo **PHC CS Portal web** que permite criar um site público interativo, atraente e facilmente atualizável mesmo que não saiba HTML.
  
  
Para mais informações clique [aqui](http://www.phcsoftware.com/solucoes/produtos/phc-on/).

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionalidades Exclusivas com Phc On' ) |