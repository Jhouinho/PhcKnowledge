---
title: Funcionamento
source: funcionamento.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamento

Funcionamento

|  |
| --- |
| Funcionamento |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O módulo de Suporte foi desenvolvido para gerir em simultâneo a carteira de clientes, o parque de equipamento, as suas intervenções e os pedidos de assistência técnica.    Assim existem duas áreas principais :      * Gestão do Parque de Equipamento;  * Controlo do dia-a-dia da assistência pós-venda.    Para gerir estas duas áreas o programa está organizado do seguinte modo:     **Gestão do Parque de Equipamento**    **Clientes**  Uma tabela onde se colocam as informações genéricas relativas a cada cliente, nomeadamente nome, morada, nº contribuinte, etc. e que será também a base para a facturação.    **Entidades**  Uma tabela de entidades, para colocar os utilizadores dos equipamentos. Nesta tabela serão colocados os dados genéricos, nomeadamente nome, morada, etc..    **Instalações**  Existe uma tabela onde se define a informação para cada instalação realizada, ou seja, o local onde se encontra, para que cliente e entidade, que equipamento foi instalado, em que situação se encontra (garantia, contrato, etc.).    *Nota:*  A palavra **instalação** pode ser definida pelo utilizador se assim o desejar. Por outro lado, se a área de negócio do utilizador pressupõe que para cada instalação só existe um equipamento, como por exemplo, automóveis, telemóveis, etc.., então pode-se configurar o software para simplesmente não utilizar as instalações, devendo então apenas criar o equipamento do cliente simplificando assim a utilização do programa.    **Equipamentos**  Para cada equipamento pode-se definir todas as suas características, a quem pertence, quando foi vendido, onde se encontra, qual a marca, modelo, etc..    Com este tratamento, sabe-se a qualquer momento o equipamento que se possui, a quem se vendeu e a quem se comprou, permitindo ainda fazer a gestão do equipamento por situação, ou seja, o que está em garantia ou contrato e até quando.    **Controlo do dia-a-dia da assistência pós-venda**    Nesta área existe:    **Pedidos de assistência técnica**  Para qualquer equipamento ou instalação é possível abrir um pedido de assistência técnica. Neste pedido define-se o que o cliente transmitiu, nomeadamente, quem pediu, qual a avaria, qual o equipamento avariado, etc.. Com estes pedidos é possível controlar a qualquer momento o que há para fazer ao nível da assistência técnica.    Os pedidos devem ser impressos. Para tal pode por exemplo criar uma impressão do pedido com todos os seus dados e entregá-la ao técnico que o executará. Na impressão deve existir um espaço para colocar os tempos utilizados, as peças colocadas, etc..    **Folhas de Obra (Dossier Interno)**  As folhas de obra pretendem controlar o que foi colocado no equipamento na assistência realizada, ou seja, as peças colocadas, os tempos utilizados, etc.. Assim, no ato de fecho do pedido, pode abrir uma folha de obra com a informação colocada pelo técnico no pedido, de modo a, e caso possua o módulo Stocks, dar baixa de stock das peças colocadas, valorizar os dados que vão para o historial do equipamento e, se possuir o módulo de Gestão, poder faturar automaticamente a folha de obra.  Se desejar poderá abrir esta folha logo aquando da abertura do pedido.    **Historial de Equipamento**  Ao fechar o pedido, todos os seus dados, bem como os valores da folha de obra, ficam arquivados no historial do equipamento para posterior consulta e estatísticas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento' ) |