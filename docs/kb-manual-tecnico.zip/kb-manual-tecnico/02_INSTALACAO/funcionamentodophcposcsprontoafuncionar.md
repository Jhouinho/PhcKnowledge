---
title: Funcionamentodophcposcsprontoafuncionar
source: funcionamentodophcposcsprontoafuncionar.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodophcposcsprontoafuncionar

Funcionamento do Phc Pos Cs Pronto a Funcionar

|  |
| --- |
| Funcionamento do Phc Pos Cs Pronto a Funcionar |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este capítulo visa explicar o modo de funcionamento do PHC POS CS pronto a funcionar.    Ao entrar na aplicação surge o ecrã de **Assistente de Instalação e Manutenção**. Neste ecrã passam a surgir duas novas opções:  e .    A opção **Nova Empresa** apenas deve ser ativada ao instalar a aplicação pela 1ª vez.  Ao ativar esta opção, deverão ser preenchidos todos os passos para que ao terminar a execução deste assistente a aplicação esteja pronta a funcionar.     Ao clicar em **Otimizar para POS** o assistente passa a ter os seguintes passos: - Passo 1 de 9 - Dados da Empresa  - Passo 2 de 9 - Parâmetros a definir  - Passo 3 de 9 - Criação de Utilizadores  - Passo 4 de 9 - Criação de Famílias  - Passo 5 de 9 - Criação de Artigos  - Passo 6 de 9 - Configurações  - Passo 7 de 9 - Selecionar ficheiros  - Passo 8 de 9 - Operações de reconstrução  - Passo 9 de 9 - Confirmar as seleções anteriores     Se tiver a opção **Otimizar POS** ativa, os dados da empresa e os valores definidos nos parâmetros são preenchidos automaticamente nos *Passos 1 e 2*, respetivamente.  Se nos *Passos 3, 4 e 5* forem criados Utilizadores, Famílias ou Artigos, respetivamente, estes são acrescentados aos que já existem.     O Passo 6 permite definir as **Lojas**, **Terminais de Venda**, **Contas de Tesouraria**, **Configurar Impressoras de Texto**, **Setores** e **Mesas**.   Se não for preenchida nenhuma opção existente neste passo, ao terminar todo processo do assistente são criados dados por defeito para que a aplicação possa funcionar de imediato.      Ao clicar neste botão é aberto o ecrã de [Lojas](tabeladelojas.htm), possibilitando logo definir todas as lojas que irão existir na aplicação.        Neste botão o utilizador terá a possibilidade de registar todos os terminais de venda que irão constar em cada uma das lojas e o seu respetivo funcionamento, sendo aberto o ecrã de [Terminais de Vendas](terminaisdevendas.htm).      Ao clicar neste botão é aberto o ecrã de [Contas de Tesouraria](contasdetesouraria.htm) para que o utilizador possa definir todas as contas.      Este botão abre o ecrã de [Configurações de Impressora](configuraçõesdeimpressoraemmododetexto.htm) onde é possível configurar as impressoras que serão utilizadas..      Este botão apenas está disponível se possuir o módulo PHC Restauração CS.  Ao clicar neste botão é aberto o ecrã de [Setores da restauração](setores.htm), onde o utilizador pode definir quais os espaços físicos existentes na Loja.      Este botão apenas surge se possuir o módulo PHC Restauração CS.  Ao clicar neste botão é aberto o ecrã de [Mesas](mesas.htm) para que o utilizador defina quais as mesas, a sua lotação e o respetivo setor a que pertencem.    No *Passo 7 de 9:* - Selecionar ficheiros" - a opção **Todos (apenas recomendado na instalação de software ou upgrade de versão)** encontra-se selecionada por defeito, não sendo possível alterar. No *Passo 8 de 9:* - "Operações de reconstrução" todas as opções vêm selecionadas e o utilizador não pode desativar nenhuma delas.    Ao clicar em  serão apagadas todas as tabelas que não sejam necessárias para a utilização dos módulos PHC POS Front CS, PHC POS Back CS e PHC Restauração CS, surgindo uma barra com o progresso a indicar qual(ais) a(s) tabela(s) que serão apagadas. Concluindo o processo de eliminação das tabelas, iniciar-se-á o processo normal de instalação e manutenção de rotina para fazer o *upgrade* da versão.    *Nota:* Quando se utiliza este assistente assume-se que a aplicação vai utilizar o sistema de Login Único para efeitos de autenticação na base de dados. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento do Phc Pos Cs Pronto a Funcionar' ) |