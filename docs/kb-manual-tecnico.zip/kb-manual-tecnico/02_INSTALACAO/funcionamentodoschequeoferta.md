---
title: Funcionamentodoschequeoferta
source: funcionamentodoschequeoferta.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodoschequeoferta

Funcionamento dos Cheque Oferta

|  |
| --- |
| Funcionamento dos Cheque Oferta |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico visa explicar a configuração e funcionamento do pagamento via cheque oferta.   Esta funcionalidade apenas está disponível com o  [PHC On ativo](funcionalidadesexclusivascomphcon.htm) e em modo Touch POS.     Para efetuar pagamento com os cheques oferta é necessário efetuar os seguintes passos:    1) Ativar o parâmetro [Utiliza vales de descontos/cheques oferta (reinstalar triggers)](ParâmetrosdoPos.htm#CAMUtiVale);    2) Definir um modo de pagamento que irá estar associado ao cheque oferta no parrâmetro **Modo de pagamento 1, 2, 3, 4, 5, 6**;    3) Escolher o valor definido no ponto anterior no parâmetro **Modo de pagamento a utilizar cheques oferta**;    4) Criar um [artigo](constituiçãodatabeladestockseserviços.htm) referente ao cheque oferta ativando a opção **É uma Refª de Serviços**;    5) Criar um [tipo de vale](tiposdevalesdedesconto.htm) do tipo "Cheque Oferta", definindo no campo **Ref. para faturar** ao artigo criado no passo anterior.      - 1º Exemplo - Referente à venda do cheque oferta:     Na loja existem várias artigos relativos a cheques oferta de diferentes preços. O cheque oferta de 10 não tem a opção **Pede o número do vale** e o cheque oferta de 20 tem esta opção ativa no tabela de [Tipos de Vales de Desconto](tiposdevalesdedesconto.htm).    O Cliente XPTO quer comprar dois cheques oferta para oferecer a um familiar, um de 10 e outro de 20.    No ecrã de Faturação ao escolher o cheque oferta de 10, a coluna "Número cheque oferta" é preenchida automaticamente porque na configuração a opção**Pede o número do vale** não está ativa e ao selecionar o artigo cheque oferta de 20, surge um novo ecrã para introduzir o número do cheque oferta.       - 2º Exemplo - Referente ao pagamento com cheque oferta:     O Cliente AEIOU, familiar do cliente XPTO, quer comprar um artigo e pretende pagar com cheque oferta de 10 que recebeu.    Após emitir a Fatura, ao escolher o modo de pagamento apenas é necessário clicar em **Cheque Oferta** e automaticamente é pedido ao operador para digitar o número do cheque oferta  e automaticamente o modo de pagamento respetivo é preenchido com o valor do cheque oferta que foi utilizado.         Posteriormente é possível verificar no ecrã de [Vales de desconto](valesdedesconto.htm) qual o documento de faturação onde o cheque oferta foi utilizado:            *Notas:* - Quando se usa [tesouraria resumida](tesourariaresumidanopos.htm), os valores registados no modo de pagamento definido como sendo de cheques oferta, não são lançados na tesouraria.     O mesmo acontece quando não se usa tesouraria resumida, onde é feito o lançamento da diferença entre o valor total do documento e o valor registado em cheques oferta.  - Apenas é gerado um cheque oferta por cada linha de um documento de faturação - independentemente de agrupar ou não referências e da quantidade.  - O Cheque Oferta é impresso automaticamente após imprimir a Fatura referente à sua venda e a [impressão](impressõesdefinidaspeloutilizador(idu).htm) utilizada para o vale é a mesma que foi definida no ecrã de [Vales de desconto](valesdedesconto.htm). Assim se o IDU utilizado para imprimir a Fatura for em modo texto, o IDU para o Vale de Desconto também deverá ser em modo texto. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento dos Cheque Oferta' ) |