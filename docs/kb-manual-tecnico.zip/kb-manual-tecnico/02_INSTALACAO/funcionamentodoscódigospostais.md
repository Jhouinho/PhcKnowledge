---
title: Funcionamentodoscódigospostais
source: funcionamentodoscódigospostais.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodoscódigospostais

Funcionamento dos Códigos Postais

|  |
| --- |
| Funcionamento dos Códigos Postais |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Código Postal**  O Software **PHC** tem instalado a tabela dos códigos postais o que permite trabalhar de duas formas diferentes.  A primeira forma de trabalhar é através da digitação do código postal no respectivo campo, pois à medida que o utilizador vai escrevendo os números, o programa vai propor um determinado código, exemplo: se digitar apenas "2" o código proposto é "2000-011 SANTARÉM", mas se digitar "26" o código proposto já é "2600-011 VILA FRANCA DE XIRA".   Por outro lado é possível pesquisar os códigos postais nacionais. Para executar esta operação basta colocar o nome da Localidade (exemplo: Lousa) no campo antes do código postal. Seguidamente, ao pressionar o botão **Escolher um código postal** e depois clicar em **Procurar** será apresentada uma janela com os possíveis códigos postais (ver exemplo).    Se no entanto não souber a localidade nem o código postal, então poderá utilizar a opção **Pesquisa por:** que permite procurar um código postal por Freguesia/Localidade ou por Arruamento ou ainda pelo Número do código postal.    A página **Actualizar** permite a introdução de novos dados ou alteração de códigos já existentes. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento dos Códigos Postais' ) |