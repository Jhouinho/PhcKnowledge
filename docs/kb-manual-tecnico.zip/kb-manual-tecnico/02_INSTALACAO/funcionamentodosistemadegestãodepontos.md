---
title: Funcionamentodosistemadegestãodepontos
source: funcionamentodosistemadegestãodepontos.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodosistemadegestãodepontos

Funcionamento do Sistema de Gestão de Pontos

|  |
| --- |
| Funcionamento do Sistema de Gestão de Pontos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este capítulo visa explicar o funcionamento do sistema de gestão de pontos, exemplificando o respetivo modo de funcionamento.  Este sistema tem como objetivo a atribuição de um conjunto de pontos ao cliente, que por sua vez poderá usufruir de um atendimento prioritário no atendimento.    Para utilizar este sistema o parâmetro [Utiliza sistema de gestão de pontos de suporte (reinstalar triggers)](ParâmetrosDosPedidosDeAssistência.htm#CAMpgestaop) tem que estar ativo.    Os pontos podem ser debitados ao introduzir ou ao fechar um Pedido de Assistência, consoante o parâmetro [Consome pontos só no fecho do Pedido de Assistência](ParâmetrosDosPedidosDeAssistência.htm#CAMConsumopontos) esteja inativo ou ativo respetivamente, e tem por base dois fatores: [prioridade](ConstituiçãoDaTabelaDePats.htm#camprior) e [tipo de técnico](ConstituiçãoDaTabelaDePats.htm#camtipotecnico).    Para utilizar o sistema de gestão de pontos é necessário:    a) Definir o número de pontos do saldo inicial do cliente e [lançar](OpçõesDisponíveisnoMenudeClientes.htm#camlancarsi) em conta corrente. Poderá ser lançado o saldo inicial apenas para um cliente ou para todos os clientes que tenham o número de pontos já definidos.  Ao lançar o saldo inicial é criado um movimento na tabela de **Movimentos de Conta Corrente de Pontos** referente ao saldo inicial, este movimento cria um lote de pontos cuja validade é definido de acordo com o [número de dias definido no parâmetro](ParâmetrosDosPedidosDeAssistência.htm#camvalidade).  Por exemplo: ao lançar o saldo inicial no dia 01.04.2014 é criado um lote com o número de pontos iniciais cuja data de validade é 01.04.2015, pois o parâmetro assume 365 dias por defeito.    b) Definir as prioridades, através de um duplo-clique em cima do campo [prioridades](ConstituiçãoDaTabelaDePats.htm#camprior) do ecrã de Pedidos de Assistência. Depois de se clicar nesse local é apresentado uma tabela **Prioridade de resposta utilizada.** Nesta tabela deverão ser criadas todas os prioridades.        c) Definir todos os tipos de técnicos no ecrã de **Tipos de Técnicos**. Neste ecrã é ainda possível definir se o técnico é um técnico especialista numa área.   Por exemplo: um técnico especialista em áudio.         d) Definir o número de pontos na [Matriz de Pontos](constituiçãodatabeladematrizdepontos.htm) a aplicar consoante a prioridade e o tipo de técnico definido no pedido de assistência.  Nesta grelha aparecem todas as prioridades e os tipos de técnicos existentes.        e) Definir os [códigos de movimentos de pontos](constituiçãodatabeladecódigosdemovimentosdepontos.htm) que irão ser utilizados nos pedidos de assistência. Em cada código é possível definir o número de pontos a atribuir quando esse código é movimentado, ou definir que o número de pontos apenas é definido ao atribuir este código num pedido de assistência.          **Consumo de Pontos**    Ao introduzir um pedido de assistência se o parâmetro **Obriga a ter saldo de pontos positivo para criar novo Pedido de Assistência** estiver ativo não é possível inserir o pedido caso o cliente já não tenha pontos ou o número de pontos não seja suficiente para o movimento a efetuar. Se o parâmetro estiver inativo, não é validado o número de pontos do cliente.    Ao criar um pedido de assistência deve ser definida a prioridade e o tipo de técnico que se deseja atribuir a esse pedido.  Se o consumo de pontos for ao introduzir o pedido de assistência, ao definir o código é criado um movimento de pontos na tabela **Conta Corrente de Movimentos de Pontos**, se o consumo apenas for ao encerrar, o movimento só é criado quando o pedido é encerrado pelo técnico.         O consumo de pontos que será utilizado no movimento é calculado da seguinte forma: - se o número de pontos for definido no pedido de assistência, o movimento é criado com esse número;  - se no pedido de assistência o número de pontos for 0, mas estiver definido no código de movimento o número de pontos, é utilizado esse;  - se no pedido de assistência e no código do movimento o número de pontos for 0, é utilizado o número de pontos definidos na matriz.     A qualquer momento pode ser visualizado o extrato de movimentos que o cliente tem, utilizando a opção [Extrato de movimentos de conta corrente de pontos deste cliente](OpçõesDisponíveisnoMenudeClientes.htm#camextratoccp). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento do Sistema de Gestão de Pontos' ) |