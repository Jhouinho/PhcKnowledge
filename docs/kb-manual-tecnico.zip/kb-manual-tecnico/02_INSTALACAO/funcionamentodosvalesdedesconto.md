---
title: Funcionamentodosvalesdedesconto
source: funcionamentodosvalesdedesconto.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodosvalesdedesconto

Funcionamento dos Vales de Desconto

|  |
| --- |
| Funcionamento dos Vales de Desconto |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico visa explicar a configuração e funcionamento dos Vales de Desconto. A utilização de Vales de Desconto apenas está disponível com o  [PHC On ativo](funcionalidadesexclusivascomphcon.htm) e em modo Touch POS.    Para ativar esta funcionalidade devem ser efetuados os seguintes passos:     1) Ativar o parâmetro [Utiliza vales de descontos/cheques oferta (reinstalar triggers)](ParâmetrosdoPos.htm#CAMUtiVale);    2) Recriar as [Zonas Touch](opçõesdaszonastouch.htm) para que o botão  passa a surgir nas [Opções do Documento](IntroduçãodeDocumentosemTouch.htm#mpszonapageframe);    3) Configurar uma série de faturação para promoções com a opção **Ao introduzir atualiza promoções**;    4) Configurar uma série de faturação para descontos com a opção **Calcula descontos por quantidade ou valor Just in Time**;    5) Garantir a correta manutenção das tabelas de IDUS, para isso aceda ao ecrã "Instalação e Manutenção", selecione o botão **Apenas IDUS**, ative a opção **re-instalar triggers** e clique no botão **Instalar os ficheiros Selecionados**. Para concluir esta configuração, saia e volte a entrar na aplicação.       Antes de descontar um vale numa venda é necessário que tenham já sido emitidos e impressos os [vales de desconto](valesdedesconto.htm).      Exemplo:    A nossa loja enviou a todos os clientes que fazem anos no próximo mês um de 15% de desconto para comprar superiores a 20.        Certo dia o cliente vem efetuar compras à loja e traz esse vale de desconto para que o operador desconte esse vale.    No momento da venda, após escolher o(s) artigo(s), o operador apenas necessita de aplicar o vale de desconto:        Ao clicar no botão **Vales de descontos** surge o ecrã para digitalizar o código do vale, podendo o operador digitalizar o número manualmente ou lendo o código de barras do vale:        Automaticamente o desconto é aplicado no documento de faturação:        Posteriormente é possível verificar no ecrã de **[Vales de desconto](valesdedesconto.htm)** qual o documento de faturação onde o vale de desconto foi aplicado:          *Notas:* - Um vale de desconto em percentagem é considerado um desconto comercial. Um desconto em valor que se aplique a todos os artigos é considerado um desconto financeiro.    O cálculo dos descontos é idêntico ao cálculo efetuado na opção "Descontos".     Um vale de desconto em valor que se aplique a um artigo, ou determinada família, é considerado um desconto unitário em valor nas linhas do documento, sendo controlado se o valor mínimo (unitário) do vale de desconto é inferior ao preço de venda unitário.    O desconto em valor nas linhas só é visível quando o respetivo documento de faturação está configurado para o efeito.  - Os vales de descontos devem ser aplicados apenas no final da venda e antes do pagamento, pois não é controlado se depois da aplicação dos vales são eliminadas linhas onde foram aplicados os vales.  - Os vales de descontos são cumulativos, ou seja, são acumuláveis com outros descontos.  - O vale de desconto é impresso automaticamente após imprimir a Fatura respetiva e a [impressão](impressõesdefinidaspeloutilizador(idu).htm) utilizada para o vale é a mesma que foi definida no ecrã de [Vales de desconto](valesdedesconto.htm). Assim se o IDU utilizado para imprimir a Fatura for em modo texto, o IDU para o Vale de Desconto também deverá ser em modo texto. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento dos Vales de Desconto' ) |