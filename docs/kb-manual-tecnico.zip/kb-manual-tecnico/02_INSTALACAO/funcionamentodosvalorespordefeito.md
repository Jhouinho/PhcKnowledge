---
title: Funcionamentodosvalorespordefeito
source: funcionamentodosvalorespordefeito.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentodosvalorespordefeito

Funcionamento dos Valores por Defeito

|  |
| --- |
| Funcionamento dos Valores por Defeito |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| **Valores por defeito**    Para poder utilizar os valores por defeito é necessário activar a respectiva opção nos [Parâmetros Gerais](ParâmetrosGerais.htm#vdefeito).    No seguinte exemplo definiu-se que ao inserir um novo cliente (assim que começa a introduzir) é preenchida a Zona (CL.ZONA) com o valor Lisboa.         Para definir um valor por defeito é necessário definir a **tabela** (CL, AG, PC, etc.) e o **campo** pretendido (CL.ZONA, ST.PV1, FT.TOTAL, etc.).    De seguida deve-se definir a altura em que o campo é preenchido: **assim que se começa a introduzir** os dados, ou seja, na abertura do novo registo, ou **apenas quando se manda gravar** o registo.    A atribuição de um valor por defeito pode ser feito de três formas diferentes:     * atribuição de um valor. Esta opção permite atribuir um valor fixo ao campo, como por exemplo: quando se abre ou grava um artigo, preencher o campo da Família com "Informática", ou ao gravar um cliente preencher o campo do Segmento de Marcado com "Médio", etc.  * execução de um comando x-base. Desta forma é possível definir um valor segundo uma determinada condição, por exemplo. Isto significa que o valor por defeito só é utilizado quando a expressão indicada for verdadeira.      No seguinte exemplo é preenchido o campo "Referência" da tabela ST (stocks e serviços), com um número sequencial.        Execução de um comando transact-sql. Esta opção funciona de forma idêntica à anterior, mas com comandos de transact-sql.  Os últimos dois campos mencionados de programação têm uma funcionalidade que permite a procura rápida e introdução directa de nomes de campos.   Para tal, é necessário, com um clique direito sobre o campo, seleccionar a opção [Introduzir Campos de Tabelas](dicionáriodedados.htm).    Ao utilizar um comando transact-sql poderá também activar a opção **É um default no server**, esta opção não é mais que criar por defeito um valor directamente na tabela do servidor, assim sempre que criar um registo, o campo respectivo apresentará o valor por defeito criado.   Após criar ou apagar um valor por defeito que utilize esta opção, deverá ir à instalação e manutenção e correr a opção "Verificar os defaults", para assumir fisicamente o default na tabela do servidor.  Exemplo:  Criar um valor por defeito à tabela BO ao campo BO.ZONA com a opção default no server activa. Depois de criar o valor por defeito corro a instalação e manutenção, apartir desta altura na minha tabela BO passarei a ter o campo zona com o valor por defeito pretendido.  Ao gravar um registo na tabela BO, o campo zona apresentará sempre o valor por defeito.  Depois vou eliminar o registo do valor por defeito.   Ao voltar novamente à tabela BO, o campo zona continuará a apresentar o valor por defeito, porque após eliminar o registo do ecrã dos valores por defeito não corri a instalação e manutenção para alterar o default do server.          *Nota:*  A diferença entre a utilização do comando x-base e o comando transact-sql reside na forma como a instrução é executada. Se a instrução vai ser executada sobre dados que estão no **posto de trabalho**, então deverá ser utilizado um comando x-base. Caso os dados a afectar estejam no **servidor**, será necessário recorrer a um comando transact-sql. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento dos Valores por Defeito' ) |