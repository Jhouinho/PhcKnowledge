---
title: Funcionamentoeconfiguraçãodavalorizaçãodestock
source: funcionamentoeconfiguraçãodavalorizaçãodestock.htm
tipo: Manual Técnico
idioma: PT
---

# Funcionamentoeconfiguraçãodavalorizaçãodestock

Funcionamento e Configuração da Valorização de Stock

|  |
| --- |
| Funcionamento e Configuração da Valorização de Stock |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico tem como principal objectivo explicar o funcionamento e as configurações necessárias para trabalhar com a Valorização de Stocks por Data e Hora.    Desta forma, propomos que siga os seguintes passos que indicam as configurações e o modo de funcionamento da valorização de stocks por Data e Hora.      **1º PASSO - Definir os Parâmetros**  Deve começar por activar o [parâmetro](ParâmetrosDeStocksEServiços.htm#PLRValoriza) **Utiliza valorização de Stocks por Data e Hora quando o custeio de stock é «Preço de Custo Ponderado» (re-instalar triggers)**, colocar o [parâmetro](ParâmetrosDeStocksEServiços.htm#mpspcutil1) **Custeio de Stocks (re-instalar triggers)** com **Preço de Custo Ponderado** e o [parâmetro](ParâmetrosDeStocksEServiços.htm#PLRpcp) **Utiliza o pr.custo ponderado do último Inventário Físico, na correcção de erros e actualização do custo das vendas (apenas quando o custeio de stock é «Preço de Custo Ponderado»)** inactivo.      **2º PASSO - Preenchimento da Hora**  Com a configuração definida no passo anterior, fica disponível o campo **Hora para Stock** nos ecrãs que geram movimentos de stock, isto é:   - Documentos de Facturação configurados como "Lança os movimentos em stock";  - Documentos de Compras configurados como "Lança em stocks com o código «X»" ou "Lança como valor em stocks" ou "Lança como valor em stocks pela diferença para a entrada física, com o código «X»";  - Dossiers Internos configurados como "Movimenta stocks";  - Inventário Físico;     Este campo é preenchido por defeito com a hora actual, sendo permitido alterá-lo.  No ecrã de Movimentos de Stocks e no ecrã de Movimentos de Valor em Stocks também fica disponível o campo **Hora**.  Ao gravar o Documento nestas condições é gerado um Movimento de Stock ou Movimento em Valor com o campo **Hora** preenchido com o valor introduzido no campo **Hora para Stock** do Documento.     Estas configurações também se aplicam a documentos que estão disponíveis no PHC CS Web Intranet.  No PHC CS Web Extranet o campo **Hora para Stock** não aparece visível, mas é preenchido por defeito com a hora actual para os documentos configurados como indicado anteriormente.    O campo **Hora para Stock** também não está visível nos ecrãs em que se introduzem Dossiers Internos e Documentos de Facturação específicos para os módulos de POSFront, TouchPOS e Restauração, mas é preenchido por defeito com a hora actual.    O Monitor de Transformações de Transacções do módulo Estações de Serviço, passa a importar o campo **Hora da Transacção** para o campo **Hora** dos documentos gerados e dos Movimentos de Stock lançados. Quando esta funcionalidade está activa, o campo **Hora para Stock** fica visível e o campo **Hora** usado pelo módulo fica invisível para os documentos configurados como indicado acima.      **3º PASSO - Consultar a Lista de Movimentos**  Posteriormente, pode consultar a lista de movimentos ordenada por hora no Extracto de Movimentos de Artigos, no Inventário de Stocks, no Inventário Físico e na Rotina de Correcção de Erros no Stock.  Para os Movimentos de Stock e para os Movimentos de Valor em Stocks, que não tenham o campo **Hora** preenchido, é utilizado o campo que guarda a hora de criação do registo (ousrhora). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funcionamento e Configuração da Valorização de Stock' ) |