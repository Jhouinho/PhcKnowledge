---
title: Funções
source: funções.htm
tipo: Manual Técnico
idioma: PT
---

# Funções

Funções

|  |
| --- |
| Funções |

|  |
| --- |
| Nesta área a aplicação pretende promover o refinamento sucessivo dos requisitos de cada função, por forma a estabelecer padrões de exigência mínimos no desempenho dos seus colaboradores. Neste capítulo será explicado o funcionamento da respectiva [tabela](constituiçãodatabeladefunções.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funções' ) |