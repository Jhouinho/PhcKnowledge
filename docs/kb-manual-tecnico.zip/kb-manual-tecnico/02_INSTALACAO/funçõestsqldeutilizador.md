---
title: Funçõestsqldeutilizador
source: funçõestsqldeutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Funçõestsqldeutilizador

Funções Tsql de Utilizador

|  |
| --- |
| Funções Tsql de Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite que o utilizador possa criar as suas funções de Transact-Sql no próprio servidor de SQL, a partir do software PHC.  Essa possibilidade já existia anteriormente, pois bastava usar a função U\_SQLEXEC para executar uma dessas funções em sítios que se podia programar xbase, ou então usar a função directamente em sítios que permitissem programar em TSQL.  O objectivo desta funcionalidade é evitar a duplicação de código em vários locais da aplicação. Assim se o código for o mesmo em vários locais, cria-se uma função que poderá ser usada nos vários locais da aplicação.      **Nome**  Permite indicar o nome da função Transact-Sql em questão.    **Classificação**  Permite criar uma classificação associada a função em questão.    **Inactiva**  Ao activar esta opção a função em questão será descactivada. Após activar esta opção deverá correr a instalação e manutenção ou a opção de menu para efectivar a desactivação da função.    **Expressão da função em Transact-Sql**   Este campo permite escrever o contéudo da expressão da função em causa.  Esta expressão deverá conter a seguinte sintaxe:  CREATE FUNCTION [ owner\_name. ] function\_name   ( [ { @parameter\_name [AS] scalar\_parameter\_data\_type [ = default ] } [ ,...n ] ] )     RETURNS scalar\_return\_data\_type    [ WITH < function\_option> [ [,] ...n] ]     [ AS ]    BEGIN   function\_body   RETURN scalar\_expression  END      *Nota:*  Após criado o registo no ecrã de funções, o mesmo deverá ser criado no servidor, para tal poderá utilizar as opções que se encontram disponíveis nas opções de menu do respectivo ecrã ou então através do botão **Instalar as funções TSQL de utilizador**, que se encontra disponível no ecrã de [Instalação e Manutenção](Funcionamentodainstalaçãoemanutenção.htm#mpsftsql).        **Opções Disponíveis no menu de Funções TSQL de Utilizador**   Para correr uma destas opções é necessário que o utilizador tenha acesso no servidor de SQL de criar Tabelas, Triggers, etc.  **Criar/Recriar esta função no servidor**  Esta opção permite criar ou alterar a função no servidor.    **Apagar esta função no servidor**  Esta opção permite apagar a função no servidor.        **Funcionamento das Funções de Utilizador:**  Depois de criar a sua função, preenchendo todos os campos anteriormente mencionados, poderá utilizar o código criado quando estiver a escrever determinada expressão, por exemplo nos eventos, análises avançadas, regras, campos livres do idu. No respectivo campo que guarda a expressão podemos fazer duplo clique para abrir um editor de expressões em formato programa.  Nesse editor, ao clicar no clique direito do rato poderá aceder à opção de Introduzir Funções T-SQL de Utilizador, podendo assim seleccionar a função pretendida.      *Exemplo:*  Esta função permite verificar o utilizador que está a entrar no sistema.  CREATE FUNCTION dbo.User\_CheckPe\_Stamp (@UsPeStamp as char(25), @PeStampToCheck as char(25))  RETURNS bit AS  BEGIN  Declare @lResult as bit  Set @lResult = 0    Declare @cFindStamp as char(25)  Set @cFindStamp = ' '    WHILE 1=1  Begin  if @UsPeStamp = @PeStampToCheck  begin  set @lResult = 1  break  end  else  begin  Set @cFindStamp = (Select u\_rpestamp from pe (nolock) where pe.pestamp=@PeStampToCheck)    if (isnull(@cFindStamp,'') = '')  break  else  begin  if (@cFindStamp = @UsPeStamp)  begin  set @lResult = 1  break  end  else  set @PeStampToCheck = @cFindStamp  end  end  End  Return @lResult  END      *Nota:*  Sempre que uma Função de Utilizador do SQL Server é criada pela aplicação, é-lhe imediatamente atribuída permissão de execução pelo role Public, o que faz com que utilizadores pertencentes a este role a possam executar. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Funções Tsql de Utilizador' ) |