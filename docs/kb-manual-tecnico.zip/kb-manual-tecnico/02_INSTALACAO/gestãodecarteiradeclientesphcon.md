---
title: Gestãodecarteiradeclientesphcon
source: gestãodecarteiradeclientesphcon.htm
tipo: Manual Técnico
idioma: PT
---

# Gestãodecarteiradeclientesphcon

Gestão de Carteira de Clientes Phc On

|  |
| --- |
| Gestão de Carteira de Clientes Phc On |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Foi desenvolvido um novo ecrã que permite gerir a carteira de Clientes com um acordo PHC On ativo.  No menu "Encomendas" há uma nova opção, com o nome "Renovação do PHC On". Este ecrã apenas está disponível para utilizadores com acesso de supervisão.         O ecrã apresenta a possibilidade de ver as instalações pela ordenação preferida e por procuras nos vários campos apresentados.  Nesta listagem são apresentadas as subscrições de Clientes com PHC On ativo que lhe estão associadas e que serão alvo de renovação automática.   Associado a cada subscrição tem o valor previsto de PHC On. Pode também consultar o detalhe da subscrição. Os valores apresentados não incluem IVA nem qualquer desconto de que a subscrição possa beneficiar.         Neste ecrã pode ainda executar duas operações sobre as subscrições em função de determinadas datas:  - Cancelar a renovação automática do acordo PHC On (desde o 120º dia do acordo ao último dia útil do mês -2 relativamente ao mês da subscrição do PHC On);  - Solicitar emissão de Nota de Crédito da renovação PHC On, desde a emissão da fatura até ao início do novo acordo (desde que não tenha sido ativada nenhuma ficha da renovação).     Em qualquer uma das situações deve indicar qual o motivo para o seu pedido. Este pedido carece de validação pela PHC.     **Cancelamento do acordo PHC On**   Para o cancelamento da renovação do PHC On deve preencher os dados solicitados, sendo que este pedido está sujeito à validação da PHC.   Caso pretenda alterar os módulos envolvidos na renovação do PHC On deve solicitar o cancelamento da renovação automática e colocar uma nova encomenda com o PHC on pretendido. Nesta altura poderá utilizar a opção "Reativação do PHC On ", descrita nos próximos pontos.         **Devolução da renovação do PHC On**   Para a devolução da renovação do PHC On deve preencher os dados solicitados, sendo que este pedido está sujeito à validação da PHC.         **Reativação do PHC On**   Caso pretenda reativar o acordo de um Cliente que tenha cancelado ou devolvido pode utilizar nas encomendas a opção "Reativar acordo PHC On", disponível no separador "Dados do Cliente". Deve então preencher o NIF do Cliente. Caso este NIF pertença a um Cliente associado ao Parceiro e que já teve um acordo PHC On, que entretanto cancelou, será incluído nos artigos uma sugestão de encomenda. Esta sugestão de encomenda deve ser validada pelo Parceiro e deve ter em atenção as Condições de Comercialização em vigor. Esta sugestão não valida a encomenda, apenas pretende facilitar o processo de criação de encomenda. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Gestão de Carteira de Clientes Phc On' ) |