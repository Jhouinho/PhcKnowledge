---
title: Gráficodegantt(Funcionários)
source: gráficodegantt(funcionários).htm
tipo: Manual Técnico
idioma: PT
---

# Gráficodegantt(Funcionários)

Gráfico de Gantt (funcionários)

|  |
| --- |
| Gráfico de Gantt (funcionários) |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Durante a produção de um bem são vários os fatores que através da sua presença, uso ou simples existência, afetam de forma preponderante a fabricação.     Um dos fatores principais é o fator humano. Em certas produções a falta de um determinado funcionário implicará que determinada operação não poderá ser realizada, pelo que o controlo desta disponibilidade vai afetar a capacidade da empresa para responder às necessidades dos seus clientes.     É precisamente nestes casos que o gestor necessita de uma ferramenta rápida, eficiente e intuitiva, que possa disponibilizar o tempo de trabalho já ocupado de cada um dos recursos de mão-de-obra que possui, ou mesmo validar formas de otimizar os tempos de trabalho desses mesmos recursos, por exemplo, colocar o funcionário X na operação Y para substituir o funcionário A que hoje não está presente.    O PHC Manufactor CS possui tal ferramenta. Esta encontra-se disponível sobre o menu Planeamento, Outras opões de Planeamento gráfico, opção "**Por funcionários** ".     Esta ferramenta gráfica está disponível desde que as seguintes premissas estejam cumpridas:    - Existência de licenças do [Módulo Planning](móduloplanning.htm).  - Parâmetro de planeamento [Ativar Análise de Capacidade](Parâmetros-OpçãoPlaneamento.htm#rvactivaranalisedecapacidade).  - Parâmetro de planeamento [Incluir cálculo de capacidade de mão de obra nas rotinas de planeamento](Parâmetros-OpçãoPlaneamento.htm#rvincluircalculocapacidademaodeobra).    Estando na presença destas 3 condições, é apresentado um acesso sobre o menu principal de planeamento.      **Como deverá interpretar o Gráfico de Gantt (Funcionários)?**    Tal como o planeamento gráfico da aplicação, a representação não é mais que um Gráfico de Gantt, no entanto, este apresenta a informação sobre a ótica do funcionário.    Este método de visualização é uma forma bastante rápida e eficiente de dar à interpretação a forma como o tempo de um funcionário se encontra alocado.   Tendo por base esta informação (que no caso é global no que se refere aos funcionários), permite que o gestor rapidamente rearranje a forma como os seus recursos, mão-de-obra, são usados libertando ou alocando conforme as necessidades ou requisitos da operação, sempre sobre a ótica da mão-de-obra.    O gestor pode sentir a necessidade por vezes no seu trabalho de alterar no planeamento de uma operação o funcionário atribuído. Neste caso, o responsável (planeador) pode efetuar a movimentação de funcionários de acordo com as presenças atuais e de acordo com a situação do dia.    Para tal, basta selecionar a operação em causa, fazer clique direito do rato, e escolher a opção "**Mudar de funcionário**".    Se ativar a opção "**Permite apenas funcionários disponíveis na operação**" ao clicar no botão para escolha do funcionário, a aplicação apenas apresenta os funcionários exclusivos dessa operação.Caso contrário, ao clicar no botão para escolha do funcionário, a aplicação apresenta uma listagem com todos os funcionários existentes.       Ao alterar um funcionário é verificada a disponibilidade do novo funcionário. Se tiver disponibilidade no período indicado a aplicação aceita a substituição, caso contrario não deixa movimentar e avisa o utilizador para esse efeito através da seguinte mensagem:    *"O funcionário indicado não tem disponibilidade para todo o período necessário."*      *Nota*: Esta ferramenta gráfica poderá ser um valor acrescentado para organizações que trabalhem por projeto as quais possuam equipas alocadas a "sites" externos. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Gráfico de Gantt (funcionários)' ) |