---
title: Guardar Informação Numérica Indexada a Determinada Data
source: guardarinformaçãonuméricaindexadaadeterminadadata.htm
tipo: Manual Técnico
idioma: PT
---

# Guardar Informação Numérica Indexada a Determinada Data

Com o objetivo de poder guardar informação numérica indexada a determinada data e passível de podermos obter gráficos de análises foram criadas funcionalidades internas na gama PHC CS Enterprise.
Assim, foi criada uma tabela de numeradores chamada ENU, na qual para um código, uma data e hora, podem ser guardados de uma forma muito simples até 10 valores. Isto irá permitir que em alertas, eventos, ou outro código do utilizador o implementador possa guardar num determinado local usando apenas a função
ENUINTRO
os valores que necessita de um determinado dia.
Da mesma forma existe uma função ENUINTROMES que guarda e atualiza valores referente a um determinado mês/ano.
Para obter um gráfico e colocá-lo em conteúdos HTML ou num email em HTML, pode-se criar um cursor com os dados que se pretende, o qual pode ser baseado nesta tabela de numeradores ou em qualquer tabela do sistema. Com a função gChart irá obter uma imagem baseada na API de gráficos da PHC, que desde que tenha acesso à internet, mostrará ao utilizador um gráfico que pode ser de vários tipos (Gauge, linhas, barras, etc).
Assim, pode analisar de uma forma mais simples e intuitiva evoluções temporais de determinados indicadores no Software PHC.
Exemplo:
Alerta - Nomes de clientes que adquiriram Software PHC nas últimas semanas:
LOCAL msel,retval
local madv,mcor,mtri,mfx,ment
store 0 to madv,mcor,mtri,mfx,ment
retval=""
msel="select sn.sntipo,sn.nome,sn.clnome from sn where sn.ousrdata>=dateadd(dd,-8,getdate()) order by sn.sntipo,sn.nome"
LOCAL mgtotal
mgtotal=0
IF
u_sqlexec
(msel,"temph")
select temph
goto top
scan
if "advanced" $ lower(temph.sntipo)
madv=madv+1
endif
if "corporate" $ lower(temph.sntipo)
mcor=mcor+1
endif
if "enterprise" $ lower(temph.sntipo)
ment=ment+1
endif
if "phc fx" $ lower(temph.sntipo)
mfx=mfx+1
endif
if "trial fx" $ lower(temph.sntipo)
mtri=mtri+1
endif
endscan
declare list_tit(3),list_cam(3),list_pic(3)
list_tit(1)="Cliente"
list_cam(1)="temph.nome"
list_pic(1)=""
list_tit(2)="Software"
list_cam(2)="temph.sntipo"
list_pic(2)=""
list_tit(3)="Agente"
list_cam(3)="temph.clnome"
list_pic(3)=""
retval=retval+listtohtml("temph","Clientes que adquiriram software PHC na última semana em "+dtoc(date()),2,,.t.)
fecha("temph")
endif
enuintro
(.t.,"Instalacoes Semana","Instalacoes Semana",date(),time(),"Corporate",mcor,"Advanced",madv,"Enterprise",ment,"PHC FX",mfx,"Trial FX",mtri)
if
u_sqlexec
("select top 15 val1,val2,val3,val4,val5,data from enu (nolock) where codigo='Instalacoes Semana' order by data desc","temp1enu")
select temp1enu
index on data tag data
goto top
local mret
mret="<center><table><tr><td>"
mret=mret+gchart("110x110","Corporate","lc","25,10","temp1enu","temp1enu.val1","substr(dtoc(temp1enu.data),1,2)")
mret=mret+"</td><td>"
mret=mret+gchart("110x110","Advanced","lc","25,10","temp1enu","temp1enu.val2","substr(dtoc(temp1enu.data),1,2)")
mret=mret+"</td><td>"
mret=mret+gchart("110x110","Enterprise","lc","25,10","temp1enu","temp1enu.val3","substr(dtoc(temp1enu.data),1,2)")
mret=mret+"</td><td>"
mret=mret+gchart("110x110","PHC FX","lc","25,10","temp1enu","temp1enu.val4","substr(dtoc(temp1enu.data),1,2)")
mret=mret+"</td><td>"
mret=mret+gchart("110x110","Trial FX","lc","25,10","temp1enu","temp1enu.val5","substr(dtoc(temp1enu.data),1,2)")
mret=mret+"</td></tr></table>"
retval=mret+"</center><br><br>"+retval
endif
RETURN retval
select top 15 val1,val2,val3,val4,val5,data from enu (nolock) where codigo='Instalacoes Semana' order by data desc
