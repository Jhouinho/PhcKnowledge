---
title: Hardware e Software Recomendado Web
source: hardwareesoftwarerecomendadoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Hardware e Software Recomendado Web

Para garantir que a aplicação funcione corretamente, disponibilizamos este documento que indica as caraterísticas mínimas recomendáveis nas plataformas atuais.
1. Servidor Web (PHC CS WEB gamas Corporate, Advanced, Enterprise)
Ter PHC CS Desktop licenciado e conexão com a base dados SQL Server do PHC CS Desktop;
Disco SATA 7200 RPM e 500 GB;
Processador dual core de 64 bits a 1,4 GHz (mínimo)
Software Anti-virus;
Ligação Internet de Banda Larga;
Sistema operativo Microsoft Window 8, 8.1 ou Windows 10 (versões profissionais) 32/64 Bits;
Sistema operativo Microsoft Windows 2012 Server, Microsoft SQL Express 2012 ou superiores (32/64 Bits);
IIS (Internet information Server) versão 8 no mínimo;
.Net Framework 4.6.2;
4 Gb de ram (versões não server) e 8 Gb mínimo nas versões Windows Server;
Placa de rede 1 Gbps;
Ups (fonte de alimentação para falhas de energia);
Endereço IP fixo na ligação Internet ou Domínio (depende do licenciamento PHC Adquirido).
Algumas recomendações adicionais
Sistema operativos não servidores (Ex: Windows 8.1 Pro);
O IIS nas versões não servidor (ex: Windows Server) estão limitadas até 10 requests em simultâneo por parte dos clientes em browser. Nas versões servidor não existe limitação.
Recomendação de segurança de dados
Recomenda-se o servidor IIS não esteja no mesmo computador do servidor PHC CS Desktop (SQL Server). Como o servidor Web vai estar conectado à Internet publica a probabilidade de ataques é superior pelo que ao estar separado do servidor de dados também a performance do servidor de SQL vai ser superior;
Recomenda-se também a proteção de routing de portas no firewall da rede desde a Internet para a Intranet.
Memória Ram
A quantidade de memória RAM depende de vários fatores, quanto mais melhor, principalmente por causa da paginação (memória virtual do Sistema operativo) que é usada para cache do servidor IIS.
Quanto mais requests dos clientes então deve-se ponderar a adição de mais RAM.
CPU
Processadores multi-core são preferíveis isto porque o Sistema operativo pode repartir melhor os processos.
Disco rígido (HDD)
No PHC CS WEB existem funcionalidades que permitem armazenar imagens e utilizar serviços de FTP (Ex: PHC CS Documentos web) e neste caso deve-se ter espaço no disco do servidor Web suficiente para o crescimento da informação. Também discos rápidos (SATA ou SSD) são preferíveis.
UPS
A rede e o servidor de PHC CS WEB devem estar eletricamente estabilizados de forma que se houver falha elétrica.
2. Requisitos do lado do Cliente
Browser IE 11 ou superior, Firefox v53 ou superior, Chrome, Safari e outros nos sistemas Desktop;
Nos Sistemas operativos móveis, Android 6.0 ou superior, IOS 7 ou superior e Windows Phone 8.1 ou superior (não suportamos a versão do Windows 8.1 para o Surface RT);
Resolução mínima de ecrã em dispositivos móveis de 480x800 px e largura mínima de 320px;Conexão à Internet por Wlan, 3G, 4G (quanto mais rápida a ligação melhor)..
Instalação e Configurações do Phc Cs Web
