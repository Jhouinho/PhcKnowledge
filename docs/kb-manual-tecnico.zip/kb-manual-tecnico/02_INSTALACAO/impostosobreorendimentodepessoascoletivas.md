---
title: Imposto sobre o Rendimento de Pessoas Coletivas
source: impostosobreorendimentodepessoascoletivas.htm
tipo: Manual Técnico
idioma: PT
---

# Imposto sobre o Rendimento de Pessoas Coletivas

DEDUÇÃO POR LUCROS RETIDOS E REINVESTIDOS
Permite a dedução à coleta do IRC de 10% dos lucros retidos que sejam reinvestidos, em ativos elegíveis, no prazo de dois anos contados a partir do termo do período de tributação a que correspondam os lucros retidos, com o máximo de dedução anual de 25% da coleta do IRC.
CLIENTE
Ao efetuar o encerramento do ano fiscal em 2014 deve ser tido em conta a possibilidade de dedução à coleta do IRC de 10% dos lucros retidos que sejam reinvestidos, em ativos elegíveis.
REGIME FISCAL DOS EMPRÉSTIMOS EXTERNOS
Prorrogação para 2014 do regime de isenção de IRS ou de IRC aplicável aos juros de capitais provenientes do estrangeiro representativos de contratos de empréstimo Schuldscheindarlehen celebrados pelo Instituto de Gestão da Tesouraria e do Crédito público, E.P.E. (IGCP), em nome e em representação da República Portuguesa, desde que o credor seja um não residente sem estabelecimento estável em território português ao qual o empréstimo seja imputado.
INFORMATIVO
Informação apenas para empresas que possuam empréstimos Schuldscheindarlehen ao estrangeiro.
REGIME ESPECIAL DE TRIBUTAÇÃO DOS VALORES MOBILIÁRIOS REPRESENTATIVOS DE DÍVIDA EMITIDA POR ENTIDADES EXTERNAS
Prorrogação para 2014 do regime de isenção de IRS e de IRC aplicável aos rendimentos dos valores mobiliários representativos de dívida pública e não pública emitida por entidades não residentes, que sejam considerados obtidos em território português nos termos dos Códigos do IRS e do IRC, quando venham a ser pagos pelo Estado Português enquanto garante de obrigações assumidas por sociedades das quais é acionista em conjunto com outros Estados membros da União Europeia.
INFORMATIVO
AUTORIZAÇÃO LEGISLATIVA
Regime especial de tributação dos valores mobiliários representativos de dívida emitida por entidades não residentes
Autorização legislativa concedida ao Governo para rever e sistematizar o regime especial de tributação dos rendimentos de valores mobiliários representativos da dívida.
Prevê-se as seguintes alterações ao regime:
Alargar o âmbito do regime aos rendimentos dos valores mobiliários representativos da dívida pública e não pública, incluindo os valores mobiliários de natureza monetária designados por papel comercial, integrados e registados exclusivamente junto de entidades gestoras de sistemas de compensação e liquidação internacional;
Definir as entidades a quem incumbe o cumprimento das obrigações fiscais, designadamente de retenção na fonte, de pagamento e declarativas;
Rever, com o objetivo da sua simplificação:
- Os deveres de informação a prestar pelas entidades envolvidas;
- Os procedimentos relativos à identificação dos beneficiários efetivos; e
- Os mecanismos de reembolso do imposto indevidamente retido na fonte;
Definir as entidades responsáveis pelo pagamento do imposto não retido na fonte ou reembolsado indevidamente;
Estabelecer as consequências, incluindo de natureza sancionatória, do incumprimento das demais obrigações previstas neste regime.
