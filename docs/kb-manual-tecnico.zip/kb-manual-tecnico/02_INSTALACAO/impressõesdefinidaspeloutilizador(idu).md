---
title: Impressõesdefinidaspeloutilizador(Idu)
source: impressõesdefinidaspeloutilizador(idu).htm
tipo: Manual Técnico
idioma: PT
---

# Impressõesdefinidaspeloutilizador(Idu)

Impressões Definidas pelo Utilizador ( Idu )

|  |
| --- |
| Impressões Definidas pelo Utilizador ( Idu ) |

|  |
| --- |
| As **Impressões definidas pelo utilizador** são uma ferramenta de [desenho de impressões](configurarodesenhodaimpressão.htm) de documentos do software. Ao longo da explicação da criação e manutenção destas impressões, elas serão referenciadas com a abreviatura de IDU.     O IDU foi criado com o intuito de fornecer ao utilizador um ambiente poderoso e fácil de utilizar, de modo a permitir criar rapidamente impressões atrativas e eficientes das tabelas das diversas aplicações.  As funcionalidades estão disponíveis nas [barras de ferramentas](barrasdeferramentasdoidu.htm) e nos [menus](menusdoidu.htm) do IDU.    Este ambiente em modo gráfico, foi desenhado numa perspetiva de WYSIWYG (what you see is what you get), que traduzido que dizer, "o que você vê é o que você obtém". Embora esta filosofia dependa muito do hardware que o utilizador possua, nomeadamente o tipo de impressora instalada (é possível desenhar impressões em modo gráfico ou em [modo de texto](configuraçõesdeimpressoraemmododetexto.htm)), ou seja, como se trata de desenhos de impressões, os resultados que se obtêm com este ambiente de trabalho, estão intimamente ligados à configuração da impressora predefinida do Windows.    Aconselha-se que a resolução gráfica seja igual ou superior a 800x600 pixels, permitindo assim retirar o melhor aproveitamento do desenho, sendo a resolução 1024x768 a que tirará melhor partido desta plataforma.    Existem várias formas de aceder aos IDUs, dependendo do tipo de Impressão que se pretende. Uma das formas mais diretas é a utilização dos botões laterais  ou  . O primeiro botão existe apenas nas tabelas cujo IDU é monopágina (ficha de cliente, de artigo, de entidade, etc.) ; o segundo existe nas tabelas cujo IDU é multi-página (faturas, compras, dossiers internos, etc.).     Estes botões permitem aceder tanto ao [ecrã de desenho](acessoaoecrãdedesenhodoidu.htm) como ao [ecrã de impressão](acessoaoecrãdeimpressãodoidu.htm) do IDU. Para aceder ao ecrã de desenho deve fazer clique direito em qualquer desses botões e clique esquerdo para aceder ao ecrã de impressão.    As impressões são configuradas através dos [parâmetros dos IDUS](utilidadedosparâmetrosdosidus.htm).     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre conceitos básicos para configurar um IDU, carregando [aqui](http://on.phc.pt/onphce/ass/emuview.aspx?stamp=e92gf%3aec%3a42.%3a2fc.%3afd5.e39) e [aqui](http://on.phc.pt/onphce/programs/nwwwview.aspx?stamp=gcf9bbb65g2.86bb.fe75.3fc). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Impressões Definidas pelo Utilizador ( Idu )' ) |