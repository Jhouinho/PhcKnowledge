---
title: Impressõesdefinidaspeloutilizador(Idu)Nomanufactor
source: impressõesdefinidaspeloutilizador(idu)nomanufactor.htm
tipo: Manual Técnico
idioma: PT
---

# Impressõesdefinidaspeloutilizador(Idu)Nomanufactor

Impressões Definidas pelo Utilizador ( Idu ) no Manufactor

|  |
| --- |
| Impressões Definidas pelo Utilizador ( Idu ) no Manufactor |

|  |
| --- |
| As **Impressões definidas pelo utilizador** são uma ferramenta de [desenho de impressões](configuraçãododesenhodaimpressãonomanufactor.htm) de documentos do software. Ao longo da explicação da criação e manutenção destas impressões, elas serão referenciadas com a abreviatura de IDU.     O IDU foi criado com o intuito de fornecer ao utilizador um ambiente poderoso e fácil de utilizar, de modo a permitir criar rapidamente impressões atractivas e eficientes das tabelas da aplicação.  As funcionalidades estão disponíveis nas [barras de ferramentas](barrasdeferramentasdoidunomanufactor.htm) e nos [menus](menusdoidunomanufactor.htm) do IDU.    Este ambiente em modo gráfico, foi desenhado numa perspectiva de WYSIWYG (what you see is what you get), que traduzido que dizer, "o que você vê é o que você obtém". Embora esta filosofia dependa muito do hardware que o utilizador possua, nomeadamente o tipo de impressora instalada, é possível desenhar os relatórios de uma forma intuitiva, tendo sempre presente que o que o utilizador está a desenhar é o que vai ser impresso. Esta facilidade permite que diminuir o tempo de execução dos relatórios o que leva a uma diminuição do tempo de implementação da aplicação. Personalizações posteriores são também facilitadas pois os relatórios podem ser alterados. Esta facilidade de desenho abre as portas ao utilizador comum de desenhar os seus próprios relatórios.     Aconselha-se que a resolução gráfica seja igual ou superior a 800x600 pixels, permitindo assim retirar o melhor aproveitamento do desenho, sendo a resolução 1024x768 a que tirará melhor partido desta plataforma.    Existem várias formas de aceder aos IDUs, dependendo do tipo de Impressão que se pretende. Uma das formas mais directas é a utilização do botão lateral  .     Este botão permite aceder tanto ao [ecrã de desenho](acessoaoecrãdedesenhodoidunomanufactor.htm) como ao [ecrã de impressão](acessoaoecrãdeimpressãodoidunomanufactor.htm) do IDU. Para aceder ao ecrã de desenho deve fazer clique direito em qualquer desses botões e clique esquerdo para aceder ao ecrã de impressão. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Impressões Definidas pelo Utilizador ( Idu ) no Manufactor' ) |