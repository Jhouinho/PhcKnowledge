---
title: Imprimircódigodebarrasemrelatóriosdedocumentos
source: imprimircódigodebarrasemrelatóriosdedocumentos.htm
tipo: Manual Técnico
idioma: PT
---

# Imprimircódigodebarrasemrelatóriosdedocumentos

Imprimir Código de Barras em Relatórios de Documentos

|  |
| --- |
| Imprimir Código de Barras em Relatórios de Documentos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| É possível criar relatórios de impressão de documentos (Faturas, Compras, Dossiers, entre outros) para imprimir os códigos de barras dos artigos, recorrendo à instalação de kit de Drive FX.    Para tornar o processo mais rápido e simples, aconselha-se recorrer à duplicação de um relatório da PHC, em oposição à criação de um novo relatório.    **Para incluir o código de barras dos artigos no relatório, seguir os seguintes passos:**   - Aceder ao ecrã de relatórios, situado no menu **Configurações/Framework/Relatórios**. - Selecionar o relatório a alterar. - Clicar sobre o botão **Editar Layout**. - No desenho do relatório, do lado esquerdo do ecrã, encontram-se os vários tipos de objeto disponíveis. Nessa zona, selecionar o tipo de objeto com o nome **XRBarCode** (símbolo código de barras) e arrastá-lo para o relatório, para a banda **Detail2** que corresponde aos campos das linhas. - Selecionar o objeto, e na propriedade **A ligação de dados**, pertencente ao agrupador **AÇÕES**, selecionar o campo de código de barras pertencente ao ecrã de Artigos e Serviços (sob a área das linhas). - Ajustar o tamanho do objeto ao espaço disponível nessa zona, tendo em conta que a propriedade **Auto-Módulo** (Pode Crescer), pertencente ao agrupador **COMPORTAMENTO** deve estar ativa, para que o código de barras possa ser expandido ao imprimir o relatório, caso se justifique. Caso a propriedade não fique ativa, pode ocorrer na impressão o erro **Os limites do controle são muito pequenos para o código de barras** , indicador de que o campo não consegue ajustar-se ao espaço disponível. - Nesse objeto, ter também em conta a propriedade **Simbologia**, pertencente ao agrupador **COMPORTAMENTO**. Nessa propriedade deve ser preenchido o tipo de código de barras pretendido, compatível com o leitor disponível para a leitura. - Ativar o relatório. - Associar o relatório a um add-on e publicá-lo na Drive FX Store ou diretamente no cliente através de um add-on privado.          Alerta   Para garantir a correta leitura do código impresso através do leitor de código de barras disponível, poderão ser necessários testes, em que na impressão se ajustam os tipos de códigos de barras e tamanho de letra na impressão, até encontrar o formato certo para o leitor de código de barras disponível. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Imprimir Código de Barras em Relatórios de Documentos' ) |