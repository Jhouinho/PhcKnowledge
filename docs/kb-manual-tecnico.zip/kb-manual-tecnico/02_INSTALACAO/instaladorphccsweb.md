---
title: Instalador Phc Cs Web
source: instaladorphccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Instalador Phc Cs Web

Este formato de instalação é o processo mais automatizado para instalar a
Intranet
, a
Extranet
e o
Portal
. Se utilizar este método de instalação, deixa de ser necessário o recurso Web Deploy para efetuar uma nova instalação ou para atualizar uma instalação já existente.
Este método de instalação não dispensa o cumprimento dos requisitos técnicos, como as configurações das
Features do Windows
.
Validação dos requisitos técnicos
(chaves comuns);
Instalação da aplicação "Nova"
;
Atualização da aplicação "Existente"
;
Informação adicional sobre a instalação
.
Validação dos requisitos técnicos
Assim que o utilizador executar o ficheiro "intranet.setup.msi" fornecido pela PHC, é realizada uma verificação à existência de recursos fundamentais, como o Internet Information Services (IIS) e a Framework .Net 6.4.2 . Caso não estejam instalados, a aplicação informa mostrando as seguintes imagens:
- Internet Information Services (IIS)
- Framework .Net 4.6.2.
Instalação da aplicação "Nova"
Garantida a existência dos de recursos fundamentais para o funcionamento da aplicação, o utilizador poderá continuar com a instalação pelo respetivo
setup
(Intranet; Extranet ou Portal), onde lhe será apresentado o seguinte ecrã:
Ao clicar em "Seguinte" será encaminhado para o passo seguinte, onde poderá indicar se o procedimento a seguir é a uma instalação "Nova" ou a atualizar uma aplicação "Existente".
Neste momento é oportuno aceder à informação que permite ao utilizador obter os dados da instalação do cliente, seja pela Carta de Aceitação, enviada pela PHC, ou através do site da Comunidade PHC.
Esta informação mencionada é importante para os próximos passos, uma vez que o ficheiro
appSettings.config
será gerado automaticamente (na instalação de uma "Nova" aplicação).
Selecionando a opção "Nova" e depois de clicar em "Seguinte", o utilizador é reencaminhado para um outro passo, onde deverá especificar qual o nome a atribuir à aplicação, que neste caso é o "Intranet", bem como a "App Pool" que lhe ficará associada.
Existe a possibilidade de indicar se irá ser criada uma "Diretoria Virtual" ou um "Website". Selecionando a primeira opção, a aplicação será instalada como sendo uma subdiretoria do Default Web Site do IIS (Internet Information Services).
No entanto, se o utilizador escolher a opção: "Website", será apresentado um outro campo, onde deve indicar qual a porta (por defeito: 80) a utilizar pelo website. Com esta opção ativa, será criado um novo site, deixando de ser uma subdiretoria do "Default Web Site" do IIS.
Na parte inferior, encontrará a informação referente à configuração da chave para estabelecer a ligação ao servidor
appSettings.config
, que deverá ser obrigatoriamente preenchida:
-
Servidor:
Deverá conter o nome do servidor onde será efetuada a ligação;
-
Base de dados:
Nome da base de dados à qual irá estar associada a aplicação;
-
Utilizador:
Especificar qual o utilizador para a autenticação à base de dados;
-
Palavra-chave:
Password associada ao utilizador anteriormente indicado.
Ao lado de cada campo, encontrará o botão "i" que ao ser selecionado, irá apresentar uma breve explicação sobre qual o valor a preencher em cada um dos locais.
Nos dois ecrãs estão apresentados todos os dados referentes à "Nova" instalação. Esta informação é maioritariamente fornecida por carta de aceitação, enviada pela PHC. Esta informação será interiorizada automaticamente no ficheiro
appSettings.config
.
Neste ponto, caso não tenha permissões de administrador, será apresentada uma janela do próprio Windows a solicitar a inserção das credenciais do administrador.
Os campos apresentados na imagem, devem conter a informação referente a:
- Licenciamento (carta de aceitação enviada pela PHC);
- Dados para configurar o "remote server" para o email (administrador de sistema);
- Identificação da gama a utilizar, com o respetivo "Número de Série".
No passo seguinte, os campos devem ser preenchidos com os números de série dos respetivos módulos da aplicação, também de acordo com a carta de aceitação enviada pela PHC.
Nesta imagem, os módulos são referentes ao
setup
da Intranet. No entanto, para que as opções de configuração - da Extranet e/ou Portal - sejam disponibilizadas na intranet, os respetivos campos também devem ser preenchidos.
Ao clicar em "Seguinte", a instalação inicia-se e o ficheiro
appSettings.config
será criado automaticamente no decorrer da instalação.
Terminada a instalação, será apresentada a seguinte mensagem:
Após clicar na opção "Concluir" a instalação do PHC CS WEB estará terminada. Depois ao aceder ao Internet Information Services (IIS), verificará que já foi adicionada a nova aplicação, com o nome "Intranet", de acordo com o que foi indicado aquando da execução do
setup
de instalação.
Para criar uma "Nova" instalação para a Extranet ou Portal, deverá utilizar os
setups
correspondentes, sendo a metodologia semelhante.
Atualização da aplicação "Existente"
O processo de atualização/upgrade de uma instalação foi totalmente revisto de forma a ser cada vez mais simples e transparente para o utilizador.
Este novo instalador, tem ainda a vantagem de o utilizador não ter que efetuar backup da informação que possa ter na diretoria
"pimages"
como por exemplo, adaptações de CSS ou imagens, porque o próprio
setup
faz este tipo de controlo, não alterando esses ficheiros.
Para tal, ao correr o
setup
, deverá especificar que se trata de uma instalação "Existente" para garantir a atualização/upgrade de uma instalação.
O utilizador deixa de ter necessidade de preencher os dados de configuração do ficheiro "appSettings.config", porque o próprio
setup
irá ler esses dados ao "appSettings.config" e importá-los para a instalação atual.
Desta forma, após aparecer o ecrã dos módulos da aplicação pré-preenchido com a informação do
appSettings.config
, bastará continuar a mesma metodologia da instalação da "Nova" aplicação.
Esta informação é análoga para a atualização da Intranet; Extranet ou Portal, mediante o
setup
utilizado.
Informação adicional sobre a instalação
No local da instalação fica um ficheiro chamado web.Config e um ficheiro
appSettings.config
, que são muito importantes. É nestes ficheiros onde será efetuada a configuração da informação necessária à execução da aplicação.
Se não estiverem no local por defeito (C:\inetpub) é porque o IIS (Internet Information Services), não foi instalado nessa diretoria. Neste caso, terá que verificar qual o caminho para a diretoria do IIS.
Aceder ao IIS, selecionar a aplicação que acabou de instalar e efetuar clique direito sobre a mesma. Selecionar a opção
"Manage Application"
e depois a opção
"Advanced Settings"
.
O IIS vai abrir um ecrã de configurações avançadas onde se deve clicar no botão relativo ao
"Application Pool"
.
A aplicação volta a abrir um ecrã no qual se pode observar a versão da Framework relativa à
"Application Pool"
selecionada. Deve estar selecionada a versão a 4.5.
De forma a melhorar o desempenho em termos de rapidez do PHC CS Web devem ser efetuados os seguintes passos no IIS:
Aceder às Application Pools e selecionar a application pool utilizada pelo PHC CS Web;
Aceder às "Advanced Settings..." e selecionar as seguintes opções:
- Start Mode: AlwaysRunning
- Idle Time Out Action: Suspended
- Maximum worker processes: 0
Depois das alterações é necessário fazer o "Recycling..." da application pool.
Instalação e Configurações do Phc Cs Web
