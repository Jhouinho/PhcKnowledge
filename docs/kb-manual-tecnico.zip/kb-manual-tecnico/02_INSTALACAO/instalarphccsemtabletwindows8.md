---
title: Instalarphccsemtabletwindows8
source: instalarphccsemtabletwindows8.htm
tipo: Manual Técnico
idioma: PT
---

# Instalarphccsemtabletwindows8

Instalar Phc Cs em Tablet Windows 8

|  |
| --- |
| Instalar Phc Cs em Tablet Windows 8 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo apresenta a configuração do Windows 8 em modo Touch para se consiga trabalhar corretamente no PHC CS.    Foram reportadas algumas dificuldades na seleção de valores nas listas da aplicação, como por exemplo, a seleção da **Empresa** no ecrã de **Login** do PHC CS, quando utilizada máquina Touch com Windows 8 sem ter um rato conectado.    Quando não existe um rato ligado ao computador, o Windows 8 ativa o *modo de touch*. Neste modo, alguns controlos das aplicações têm um comportamento diferente do esperado otimizado para o toque.  Isto provoca algumas dificuldades na utilização do PHC CS, pelo que não deve ser utilizado este modo.     Para resolver esta situação e conseguir trabalhar normalmente, é necessário emular no Windows 8 a existência do rato.    Isto pode ser conseguido acedendo ao "Painel de Controlo".        No "Painel de Controlo" do Windows, estão disponíveis as principais configurações do "Sistema Operativo", como adicionar novo hardware, adicionar e remover software, controlar contas de utilizadores ou alterar opções de acessibilidade.  A opção pretendida está no menu de **Centro de Facilidade de Acesso**. Este menu disponibiliza configurações para tornar o computador mais fácil e confortável de utilizar.        Neste menu temos a opção **Tornar o rato mais fácil de utilizar**. Esta opção irá apresentar um novo menu, onde podem ser alteradas configurações para tornar o rato mais fácil de utilizar, como por exemplo o tamanho e cor do ponteiro.        Neste menu temos a opção **Ativar as Teclas do Rato**. Esta opção permite que se utilize o rato através do teclado numérico.     Se não existir um rato ligado à máquina, a única forma de utilizar o "modo de rato" é ativar a opção anterior. No "modo de rato", a utilização do PHC CS é idêntica a quando é usado uma máquina Windows 8 sem Touch.      Gama e versão de software PHC em que foi testado: PHC Advanced, 2014.2. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalar Phc Cs em Tablet Windows 8' ) |