---
title: Instalaçãodaextranet
source: instalaçãodaextranet.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodaextranet

Instalação da Extranet

|  |
| --- |
| Instalação da Extranet |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A instalação da Extranet de Leilões é o 2º passo para a instalação da versão Web.    Deverá aceder ao CD de instalação e localizar a diretoria "SETUP WEB\EXTRANET" e executar o ficheiro Setup.    São questionados os dados de licenciamento, como o nome do utilizador e da empresa:         Toda a instalação é simples (bastando clicar em "Seguinte").       A fase final de instalação, pressupõe o preenchimento dos dados de acesso ao servidor WEB do cliente.         Neste ecrã deverão ser preenchidos os seguintes campos:    **Servidor SQL**  Deverá ser indicado o endereço IP do servidor Web do cliente.     Deverá ser substituído o texto a negrito e itálico:    http://***IP do WebService***/webservice/WebServiceManufactor.asmx      **Nome empresa**  Nome da empresa (cliente).    *Nota*: Recomenda-se a consulta do tópico [Versão Web](versãoweb.htm) para uma melhor compreensão. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação da Extranet' ) |