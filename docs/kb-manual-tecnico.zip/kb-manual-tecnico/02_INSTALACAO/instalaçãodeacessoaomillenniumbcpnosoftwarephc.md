---
title: Instalaçãodeacessoaomillenniumbcpnosoftwarephc
source: instalaçãodeacessoaomillenniumbcpnosoftwarephc.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodeacessoaomillenniumbcpnosoftwarephc

Instalação de Acesso ao Millennium Bcp no Software Phc

|  |
| --- |
| Instalação de Acesso ao Millennium Bcp no Software Phc |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este Artigo Técnico tem como objetivo auxiliar o utilizador a instalar e configurar o acesso às opções do Portal de Empresa do Millennium BCP, no Software PHC.     Atenção: Caso o utilizador já tiver o Serviço Bancário Online a funcionar no Software PHC, é necessário desinstalar o *setup* antigo antes de instalar o novo *setup*.     **Instalação**    Para instalar as opções que permitem realizar operações bancárias do Millennium BCP a partir do Software PHC, disponível a partir da versão 2010 e em todas as gamas do CS do Software PHC, é necessário efetuar o seguinte:     Na pasta de instalação dos Serviços Bancários Online deverá executar o *setup.exe* para proceder à sua instalação:              De seguida, deverá instalar o *setup* e proceder aos passos do assistente da instalação até concluir a mesma.                     Depois de instalar o *setup* é necessário clicar no botão "Finish" para fechar o ecrã de instalação.         **Configuração**      Após a instalação do *setup* é necessário entrar no Software PHC, aceder ao menu "Sistemas" -&gt ecrã "Utilizadores" -&gt utilizador que vai utilizar os Serviços Bancários Online, e no separador "Serviços Bancários Online" é necessário efetuar os seguintes passos:    * Ativar a opção **Este utilizador tem acesso aos Serviços Bancários Online**;  * É necessário preencher o campo **Código de utilizador** e a respetiva *password*.    Ainda no ecrã "Utilizadores", é necessário clicar no botão "Configuração" para se configurar o Serviço Bancário Online e no ecrã "Escolha dos Certificados de Servidor e Cliente para os Serviços Bancários Online" é necessário ativar as seguintes opções, ou seja, os novos certificados:             Poderá pedir o seu Certificado Digital de Cliente junto do Millennium BCP, através do  [site](http://corp.millenniumbcp.pt/pt/public/solucoesfinanceiras/E-Business/Pages/MenuB2B.aspx) ou solicitar a uma Entidade Certificadora Autorizada.    De seguida, é necessário aceder as Contas de Tesouraria (menu "Gestão" -&gt "Outras opções de Tesouraria") e na conta que vai utilizar os Serviços Bancários Online do Millennium BCP, no separador "Informação", é necessário ativar a opção **Permite acesso Online**.              Assim que a opção **Permite acesso Online** estiver ativa, fica disponível o botão " Consulta Online". Ao clicar neste botão é possível consultar Online os saldos e ou os Movimentos da Conta:                 Apenas como informação adicional, com a instalação do produto Serviços Bancários Online, é criado um ficheiro do tipo:    * phccorporate.exe.config;  * phcadvanced.exe.config;  * phcenterprise.exe.config.    Com a instalação são também criados dois parâmetros em "Sistemas" -&gt "Parâmetros" -&gt "Serviços Bancários Online", sendo eles:    * Url do WebService Bank SVC;  * Url do WebService Banking File Service    Estes parâmetros são criados e configurados automaticamente pela aplicação a partir da versão 17.     Caso a sua versão seja inferior, deverá preencher os parâmetros acima indicados com o seguinte:    * <https://b2b.millenniumbcp.pt/Services/Bank.svc> * <https://b2b.millenniumbcp.pt/Services/BankingFileServices.svc>    Após instalar e configurar o acesso às opções do Millennium BCP no Software PHC é possível ao utilizador consultar o saldo e os movimentos da conta, bem como executar transferências online; realizar Reconciliações Automáticas de Movimentos; Processamento de Transferências Bancárias entre outras excelentes funcionalidades. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação de Acesso ao Millennium Bcp no Software Phc' ) |