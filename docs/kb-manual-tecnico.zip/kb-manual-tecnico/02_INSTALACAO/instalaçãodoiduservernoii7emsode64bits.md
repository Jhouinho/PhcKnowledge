---
title: Instalaçãodoiduservernoii7Emsode64Bits
source: instalaçãodoiduservernoii7emsode64bits.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodoiduservernoii7Emsode64Bits

Instalação do Iduserver no Ii7 em So de 64 Bits

|  |
| --- |
| Instalação do Iduserver no Ii7 em So de 64 Bits |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Para trabalhar com o iduserver nas aplicações de Digital, usando o Iis 7 com Sistema Operativo 64 bits, é necessário proceder às seguintes configurações no IIS:     1-No Painel de Controlo (Control Panel) deverá selecionar a opção de Ferramentas Administrativas (Administrative Tools) e seleccionar o IIS - Internet Information Services.    2-Clicar na opção Application Pools. Vão ficar disponíveis do lado direito todas as applications pools configuradas no IIS.        3-Deve selecionar a Classic.Net AppPool. Vão ficar disponíveis do lado direito as Actions.        4-Clicar na opção Advanced Settings e alterar propriedade Enable 32-Bit Applications de False para True.        5-No final deverá efetuar um reset ao IIS. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação do Iduserver no Ii7 em So de 64 Bits' ) |