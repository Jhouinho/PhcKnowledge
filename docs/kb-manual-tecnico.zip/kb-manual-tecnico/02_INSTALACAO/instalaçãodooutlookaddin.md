---
title: Instalaçãodooutlookaddin
source: instalaçãodooutlookaddin.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodooutlookaddin

Instalação do Outlook Addin

|  |
| --- |
| Instalação do Outlook Addin |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| No Cd de Instalação da aplicação PHC, vêm também os Setups do **Addin para o Microsoft Outlook 2003** e **Addin para o Microsoft Outlook 2007**. Deve correr-se o setup respectivo, de acordo com o Office já instalado, no momento da instalação do software PHC.      **Addin para o Microsoft Outlook 2003/2007**    Para correr este setup o PC deve ter instalado: - O Microsoft Outlook 2003/2007 deve conter as opções .NET programmability suport no outlook e Microsoft Forms 2.0 .NET programmability suport do office tools;   Para instalar estes componentes deve aceder, se o office já se encontrar instalado previamente, ao Painel de Controlo, à opção de Adicionar/Remover programas.  Neste local, deve seleccionar a versão do Microsoft Office instalada e premir a opção que a permite alterar. Ao entrar no Assistente, deve seleccionar a opção *Adicionar ou remover funcionalidades*, e escolher a customização avançada das aplicações.   Nas opções de instalação deve seleccionar *Microsoft Office* e dentro desta, as *Ferramentas do Office*. Deve mandar correr a ferramenta *Suporte de Programação para o .NET do Microsoft Forms 2.0*. Depois deve seleccionar a opção Microsoft Office Outlook e dentro desta mandar executar o *Suporte de Programação para o .NET*. - O Microsoft .NET 2.0 ; - O Microsoft Visual Studio 2005 Tools for Office Second Edition Runtime .    Respeitadas estas premissas pode então correr-se o **Setup.exe** do Addin, que se encontra no Cd, na pasta **Addin Documentos desktop**. Este setup, em formato de Assistente é muito simples de utilizar.    Antes de entrar no Assistente certifique-se que o Microsoft Outlook se encontra fechado.    Ao entrar no Assistente deve premir o botão Próximo para instalar o PHC Outlook Addin numa pasta no PC. O Assistente propõe automaticamente que seja guardado nos **Program Files**  sob a designação: **PHC Outlook Addin para Documentos desktop**, no entanto, o utilizador pode alterar o caminho onde quer guardar a aplicação.    Pode ainda verificar o espaço necessário em disco e ao premir o botão de Avançar o Assistente vai instalar o Addin no PC, na directoria seleccionada.    Depois de instalado o Addin deve entrar no Outlook, onde vai encontrar uma nova toolbar com as funcionalidades e [configurações](configuraçãodooutlookaddin.htm) necessárias ao bom [funcionamento da rotina de envio de e-mail(s)](funcionamentodooutlookaddinparadocumentosdesktop.htm) para o software PHC.      Por vezes pequenos erros que vão acontecendo no Outlook podem levar a que os COM add-ins fiquem inactivos o que afecta a funcionalidade do Outlook Connector. Em consequência, podem detectar-se alguns problemas e dificuldades, no Outlook Addin, nomeadamente o desaparecimento das respectivas opções, quando as mesmas estão activadas no Outlook.    Nestes casos é necessário activar o Addin. Para tal é necessário identificar os COM add-ins que estão instalados no PC. Devem efectuar-se os seguintes passos:   - Iniciar o Outlook;    - Aceder ao Menu Ferramentas e seleccionar as Opções (Tools - Options);    - No separador **Outros** premir o botão de Opções Avançadas (Others - Advanced Options);    - Nas OPções Avançadas premir o botão COM Add-Ins;    - Activar o Add-In.     Outro caminho para activar o Add-in passa pelo menu Ajuda.  Neste menu deve aceder à opção **About Microsoft Office Outlook**, premir o botão de Itens inactivos (Disabled Items) e neste local seleccionar o Add-in e activá-lo.    Se mesmo assim o problema inicial não se encontrar resolvido deve aceder-se ao Painel de Controlo e seleccionar a opção de **Adicionar/Remover Programas**. Deve seleccionar-se o Microsoft Office Outlook Connector e premir o botão de Reparar. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação do Outlook Addin' ) |