---
title: Instalaçãodophccsxl
source: instalaçãodophccsxl.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodophccsxl

Instalação do Phc Cs Xl

|  |
| --- |
| Instalação do Phc Cs Xl |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Requisitos    Para poder instalar o **PHC CS XL** deverá possuir um dos seguintes sistemas operativos:   * Windows XP * Windows Vista  * Windows 7  * Windows 8      Com as seguintes versões e componentes do Microsoft Office Excel:    * Microsoft Office 365  * Microsoft Office Excel (versão 2010 e superiores)  * Microsoft Office Excel de 32 bits ou de 64 bits    *Notas:*    * O setup de instalação do PHC CS XL, instala por defeito a framework .net 4.5;  * O PHC CS XL não é compatível com instalações remotas do Office 365.     E o computador com:    + Processador Intel (c) Pentium (c) 4 (1GHz ou superior)  + 2 GB RAM ou superior (aconselhável 4GB)      Instalação    Para instalar deverá criar uma pasta na diretoria *C:* com o nome "PHC CS XL" e colocar o *setup* do **PHC CS XL** na referida pasta.     Ao correr o processo de instalação deverá ter em conta as seguintes indicações:    Opte pela língua à qual se adapte com mais facilidade:        Siga as instruções no monitor:        No passo seguinte, deverá selecionar a diretoria onde irá ser instalado o **PHC CS XL**:        De seguida, será mostrado o ecrã onde será dada a confirmação final da instalação, como mostrada na imagem:        Por último, irá ser apresentada uma mensagem de que foi efetivamente instalado o software:        Ao concluir este processo está apto para começar a utilizar o **PHC CS XL** no Excel.    Depois da instalação é necessário abrir o Microsoft Excel e na folha de cálculo do Excel fica disponível o separador **PHC CS XL**.     *Nota:* É necessário ter a aplicação Publish instalada, caso contrário a aplicação irá pedir a sua instalação.        Ao abrir o Excel é necessário aceder ao separador **PHCXL 20**e selecionar a opção **Ativar produto**.   No seguinte ecrã é necessário preencher todos os campos:         O campo **Nº de Instalação** deve ser preenchido com o número de instalação do cliente.   O campo **Password de acesso** deve ser preenchido com a Password para o Calendário/ PHC On.  O campo **Código** deve ser preenchido com o código da ficha. Este código terá que ser facultado pelo Parceiro.       Depois de preencher todos os campos indicados é necessário clicar no botão **OK** para que o PHC CS XL fique ativo e válido.   *Nota:* Se o utilizador ficar sem ligação à Internet depois da validação do produto, terá até 30 dias para trabalhar no PHC CS XL em modo offline ou então até 15 entradas no Excel no mesmo dia, após este período é necessário ter ligação à internet.     A validação do PHC XL é realizada através de licenciamento por máquina. Por licenciamento por máquina entende-se que uma licença PHC XL é válida apenas para uma máquina local e nunca numa máquina que está na cloud. Contudo se tiver o PHC CS XL instalado numa máquina local que não é a máquina habitual de trabalho, é possível aceder à mesmo a partir do Remote Desktop.      Por fim, é necessário [configurar uma ligação](Opçõesdeconfiguração.htm#tgrconligaçoes) e posteriormente [configurar uma empresa](Opçõesdeconfiguração.htm#tgrempresa), depois de tudo configurado é só ligar à Empresa que foi criada e todas as opções do **PHC CS XL** ficam visíveis ao utilizador e a partir daqui pode construir os seus Mapas de Gestão. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação do Phc Cs Xl' ) |