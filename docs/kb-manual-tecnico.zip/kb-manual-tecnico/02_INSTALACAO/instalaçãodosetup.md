---
title: Instalaçãodosetup
source: instalaçãodosetup.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodosetup

Instalação do Setup

|  |
| --- |
| Instalação do Setup |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A instalação do Setup deverá ser executada do CD fornecido pela PHC.    Para isso, deverá aceder à diretoria de Setup e efetuar um "duplo-clique" no ficheiro "Manufactor XXXX" (Sendo que XXXX será a versão a instalar).    A imagem seguinte apresenta, de uma forma gráfica, o conteúdo da diretoria de Setup e o ficheiro a ser executado.       Ao executar o ficheiro, a aplicação questiona o utilizador qual o idioma que pretende usar para a instalação:       Posteriormente à seleção, a aplicação inicia a instalação:       Ao clicar em "Seguinte" a aplicação solicita que o utilizador leia as condições de licenciamento da aplicação e caso concorde as aceite. Só assim poderá continuar a instalação:       Clicando em "Seguinte", são questionados pelo caminho para o local onde a aplicação irá ser instalada:       A aplicação questiona agora o utilizador se pretende instalar motor de impressão de relatórios em Crystal-Reports.        Indicamos qual a pasta para o menu "Menu Iniciar" onde o PHC Manufactor CS deverá ficar arquivado.       Configuramos se pretendemos criar atalhos para o desktop e para a barra de início rápido.       Por último, a aplicação sugere que validemos as configurações realizadas.       Clicando em seguinte o processo de instalação inicia-se. O processo de instalação vai sendo apresentado sobre a forma de uma barra de progresso, até ao momento da sua finalização.        Resta indicar que a aplicação durante a instalação instala também os drivers das fichas de controlo da aplicação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação do Setup' ) |