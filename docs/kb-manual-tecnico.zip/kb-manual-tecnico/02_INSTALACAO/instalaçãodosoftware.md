---
title: Instalaçãodosoftware
source: instalaçãodosoftware.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãodosoftware

Instalação do Software

|  |
| --- |
| Instalação do Software |

|  |
| --- |
| Este capítulo visa fornecer uma panorâmica geral do funcionamento do PHC Manufactor CS e explicar em detalhe as configurações que devem ser executadas antes de iniciar o trabalho com a aplicação.     A PHC disponibiliza 2 versões:   - Desktop   Software para gestão de produção (constituído por 16 módulos), a ser instalado nos computadores de uma empresa, para acesso interno (rede LAN).     *** Módulo PLATFORM**  *** Módulo CONFIGURADOR**  *** Módulo GRELHAS**  *** Módulo LEILÕES (Descontinuado)**  *** Módulo LOTE**  *** Módulo MANUTENÇÃO**  *** Módulo MOLDES**  *** Módulo MRP**  *** Módulo MULTILINGUA**  *** Módulo ORÇAMENTO**  *** Módulo PACKING LIST**  *** Módulo PLANNING**  *** Módulo QUALIDADE**  *** Módulo RECURSOS**  *** Módulo TAREFAS**  *** Módulo TOUCH**  - Web   Software para gestão candidaturas a fornecedores (módulo LEILÕES), a ser instalado no servidor WEB uma empresa para permitir aos fornecedores candidatarem-se a leilões, disponibilizados pelo cliente. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação do Software' ) |