---
title: Instalação e Configuração do Phc Cs Web
source: instalaçãoeconfiguraçãodophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Instalação e Configuração do Phc Cs Web

Este tópico irá ajudar a efetuar a instalação e configuração da sua aplicação em PHC CS Web.
Saiba todas as informações necessárias sobre:
Requisitos necessários:
Para a instalação do software PHC CS Web, o sistema deve cumprir alguns requisitos. Estas especificações são as mínimas recomendadas. No entanto, para uma melhor otimização da aplicação, todas devem ser confirmadas em função da velocidade requerida, do volume de informação e do número de utilizadores.
Uma vez que a versão atual da aplicação está desenvolvida com tecnologia recente, pode não funcionar da melhor forma em todas as plataformas. Por isso, solicitamos a disponibilidade do utilizador, aconselhando a leitura deste tópico.
Hardware e software Recomendado Web
Instalações e configurações necessárias:
De forma a auxilar o utilizador na configuração de aplicações externas, necessárias para que o utilizador possa usufruir da aplicação PHC CS Web.
Instalação do Software em Windows Server
Instalação e Configuração do PHC CS Web
Configurações necessárias para a aplicação:
Existem também algumas configurações que o utilizador deve efetuar de acordo com a sua realidade empresarial. Para isso, poderá apoiar-se na informação que encontrará nos seguintes tópicos:
Configuração do AppSettings Versão
Configuração dos Mapas Definidos em Iis 7
Instalação dos Manuais das Aplicações Phc Cs Web
Outras configurações:
Configuração de Api
dedicada à utilização com Scripts da Framework PHC
Alteração do método de autenticação:
Alterar Método de Autenticação no PHC CS Web
Phc Cs Web
