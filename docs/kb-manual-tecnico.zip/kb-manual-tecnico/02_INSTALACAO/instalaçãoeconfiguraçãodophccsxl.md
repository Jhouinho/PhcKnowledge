---
title: Instalaçãoeconfiguraçãodophccsxl
source: instalaçãoeconfiguraçãodophccsxl.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãoeconfiguraçãodophccsxl

Instalação e Configuração do Phc Cs Xl

|  |
| --- |
| Instalação e Configuração do Phc Cs Xl |

|  |
| --- |
| Depois de ter instalado o **PHC CS XL CS** é necessário configurá-lo, ou seja, é necessário o utilizador configurar uma ligação e posteriormente criar uma Empresa. Após estas configurações é necessário ligar à [Empresa](Opçõesdeconfiguração.htm#tgrconfigurarempresa) criada.     Estas configurações são efetuadas na área das **Opções**, conforme a imagem ilustra:         A área das Opções é composta pelas seguintes opções:    * [Configurar Ligação](Opçõesdeconfiguração.htm#tgrconfigurarligaçao): permite configurar a estrutura das ligações sobre os dados contabilísticos importados;  * [Configurar Empresas](Opçõesdeconfiguração.htm#tgrconfigurarempresa): permite gerir as empresas que vão ser integradas no **PHC CS XL**;  * [Outras Opções](Opçõesdeconfiguração.htm#tgroutrasopcoes): permite gerir e configurar a forma como o PHC acede aos ficheiros de trabalho. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação e Configuração do Phc Cs Xl' ) |