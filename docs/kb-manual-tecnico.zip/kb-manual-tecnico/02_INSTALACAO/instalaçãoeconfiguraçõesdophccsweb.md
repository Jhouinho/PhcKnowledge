---
title: Instalação e Configurações do Phc Cs Web
source: instalaçãoeconfiguraçõesdophccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Instalação e Configurações do Phc Cs Web

Instalação do Software em Windows
O Software PHC CS Desktop em Windows deve estar corretamente instalado.
Na instalação e manutenção automática, o processo é efetuado sem a intervenção do utilizador. A aplicação verifica se existem alterações às tabelas existentes na base de dados, em caso afirmativo, irá correr a instalação e manutenção apenas para essas mesmas tabelas.
Caso opte pela manutenção personalizada após lida a informação do 1º ecrã, clicar em "Próximo" e no passo "1 de 3" selecionar a opção "Todos";
Clicar em "Próximo";
No passo "2 de 3" clicar
todas as opções
do ecrã e de seguida em "Próximo";
No passo "3 de 3" é dada a informação relativa à manutenção a ser realizada. Deverá então clicar no botão "Terminar" e avançar para a manutenção.
Em alternativa pode na opção Instalação e Manutenção escolher a opção Atualizar tabela de dicionário de dados para todas as tabelas.
Criação dos Utilizadores
Utilizadores SQL
Conforme o tipo de aplicação que se pretende instalar, devem ser criados os respetivos utilizadores SQL:
Tipo de Aplicação: Pública - Nome do Utilizador: Público
Tipo de Aplicação: Interna - Nome do Utilizador: Interno
Tipo de Aplicação: Externa - Nome do Utilizador: Externo
Estes utilizadores já vão configurados no ficheiro
appSettings.config
com os nomes anteriormente indicados. Se quiser alterar pode fazê-lo e neste caso deve alterar a seguinte chave:
add key="DSN" value="server=A;uid=B;pwd=C;database=D;"/
Em que B deve ser substituído pelo nome do utilizador criado e, no caso de ter configurada uma password esta deve ser indicada em C.
Aplicações internas (Intranet):
No caso de estar a instalar uma aplicação interna, os utilizadores são criados no menu Sistema na opção
Utilizadores
.
Qualquer utilizador normal do Software em Windows pode ter acesso às aplicações PHC CS Web, basta para tal na página
PHC CS Web
escolher a opção
Tem acesso via PHC CS Web
.
Os utilizadores têm acesso por Package, isto é, o Software apresenta a listagem de todas as aplicações internas, mas o utilizador pode só ter acesso a uma delas. Neste caso deve ser passado o nome da aplicação para a janela do lado direito.
Aplicações externas(Extranet):
No caso das aplicações externas, os utilizadores são criados no módulo Supervisor, na opção
Utilizadores de Clientes
. É ainda necessário na ficha do cliente, na opção de menu
Utilizadores deste cliente - PHC CS Web
e na página
Outras opções do Cliente
escolher as aplicações que o cliente adquiriu.
Instalação do IIS (Internet Information Services)
No painel de controlo do Computador, opção Adicionar/Remover Programas tem de escolher a opção de Adicionar/Remover Componentes do Windows para instalar o IIS. Este componente vai ser instalado por defeito em:
C:\Inetpub
Se ao instalar a aplicação encontrar um problema, a solução passa por aceder ao Painel de Controlo, Programas, Turn Windows features on or off, e definir as seguintes configurações:
Instalação da Aplicação
No CD de instalação, existe uma diretoria chamada 'Aplicacoes', dentro desta diretoria, existem as pastas com os nomes das aplicações e dentro de cada está um ficheiro zip.
- Para instalar o PHC CS Web é necessário ter o Web Pllaform Instaler (Deploy) instalado no IIS.
- Para instalar pode efetuar o download em http://www.iis.net/downloads/microsoft/web-deploy, ou no Cd de instalação na pasta Outros/ deploy, correr o setup.
No web Plaftorm installer 4.6 no separador "produts" proceder à instalação do Web Deploy 3.5.
No IIS, no Default Web Site efetuar clique direito e escolher a opção, deploy - Import application. O processo de instalação da aplicação passa por efetuar os seguintes passos:
1 - Selecionar o caminho onde se encontra o ficheiro da aplicação, por exemplo, "Intranet.zip".
2 - Na instalação surge os ficheiros que vão ser instalados. Não desseleccionar nenhum.
3 - O próximo passo devemos indicar qual o nome que pretendemos dar ao nosso projeto PHC CS Web
4- Ao clicar em next, será instalada a aplicação.
Poderá da mesma forma, instalar a aplicação da seguinte forma:
Poderá também, instalar a aplicação, ou atualizar o projeto do PHC CS Web de uma forma automática:
Podemos copiar os ficheiros da aplicação, que pretendemos instalar, para uma diretoria.
Dentro da pasta de PHC CS Web, no ficheiro intranet.setparameters.xml, editamos o ficheiro e colocamos o nome do projeto que pretendemos, dar exemplo: setParameter name="IIS Web Application Name" value="Default Web Site/intranet"
Abrir o Command prompt (como run as administrator) colocar o seguinte caminho (Exemplo):
Cd:C:\XPTO \intranet\intranet.deploy.cmd /y
Ao correr este ficheiro vai efetuar a instalação e criar o projeto com o nome que foi dado no intranet.setparameters.xml.
E para que seja um processo automático poderá criar um bat.file com as seguintes configurações, efetuando os seguintes passos:
@echo off
C:\intranet\intranet.deploy.cmd /y
Desta forma, cada vez que for necessário proceder a alguma atualização, basta correr o bat.file.
Como fazer um bat.file
Abrir um ficheiro Notepad e gravar o mesmo com extensão de .bat
, editar o ficheiro e colocar a informação acima indicada.
A aplicação que instalou fica, por defeito, na seguinte diretoria:
C:\inetpub\wwwroot\NomeDaAplicacao - Se não estiver neste local é porque o IIS (Internet Information Services), não foi instalado em c:\inetpub, neste caso, terá que verificar qual o caminho para a diretoria do IIS.
Se utilizar o IIS7 deve aceder ao mesmo, selecionar a aplicação que acabou de instalar e efetuar clique direito sobre a mesma. Selecionar a opção "Manage Application" e depois a opção "Advanced Settings".
O IIS vai abrir um ecrã de configurações avançadas onde se deve clicar no botão relativo ao Application Pool.
A aplicação volta a abrir um ecrã no qual se pode observar a versão da Framework relativa à Application Pool selecionada. Deve estar selecionada a versão a 4.5.
De forma a melhorar o desempenho em termos de rapidez do PHC CS Web devem ser efetuados os seguintes passos no IIS:
Aceder às Application Pools e selecionar a application pool utilizada pelo PHC CS Web;
Aceder às "Advanced Settings..." e selecionar as seguintes opções:
- Start Mode: AlwaysRunning
- Idle Time Out Action: Suspended
- Maximum worker processes: 0
Depois das alterações é necessário fazer o "Recycling..." da application pool.
Feitas estas verificações deve continuar a instalação da aplicação.
Utilizador ASPNET
Aquando da instalação da Framework, é criado no sistema um utilizador chamado ASPNET, este utilizador deve ser passado para o grupo dos Administradores locais da máquina, este procedimento é temporário para o arranque da aplicação, pois este utilizador só deverá estar neste grupo (Administradores) durante o arranque das aplicações PHC CS Web. Assim que todas as aplicações tenham sido executadas com sucesso pela 1ª vez, deverá o mesmo ser removido do referido grupo. Esta situação é necessária para que sejam (no 1º arranque bem sucedido) criados no event viewer os logs de cada aplicação.
Só é necessário este passo se a key do
Event Viewer
estiver com o valor Sim.
Instalação do IduServer
O IduServer é um aplicativo que está no cd de instalação e que deve ser instalado para quem precisa de impressões de idus em pdf nas aplicações PHC CS Web. As impressões em idu estão disponíveis nas seguintes tabelas: BO, FT, RD, FO, PE, RE, CL, PA, MH e PR.
Existe ainda uma
chave
no ficheiro
appSettings.config
, de nome <add key="SMTPSERVER" value="localhost "/>, essencial para que esta impressão funcione.
Se após instalação deste setup ocorrer um erro na aplicação ao imprimir idêntico a este:
"Erro IDU: Não foi possível inicial a aplicação de impressão." e "Erro IDU: Retrieving the COM class factory for component with CLSID {C05B3535-FA4F-4CBD-B3EA-AE999AD66101} failed due to the following error: 80040164", significa que o setup não conseguiu registar o ocx na máquina, neste caso deve registar à mão o seguinte ficheiro: iduserver.dll.
Poderá fazê-lo da seguinte forma:
regsvr32 c:\inetpub\wwwroot\iduserver\iduserver.dll
Dica: Deve instalar o iduserver na diretoria proposta pelo setup.
Nota Importante: Caso já tenha uma versão anterior instalada é necessário desregistar a dll da versão anterior e efetuar o registo da nova dll.
Configuração do ficheiro
appSettings.config
No local da instalação fica um ficheiro chamado
appSettings.config
.
Este ficheiro é muito importante pois é nele que existe muita da informação necessária à aplicação para que esta seja executada.
Nota: Este ficheiro é Case Sensitive, isto quer dizer que, por exemplo, On é diferente de on e nos casos de enganos as instruções não são lidas.
Entrada na Aplicação
Após a configuração do ficheiro
appSettings.config
a aplicação está preparada para arrancar, para tal basta no browser fazer:
Localhost/nome da aplicação [enter] (no caso do servidor local)
Nome do servidor/nome da aplicação [enter]
Nota: Depois de entrar uma vez na aplicação, deve retirar o utilizador ASPNET do grupo dos administradores.
Re-arranque da Aplicação
No caso de ser necessário re-arrancar a aplicação, é possível fazê-lo de diversas formas:
- alterando a chave do "
ENOME
" que se encontra no ficheiro
appSettings.config
e posteriormente, reiniciar o IIS (Internet Information Services);
- executando o comando: iisreset, na linha de comandos do DOS;
- através das opções de configuração acedidas pelo comando: ../programs/gensel.aspx?opcoes=sim (opção Re-arrancar a aplicação); ou
- re-arrancando o computador.
Dica:
O PHC CS Web demora mais de 30 segundos a arrancar de cada vez que um utilizador entra no software após este ter sido arrancado. É o momento em que o sistema compila a aplicação. Assim, para evitar que isto aconteça a outros utilizadores, sempre que arrancar a aplicação, entre na aplicação para que esta faça a compilação inicial.
Geral.css e User.css
Existe um ficheiro de configurações chamado geral.css, este ficheiro aquando da instalação da aplicação é colocado na diretoria CSS.
É no ficheiro de configurações geral.css, que estão definidos os formatos genéricos de toda a aplicação, sendo principalmente tamanhos, margens e alinhamentos.
Existem alguns CSS que permitem a definição das cores em função do tema cromático escolhido pelo utilizador, sendo os seguintes:
- Theme-default.css- Onde estão as definições do tema "Normal"
- Theme-classic.css - Onde estão as definições do tema "Cor"
- Theme-dark.css - Onde estão as definições do tema "Escuro"
- Theme-4.css - Onde estão as definições do tema "Aqua"
- Theme-5.css - Onde estão as definições do tema "Glaciar"
- Theme-6.css - Onde estão as definições do tema "Anil"
- Theme-7.css - Onde estão as definições do tema "Coral"
- Theme-8.css - Onde estão as definições do tema "Prado"
- Theme-9.css - Onde estão as definições do tema "Branco"
No caso de se pretenderem alterações, por exemplo às cores, estas devem ser feitas no ficheiro chamado user.css, que se encontra na diretoria PIMAGES e que fica vazio aquando da instalação. Não são aconselháveis alterações ao geral.css.
Existe um ficheiro para cada tema onde é possível pode sobrepor as definições de cores ao seu gosto:
- Pimages/user1.css para o tema "Normal"
- Pimages/user2.css para o tema "Cor"
- Pimages/user3.css para o tema "Escuro"
- Pimages/user4.css para o tema "Aqua"
- Pimages/user5.css para o tema "Glaciar"
- Pimages/user6.css para o tema "Anil"
- Pimages/user7.css para o tema "Coral"
- Pimages/user8.css para o tema "Prado"
- Pimages/user9.css para o tema "Branco"
Ficheiro [App_Offline](app_offline.md).txt
O ficheiro [App_Offline](app_offline.md).txt, que é instalado com o
PHC CS Web
, permite desligar temporariamente o site.
Quando se pretende, por exemplo, efetuar manutenção do site, basta renomear o ficheiro para
App_Offline.Htm
passando a surgir a informação de que o site se encontra temporariamente indisponível.
Para voltar a colocar o site disponível, ou seja, voltar a ligar, basta renomear o ficheiro para
[app_offline](app_offline.md).txt
.
Instalação e Configurações do Phc Cs Web
