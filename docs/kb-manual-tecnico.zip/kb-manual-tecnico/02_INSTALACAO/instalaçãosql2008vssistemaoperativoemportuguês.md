---
title: Instalaçãosql2008Vssistemaoperativoemportuguês
source: instalaçãosql2008vssistemaoperativoemportuguês.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãosql2008Vssistemaoperativoemportuguês

Instalação Sql 2008 Vs Sistema Operativo em Português

|  |
| --- |
| Instalação Sql 2008 Vs Sistema Operativo em Português |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Durante a instalação do SQL Server 2008 ou do SQL Express 2008, poderá eventualmente, surgir o seguinte erro, durante a verificação das regras de instalação do SQL:    Performance counter registry hive consistency failed        O erro em causa resulta do facto da versão a ser instalada do SQL 2008 (Server ou Express), ter como língua nativa de instalação o inglês, e o sistema operativo onde está a ser instalado encontrar-se em português.    Durante a instalação do SQL é pesquisada uma chave de registo no sistema operativo (Regedit), que não é encontrada, devido ao idioma do sistema operativo ser diferente do idioma do SQL Server.    O SQL, durante a instalação, efectua uma pesquisa no Regedit pela chave:    HKEY\_LOCAL\_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib\016    E encontra a seguinte:    HKEY\_LOCAL\_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib\0816    A forma de solucionar este problema passa por nos posicionar em **Start - Executar** e escrever no espaço correspondente o seguinte:        Posteriormente, ao abrir o ficheiro de registo do sistema operativo (Regedit), deverá seleccionar o menu Edit, e depois a opção "Find", para seguidamente realizar a procura pela chave supracitada.        Após encontrar a chave referida, deverá posicionar-se na mesma, efectuar clique direito e seleccionar "Export", de forma a exportar a mesma, por exemplo, para o desktop, renomeando-a para 123.reg (exemplo).     Seguidamente, deverá abrir o ficheiro renomeado (no exemplo, 123.reg) com o Notepad, de forma a editar o ficheiro em causa. Uma vez aberto o ficheiro, deverá seleccionar no menu **Edit** a opção **Replace**, para realizar Find/Replace **0816** por **016**.    Após realizar a substituição, grave o ficheiro.     Posicionando-se no ficheiro 123.reg, deverá efectuar duplo clique e a chave fica registada no registry dessa máquina. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação Sql 2008 Vs Sistema Operativo em Português' ) |