---
title: Instalaçãowebservicedeleilões
source: instalaçãowebservicedeleilões.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçãowebservicedeleilões

Instalação Webservice de Leilões

|  |
| --- |
| Instalação Webservice de Leilões |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A instalação do Web-Service de Leilões é o 1º passo para a instalação da versão Web.    Deverá aceder ao CD de instalação e localizar a diretoria "SETUP WEB\WEBSERVICE" e executar o ficheiro Setup.    São questionados os dados de licenciamento, como o nome do utilizador e da empresa:         Toda a instalação é simples (bastando clicar em "Seguinte").       A fase final de instalação pressupõe o preenchimento dos dados de acesso ao servidor WEB do cliente.         Neste ecrã, deverão ser preenchidos os seguintes campos:    **Servidor SQL**  Nome do Servidor SQL onde está instalada a base de dados Manufactor (e que o Web-Service vai aceder).    **Nome do utilizador**  Nome do Utilizador SQL a usar pelo Web-Service para aceder à base de dados Manufactor.    **Password do utilizador**  Password do Utilizador SQL a usar pelo Web-Service para aceder à base de dados Manufactor.    **Nome da base de dados**  Nome da base de dados Manufactor.    Como apresentado na imagem, deverá ser testada a conexão ao servidor (clicando em "Testar conexão").    *Nota*: Recomenda-se a consulta do tópico [Versão Web](versãoweb.htm) para uma melhor compreensão. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalação Webservice de Leilões' ) |