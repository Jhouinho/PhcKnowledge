---
title: Instalações
source: instalações.htm
tipo: Manual Técnico
idioma: PT
---

# Instalações

Instalações

|  |
| --- |
| Instalações |

|  |
| --- |
| A utilização da tabela de instalações é uma opção, ou seja, o utilizador pode configurar a aplicação para usar ou não a referida tabela. Para esse efeito deverá definir nos [Parâmetros gerais](Parâmetrosdasinstalações.htm#usa instalações) (menu Sistema) se pretende ou não usar a tabela de instalações.    Isto significa que existem então 2 possibilidades para fazer o acompanhamento dos diversos equipamentos:    1ª) Usando a [tabela de instalações](constituiçãodatabeladeinstalações.htm) que agrupará para cada instalação um ou mais equipamentos;    2ª) Usando apenas a tabela de equipamentos tendo estes registos independentes.    A ideia é muito simples: a partir da 1ª opção, pode-se afectar a cada cliente/instalação, todo o seu equipamento, obtendo desta forma estatísticas agrupadas e controlando assim todas as intervenções realizadas para um determinado cliente.    A partir dos [botões deste ecrã](opçõesdisponíveisnoecrãdeinstalações.htm) podem ser realizadas diversas opções.  Aqui serão explicados também os [parâmetros](parâmetrosdasinstalações.htm) e os [acessos](acessosdasinstalações.htm) das instalações. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalações' ) |