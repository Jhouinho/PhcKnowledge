---
title: Instalaçõesdesuporteweb
source: instalaçõesdesuporteweb.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçõesdesuporteweb

Instalações de Suporte Web

|  |
| --- |
| Instalações de Suporte Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção apenas se encontra disponível se o *PHC CS Desktop* trabalhar com instalações e o utilizador tiver o respetivo parâmetro ativo. Também deve ativar o parâmetro "Usa no menu a opção de instalações" da aplicação PHC CS Web, existente no nó **Suporte Extranet web** da **Intranet**.    Neste local poderá consultar todas as suas instalações.     As opções de consulta são:  **Marca**  Neste local pode consultar as marcas disponíveis, basta escolher a que pretende.    **Modelo**  Neste local pode consultar os modelos disponíveis, basta escolher o que pretende.    **Série**  A consulta pode ser efetuada por número de série do equipamento.    **Instalação**  No caso de pretender consultar os equipamentos de determinada instalação, basta colocar neste local o número da mesma.    **Instalações por página**  Pode escolher neste local, quantos registos de instalações pretende que sejam mostrados por página.    Para verificar as instalações basta clicar em **Instalações**.  Ser-lhe-á mostrada uma lista com os registos encontrados com as opções da sua procura.   Na lista apresentada, poderá, através da opção  selecionar a instalação pretendida.     Acede desta forma à **Instalação** onde encontra mais dados sobre a mesma, por exemplo se possuir equipamentos poderá ver a ficha do equipamento.  Na barra de ferramentas encontra as seguintes opções:  **Consulta de Instalações**  Esta opção permite-lhe voltar ao ecrã anterior para poder efetuar uma nova consulta de instalações.    **[Consulta de Pedidos](consultadepedidosnaextranet.htm)** |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalações de Suporte Web' ) |