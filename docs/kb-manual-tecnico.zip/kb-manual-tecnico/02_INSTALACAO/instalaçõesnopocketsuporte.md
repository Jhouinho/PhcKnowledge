---
title: Instalaçõesnopocketsuporte
source: instalaçõesnopocketsuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Instalaçõesnopocketsuporte

Instalações no Pocket Suporte

|  |
| --- |
| Instalações no Pocket Suporte |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite consultar as Instalações que passaram para o PDA.        Na parte superior do ecrã existe uma opção de procura. Os campos disponíveis para a procura são:  . Nº Instalação  . Nome/Ent.  . Agente  . Situação    e as condições de procura são:  = (igual),   < (menor),   > (maior),   <= (menor ou igual),   >= (maior ou igual),   começado por,   contém e   <> (diferente)    Na grelha apresentada é possível ver os registos das Intervenções ordenadas por qualquer uma das colunas. Para tal, basta clicar no nome da coluna pela qual se pretende ver a listagem ordenada.    Ao escolher a Instalação poderá consultar os dados disponíveis. Para tal deverá clicar nas páginas respectivas.   Na página **Dados** encontram-se os campos de identificação da Instalação, como se pode observar na imagem.          Na pagina **Outros/Ag.** podem observar-se os dados do Agente e da situação do equipamento.          Na pagina Equipamento podem visualizar-se os equipamentos relacionados com o a Instalação e navegar para o registo dos mesmos através do botão  .          Se pretender ter mais informação, poderá criar campos do utilizador. Estes campos são criados no módulo Supervisor na opção Campos para Dispositivos.  Se ao criar um campo para dispositivo, este já existir por defeito no Pocket, o mesmo não é considerado.     Os botões  e  permitem percorrer, uma a uma, as linhas das listagens apresentadas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Instalações no Pocket Suporte' ) |