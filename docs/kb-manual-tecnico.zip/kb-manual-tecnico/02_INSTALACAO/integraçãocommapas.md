---
title: Integraçãocommapas
source: integraçãocommapas.htm
tipo: Manual Técnico
idioma: PT
---

# Integraçãocommapas

Integração com Mapas

|  |
| --- |
| Integração com Mapas |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Ligação entre o software PHC e o provedor de mapas permite a análise de informação geográfica baseada em informação disponível nas bases de dados do PHC.    Depois de efectuar em [parâmetros](parâmetrosgerais.htm) as configurações necessárias para se poder navegar para o mapa a partir da morada, bastará clicar no novo botão ao lado do campo morada.     Depois de efectuados os procedimentos anteriores, fica disponível a visualização da informação geográfica nos seguintes ecrãs:    Módulo de Gestão   - Clientes;  - Fornecedores;  - Documentos de Facturação.     Módulo de CRM   - Contactos;  - Visitas.     Módulo de Suporte   - Instalações;  - Equipamentos.     Módulo de Imóveis   - Propriedades.     Todos   - Dossiers Internos;  - Entidades.     **NOTA:** **O utilizador tem que respeitar as condições de licenciamento do site de mapas.** **A PHC Não se responsabiliza pelo funcionamento do site de mapas.** **Os exemplos de sites, são apenas exemplos. O utilizador deve escolher o que desejar.**    Exemplos:    **Bing maps**    Endereço de mapa: http://www.bing.com/maps/?v=2&where1=#MORADA#%20Portugal&encType=1  Expressão de espaço no url de mapa: %20    **NOTA:** Quando se trabalha com o bing maps tem de se separar a morada da localidade e esta, do código postal, com vírgula.        **Yahoo**    Endereço de mapa: http://maps.yahoo.com/#mvt=m&zoom=17&q1=#MORADA#  Expressão de espaço no url de mapa: \_    **Google**    Endereço de mapa: http://maps.google.pt/maps?f=q&hl=pt&geocode=&q=#MORADA#  Expressão de espaço no url de mapa: + |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Integração com Mapas' ) |