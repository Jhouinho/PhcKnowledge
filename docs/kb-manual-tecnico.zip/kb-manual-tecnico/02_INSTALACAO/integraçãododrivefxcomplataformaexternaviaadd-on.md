---
title: Integração do Drive Fx com Plataforma Externa Via Add-on
source: integraçãododrivefxcomplataformaexternaviaadd-on.htm
tipo: Manual Técnico
idioma: PT
---

# Integração do Drive Fx com Plataforma Externa Via Add-on

Este artigo tem como objetivo fornecer um caso prático de criação de um add-on que integra dados de uma plataforma externa com o Drive FX.
Tudo isto através da framework Drive FX, utilizando o seu kitparceiro Drive FX.
A plataforma em causa é uma plataforma de Gestão de Eventos, e pretende-se importar para o Drive FX a informação acerca dos eventos criados. Isto para centralizar a informação num só local.
INTEGRAÇÃO DO DRIVE FX COM UMA PLATAFORMA DE GESTÃO DE EVENTOS
. Criar a ficha do add-on, através do menu Framework, opção
Add-ons
.
. Colocar o add-on em modo de desenho, através do botão
Ações
.
Construção dos campos e ecrã de Eventos
Inicialmente, deve-se analisar se os campos necessários à integração já se encontram no Drive FX, ou se existe necessidade de criar uma Personalização de Ecrã com campos, que melhor se adequem ao objetivo da integração.
Para este exemplo foi criada uma nova personalização de entidade, denominada
Eventos
, com os seguintes campos:
Nome
Descrição
Tipo
Comprimento
Decimais
Obrigatório
U8882_eventsstamp(*)
ID
Texto
