---
title: Interligaçãosíncrona
source: interligaçãosíncrona.htm
tipo: Manual Técnico
idioma: PT
---

# Interligaçãosíncrona

Interligação Síncrona

|  |
| --- |
| Interligação Síncrona |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A próxima imagem apresenta, de uma forma gráfica, um esquema técnico da interligação síncrona entre as duas bases de dados:           O administrador de sistema poderá optar pela sincronização síncrona, ao instalar as ligações ao software PHC, escolhendo a seguinte opção "Conector desligado": |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Interligação Síncrona' ) |