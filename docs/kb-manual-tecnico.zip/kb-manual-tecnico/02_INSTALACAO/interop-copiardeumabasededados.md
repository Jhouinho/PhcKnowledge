---
title: Interop Copiardeumabasededados
source: interop-copiardeumabasededados.htm
tipo: Manual Técnico
idioma: PT
---

# Interop Copiardeumabasededados

Interop - Copiar de uma Base de Dados

|  |
| --- |
| Interop - Copiar de uma Base de Dados |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico visa explicar de que forma se pode copiar tabelas entre diferentes bases de dados.    De forma a possibilitar a cópia de tabelas entre diversas empresas existe uma rotina, presente nas opções diversas do ecrã de Sociedades, denominada **Copiar de uma Base de Dados**.     Esta rotina vai permitir, por exemplo, aos gabinetes de contabilidade usufruirem de significativas vantagens, nomeadamente, a facilidade e rapidez na execução da cópia, sendo esta a de maior importância, assim como permite prevenir eventuais erros de utilizador, aquando da inserção de dados manualmente.    Um exemplo que ajudará a clarificar a importância desta rotina, em gabinetes de contabilidade, é referente à tabela de documentos Predefinidos, devido ao facto de cada gabinete utilizar os seus próprios documentos.     Assim, de forma a facilitar este processo, o gabintete poderá configurar a tabela de documentos Predefinidos, de uma determinada empresa, e copiá-la de forma rápida para as restantes empresas.    Para executar esta rotina o utilizador deverá posicionar-se na empresa para a qual pretende efetuar a cópia, ou seja, a sociedade de destino. Seguidamente, ao aceder à opção diversa **Copiar de uma Base de Dados** surgir-lhe-á o ecrã de Instalação e Manutenção, devendo preencher os campos **Nome do Server (Origem)**, **Nome da Base de Dados (origem)** e selecionar o **Método de Autenticação**. Também existe a possibilidade de validar a opção **Não apagar os registos que já existem**, de forma a evitar que a cópia dos dados da Base de Dados de origem apague os dados existentes na Base de Dados de destino.    Seguidamente, o utilizador apenas terá de selecionar quais as tabelas que pretende copiar para a sociedade de destino, premir **Instalar os ficheiros seleccionados** e a aplicação irá criar ou atualizar as Bases de Dados e copiar a informação definida (de Origem).         Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre InterOp, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=248389cf1c8.e9%3a%3a.ec55.8cg). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Interop - Copiar de uma Base de Dados' ) |