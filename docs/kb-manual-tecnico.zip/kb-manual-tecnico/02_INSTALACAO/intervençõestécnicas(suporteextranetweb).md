---
title: Intervençõestécnicas(Suporteextranetweb)
source: intervençõestécnicas(suporteextranetweb).htm
tipo: Manual Técnico
idioma: PT
---

# Intervençõestécnicas(Suporteextranetweb)

Intervenções Técnicas (suporte Extranet Web)

|  |
| --- |
| Intervenções Técnicas (suporte Extranet Web) |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção apenas é disponibilizada no menu se o parâmetro "Usa no menu a opção de intervenções técnicas" se encontrar ativo.  Neste local poderá consultar todas as intervenções realizadas a um determinado [pedido de assistência técnica](meuspedidosdeassistência.htm).      As opções de **Consulta de intervenções** são:    **Entidade**  Identifica o nome do cliente/entidade. Este campo é de preenchimento automático, fica preenchido com o nome do utilizador.    Pode **Observar apenas as Intervenções por realizar**, excluindo assim da sua pesquisa as intervenções já realizadas.    **Entre as datas do pedido**  Neste local pode definir um intervalo de datas no qual se insira o pedido de assistência relacionado com a intervenção em pesquisa.    **Técnico**  Permite procurar pelo nome do técnico.    **Marca**  Permite procurar pela marca do equipamento.    **Modelo**  Permite procurar pelo modelo do equipamento.    **Série**  Permite procurar pelo nº de série do equipamento.    **Pedido de Assistência**  Permite procurar pelo nº do pedido de Assistência.    **Intervenções por página**  Quantas intervenções por página pretende consultar.    Após definir todas as opções de consulta pretendidas terá que clicar em **Intervenções Técnicas** para a observar a listagem.        Ao clicar na opção , poderá visualizar a intervenção.      **Nome**  Nome do cliente    **Número**  Número do Cliente      ``` Página Principal ``` **Realizada**  Permite identificar se a intervenção em causa foi realizada ou não.    **Nº Pat**  Permite identificar o nº do pat associado a esta intervenção. Ao clicar no nº pode navegar para o [PAT](meuspedidosdeassistência.htm).    **Instalação**  Permite identificar o nº da instalação associada a esta intervenção. Ao clicar no nº pode navegar para a [instalação](instalaçõesdesuporteweb.htm).    **Série**  Permite identificar o Nº de série do equipamento da intervenção.    **Marca**  Permite identificar a marca do equipamento da intervenção.    **Modelo**  Permite identificar o modelo do equipamento da intervenção.    ``` Relatório ``` **Relatório**  Nesta opção é possível observar o relatório da intervenção.    Poderá, através do botão surtido para o efeito, imprimir o documento.    Pode ainda aceder à opção de [Consulta de Intervenções](IntervençõesTécnicas(SuporteExtranetWeb).htm#mpsmhview) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Intervenções Técnicas (suporte Extranet Web)' ) |