---
title: Introduçãoeconfiguraçãodoclínica
source: introduçãoeconfiguraçãodoclínica.htm
tipo: Manual Técnico
idioma: PT
---

# Introduçãoeconfiguraçãodoclínica

Introdução e Configuração do Clínica

|  |
| --- |
| Introdução e Configuração do Clínica |

|  |
| --- |
| Este package visa permitir a gestão eficiente de uma Clínica a partir do controlo total do processo clínico e administrativo. Para uma boa gestão desta aplicação o utilizador deverá proceder inicialmente à sua [parametrização](parâmetrosdoclínica.htm) e de seguida efetuar todas as configurações inerentes ao funcionamento da mesma.   No primeiro plano, para além de toda a informação relativa à identificação e historial do [paciente](pacientes.htm) facilmente preenchida na primeira consulta, o utilizador pode, através das [Medidas do Paciente](OpçõesDisponíveisnoEcrãdePacientes.htm#mpsobs3), [Dados Clínicos](dadosclínicosdopaciente.htm) e [Fichas Visuais](OpçõesDisponíveisnoEcrãdePacientes.htm#mpsvisual), atualizar a informação sempre que o achar necessário. Esta informação do foro clínico é gerida por [acessos](acessosdoclínica.htm) atribuídos a cada utilizador, acessos estes criados de uma forma muito rigorosa com o fim de permitir, por exemplo, a introdução de registos por médicos, a visualização dos mesmos por assistentes e proibir o acesso aos mesmos a colaboradores da área administrativa.  Ainda e não menos importante é a localização de ecrãs de informação clínica, a qual foi distribuída pelas opções fulcrais relacionadas com pacientes, como por exemplo, [Marcações](marcações.htm) e [Agenda de Marcações](agendademarcações.htm).    No Plano Administrativo este package conta com uma Agenda de Marcações, a partir da qual, e de acordo com os acessos concedidos a cada utilizador, é possível aceder às restantes opções primárias da aplicação como sendo os Pacientes, os [Períodos por Especialista/Especialidade](períodosporespecialistaespecialidade.htm) e às Marcações. A agenda permite uma visualização rápida de todas as marcações efetuadas e marcadas para o dia definido pelo utilizador, podendo esta informação ser filtrada por Especialidade e/ou por especialistas. Ainda, esta opção conta com uma legenda que pode ser facilmente criada pelo utilizador de forma a permitir distinguir as marcações através de cores, por exemplo; marcações efetuadas, pacientes atrasados, entre outros; possibilitando assim uma gestão e análise no momento, da rotina diária da Clínica. Ainda neste âmbito, as marcações de consultas para além de serem efetuadas de acordo com os horários estipulados de cada especialista, levam ainda em consideração as [ausências](registodeperíodosextraausênciasdeespecialista.htm) dos mesmos previamente marcadas.   É através do ecrã de Marcações, o qual permite aceder à informação do foro administrativo mas também a toda a informação do foro clínico através do processo clínico e da distribuição de opções a cima referidas, que se processa a [faturação ao Cliente/Entidade](configuraçãodafaturação.htm) de acordo com as [comparticipações](comparticipações.htm) e valores de tratamentos e consultas previamente estabelecidos. A componente Faturação só existe no Clínica caso o utilizador tenha devidamente instalado o módulo Gestão.  For fim, o processo administrativo agrega ainda a gestão da informação relativa aos Clientes, Stocks e Serviços, Comparticipações, [Configurações de texto para a Faturação](configuraçãodetextoparafaturação.htm) e Emissão Automática de faturação, sendo esta última muito prática quando, por exemplo, se fatura a uma entidade um número elevado de consultas efetuadas.   Existe ainda um outro plano igualmente importante neste package; o Plano estatístico, que permite efetuar análises minuciosas relativamente aos pacientes e às marcações, contribuindo assim para uma gestão eficaz da unidade clínica. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Introdução e Configuração do Clínica' ) |