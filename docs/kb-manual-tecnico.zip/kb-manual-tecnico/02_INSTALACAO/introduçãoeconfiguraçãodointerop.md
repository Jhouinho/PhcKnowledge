---
title: Introduçãoeconfiguraçãodointerop
source: introduçãoeconfiguraçãodointerop.htm
tipo: Manual Técnico
idioma: PT
---

# Introduçãoeconfiguraçãodointerop

Introdução e Configuração do Interop

|  |
| --- |
| Introdução e Configuração do Interop |

|  |
| --- |
| Este manual irá explicar ao utilizador como utilizar o programa, onde é possivel interligar e operar diversas bases de dados em simultâneo, agendando [tarefas](tarefasagendadas.htm) ou executando individualmente [processamentos](monitordeprocessamentos.htm) e [mapas](monitordemapas.htm).    Existem configurações importantes, que o utilizador deverá definir antes de iniciar o trabalho com as diversas [sociedades](sociedades.htm), e [acessos](acessosdointerop.htm) do utilizador.    Contamos que, com este Manual e alguma prática consiga, rapidamente, utilizar este programa. Não queremos, no entanto, deixar de chamar a atenção para a importância da leitura total e atenta tanto das [Opções Globais](opçõesglobais.htm) como deste Manual antes de iniciar o seu trabalho.    *Nota Importante:*  Se possuir o módulo InterOp na gama Corporate só pode efectuar Processamentos, imprimir Mapas, Copiar Bases de Dados, efectuar Instalação e Manutenção, executar Integrações pelo Monitor, etc, para bases de dados de Corporate, ou seja com MSDE ou SQL Server Desktop Engine.   Em suma, na gama Corporate as funcionalidades deste módulo não funcionam para Bases de dados em SQL Server. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Introdução e Configuração do Interop' ) |