---
title: Introduçãoeconfiguraçãodosuporte
source: introduçãoeconfiguraçãodosuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Introduçãoeconfiguraçãodosuporte

Introdução e Configuração do Suporte

|  |
| --- |
| Introdução e Configuração do Suporte |

|  |
| --- |
| Este manual irá explicar ao utilizador como [utilizar o programa](funcionamento.htm), onde está arquivada toda a informação sobre cada instalação, equipamento, pedido de assistência e intervenção, e como são efectuados os respectivos passos.    Existem configurações importantes, para além das Tabelas de códigos, que o utilizador deverá definir antes de iniciar o trabalho com o Software, tais como os diversos Parâmetros:     * [Equipamentos](parâmetrosdosequipamentos.htm)  * [Instalações](parâmetrosdasinstalações.htm)  * [Marcas e modelos](parâmetrosdosequipamentos.htm)  * [Agenda de marcações](parâmetrosdaagendademarcações.htm)  * [Pedidos de assistência](parâmetrosdospedidosdeassistência.htm)      e os Acessos dos utilizadores.     * [Intervenções técnicas](acessosdasintervençõestécnicas.htm)  * [Área de marcações](acessosdaáreademarcações.htm)  * [Base de dados técnica](acessosdabasededadostécnica.htm)  * [Marcações](acessosdasmarcações.htm)  * [Marcas e modelos](acessosdasmarcasemodelos.htm)  * [Pedidos de assistência](acessosdospedidosdeassistência.htm)  * [Instalações](acessosdasinstalações.htm)  * [Técnicos](acessosdostécnicos.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Introdução e Configuração do Suporte' ) |