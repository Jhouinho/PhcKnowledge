---
title: Invalid Seek Offset
source: invalidseekoffset.htm
tipo: Manual Técnico
idioma: PT
---

# Invalid Seek Offset

Problema:
Invalid
 seek offset
Solução:
Este
 erro acontece quando existe uma falha de rede, como tal o sistema deve ser
 analisado, nomeadamente verificar quais os PC´s que penduram (se é só um ou
 mais), verificar as placas de rede, retirar e voltar a instalar os protocolos,
 verificar os cabos de rede, etc.
Por
 vezes acontece esta situação pelo facto do posto ter na BIOS activado o modo
 sleep o que faz com que a placa se desactive da rede após alguns minutos sem
 reconhecer actividade.
