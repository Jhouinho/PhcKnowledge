---
title: Inventáriopermanente
source: inventáriopermanente.htm
tipo: Manual Técnico
idioma: PT
---

# Inventáriopermanente

Inventário Permanente

|  |
| --- |
| Inventário Permanente |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Como é do conhecimento geral o inventário permanente visa fazer o apuramento do Resultado Bruto (ou Margem Bruta) todos os meses, ao contrário do inventário intermitente ou periódico, que só permite obter os mesmos resultados no final do ano, em que é lançado pela totalidade os custos das mercadorias vendidas e matérias consumidas (CEV e MC).    O Inventário Permanente é actualmente obrigatório para todas as empresas que cumpram dois de três requisitos:    1- 10 funcionários em média durante o ano;   2- 700 mil euros de Volume de negócios;  3- 350 mil euros de Balanço.    **Configuração**    No ficheiro de artigos, deverão ser colocadas duas contas para cada artigo (que não seja um serviço):     * Conta de Existências: 32...  * Conta de Custo de Existências Vendidas: 61...    *Nota*:  Os campos assinalados encontram-se na página **Integração** da ficha do artigo.    Quando se executa a integração na Contabilidade, com a opção **Movimentar inventário permanente**, são executados os seguintes movimentos:    **1 -** nas compras:  É efectuado um movimento a crédito na conta de compras pelo valor líquido da compra (Valor da compra após descontos comerciais mas antes de descontos financeiros), é efectuado um movimento a débito na conta de existências do artigo por este mesmo valor.    *Nota*:  Existe uma outra opção, "O desconto financeiro é lançado em existências"  Se for utilizada esta opção, o valor creditado na conta de compras e debitado na conta de existências é o valor da compra após descontos comerciais e financeiros.    **2 -** na facturação:  É debitada a conta de custo de existências vendidas (definida na ficha do artigo) pelo valor do custo da venda. Este valor é exactamente o valor que estiver gravado na linha do documento de facturação no momento da integração. É ainda creditada a conta de existências definida na ficha do artigo pelo mesmo valor.    No caso de documentos de facturação com oferta de existências, por exemplo, uma factura que contém um artigo cujo Valor é zero (oferta).  As conta SNC do artigo oferta estão definidas da seguinte forma:  conta de inventário - 3213  CEV - 612  REO - 3823  COE 6884  IEO - 6312    A contabilização desta factura será:    - com Inventário Permanente, quando o valor da oferta não excede o limite  Debita - 6884   Credita - 3823 (pelo preço custo)    Debita - 3823  Credita - 3213 (pelo preço custo)    - com Inventário Permanente, quando o valor da oferta excede o limite  Debita - 6884   Credita - 3823 (pelo preço custo)  Debita - 6312  Credita - 243323 (pelo valor do Iva)    Debita - 3823  Credita - 3213 (pelo preço custo)    - sem Inventário Permanente, quando o valor da oferta não excede o limite  Debita - 6884   Credita - 3823 (pelo preço custo)    - sem Inventário Permanente, quando o valor da oferta excede o limite  Debita - 6884   Credita - 3823 (pelo preço custo)  Debita - 6312  Credita - 243323 (pelo valor do Iva)    *Nota*: Situações proibidas com a utilização de Inventário Permanente:   * Nunca ter Stocks negativos;  * Nunca integrar as Vendas para a Contabilidade, antes de ter lançadas as Compras. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Inventário Permanente' ) |