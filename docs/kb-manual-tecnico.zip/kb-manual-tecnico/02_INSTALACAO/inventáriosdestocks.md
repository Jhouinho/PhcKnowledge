---
title: Inventáriosdestocks
source: inventáriosdestocks.htm
tipo: Manual Técnico
idioma: PT
---

# Inventáriosdestocks

Inventários de Stocks

|  |
| --- |
| Inventários de Stocks |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta análise permite obter diversos inventários de stocks.    **Inventários de Stocks**    Nesta opção tem a possibilidade de realizar inventários por armazém, por determinada data, ou ambos, podendo escolher ainda quais as valorizações que quer dar ao Stock.  Para além de visualizar os valores do inventário pretendido poderá também incluir na listagem:    * incluir Lotes, sendo possível visualizar os lotes dos artigos que fazem parte do inventário. Esta opção só se encontra disponível se possuir o módulo de lotes;  * incluir cores e tamanhos, sendo possível visualizar as cores e tamanhos dos artigos que fazem parte do inventário. Esta opção só se encontra disponível se possuir o módulo das grelhas;  * incluir Série, sendo possível visualizar o número de série dos artigos que fazem parte do inventário e que se encontram em armazém, para utilizar esta funcionalidade o tipo de inventário não poderá ser definido para uma determinada data. Esta opção só se encontra disponível se possuir o módulo suporte ou equipamento;  * incluir zona do armazém, sendo possível visualizar a zona do armazém onde se encontra o artigo. Esta opção apenas está disponível se possuir o Módulo Logística;  * incluir Alvéolo, sendo possível visualizar o alvéolo onde se encontra o artigo. Esta opção apenas está disponível se possuir o Módulo Logística.          Poderá observar uma lista com os armazéns disponíveis para o inventário. O utilizador poderá escolher todos os armazéns, ou então, a partir da lista, remover ou adicionar armazéns. Essa lista estará disponível apenas quando o tipo de inventário é "Inventário com stock separado por armazém" ou "Inventário por armazém em determinada data".    Há também a possibilidade de poder filtrar de acordo com um tipo de inventário especifico, determinado a partir do botão "Tipo para inventário".        Ao selecionar uma das opções deste campo a aplicação irá filtrar e apresentar apenas os resultados que se enquadrem de acordo todas as opções selecionadas deste ecrã, incluindo a escolhida neste campo.    *Nota*: Esta funcionalidade apenas se encontra disponível para quem disponha de PHC ON ativo.    O inventário a visualizar poderá ser ordenado por Referência, Designação, Família, Armazém, Zona e Alvéolo (estas duas últimas apenas disponíveis com o Módulo Logística). Se ordenar o inventário por família, zona ou alvéolo, fica visível o campo **Sub-totaliza famílias**, **Sub-totaliza zonas** ou **Sub-totaliza por Alvéolos** que permite sub-totalizar as quantidades e valores dessas ordenações. Se tiver o parâmetro [Cálculo do inventário no servidor (reinstalar triggers)](ParâmetrosdeStockseServiços.htm#mchcinven) no nó Stocks", permite que seja feito um cálculo parcial do inventário no servidor de SQL.    **Sub-Totaliza Armazéns**   Esta opção só aparece disponível caso a ordenação do inventário seja efectuada por armazém, pelo que, o utilizador pode decidir se os resultados são ou não apresentados com sub-totalização por armazém.    Permite ainda a [visualização](opçõesdasanálises.htm) do inventário ou impressão, a emissão de [etiquetas](idusdeetiquetas.htm) e definir um [filtro](filtros.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Inventários de Stocks' ) |