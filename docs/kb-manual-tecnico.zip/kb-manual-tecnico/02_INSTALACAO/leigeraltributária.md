---
title: Lei Geral Tributária
source: leigeraltributária.htm
tipo: Manual Técnico
idioma: PT
---

# Lei Geral Tributária

RECURSO CONTECIOSO AUTÓNOMO DAS INFORMAÇÕES VINCULATIVAS
Passa a existir possibilidade de recurso contencioso autónomo quanto às decisões da Administração Tributária relativa a:
Inexistência dos pressupostos para a prestação de uma informação vinculativa ou a recusa de informação vinculativa urgente;
Existência de especial complexidade técnica que impossibilite a prestação da informação vinculativa;
Enquadramento jurídico-tributário dos factos constantes da resposta ao pedido de informação vinculativa.
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
ORIENTAÇÕES GENÉRICAS
Passa a existir a obrigação de revisão, por parte da Administração Tributária, quanto às orientações genéricas por si emanadas, de acordo com a jurisprudência dos tribunais superiores (Tribunal Central Administrativo (Sul e Norte) e Supremo Tribunal Administrativo).
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
PAÍSES, TERRITÓRIOS OU REGIÕES COM UM REGIME FISCAL MAIS FAVORÁVEL
Passa a existir a definição do conceito de país, território ou região com regime fiscal claramente mais favorável, considerando-se como tais aqueles que constam de Portaria aprovada pelo Governo (atualmente, Portaria n.º 150/2004, de 13 de Fevereiro com as alterações da Portaria n.º 292/2011, de 8 de Novembro), concretizando-se que estarão abrangidos nessa qualificação os países, territórios ou regiões que:
Não disponham de um imposto de natureza idêntica ou similar ao IRC ou, dispondo, a taxa aplicável seja inferior a 60% da taxa de imposto prevista no n.º 1 do artigo 87.º do Código do IRC (atualmente, de 25%);
As regras de determinação da matéria coletável sobre a qual incide o imposto sobre o rendimento divirjam significativamente dos padrões internacionalmente aceites ou praticados, nomeadamente pelos países da OCDE;
Existam regimes especiais ou de benefícios fiscais, designadamente isenções, deduções ou créditos fiscais, mais favoráveis do que os estabelecidos na legislação nacional, dos quais resulte uma redução substancial da tributação
A legislação ou a prática administrativa não permita o acesso e a troca efetiva de informações relevantes para efeitos fiscais.
Prevê-se a possibilidade dos países constantes dessa lista solicitarem a revisão do respetivo enquadramento, com base no não preenchimento dos critérios definidos.
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
PRESUNÇÃO NO QUE CONCERNE ÀS DECLARAÇÕES DOS SUJEITOS PASSIVOS
Alteração à regra da presunção de veracidade de que gozam as declarações apresentadas pelos sujeitos passivos, bem como dos dados constantes da sua contabilidade ou escrita que, para além de estar condicionada à verificação de que as mesmas estejam organizadas de acordo com a legislação comercial e fiscal, passam a estar também condicionada à verificação dos demais requisitos de que depende a dedutibilidade dos gastos.
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
CONFIDENCIALIDADE
É cessado o dever de confidencialidade que impende sobre a Administração Tributária quando se vise confirmar o número de identificação fiscal e domicílio fiscal às entidades competentes para a realização do registo comercial, predial e automóvel.
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
SIMULAÇÃO DOS NEGÓCIOS JURÍDICOS
Eliminação da condição de declaração de nulidade por parte do órgão judicial para efeitos da tributação do negócio jurídico real constante de documento autêntico.
INFORMATIVO
Esta informação deve ser aplicada no contexto individual de cada pessoa/empresa, não existindo qualquer suporte por parte da PHC.
Para regressar à página principal clique
aqui
