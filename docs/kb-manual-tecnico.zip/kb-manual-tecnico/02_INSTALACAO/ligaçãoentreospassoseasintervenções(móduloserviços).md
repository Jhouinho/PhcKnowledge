---
title: Ligaçãoentreospassoseasintervenções(Móduloserviços)
source: ligaçãoentreospassoseasintervenções(móduloserviços).htm
tipo: Manual Técnico
idioma: PT
---

# Ligaçãoentreospassoseasintervenções(Móduloserviços)

Ligação Entre os Passos e As Intervenções (módulo Serviços)

|  |
| --- |
| Ligação Entre os Passos e As Intervenções (módulo Serviços) |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Como não existe ligação entre os registos de intervenções e os passos de intervenções não existe forma de criar IDUs de intervenções com informação dos passos que deram origem às intervenções.  Para ultrapassar esta situação pode-se fazer uma implementação específica com campos de utilizador e valores por defeito.    1º - Criar campo de utilizador na tabela de intervenções de serviços para guardar o stamp da intervenção.  Tabela: Cali  Nome do campo: calpstp (que será guardado na tabela como u\_calpstp)  Tipo de campo: 3 (tabela e lista)  Tipo: Caracter  Tamanho: 25    2º - Criar outro campo de utilizador (do tipo virtual). Podem-se criar um ou mais campos por cada campo do passo que se queira disponível no idu da intervenção. Neste exemplo é apenas criado um campo virtual que corresponde ao campo resumo da tabela passos.    Campo para guardar o resumo do passo na intervenção :  Tabela = Cali  Nome do campo = resumo2 (por exemplo)  Descritivo = resumo2  Tipo de campo = 2 (virtual)  Tipo = Caracter  Tamanho = 35  Expressão em Transact SQL:  select resumo from calp (nolock) where calp.calpstamp=cali.u\_calpstp    3º - Criar um valor por defeito para que ao transformar um passo numa intervenção, o stamp do passo seja guardado na tabela de intervenções (no 1º campo de utilizador que foi criado).  Tabela = Cali  Campo = calpstp  Comando Xbase = calp.calpstamp    O valor por defeito é executado assim que começa a introduzir um registo no ecrã.    Tendo estes campos criados e instalados e o default criado, a aplicação passa a ter o seguinte comportamento:    A partir dos passos sempre que se transformar em intervenção (opções diversas do ecrã), o valor por defeito irá colocar o stamp do passo no registo da intervenção na coluna u\_calpstp. Ao desenhar o IDU da intervenção, passa a ter disponível um novo campo - Resumo2, que devolverá como resultado, o conteúdo do campo Resumo do passo. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Ligação Entre os Passos e As Intervenções (módulo Serviços)' ) |