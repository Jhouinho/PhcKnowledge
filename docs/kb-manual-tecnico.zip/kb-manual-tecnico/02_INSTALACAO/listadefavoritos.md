---
title: Lista de Favoritos
source: listadefavoritos.htm
tipo: Manual Técnico
idioma: PT
---

# Lista de Favoritos

Esta opção permite criar links para os ecrãs utilizados mais frequentemente.
A Lista de Favoritos contêm os
links
que o utilizador tem interesse em guardar para o acesso rápido à informação / página pretendida.
Para adicionar os ecrãs da aplicação na Lista de Favoritos tem disponível, em cada um deles, o botão
. Desta forma, ao clicar no botão, o ecrã "Favoritos" é preenchido automaticamente com o link do ecrã e ao gravar é apresentado na
Lista de Favoritos
.
Encontra-se sempre visível a lista dos favoritos definidos para constarem na lista principal. Através do clique em qualquer um destes favoritos, acede à página / site respetivos.
Ao clicar no título da lista, terá acesso a uma listagem de todos os favoritos existentes agrupados por categoria. Nesta listagem poderá aceder à página pretendida, bastando para tal clicar na designação/resumo do favorito respetivo. Aqui tem ainda a possibilidade de aceder ao ecrã de favoritos, através da opção "Ir para o ecrã de Favoritos".
Resumo
Permite indicar o nome do favorito, ou o nome do ecrã que pretende aceder de forma a ser percetível.
Link
Permite indicar o caminho do
link
para aceder ao favorito.
Exemplo:
Se se encontra na
Intranet
e pretende criar um favorito para as Tarefas Pessoais, neste campo terá que colocar:
http://nomedoserver/intranet18setup/pim/etpform.aspx
Categoria
O utilizador tem a possibilidade de organizar os seus favoritos por categoria. Poderá selecionar uma categoria já existente, ou, através do ícone
criar um novo registo.
Está na lista principal
- Ao ativar esta opção o favorito criado ficará disponível na listagem de favoritos do lado esquerdo do menu.
Poderá também através dos botões:
- Imprimir a informação existente no ecrã;
- Associar a Lista de Favoritos aos próprios
favoritos
;
- Permite ao utilizador aceder à ajuda disponibilizada com a aplicação;
Minhas Opções
