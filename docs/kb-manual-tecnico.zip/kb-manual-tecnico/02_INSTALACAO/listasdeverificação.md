---
title: Listasdeverificação
source: listasdeverificação.htm
tipo: Manual Técnico
idioma: PT
---

# Listasdeverificação

Listas de Verificação

|  |
| --- |
| Listas de Verificação |

|  |
| --- |
| Para que o diagnóstico seja o mais preciso, objectivo e exaustivo possível, a equipa Auditora deve estar munida de meios documentais que auxiliem na preparação, condução e apresentação de resultados.     A documentação normalmente associada à preparação e realização de auditorias é constituída pelos documentos internos do sistema, tais como, procedimentos, instruções de trabalho e registos por documentos externos, como por exemplo o referencial normativo, outras normas ligadas ao produto/serviço que a organização entende subscrever e, ainda, a legislação e regulamentação em vigor, especificações de produto, projectos, etc..    Podem utilizar-se [listas de verificação](constituiçãodatabeladelistasdeverificação.htm) que descriminem os diversos aspectos a controlar dentro de cada área. Analisam-se os requisitos e estabelece-se a conformidade/não conformidade avaliando de forma objectiva, de acordo com o estipulado na legislação e normalização da auditoria.     Para se usar a lista de verificação com eficácia, é importante que se tenha uma compreensão clara dos objectivos, dos dados e dos resultados finais que dela podem originar. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Listas de Verificação' ) |