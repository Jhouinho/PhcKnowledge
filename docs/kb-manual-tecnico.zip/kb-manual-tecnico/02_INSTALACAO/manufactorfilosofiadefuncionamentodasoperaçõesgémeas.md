---
title: Manufactorfilosofiadefuncionamentodasoperaçõesgémeas
source: manufactorfilosofiadefuncionamentodasoperaçõesgémeas.htm
tipo: Manual Técnico
idioma: PT
---

# Manufactorfilosofiadefuncionamentodasoperaçõesgémeas

Manufactor: Filosofia de Funcionamento das Operações Gémeas

|  |
| --- |
| Manufactor: Filosofia de Funcionamento das Operações Gémeas |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O conceito de operações gémeas, baseia-se na possibilidade de associar várias operações, para que ao nível do planeamento, se possa ao comandar e controlar uma das operações (a principal), e garantir que todas as operações gémeas da principal sejam, em simultâneo, objeto das mesmas ações de planeamento.    Para que se possam associar várias operações e denomina-las gémeas, há que considerar os seguintes requisitos:    **1) As operações gémeas, pressupõem que existam em primeira instância, moldes na gama operatória.**    Ao introduzir várias OF que tenham em comum o uso de um molde e um mesmo centro de trabalho, será possível identificar uma OF principal e as restantes operações gémeas da principal. Desta forma, o planeamento das mesmas, será comum e comandado pela OF principal.    **2) Para que seja possível o uso de operações gémeas, é ainda necessário que o estado das OF seja "Lançada" ou "Confirmadas não agendadas".**     Se se verificar este pré-requisito, é possível de forma automática (através do ecrã de confirmação de várias OF), determinar que todas as OF que tenham em comum o uso de um determinado molde, sejam gémeas.     Será também possível, manualmente, ao efetuar duplo clique no campo "Gémea" do ecrã "Ordens de Fabrico", ver que outras "Ordens de Fabrico" têm operações que podem ser consideradas gémeas da que estamos posicionados (é necessário que estejamos posicionados numa OF com molde na gama operatória).     Como resultado da associação de operações através deste conceito obtém-se:    Ao escolhermos como gémea uma operação de outra OF, ao navegarmos para o registo da mesma, verificamos que ela ficou dependente da primeira, no entanto, na OF principal a gémea é apresentada como sendo ela mesma (ou seja é sempre apresentado no campo Gémea, o valor da OF principal).     No ecrã de planeamento, a pesquisa de OF deve ser sempre feita pela OF principal sendo que as outras estão dependentes desta.    As OF quando associadas por operações gémeas são sempre apresentadas no diário de trabalho com a duração da mais longa do conjunto.    *Exemplo*:  Operação 1 -&gt 1 hora   Operação 2 -&gt 1/2 hora  Operação 3 -&gt 2 horas (principal)    Neste cenário, no "Diário de Trabalho", os tempos considerados para as operações 1 e 2 são equivalentes ao tempo da operação 3. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Manufactor: Filosofia de Funcionamento das Operações Gémeas' ) |