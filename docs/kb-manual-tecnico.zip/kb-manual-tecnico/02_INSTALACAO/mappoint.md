---
title: Mappoint
source: mappoint.htm
tipo: Manual Técnico
idioma: PT
---

# Mappoint

Mappoint

|  |
| --- |
| Mappoint |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A integração entre o Software PHC e o Microsoft MapPoint permite a análise de informação geográfica (mapas, rotas e análise de dispersão), baseada em informação disponível nas bases de dados PHC.    Para utilizar este Software integrado no Software PHC deve: - Instalar uma licença de MapPoint 2004;  - Ativar o respectivo parâmetro no Software PHC, **Usa MapPoint 2004 (Tem que reiniciar a aplicação!)**.     Depois de efetuados os procedimentos anteriores, fica disponível a visualização da informação geográfica nos seguintes ecrãs:  Módulo de Gestão  * Clientes;  * Fornecedores;  * Documentos de Facturação.   Módulo de CRM  * Contactos;  * Visitas.   Módulo de Suporte  * Instalações;  * Equipamentos.   Módulo de Imóveis  * Propriedades.   Todos  * Dossiers Internos;  * Entidades.       Nas **opções disponíveis no ecrã** aparece o seguinte botão, , que permite:   - Localizar a posição no mapa   Ao clicar nesta opção e caso existam várias moradas mas com códigos postais diferentes, é questionado ao utilizador qual pretende visualizar:        O utilizador deverá escolher a morada que pretende clicando no seguinte botão,  ou , conforme o pretendido.    Caso clique no botão de visualizar será apresentado o mapa indicando a posição da morada em questão.         - Rota da Sede para esta morada   Ao clicar nesta opção será apresentado o melhor caminho da morada da sede à morada em questão.        O ponto 1 indica a morada da sede, o ponto 2 indica a morada em questão. O software MapPoint indica o caminho exato que precisa de efetuar entre as duas moradas:          Nas **Opções disponíveis no Menu** de cada ecrã, poderá visualizar a **Análise de dispersão geográfica em MapPoint 2004**. Esta análise apresenta num mapa a localização de diversos pontos, ou seja, pode fazer um filtro a uma determinada tabela que tenha moradas, neste caso códigos postais e gerar um mapa com essa informação.  Por exemplo: Observar todos os clientes de um vendedor        O Software MapPoint 2004 permite uma série de análises adicionais. Na maior parte dos casos estas análises podem ser realizadas com a importação de dados do exterior, nomeadamente de folhas de cálculo Excel. Em virtude do Software PHC permitir exportar para Excel ou [Open Office Calc](ManutençãoPersonalizada.htm#Open Office Calc) todos os dados que o utilizador pretender, é possível aproveitar todas as excelentes funcionalidades que este produto possuí.    Exemplos:  Nos dossiers Internos, poderá efetuar a rota necessária para efetuar a entrega de mercadorias, apartir das Guias de Remessas.      No final poderá imprimir o percurso a fazer ou então imprimir o mapa que contém o percurso. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Mappoint' ) |