---
title: Menu da Aplicação
source: menudaaplicação.htm
tipo: Manual Técnico
idioma: PT
---

# Menu da Aplicação

As aplicações
PHC CS Web
dividem-se em três tipos distintos, consoante a sua natureza. Primeiramente, existe a
Intranet
que inclui todas as aplicações internas, a
Extranet
que inclui as aplicações externas e o
Portal
que se encontra disponível a qualquer pessoa que aceda ao site.
As
Aplicações Internas
têm uma autenticação diretamente relacionada com a tabela de utilizadores do Sistema PHC.
Na aplicação
PHC CS Desktop
deve, na pasta "Acessos PHC CS Web" do ficheiro de utilizadores, definir que o utilizador tem acesso via
PHC CS Web
e qual a
password
de acesso.
Conforme as aplicações instaladas é possível dar ou não acesso individual a cada uma delas.
Por exemplo, um utilizador poderá ter acesso à aplicação
Gestão web
e não ter à aplicação
Contabilidade web
, para tal basta passar para o lado dos packages incluídos a aplicação
Gestão web
.
As
Aplicações Externas
têm uma autenticação diretamente relacionada com a tabela de utilizadores de clientes do Sistema PHC.
Na aplicação PHC CS Desktop, no menu
Supervisor
, o utilizador deverá aceder à opção "Utilizadores de Clientes", onde devem ser criados os utilizadores para este tipo de aplicações.
De seguida,na ficha do respetivo cliente, em PHC CS Desktop, nas opções diversas do registo
"Utilizadores deste cliente - PHC CS Web"
, devem ser marcadas quais as aplicações a que os clientes daquele utilizador podem aceder, bem como os acessos que se pretendidos.
As aplicações da intranet são:
Contabilidade web
Crm web
Documentos intranet web
Equipa intranet web
Formação web
Gestão web
Colaborador web
Suporte intranet web
Supervisor web
Nota:
A licença de Supervisor ficará automaticamente validada se existir alguma aplicação interna validada e caso o utilizador tenha definido, na ficha do Utilizador, que tem acesso a Supervisor web.
As aplicações da extranet, são:
Equipa extranet web
Formação extranet web;
Front web
Suporte extranet web
Concluindo, o manual
PHC CS Web
encontra-se estruturado com o objetivo de proporcionar ao utilizador o conhecimento necessário à rápida instalação, configuração e eficaz manuseamento das aplicações do PHC CS Web.
No entanto, a utilização do
Menu Central
permite ao utilizador aceder aos registos (em modo de introdução ou consulta) de forma versátil e rápida.
Nos ecrãs de dados (mainforms), por exemplo, num ecrã de faturação, caso nunca tenha feito uma procura, o ecrã apresenta um link de ajuda que se direciona para a informação sobre o ecrã em questão no manual. Caso já tenha feito uma procura, o ecrã apresenta automaticamente os registos recentes.
Phc Cs Web
