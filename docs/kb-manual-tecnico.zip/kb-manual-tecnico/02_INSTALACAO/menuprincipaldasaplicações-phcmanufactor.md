---
title: Menuprincipaldasaplicações Phcmanufactor
source: menuprincipaldasaplicações-phcmanufactor.htm
tipo: Manual Técnico
idioma: PT
---

# Menuprincipaldasaplicações Phcmanufactor

Menu Principal das Aplicações - Phc Manufactor

|  |
| --- |
| Menu Principal das Aplicações - Phc Manufactor |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O menu principal de qualquer aplicação tem sempre 6 opções:    **Sistema**  Nesta opção escolhe-se as configurações genéricas, ou seja, utilizadores, manutenção personalizada, mensagens, etc.    **Editar**  Nesta opção estão as opções de edição do Windows, nomeadamente desfazer, copiar, cortar, colar e fechar todas as janelas.    **Platform**   Nesta opção encontram-se os programas propriamente ditos.    **Supervisor**  Este menu dá acesso às opções associadas a procedimentos de gestão da base de dados, instalação manutenção, bem como a opções de implementação.   Encontra-se vedada a utilizadores não administradores de sistema.     **Análises**  Nesta opção estão os mapas de análise que o programa permite realizar, ou seja, as diferentes estatísticas.    **Janelas**  Nesta opção pode-se restaurar, minimizar ou fechar as janelas que se encontrem abertas.   Para minimizar o utilizador pode também clicar no botão existente na barra de ferramentas geral do software.    Esta opção permite ainda reordenar a posição das janelas em cascata. Esta reordenação em cascata, também pode ser efetuada através do botão, visível na Barra de Ferramentas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Menu Principal das Aplicações - Phc Manufactor' ) |