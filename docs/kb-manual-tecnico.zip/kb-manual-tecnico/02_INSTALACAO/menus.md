---
title: Menus
source: menus.htm
tipo: Manual Técnico
idioma: PT
---

# Menus

Os menus permitem que o utilizador consiga ir para o local desejado, por exemplo para um outro
site
ou para uma página específica no mesmo
site
. Estes aparecem no topo da página e começam da esquerda para a direita.
De seguida vai ser explicada a
criação
de um menu, por um utilizador com permissões de
supervisor
. Este menu vai permitir passar por exemplo, de um ecrã da aplicação para o ecrã "Contactos", pertencente ao módulo
PHC CS CRM web
.
No final da descrição dos campos que constituem este ecrã serão apresentadas as opções de interação com o ecrã em modo de
consulta
e um
exemplo
de um Menu configurado para o Portal.
Ecrã em modo de Introdução
Quando o utilizador está no ecrã em modo de introdução/alteração dispõe dos seguintes campos:
Caminho completo para o Link
O
link
é o caminho para o destino que o utilizador pretende.
No exemplo apresentado o
link
seria o seguinte:
../mer/emform.aspx
Inativo
Esta opção quando ativa faz com que o menu não apareça, serve por exemplo para quando o menu ainda está em desenvolvimento.
Texto do link
Neste local define-se o texto que irá aparecer no menu.
Exemplo: Contactos do PHC CS CRM web
Tooltip do link
Neste local define o texto da
tooltip
do menu. Ou seja, quando o utilizador coloca o rato em cima do texto do menu é este o texto que aparece.
Exemplo: PHC CS CRM Web - Gestão de Contactos
Ordem pela qual aparece no menu
Este campo serve para ordenar os diversos menus que possam existir. Se não utilizar este campo a ordem é a de criação dos menus.
Por exemplo:
2
Separador do menu principal
Esta opção serve para, no caso do menu lateral, definir em qual separador pretende introduzir a nova opção. Se o separador não existir, o mesmo é criado pela aplicação sem nenhuma descrição.
É possível definir qual o menu em que se pretende que apareça o item de menu do utilizador.
Para isso existem as seguintes opções:
Surge no Menu Aplicacional
: Este é o menu da aplicação.
Surge no Menu Global do Cabeçalho
: Este menu é o do cabeçalho que se pode encontrar por cima ou em baixo do
header
(conforme configuração do utilizador nos parâmetros);
Surge no Menu Global do Rodapé
: Este menu é o do rodapé;
Surge no Menu de Introdução direta
: Esta opção permite que o utilizador adicione a opção de menu que está a criar no registo, ao menu de introdução direta que se situa na
Página Principal
.
Surge nos destaques da Extranet
: Este menu surge abaixo do
header
e está disponível apenas para
Extranet
.
Visível no Painel Global de Análises
: Se ativar esta opção, o menu ficará disponível no
Painel Global de Análises
. E se pretender, pode ainda definir um "Grupo" para obter uma organização personalizada.
Extranet: Necessita de acesso ao Front
: Para ter acesso ao menu é necessário que o utilizador tenha acesso ao
PHC CS Front Web
.
Extranet: Necessita de acesso ao Suporte extranet web
: Para ter acesso ao menu é necessário que o utilizador tenha acesso ao
PHC CS Suporte extranet web
.
Extranet: Necessita de acesso ao Equipa extranet web
: Para ter acesso ao menu é necessário que o utilizador tenha acesso ao
PHC CS Equipa extranet web
.
Nota:
Estas opções são autónomas umas das outras.
Caso o utilizador opte por
Tem que possuir um determinado acesso à tabela
:
Poderá limitar o acesso por tabela. Ou seja, para ter acesso ao menu é necessário que o utilizador tenha acesso a tabela descrita no campo
Tabela de acesso
e com o respetivo tipo de acesso preenchido no campo
Acesso
.
Um menu pode estar disponível nos diversos packages que o cliente tiver instalado, neste caso especifico o menu ficaria disponível na
Extranet
.
Ecrã em modo de Consulta
Quando o utilizador acede em modo de consulta, terá a possibilidade de utilizar as
opções de registo
, bem como procurar um registo,
alterar
e/ou apagar o mesmo.
Exemplo
Para criar um menu no
Portal
, deve selecionar o
package
"Portal" e selecionar a opção "Surge no Menu Global no Cabeçalho" por exemplo, 3 objetos configurados no Menu da Framework PHC:
- Início;
- Monitor de Sistema;
- Missão.
Descrição das configurações do Menu "Monitor de Sistema" no Menu Global no Cabeçalho do Portal:
Caminho completo para o link
: ../programs/sismon.aspx
Texto do link
: &ltspan class="glyphicon glyphicon-wrench"></span>
Tooltip do link
: Opções internas de configuração
Ordem pela qual aparece no menu
: 2
Surge no Menu Global no Cabeçalho
: Ativo
Package a incluir:
Portal
Resultado final no Menu Global no Cabeçalho é:
Framework Phc Cs Web
