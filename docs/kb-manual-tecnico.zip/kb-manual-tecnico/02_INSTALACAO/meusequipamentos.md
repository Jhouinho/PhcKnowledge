---
title: Meusequipamentos
source: meusequipamentos.htm
tipo: Manual Técnico
idioma: PT
---

# Meusequipamentos

Meus Equipamentos

|  |
| --- |
| Meus Equipamentos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Neste local poderá consultar todos os seus equipamentos, no entanto esta opção só está disponível se o seu fornecedor a tiver ativado e se o parâmetro "O Equipamento é visível no Suporte extranet web", na aplicação **PHC CS Desktop** se encontrar ativo.    As opções de consulta deste ecrã são:    **Marca**  Neste local pode consultar as marcas disponíveis, basta escolher a que pretende.    **Modelo**  Neste local pode consultar os modelos disponíveis, basta escolher o que pretende.    **Série**  A consulta pode ser efetuada por número de série do equipamento.    **Instalação**  No caso de pretender consultar os equipamentos de determinada instalação, basta colocar neste local o número da mesma.    **Equipamentos por página**  Pode escolher neste local, quantos registos de equipamentos pretende que sejam mostrados por página.    Para verificar os equipamentos basta clicar em **Equipamentos**.  Ser-lhe-á mostrada uma lista com os registos encontrados com as opções da sua procura.   Na lista apresentada, poderá, através da opção  selecionar o equipamento pretendido.     Acede desta forma à **ficha do equipamento** onde encontra mais dados sobre o mesmo.  Na barra de ferramentas encontra as seguintes opções:  **Consulta de Equipamentos**  Esta opção permite-lhe voltar ao ecrã anterior para poder efetuar uma nova consulta de equipamentos.        **[Consulta de Pedidos](consultadepedidosnaextranet.htm)** |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Meus Equipamentos' ) |