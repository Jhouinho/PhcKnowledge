---
title: Monitor de Abertura Rápida de Pedidos de Assistência
source: monitordeaberturarápidadepedidosdeassistência.htm
tipo: Manual Técnico
idioma: PT
---

# Monitor de Abertura Rápida de Pedidos de Assistência

O objetivo fundamental deste monitor é proporcionar ao utilizador uma forma rápida de abrir um Pedido de Assistência Técnico. Poderá aceder logo ao monitor
Abertura Rápida de PAT
e abrir um pedido de assistência técnica escolhendo de imediato o cliente a que o PAT se refere.
Além disso, poderá aceder a este monitor em diversas partes da aplicação como na Homepage ,por exemplo. Para isso, poderá recorrer à configuração de um Evento ou Links.
Assim que aceder ao Monitor terá a possibilidade de efetuar uma pesquisa por cliente, utilizando o campo
. Os resultados obtidos são logo filtrados e só serão mostrados os clientes que já tenham adquirido equipamento(s).
Uma vez selecionado um cliente, já é possível introduzir um PAT, clicando no botão:
, podendo preencher os dados que pretende.
O monitor utilizado está desenvolvido para ser acedido autonomamente e necessita da pesquisa de um cliente, tornando-o mais eficaz e direcionado na obtenção da informação.
Introdução de Monitor
Ao introduzir um Monitor, através do menu "Framework PHC", o utilizador tem obrigatoriamente que definir o
Título
do Monitor. E, facultativamente, poderá preencher o campo
Subtítulo
.
Pode iniciar a personalização do Monitor à medida das suas necessidades, começando pelo campo
Cabeçalho
para descrever o objetivo do mesmo.
Depois de definir a
Altura Máxima
de todas as colunas, pois, em cada escolha a respetiva coluna volta à posição inicial. Se estiver zero significa que não têm altura máxima expandindo em função dos dados apresentados.
Nota:
Só deve ser utilizado se não for importante a posição do cursor.
Como este monitor tem a particularidade de não depender de um registo específico, mas sim de uma pesquisa a efetuar no próprio Monitor, devem ser configurados os campos do separador
Dados para a Coluna 1
como por exemplo:
Nº de linhas em cada página na coluna 1
- [5];
Coluna 1 não tem paginação
- [Inativa]
% de ocupação da col. 1
- [34]
Título da coluna 1
- [Selecione o cliente:]
Texto para caixa de procura
- [Nome do cliente?]
Tem procura na coluna 1 (Checkbox)
- [Ativa]
Texto para caixa de procura
- [Ativa]; e
O monitor só é executado se existir algo na procura da coluna 1(Checkbox)
- [Ativa]
Com esta configuração, existirá no Monitor o campo
, que conjuntamente com o
Item de Monitor
que vai ser criado, é possível filtrar logo informação concreta.
Uma vez configurado o monitor para ter um campo de pesquisa no início do mesmo, deve ser agora, introduzido um
Item de Monitor
com a seguinte configuração:
Introdução de Itens de Monitor
Na primeira coluna estarão os "Itens de Monitor", sobre os quais será a restante informação nas colunas 2 e 3. Para isso, recorrendo ao ecrã de Monitores (em modo de consulta), o utilizador poderá introduzir os Itens de Monitor que achar oportunos, após aceder a:
Neste caso concreto de forma a exemplificar, será criado um Item de Monitor:
1.	Instalações e Equipamentos;
O preenchimento do campo "Resumo" é obrigatório e assumirá o texto no correspondente Item de Monitor na primeira coluna. Por defeito a informação no Monitor é automaticamente preenchida, porque o ecrã antecedente foi o do respetivo Monitor.
Caso seja intenção do utilizador alterar a ordem dos itens de monitor, o utilizador poderá utilizar o campo "Ordem".
No campo "Cabeçalho" o utilizador indica o texto que aparece no cabeçalho da segunda coluna, como por exemplo: "Equipamentos de
#RESUMO#
".
1.1. - Expressão para listagem da Coluna 1 (do Item de Ecrã)
Este campo deve conter a Expressão de dados (Select à base de dados), que permite obter os resultados pretendidos. Neste caso específico, uma procura contida por nome de cliente, que já tenha adquirido algum equipamento.
Como por exemplo:
select nome as resumo, convert(char(10),no) as stamp, count(*) as soma from ma (nolock) where nome like '%#PROCURA#%' group by nome,no order by nome
Como a seleção do cliente, por parte do utilizador, leva ao aparecimento de informação na coluna 2, a mesma também deve estar preenchida de forma a apresentar a informação pretendida.
1.2. - Expressão para listagem da Coluna 2 (do Item de Ecrã)
Neste caso específico, após o utilizador ter selecionado o cliente, é apresentada informação dos Equipamentos como: Modelo e Nº de série, ordenados por Marca, Modelo e Nº série respetivamente.
Para isso é necessário que neste campo deve estar uma Expressão de dados (Select à base de dados), que permite obter tais resultados, como por exemplo:
select '
'+marca+'
' as grupo, maquina as Modelo, serie as No_de_Série,mastamp as stamp from ma (nolock) where ma.no=#STAMP# order by marca,maquina,serie
Para apresentar a informação nesta Coluna 2, o utilizador tem ao seu alcance as seguintes opções:
Agrupa pela primeira coluna da coluna 2;
Sem cores alternadas nas linhas;
Coluna 2 em letra de tamanho reduzido;
Coluna 2 com totais;
Coluna 2 com número de registos; e
Coluna 2 sem títulos
Neste item de monitor apresentado, ativou-se a primeira opção
Agrupa pela primeira coluna da coluna 2
.
1.3. - Apresentação da Coluna 3 (do Item de Ecrã)
Neste campo, colocar-se-á a Expressão de dados (Select à base de dados), que obterá a informação mais adequada e detalhada, mediante a necessidade do utilizador.
Na "Expressão de dados da coluna 3" poderá adicionar o seguinte código, para recolher informação da base de dados:
select marca,maquina,serie,mastamp from ma (nolock) where ma.mastamp='#STAMP#'
De forma a tornar mais agradável a leitura da informação recolhida na Base de Dados, o utilizador pode personalizar a mesma. A título de exemplo, apresenta-se o seguinte código no campo "Template de apresentação de dados na coluna 3", que deve ser considerado como "É um programa":
dim m as string = ""
m +="Marca: <b>"+mainformdataset.tables(0).rows(0).item("marca").tostring+"</b><br>"
m += "Modelo: "+mainformdataset.tables(0).rows(0).item("maquina").tostring+"<br>"
m += "Nº de série: <b>"+mainformdataset.tables(0).rows(0).item("serie").tostring+"</b><br>"
dim ds as datatable=cdata.getdatatable("select convert(varchar(8000),problema)+'<br><span class=glabelpgray>'+convert(char(10),pdata,121)+'</span>' as Problema, solucao as Solução from pa (nolock) where pa.serie='"+mainformdataset.tables(0).rows(0).item("serie").tostring+"' order by pdata desc")
if ds.rows.count=0
m += "<br><br><h2>Ainda não existiram pedidos de assistência com este equipamento.</h2>"
else
m+= "<br><span class=glabelp>Histórico de assistência.</span><br>"
m+=xcutil.listtohtml(ds)
end if
return m
