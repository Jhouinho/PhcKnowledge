---
title: Monitor de Análises Oee
source: monitordeanálisesoee.htm
tipo: Manual Técnico
idioma: PT
---

# Monitor de Análises Oee

Monitor OEE
O OEE - Overall Equipment Effectiveness - é uma forma de monitorizar e melhorar a eficiência dos seus processos de manufatura, fazendo parte das "best practices"(melhores práticas), ou seja, o conjunto de procedimentos que definem a melhor forma de gerir uma fábrica.
O OEE é um indicador simples e prático: ao dividir as mais comuns e importantes fontes de perdas da produtividade industrial em três categorias primárias - Índice de Qualidade, Disponibilidade e Performance - oferece uma excelente vista da situação da fábrica para diagnóstico de desvios e identificação de ações de melhoria.
Contém uma variável onde poderá escolher como deseja ver os indicadores e análises do monitor, apresentadas para:
Um centro de trabalho;
Um grupo de centro de trabalho, ou;
Um recurso.
Para ter dados para cada recurso, deve primeiro configurá-lo na ficha respetiva no PHC CS Manufactor.
Como exemplo do Centro de Trabalho "máquina de corte 1":
Esta deve validar a opção
Permite cálculo de Análise OEE
e deve ainda indicar no campo seguinte a Velocidade teórica do recurso, que é a velocidade máxima possível neste processo, ou seja, o tempo mínimo necessário para produzir uma unidade de produto (expressa em "h/unidade de produto" ou "minutos/unidade de produto"). Este valor, se não for conhecido, pode vir indicado no manual de instalação do equipamento ou então, de uma forma prática e realista, ser medido na produção real com a máquina a operar de forma segura, na sua velocidade máxima.
Esta velocidade é necessária para determinar quantas unidades, no máximo, poderiam ser produzidas num dado período de tempo de trabalho. Da comparação dessa quantidade teórica com a quantidade realmente produzida obtém-se o Índice de Performance (ou Velocidade).
Ainda no ecrã "Centro de Trabalho" pode usar o botão
para navegar para o Monitor OEE no PHC CS Web. Para tal deve configurar no PHC CS Manufactor o parâmetro geral
url para os painéis web PHC
, colando lá o endereço para o Monitor OEE.
Exemplo:
http://localhost/Intranet19/programs/mon.aspx?i=7
No topo do monitor pode ver sete Snapshots relativos aos índices de:
OEE Disponibilidade: Valor de ontem e Evolução diária (referente aos últimos 15 dias);
OEE Performance: Valor de ontem e Evolução diária (referente aos últimos 15 dias);
OEE Qualidade: Valor de ontem e Evolução diária (referente aos últimos 15 dias);
OEE Global.
No Monitor OEE, ao selecionar, por exemplo o Centro de Trabalho C1, poderá ainda selecionar se pretende ver os resultados do OEE por dias, semanas ou meses, e referentes a que período de tempo.
Depois poderá ver o detalhe de cada período de tempo selecionado, sendo sempre possível detalhar até ao nível dos resultados diários, pois o Manufactor calcula o OEE, por defeito, ao nível mais detalhado, que é o diário.
É possível navegar a partir destes dados para análises avançadas que pormenorizar as causas destes valores. Assim, ao clicar sobre a quantidade de horas do "tempo real" para uma dada data, no exemplo da imagem acima às 4 horas de "tempo real" de trabalho registadas no dia 31.03.2016, será direcionado para a Análise de Paragens desse mesmo dia. Isto é útil para rapidamente encontrar os registos de paragens que causam diferenças entre o programado e o real.
Se quiser saber as causas das diferenças entre quantidades conformes e as totais testadas, ao clicar na quantidade de "unidades conformes" é direcionado para a Análise de Defeitos Mais Encontrados.
Em ambas as análises, se clicar no botão , terá acesso a outro ecrã da mesma análise, onde poderá variar o período de tempo a que se referem os resultados, ao ajustar os campos de data com a ajuda do prático calendário de consulta.
Monitor de Desvios
O template dá acesso a um monitor de desvios que contém os seguintes itens:
Desvios de quantidades de componentes
Desvios de prazos
Desvios de tempos
Análises avançadas
Além disto o template ainda contém as seguintes análises avançadas:
Paragens de produção
Artigos com mais rejeições
Defeitos mais encontrados
Estas transportam para o PHC CS Web análises que já existiam no PHC CS Manufactor, podendo alterá-las ou construir outras, e também aplicar diferentes tipos de gráficos para visualizar os dados, a partir das potencialidades da Framework do PHC CS Web e expressões que apontem para as tabelas de PHC CS Manufactor, na BD selecionada.
Dashboard
O template traz ainda um Dashboard para concentrar numa única página os Snapshots e Análises que tiverem mais significado para a gestão do dia a dia da fábrica.
De base o Dashboard contém:
Top 5 Artigos Produzidos;
Ocupação das Máquinas de Corte e Ocupação das Prensas;
Índice de Qualidade;
Ordens de Fabrico com atraso previsto, e;
Lista de Paragens de Produção.
Com um mínimo de adaptação poderá de imediato obter resultados, por exemplo, mudando as referências das máquinas para as que existem na BD real.
O Dashboard é configurável em termos de posição e aspeto dos seus componentes, podendo eliminar ou acrescentar análises e gráficos para personalizar ao máximo a experiência do utilizador. Para tal, deve aceder ao menu Framework > Dashboard > Produção > Objetos deste Dashboard:
Saiba como configurar o Template do Monitor de Análises OEE,
aqui
.
Para obter mais informação desta funcionalidade do PHC CS Manufactor, por favor aceda aos seguintes tópicos do respetivo manual:
Análises Oee - Overall Equipment Effectiveness
Constituição da Tabela de Centros de Trabalho
Constituição da Tabela de Grupos de Centros de Trabalho
Constituição da Tabela de Postos de Trabalho (terminais)
Parâmetros - Opção Análise de Cálculo Oee
Monitores
