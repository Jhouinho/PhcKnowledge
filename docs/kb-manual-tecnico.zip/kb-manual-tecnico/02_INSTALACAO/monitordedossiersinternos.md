---
title: Monitordedossiersinternos
source: monitordedossiersinternos.htm
tipo: Manual Técnico
idioma: PT
---

# Monitordedossiersinternos

Monitor de Dossiers Internos

|  |
| --- |
| Monitor de Dossiers Internos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção é bastante útil pois, permite obter informações estatísticas sobre todos os dossiers internos que foram emitidos.Caso o utilizador não possua o módulo de Gestão, poderá aceder a esta análise através do menu de opções nos Dossiers internos.    Em primeiro lugar é necessário indicar quais os dossiers que se pretendem utilizar na análise, passando os respectivos nomes de **Dossiers internos** para **Dossiers incluídos para análise**. Para esse efeito utilizam-se os seguintes botões:         Com esta opção é possível passar apenas um ou diversos dossiers de um dos lados para o outro.    Depois do utilizador decidir quais os dossiers a incluir, deve efectuar a actualização dos dados no ecrã, clicando para esse efeito em . Ao executar esta opção são apresentados os respectivos dossiers internos (do lado esquerdo), estando essa lista organizada pelo tipo de dossier (Folha-de-Obra, proposta, etc.). Para cada tipo de dossier é apresentado um valor entre parêntesis, indicando a quantidade de dossiers encontrados.  Para que o utilizador possa observar os nomes em que foram emitidos os dossiers (clientes, entidades, etc.), basta clicar no sinal mais (**+**). Caso não pretenda observar mais informação, deverá carregar no sinal menos (**-**). O mesmo processo é utilizado para ver os diversos dossiers de determinado cliente, entidade, fornecedor (consoante o módulo de software que foi adquirido).    Quando se selecciona um dossiers, é apresentada a respectiva informação, isto é, consoante o separador que se seleccionar. Em **Dados** é possível observar a data, a moeda e a referência interna, em **Linhas** é possível observar o conteúdo das linhas do dossier (data, referência, designação, quantidade, valores, etc.). Caso o utilizador possua o módulo Suporte, será ainda possível clicar em **Instalação**, podendo-se desta forma observar a instalação que está associada ao dossier interno.     Caso o utilizador pretenda editar o dossier, bastará fazer um duplo-clique em cima da linha. Alternativamente é possível clicar no botão que permite observar o dossier que deu origem à informação apresentada .     Outra forma diferente de utilizar o Monitor de dossiers é a procura directa, executada através do botão . Esta opção permite procurar qualquer dossier, bastando indicar uma informação nele contido, por exemplo a data. Caso o primeiro dossier encontrado não seja o desejado, pode-se utilizar a continuação da procura .    Para limitar a informação que pretende poderá construir um [filtro](filtros.htm), por exemplo para ver só os dossiers abertos.    A opção **Agrupa dossiers por campo de utilizador [Tabela 2](ConfiguraçãodeDossiers.htm#crtabela2)** permite criar uma separação dentro do grupo dos clientes, fornecedores, etc, consoante o tipo de dossier utilizado.    *Nota:*  Todos os botões deste ecrã estão explicados nas [Opções das Análises](opçõesdasanálises.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Monitor de Dossiers Internos' ) |