---
title: Monitor de Sistema
source: monitordesistema.htm
tipo: Manual Técnico
idioma: PT
---

# Monitor de Sistema

O monitor de sistema é o local onde o utilizador (administrador/supervisor) pode consultar toda a informação atual sobre o sistema, desde os erros que estão a acontecer, o código de utilizador que está a correr, os acessos à base de dados e muito mais.
Está disponível na Intranet para administradores/supervisores, ou na extranet e portal para quem tem acesso à password de administração (key ADMINPW no
Appsettings.config
).
O monitor está dividido em duas áreas:
-
Opções avançadas
;
-
Gestão de dados em tempo real
;
Opções avançadas
Nas
o utilizador pode aceder a determinadas áreas chave da aplicação e executar procedimentos como:
Cache
Limpar cache total
Ao selecionar esta opção, e de acordo com a configuração no
Appsettings.config
, passamos a ligar ou desligar o cache para que a aplicação seja mais rápida, e para que o acesso a imagens que estejam na base de dados (no caso de possuir o módulo PHC CS Documentos intranet web) e nas notícias funcionem.
Desligar cache
Permite ao utilizador desligar o cache definitivamente através da própria aplicação. Alterando a chave no ficheiro
Appsettings.config
(web.config key CacheLigado=N), caso o utilizador tenha acesso de escrita ao ficheiro (o que não é recomendado).
Informação
Dados do Sistema
Mostra toda a informação sobre o sistema instalado. Como por exemplo:
Versão do software: 18.00.39
Utilizador: Administrador de Sistema
http://localhost/Intranet18/
C:\inetpub\wwwroot\Intranet18Licenciado a PHC
Formato: Normal
Nome do PC: PHC201501001
Sistema Operativo:
.plataforma: Win32NT
etc.
Licenciamento
Re-arrancar a aplicação
Esta opção permite ao utilizador re-arrancar a aplicação sem ter que sair da mesma. A interação com esta opção Altera o ficheiro
Appsettings.config
, guardando a informação de data e hora do re-arranque.
Nota:
Não funciona se o utilizador não tiver acesso de escrita ao ficheiro.
Módulos autenticados
Esta opção permite ao utilizador visualizar uma lista que mostra a informação sobre:
- Quais os módulos autenticados no PHC CS Web;
- Data do término da autorização do licenciamento;
- Quantidade possível de utilizadores autorizados a usufruir da aplicação;
- Nº de utilizadores que estão registados em cada um dos módulos; e
- Listagem com a identificação dos utilizadores que têm o módulo ativo na sua Ficha de Utilizador, na aplicação PHC CS Desktop.
Nota:
Quando, num módulo, a quantidade de "Utilizadores utilizados" for superior à de "Utilizadores autorizados" os mesmos deixam de ter acesso ao módulo no PHC CS Web. Para voltar a aceder ao módulo no PHC CS Web, é necessário o Administrador/Supervisor remover o módulo do Package incluído, das fichas dos utilizadores, consoante a quantidade de utilizadores excedentes.
Autenticar o sistema
Refaz e atualiza a autenticação do sistema.
Retirar a autenticação do sistema
Retira a autenticação do sistema, para poder usá-la noutro sistema.
Framework
Dicionário de dados
Acesso direto ao ecrã de dicionário de dados.
Objetos de framework de um ecrã
Acesso direto ao ecrã de objetos de framework.
Gestão de dados em tempo real
Na área de
Dados em tempo real
, existem diversas opções:
Temos a informação da última atualização dos dados. Cada vez que acede a este ecrã, necessita de clicar no botão
para que o conteúdo seja atualizado com os últimos dados recolhidos. Tem também a opção
que permite limpar todo o conteúdo das várias áreas e recomeçar a recolher a informação da sessão corrente. Como opções nos dados em tempo real dispomos de:
-
Erros de sessão
;
-
SQL Profiler
;
-
Log de código
;
-
Simulador de Sql
;
Nesta área poderá analisar os erros da sessão atual, desde o momento em que ativou o registo dos erros na aplicação. Por defeito, o log de erros da sessão é ativado assim que abre este ecrã.
Se clicar no botão
poderá aceder às seguintes opções:
Limpar erros desta sessão
Limpa o conteúdo desta área e recomeça a recolher dados.
Ver LogErr
Se tiver a respetiva chave de
logerr
ativa, pode ver os erros gravados na base de dados, que acontecem a qualquer utilizador.
Ver onerror.txt
Se no ficheiro
Appsettingns
a respetiva chave estiver ativa "S", o utilizador pode consultar o conteúdo do ficheiro onerror.txt, que contém todos os erros que ocorram durante o funcionamento da aplicação PHC CS Web.
Limpar onerror.txt
Se tiver a respetiva chave, no ficheiro
Appsettingns.config
, ativa, o utilizador pode limpar o ficheiro onerror.txt.
Nesta área ficam registados todos os pedidos ao SQL server feitos pela sessão atual, depois de ativado o log de sql. Assim poderá saber tudo o que é pedido à base de dados. Ao escolher este separador pode utilizar o botão
para, tal como o nome indica, limpar todo o conteúdo registado na sessão atual.
Nesta área está toda a informação sobre o log de código do utilizador da sessão atual. Em cada opção pode clicar para ver o código corrido, logo neste local. Se estiver na intranet pode clicar no texto (ir para código) para abrir o respetivo ecrã no registo onde está definido esse código.
Ao selecionar este separador, o utilizador passa a dispor do botão
, com as seguintes opções:
Limpar log desta sessão
Para limpar o conteúdo desta área e recomeçar a recolher informação.
Ativar/Desativar log de código para todos os utilizadores
Ativar, ou Desativar este log para todos os utilizadores (não recomendado em produção pois torna o sistema mais lento).
O Log de código de Utilizador também pode ser ativada ou desativada nos
parâmetros
.
Nota:
Se no
Appsettings.config
o valor da Key SESSIONERROR for "S", quando executa código de utilizador, a aplicação acrescenta no fundo da página o texto "Log de código de utilizador:" seguido de informação respeitante ao código executado, como o tipo, o identificador e o URL.
Limpar log de código de utilizador
Limpa os registos de log de todos os utilizadores com mais de 24 horas.
Log de código de todos
Consulta o ecrã onde mostra todo o log de código de utilizador de todos os utilizadores.
Nesta área pode simular querys diretas ao sql, desde que não sejam para alterar dados. Depois de escrever a
query
só será preciso clicar em
e o resultado será mostrado.
Notas:
Se o utilizador preferir utilizar o endereço
…/gensel.aspx?opcoes=sim
no URL, poderá continuar a fazê-lo porque a aplicação redireciona o utilizador diretamente para o
Monitor de Sistema
.
Todas as consultas feitas no simulador ficam guardadas na tabela nlog com o tipo "Framework.SimSQL" .
Administração
