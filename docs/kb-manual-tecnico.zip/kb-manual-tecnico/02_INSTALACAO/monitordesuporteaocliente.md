---
title: Monitor de Suporte ao Cliente
source: monitordesuporteaocliente.htm
tipo: Manual Técnico
idioma: PT
---

# Monitor de Suporte ao Cliente

O objetivo deste Monitor é fornecer uma visão global do estado do suporte a um determinado cliente e realizar algumas operações que facilitam a rotina diária de quem trabalha com suporte. Num único local, e de uma forma centralizada, é possível rapidamente consultar e realizar ações sobre os
PATs
relacionados ao cliente, consultar dados sobre as instalações e equipamentos ou entrar em contacto com o cliente através de telefone ou e-mail.
Este monitor está desenvolvido para ser acedido a partir da ficha do cliente.
Na primeira coluna estão disponíveis 3 opções:
1ª Instalações e Equipamentos:
Ao selecionar este item na
Coluna 1
, na
Coluna 2
é mostrada a lista de equipamentos (marca, modelo e série), caso estejam associados a uma instalação, os mesmos serão agrupados por instalação.
Ao selecionar um item na
Coluna 2
, a
Coluna 3
é preenchida automaticamente com o resumo do equipamento e da instalação, tal como nome, morada, data da instalação, designação, situação, técnico responsável e vendedor. Nesta opção também é possível ver o mapa de localização da instalação ou efetuar ações como por exemplo telefonar ou enviar um e-mail para o cliente.
2ª PATs em aberto:
Ao selecionar este item na
Coluna 1
, a
Coluna 2
automaticamente exibe todos os
PATs em aberto
, com as seguintes informações:
Número do PAT
Data de abertura
Resumo
Técnico Responsável
Ao selecionar um PAT na
Coluna 2
, a
Coluna 3
é preenchida automaticamente com as seguintes informações: problema, marca, modelo, série, status, tipo e uma tabela com o histórico das intervenções (caso existam), nesta coluna também existem 3 botões:
Fechar o PAT
- Coloca o status do PAT como "Fechado".
Ver o PAT
- O utilizador é direcionado ao ecrã de
Pedidos de Assistência
em modo consulta do PAT selecionado.
Introduzir uma Intervenção
- O utilizador é direcionado ao ecrã de introdução de Intervenções para o PAT selecionado.
3ª PATs fechados
Ao selecionar este item na
Coluna 1
, a
Coluna 2
automaticamente exibe todos os PATs fechados, com os seguintes campos:
Número do PAT
Data de abertura
Resumo
Ao selecionar um PAT na
Coluna 2
, a
Coluna 3
é preenchida automaticamente com as seguintes informações: problema, solução, data do fecho e uma tabela com o histórico das intervenções (caso existam), nesta coluna também existem 2 botões:
Reabrir o PAT
- Coloca o status do PAT como "A Decorrer".
Ver o PAT
- O utilizador é direcionado ao ecrã de
Pedidos de Assistência
em modo consulta do PAT selecionado.
Nota:
Se não for definida uma limitação para a quantidade de registos a apresentar na
Coluna 2
, a aplicação de forma inteligente coloca a paginação necessária para os registos.
Monitores
