---
title: Monitor de Visão Global do Contacto da Pessoa
source: monitordevisãoglobaldocontactodapessoa.htm
tipo: Manual Técnico
idioma: PT
---

# Monitor de Visão Global do Contacto da Pessoa

O objetivo deste Monitor é fornecer uma visão global sobre um contacto da pessoa ou pessoa. Em um único local e de uma forma centralizada, é possível rapidamente fazer uma leitura da informação comercial ou de faturação, este último caso o contacto seja também um cliente, sem ter de consultar todos os dados individualmente, conseguindo assim rapidamente, fazer um ponto de situação sobre o contacto ou pessoa.
Este monitor está desenvolvido para ser acedido a partir da ficha do contacto ou da pessoa.
Constituição da Coluna 1:
Nesta coluna é apresentada lista de opções que podem ser consultadas.
Constituição da Coluna 2:
A informação apresentada nesta coluna depende diretamente do item selecionado na
Coluna 1
e do tipo de contacto ou pessoa.
Se for uma pessoa, a única informação que poderá ter disponível será as visitas (realizadas e agendadas).
Caso seja um contacto, poderá existir visitas e negócios. Mas se o contacto for também um cliente, então existirão todas estas informações:
Produtos vendidos
;
Documentos de faturação
e possivelmente Documentos não regularizados;
Dossiers em aberto
e Dossiers Fechados;
Negócios em aberto
e Negócios encerrados;
Visitas agendadas
e Visitas realizadas.
No caso dos
Produtos Vendidos
é mostrado a lista dos produtos vendidos no cliente, com os campos nome do produto, valor e a data do movimento, ordenados pela data do movimento.
Para os
Documentos de Faturação
é mostrado o tipo de documento, número, data e valor total, ordenados por data.
Para os
Documentos não regularizados
é mostrado o tipo de documento, número, data e valor por regularizar, ordenados por data.
Para os
Dossiers em aberto
e
Dossiers fechados
é mostrado o tipo de documento, número, data e valor total, ordenados por data.
Para os
Negócios em aberto
e
Negócios encerrados
é mostrado o resumo, número, data e valor total, ordenados por data.
Para as
Visitas Agendadas
e
Visitas Realizadas
é mostrada a data, hora e o resumo da visita.
Constituição da Coluna 3:
A informação apresentada nesta coluna depende diretamente do item selecionado na
Coluna 2
. Ou seja, a informação é sequencialmente filtrada de acordo com as escolhas realizadas desde a primeira interação com o Monitor.
Nesta
Coluna 3
é apresentado o detalhe do registo escolhido na
Coluna 2
:
No caso dos
Produtos Vendidos
é mostrado o nome do vendedor, tipo de documento, referência, quantidade, valor unitário, marca, modelo, linha de produto e tipo de produto. Nesta coluna existem também 2 botões um para consultar o stock e outro para consultar o documento, ambos direciona o utilizador para os respetivos ecrãs.
Para os
Documentos de faturação
e
Documentos não regularizados
é mostrado o tipo de documento, número e as linhas do documento. Existe também um botão que permite consultar o documento, neste caso o utilizador é direcionado para o ecrã do
documento
.
Para os
Dossiers em aberto
e
Dossiers fechados
é mostrado o tipo de documento, número e as linhas do dossier. Existe também um botão que permite consultar o dossier, neste caso o utilizador é direcionado para o ecrã de
Dossiers
.
Para os
Negócios em aberto
e
Negócios encerrados
é mostrado o vendedor,
status
, ação, origem, classificação e área. Existe também um botão que permite consultar o negócio, neste caso o utilizador é direcionado para o ecrã de
Negócios
.
Para os
Visitas Agendadas
e
Visitas Realizadas
é mostrado o contacto telefónico, vendedor, tipo, zona, ação, negócio e relatório. Nesta coluna é possível clicar no telefone e automaticamente ligar para o contacto ou pessoa, se tiver instalado um
software
para ligações telefónicas, existe também um botão que permite consultar a visita, neste caso o utilizador é direcionado para o ecrã de
Visitas
.
Monitores
