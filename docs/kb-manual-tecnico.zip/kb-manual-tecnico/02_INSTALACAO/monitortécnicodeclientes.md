---
title: Monitortécnicodeclientes
source: monitortécnicodeclientes.htm
tipo: Manual Técnico
idioma: PT
---

# Monitortécnicodeclientes

Monitor Técnico de Clientes

|  |
| --- |
| Monitor Técnico de Clientes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta análise só se encontra disponível se possuir o módulo PHC CS Suporte desktop.  Pode ser acedida pelas análises do módulo PHC CS Suporte desktop ou pelo menu de opções do ecrã de clientes.  Nesta análise tem-se acesso a toda a informação que existe relativamente a um determinado cliente ou entidade.     Para iniciar a pesquisa basta selecionar **Entidade** ou **Cliente**, consoante a pesquisa que se pretende, e escrever o nome do cliente/entidade no campo em branco abaixo ou, alternativamente, escrever um ponto de interrogação (?) nesse local, para aceder à lista com todos os clientes/entidades.  Se aceder a esta análise pelo ecrã de clientes a análise encontra-se de imediato carregada com a informação referente ao cliente que estava a ser consultado pelo utilizador no ecrã de clientes.    Se aceder pelas análises do módulo PHC CS Suporte desktop, após indicação do nome deve-se clicar no botão  , para visualizar os dados do cliente ou entidade indicada.        Para ver em detalhe os dados de determinado cliente (pedidos abertos e fechados, intervenções, instalações, chamadas e contratos de suporte), basta clicar no sinal mais (+) à esquerda do nome do cliente. Desta forma será possível observar na janela à esquerda as diversas informações do cliente indicado.    Para ver a informação do registo em detalhe, basta selecionar a linha que se pretende e clicar no botão  "Ver o documento que deu origem a este movimento". Alternativamente é possível fazer um duplo-clique na linha selecionada.        Também é possível fazer um duplo clique em cima da linha (na janela esquerda).    Quando se seleciona uma linha do lado esquerdo são apresentados os respetivos dados ao lado direito.          *Nota:*  O formato dos dados que se apresentam do lado direito são variáveis, e isto acontece porque as informações das chamadas, instalações, intervenções, pedidos e de contratos são todas diferentes. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Monitor Técnico de Clientes' ) |