---
title: Motordebuscainstantânea
source: motordebuscainstantânea.htm
tipo: Manual Técnico
idioma: PT
---

# Motordebuscainstantânea

Motor de Busca Instantânea

|  |
| --- |
| Motor de Busca Instantânea |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O Monitor de Busca Instantânea encontra-se disponível no menu de análises e na barra de ferramentas geral, na qual existe uma opção própria para aceder à busca instantânea.    Este Monitor é constituído por uma Zona do lado direito que permite definir os parâmetros da procura.    **O que procurar...**  Neste campo deve colocar-se o texto que se pretende encontrar.    **Modo**  Neste campo deve selecionar-se o modo de procura, ou seja, se a aplicação vai procurar: - Frase;  - Todas as palavras;  - Qualquer palavra.     **Desde**  Neste campo deve especificar-se a antiguidade da informação que se procura: - Desde sempre ; - 1 mês ; - 6 meses ; - 1 ano .    **Agrupa os resultados por tipo**   Quando esta opção se encontra ativa, os resultados são agrupados por [tipo](ConstituiçãodaTabeladeTabelasparaBuscaInstantânea.htm#mpstabbi1) de resultados encontrados, como se pode observar na imagem abaixo.    Depois de selecionado o registo ao premir o botão  o utilizador vê do lado direito do ecrã a informação pretendida.        **Salientar palavras**  Com esta opção ativa, as palavras digitadas pelo utilizador em **O que procurar...** que forem encontradas nos registos, aparecem destacadas e vermelho, conforme se pode observar na imagem acima.    Ao premir o botão de , acede acede-se diretamente ao registo, na respetiva tabela, abrindo de forma automática o ecrã respetivo.      *Dica*:  Se ao procurar não forem encontrados dados e na análise interna ficar um erro como o seguinte: "Connectivity error: [Microsoft][SQL Native Client][SQL Server]Cannot use a CONTAINS or FREETEXT predicate on table or indexed view 'sbid' because it is not full-text indexed.", deve verificar se já se encontra instalado o [full text search](BuscaInstantânea.htm#mpsfulltextconf) na base de dados. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Motor de Busca Instantânea' ) |