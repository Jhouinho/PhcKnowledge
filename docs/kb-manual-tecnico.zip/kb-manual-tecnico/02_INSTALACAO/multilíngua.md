---
title: Multilíngua
source: multilíngua.htm
tipo: Manual Técnico
idioma: PT
---

# Multilíngua

Multilíngua

|  |
| --- |
| Multilíngua |

|  |
| --- |
| Num mundo cada vez mais global, necessidades como a tradução de interfaces com utilizadores, no que se refere a aplicações informáticas, ganham importância pois facilitam a integração de funcionários portadores de Know-how na organização.     O PHC Manufactor CS possui funcionalidades de tradução do interface da aplicação por utilizador. Isto permite que usando o mesmo software poderemos ter utilizadores a operarem a aplicação em **Castelhano** quando outros num posto ao lado usam a aplicação em **Inglês**.     De facto as potencialidades não param aqui. A PHC estruturou o PHC Manufactor CS de modo a que o dicionário pudesse ser parcial ou na totalidade produzido na empresa.    **Como funciona? O que necessito de fazer para converter a aplicação?**    Visto tratar-se de um módulo da aplicação, o uso da funcionalidade está condicionado a 3 fatores: - Aquisição de licenças  - À existência do ficheiro INS do módulo no diretório da aplicação (multilíngua.INS)  - Configuração da aplicação para o uso da funcionalidade     Tendo por base a já existência de [validações](gruposdeutilizadores-phcmanufactor.htm) ao módulo, o único procedimento que faltará realizar é a ativação da funcionalidade.   Para isso poderemos ativar o uso de multilíngua através do parâmetro geral de ["Usa Multilíngua"](parâmetros-opçãogeral.htm).     O Módulo está instalado.     **Mas tudo continua em Português. Como traduzo?**    O módulo multi-língua é uma ferramenta, na qual poderemos realizar as alterações de idioma para o que pretendermos. Por defeito a aplicação não inclui qualquer dicionário, à exceção do **Português** que se encontra "built-in".   De modo a evitar o tempo de tradução da aplicação por parte dos utilizadores, a PHC disponibiliza na sua lista de produtos dicionários em diversos idiomas os quais poderão ser adquiridos e importados. No entanto, esta tradução poderá também ser realizada pelo utilizador.     Podemos então, traduzir a aplicação através de duas formas: - [Importação de dicionário](importaçãodedicionário.htm)  - [Interface de criação de dicionário](interfacedecriaçãodedicionário.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Multilíngua' ) |