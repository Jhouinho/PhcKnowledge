---
title: Móduloletras
source: móduloletras.htm
tipo: Manual Técnico
idioma: PT
---

# Móduloletras

Módulo Letras

|  |
| --- |
| Módulo Letras |

|  |
| --- |
| A estrutura do programa é idêntica para as [letras a receber](letrasareceber.htm) e para as [letras a pagar](letrasapagar.htm). As principais diferenças dizem respeito às operações que podem ser realizadas e às entidades associadas às tabelas, estando as letras a receber associadas à tabela de clientes e as letras a pagar associadas à tabela de fornecedores.  **Regularizações** As [regularizações de letras a receber](regularizaçõesdeletrasareceber.htm) e as [regularizações de letras a pagar](regularizaçõesdeletrasapagar.htm) determinam, aquando da emissão de uma nova letra, que movimentos serão regularizados, podendo estes movimentos ser de conta corrente, reformas de letras ou outros. Ao introduzir uma regularização o utilizador indica quais os movimentos de origem (Facturas, Notas de débito, Compras ou outros) e que letras irão ser geradas (uma ou várias).  **Letras** Após emitidas as letras pelas regularizações, estas podem sofrer diversas operações (como por exemplo reformas, amortizações, etc.) que serão realizadas sobre cada uma individualmente. Na área referente ao tratamento da letra o operador pode introduzir os vários movimentos para a mesma.  **Movimentos de letras** Para cada letra fica arquivado todo o seu historial, ou seja, todos os movimentos efectuados sobre a letra.   **Esquema do formato do programa :**    Ou seja,    **Regularizações**  Emitem letras e regularizam movimentos de c/c e reformas de letras.    **Letras**  Possuem movimentos resultantes de cada operação.    **Movimentos** São o historial da letra, que interage com a Gestão comercial e a Contabilidade (caso este módulo também esteja instalado).  Assim, para cada letra poderá executar diversas operações, as quais introduzem movimentos no seu historial, executam movimentos na área do módulo de Gestão e alteram o Status da letra :  **Status da letra :**  Sempre que é realizado um movimento sobre uma letra é actualizado automaticamente o campo **Situação actual** que define a situação em que ela se encontra no momento, resultante do último movimento. Assim, a letra pode ter os seguintes Status :  Nas letras a receber: · 1. Saque em carteira · 2. No cliente para aceite · 3. Aceite em carteira · 4. Proposta a desconto · 5. Enviada à cobrança · 6. Descontada · 7. Recambiada · 8. Liquidada ou regularizada · 9. Anulada  Nas letras a pagar · 1. Seu saque · 2. Nosso aceite · 3. Recambiada · 4. Liquidada ou regularizada · 5. Anulada  *Nota*: Existem movimentos (Operações), que realizam automaticamente um ou mais movimentos na letra, por exemplo, quando se emite uma letra a partir das Regularizações de letras a receber e se escolhe como situação final o Status "2. No cliente para aceite", o programa vai realizar um movimento de "Nova letra a receber" e o movimento "Envio de letra a receber para aceite".   O ciclo de funcionamento de cada tipo de letra é o seguinte:  **Letras a receber**    **Letras a pagar** |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Módulo Letras' ) |