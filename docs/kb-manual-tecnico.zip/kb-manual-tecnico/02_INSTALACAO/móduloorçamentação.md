---
title: Móduloorçamentação
source: móduloorçamentação.htm
tipo: Manual Técnico
idioma: PT
---

# Móduloorçamentação

Módulo Orçamentação

|  |
| --- |
| Módulo Orçamentação |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Antes mesmo da fase de criação de fichas técnicas de artigos, surge uma fase de estudo das necessidades para um determinado pedido de um cliente. Este módulo permite a gestão de orçamentos, permitindo associar artigos/centros de trabalho/funcionários que nem sequer existem na empresa, de forma a simular ao máximo (e com o menor trabalho possível) os requisitos do cliente.   No final, quando for aprovado o orçamento, basta um simples "CLICK" para transformar o orçamento (e componentes fictícios) em elementos reais do seu ficheiro de artigos. A partir daqui, já pode ser usado no sistema integrado de software de gestão de produção.         NOTA: aconselhamos a consulta do [esquema de módulos existente no Manufactor](módulosdemanufactor.htm), para melhor compreensão. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Módulo Orçamentação' ) |