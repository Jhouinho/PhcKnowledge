---
title: Módulopos Front
source: módulopos-front.htm
tipo: Manual Técnico
idioma: PT
---

# Módulopos Front

Módulo Pos-front

|  |
| --- |
| Módulo Pos-front |

|  |
| --- |
| A configuração do POS Front é maioritariamente efetuada no POS Back, até mesmo, por exemplo, os [acessos](acessosdoposfront.htm) específicos e as [tabelas de códigos](tabelasdecódigosdofront-office.htm) deste módulo. Não é possível no POS front efetuar a instalação e manutenção de tabelas quer seja pelo ecrã principal quer pelo assistente, estas rotinas são efetuadas no POS back.  É no Front-office que são registadas as vendas realizadas nos diversos terminais de vendas das diversas lojas, ou seja, é neste local onde são gerados os dados que posteriormente poderão ser analisados no Back-office.     Na barra de ferramentas do Front-office é possível visualizar rapidamente qual a [loja e o terminal](identificaçãodoterminaldevendas.htm) de vendas que estão a ser utilizados, se a [caixa](situaçãodacaixa.htm) está aberta ou fechada, se existe alguma [sessão](sessõesdoterminal.htm) ativa, o [nome do operador](barradeferramentasdofront-office.htm) que está a utilizar a caixa (caso esteja uma sessão ativa) e é também possível aceder diretamente ao ecrã de [introdução de vendas](introduçãodedocumentos.htm) (o ecrã principal) através do botão .  Este ecrã permite a introdução de vendas de uma forma rápida e acessível através de botões com imagens dos artigos, [teclas do utilizador](teclasespeciaisdofrontoffice.htm) e fácil identificação dos [modos de pagamento](ecrãdepagamentodoposfront.htm).    O Monitor de POS permite visualizar todos o movimentos em diferentes moedas efetuados no terminal em questão. Se o utilizador possuir também o Gestão, estes movimentos refletidos no Monitor de POS podem ser referentes a vendas ou a pagamentos efetuados na loja a fornecedores. Para tal existe um menu de [Outros documentos](outrosdocumentos-pos.htm) que agrega os documentos de compra e os de venda.    É ainda possível realizar [transferências entre caixas](transferênciasentrecaixas-saídaseentradas.htm) , [reimprimir](reimprimirdocumentosdefaturação.htm) Documentos de Faturação , efetuar [Sangrias](funcionamentodassangrias.htm), [verificar preços](verificadordepreçosdevenda.htm) de venda, [copiar dossiers](dossiersinternosnopos.htm) de lojas para lojas e até Abrir/Fechar o período no Terminal de Pagamento Automático.      A outro nível o utilizador pode retirar diversas listagens e análises estatísticas, nomeadamente relatórios X e Z.    Se possuir o módulo Gestão a integração deste módulo com o POS permite ter um controlo completo da atividade da empresa através da emissão de inventário físico, gestão de vendedores e comissões, tratamento de talões de depósito e de cheques recebidos, entre outros.    O Pos pode também ser utilizado em modo [Touchscreen](touchpos.htm) o que altera não só o visual das funcionalidades deste módulo, mas também a forma de navegar pelas respetivas opções. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Módulo Pos-front' ) |