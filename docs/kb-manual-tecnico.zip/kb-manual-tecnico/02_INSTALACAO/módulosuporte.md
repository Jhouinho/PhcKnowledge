---
title: Módulosuporte
source: módulosuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Módulosuporte

Módulo Suporte

|  |
| --- |
| Módulo Suporte |

|  |
| --- |
| Através deste módulo é possível rentabilizar a assistência pós-venda.    Com o objetivo de gerir o parque instalado existe:  O Ficheiro de [Equipamento](equipamento.htm), com todos os dados individuais sobre o equipamento, incluindo 2º número de série e campos com o nome definido pelo utilizador, para melhor adaptação do programa a qualquer tipo de negócio,  O Ficheiro [de Instalações](instalações.htm), de modo a arquivar toda a informação sobre uma determinada instalação, nomeadamente, o seu local, o cliente, o utilizador, a lista dos equipamentos lá colocados, etc    Com o objetivo de controlar o dia-a-dia da assistência existe:  O Ficheiro de [Pedidos de Assistência](pedidosdeassistênciatécnica.htm), onde serão colocadas todas as informações sobre o pedido de assistência, nomeadamente, quem pediu, qual o equipamento e localização, qual a avaria, etc. bem como o registo de todas as [intervenções](intervençõestécnicas.htm) feitas no pedido;  Uma Gestão de folhas de obra, de modo a controlar o que foi executado na assistência, nomeadamente tempos de mão-de-obra, deslocação, que peças lá foram colocadas, o que foi substituído, etc.;  Uma Gestão de [Contratos de Assistência](contratos.htm) e Garantias;  Uma [Análise de ocupação de técnicos](monitordeatribuiçãodepedidos.htm).    Ainda numa filosofia de otimização do dia-a-dia da assistência técnica este módulo possui uma [agenda](agendademarcações.htm) onde se poderá consultar a disponibilidade de cada técnico e marcar de imediato uma intervenção em determinada hora, e ainda um [sistema de gestão de pontos](funcionamentodosistemadegestãodepontos.htm) que permite melhorar o atendimento dos pedidos de assistência e a sua organização.    Muitas vezes a solução para determinado problema já foi encontrada antes por alguém dentro da empresa. Assim, é possível criar um sistema de [conhecimento técnico](monitordeconhecimentotécnico.htm) onde se poderá procurar toda a informação que se encontra no sistema e assim encontrar as diversas respostas já dadas a determinado problema. A [base de dados técnica](basededadostécnica.htm) permite o registo dos assuntos que não estão já no sistema.   Esta opção permitirá um aumento na velocidade de resposta a problemas, bem como um aumento na produtividade dos técnicos.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre tomar decisões Técnicas no instante preciso, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=947%3afgd3g5b.21b%3a.%3a425.e4g). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Módulo Suporte' ) |