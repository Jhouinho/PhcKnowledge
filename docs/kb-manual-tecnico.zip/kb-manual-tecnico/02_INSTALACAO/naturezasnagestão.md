---
title: Naturezasnagestão
source: naturezasnagestão.htm
tipo: Manual Técnico
idioma: PT
---

# Naturezasnagestão

Naturezas na Gestão

|  |
| --- |
| Naturezas na Gestão |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O campo **Natureza** permite guardar nos registos informação sobre a Natureza destes. O nome deste campo poderá ser alterado através do parâmetro **Nome do campo de Natureza**.   Se o módulo de Contabilidade estiver instalado, ao integrar os movimentos esta informação passa automaticamente para os lançamentos criados, podendo fazer análises por este campo.   Neste caso, se activar, nos parâmetros gerais, a opção **Utiliza a natureza da contabilidade em todo o software** são mostradas apenas as Naturezas criadas na Contabilidade.   Se não utilizar este parâmetro, nas tabelas de códigos aparecerá uma tabela chamada [NATUREZA](tabeladenaturezas.htm).    Na tabela de Naturezas são criados os registos que poderão ser utilizados nos seguintes locais:  [Clientes](clientes.htm)  [Contas Correntes de Clientes](contascorrentesdeclientes.htm)  [Facturação](faturação.htm)  Para activar a natureza nas linhas dos documentos de facturação, deve na configuração do documento activar a opção **Mostra o campo natureza nas linhas**. Este campo pode passar para os movimentos de stock e produtos vendidos, isto é, consoante a configuração do documento passa o campo das linhas ou dos cabeçalhos.    [Recibos de C/c para Clientes](recibosdeccparaclientes.htm)  [Recibos de Adiantamento](recibosdeadiantamento.htm)  [Fornecedores](fornecedores.htm)  [Compras a Fornecedores](comprasafornecedores.htm)  Para activar a natureza nas linhas das compras deve activar o parâmetro de compras **Utiliza o campo natureza nas linhas (reconstruir triggers)**, através deste para a tabela movimentos de stock passa o campo das linhas, caso contrário passa o campo dos cabeçalhos.    [Pagamentos a Fornecedores](pagamentosafornecedores.htm)  [Adiantamentos a Fornecedores](adiantamentosafornecedores.htm)  [Contas Correntes de Fornecedores](contascorrentesdefornecedores.htm)  [Movimentos de Stocks](movimentosdestocks.htm)  [Conta Corrente de Vendedores](contacorrentedevendedores.htm)  [Pagamento de Comissões](pagamentodecomissões.htm)  [Processamento de Comissões](constituiçãodocálculodecomissões.htm)  [Dossiers Internos](dossiersinternos.htm)  [Produtos Vendidos](produtosvendidos.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Naturezas na Gestão' ) |