---
title: Naturezasnasletras
source: naturezasnasletras.htm
tipo: Manual Técnico
idioma: PT
---

# Naturezasnasletras

Naturezas nas Letras

|  |
| --- |
| Naturezas nas Letras |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O campo **Natureza** permite guardar nos registos informação sobre a Natureza destes. O nome deste campo poderá ser alterado através do parâmetro **Nome do campo de Natureza**.   Se o campo estiver preenchido na ficha do cliente ou fornecedor será também automaticamente preenchido nas letras a receber, regularizações de letras a receber, letras a pagar e regularizações de letras a pagar.  Se o módulo de Contabilidade estiver instalado, ao integrar os movimentos esta informação passa automaticamente para os lançamentos criados, podendo fazer análises por este campo.   Neste caso, se activar, nos parâmetros gerais, a opção **Utiliza a natureza da contabilidade em todo o software** são mostradas apenas as Naturezas criadas na Contabilidade.   Se não utilizar este parâmetro, nas tabelas de códigos aparecerá uma tabela chamada [NATUREZA](tabeladenaturezas.htm).      Na tabela de Naturezas são criados os registos que poderão ser utilizados nos seguintes locais:  [Regularizações de Letras a Receber](regularizaçõesdeletrasareceber.htm)  [Letras a Receber](letrasareceber.htm)  [Regularizações de Letras a Pagar](regularizaçõesdeletrasapagar.htm)  [Letras a Pagar](letrasapagar.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Naturezas nas Letras' ) |