---
title: Naturezasnoimobilizado
source: naturezasnoimobilizado.htm
tipo: Manual Técnico
idioma: PT
---

# Naturezasnoimobilizado

Naturezas no Imobilizado

|  |
| --- |
| Naturezas no Imobilizado |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O campo **Natureza** permite guardar nos registos informação sobre a Natureza destes. O nome deste campo poderá ser alterado através do parâmetro **Nome do campo de Natureza**.   Se o módulo de Contabilidade estiver instalado, ao integrar os movimentos esta informação passa automaticamente para os lançamentos criados, podendo fazer análises por este campo.   Neste caso, se ativar, nos parâmetros gerais, a opção **Utiliza a natureza da contabilidade em todo o software** são mostradas apenas as Naturezas criadas na Contabilidade.   Se não utilizar este parâmetro, nas tabelas de códigos aparecerá uma tabela chamada [NATUREZA](tabeladenaturezas.htm).    Na tabela de Naturezas são criados os registos que poderão ser utilizados no ecrã de [Ativos](tabeladeativos.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Naturezas no Imobilizado' ) |