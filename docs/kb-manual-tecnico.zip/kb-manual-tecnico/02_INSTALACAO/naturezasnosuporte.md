---
title: Naturezasnosuporte
source: naturezasnosuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Naturezasnosuporte

Naturezas no Suporte

|  |
| --- |
| Naturezas no Suporte |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O campo **Natureza** permite guardar nos registos informação sobre a Natureza destes. O nome deste campo poderá ser alterado através do parâmetro **Nome do campo de Natureza**.   Se o módulo de Contabilidade estiver instalado, ao integrar os movimentos esta informação passa automaticamente para os lançamentos criados, podendo fazer análises por este campo.   Neste caso, se activar, nos parâmetros gerais, a opção **Utiliza a natureza da contabilidade em todo o software** são mostradas apenas as Naturezas criadas na Contabilidade.   Se não utilizar este parâmetro, nas tabelas de códigos aparecerá uma tabela chamada [NATUREZA](tabeladenaturezas.htm).      Na tabela de Naturezas são criados os registos que poderão ser utilizados nos seguintes locais:  [Pedidos de Assistência Técnica](pedidosdeassistênciatécnica.htm)  [Abertura de Pats](aberturadepats.htm)  [Intervenções Técnicas](intervençõestécnicas.htm)  [Equipamento](equipamento.htm)  [Instalações](instalações.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Naturezas no Suporte' ) |