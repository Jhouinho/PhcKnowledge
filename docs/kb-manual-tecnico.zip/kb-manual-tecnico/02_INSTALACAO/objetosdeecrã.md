---
title: Objetos de Ecrã
source: objetosdeecrã.htm
tipo: Manual Técnico
idioma: PT
---

# Objetos de Ecrã

Esta opção serve para criar objetos que fazem parte da tabela (campos da tabela e campos do utilizador), mas que não estão visíveis no ecrã.
Esta opção apenas estará disponível no menu da Framework PHC, se o parâmetro
Usa Objetos de ecrã
estiver ativo em pelo menos num dos módulos Intranet, Extranet e Portal.
Ao longo da explicação dos campos (
em modo de introdução
), vai ser construído um exemplo prático, que se baseia na criação de um campo no ecrã "Introdução de encomendas" do módulo
Front Web
. Este campo é o "Texto final 1" criado na configuração dos dossiers internos, que se vai chamar "Licenciamento" e o seu nome interno é "Trab1".
Quando o utilizador
consulta um registo
de uma Opção de Ecrã, tem à sua disposição as opções base dos registos.
Ecrã em modo de Introdução/Configuração
Para introduzir um Template de Tabela, o utilizador dispõe dos seguintes campos:
Nome do ecrã onde será colocado
Aqui é colocado o nome do ecrã onde se pretende colocar o campo (objeto).
Exemplo
: Encform.
Título do campo
Aqui define-se qual o título do campo.
Exemplo
: Licenciamento.
Inativo
Esta opção define se este objeto está ou não inativo, ou seja se aparece ou não no ecrã definido.
Nome do campo na base de dados
Neste local é definido qual o nome do campo onde vai ser gravada a informação na tabela.
No exemplo
o campo chama-se: "Trab1".
ID do objeto
Esta opção deve ser utilizada quando existirem dois objetos de ecrã com o mesmo nome.
Nome da página (dentro do form) onde será colocado o campo
Neste local é dado um nome à página onde vai ser colocado o campo.
Exemplo
: Dados do utilizador.
Tabela (caso seja diferente da tabela principal)
Neste campo o utilizador pode definir uma tabela secundária como por exemplo, a tabela "Dossiers Internos - Outros Dados (.bo2)" do ecrã de Dossiers Internos. Assim, o utilizador tem ao seu alcance a utilização dos campos das tabelas complementares num o objeto de ecrã.
Apresentam-se as tabelas complementares que se podem utilizar neste campo, com a identificação dos respetivos ecrãs:
Tabelas BO2 e BO3:
Dossiers Internos (boform - Intranet)
Listagem de Dossiers (bolist - Intranet)
Encomendas (encform - Extranet)
Tabelas FT2 e FT3:
Documentos de Faturação (ftform - Intranet)
Consulta de Documentos de Faturação (clftlist - Intranet)
Consulta de Documentos de Faturação (ftlist - Extranet)
Tabela FO2:
Listagem de compras (flfolist - Intranet)
Tabela STOBS:
Artigos e Serviços (sftorm - Intranet)
Escolha de Artigos/Serviços (stvlist - Intranet)
Escolha de Artigos/Serviços (stlist - Extranet)
Nº Interno do Documento/Dossier
Permite indicar o número interno de uma série de documento de faturação ou dossier interno onde, de forma exclusiva, aparecerá a opção de ecrã.
Expressão do campo ( no caso de ser uma expressão )
É possível associar uma expressão SQL ao campo.
Tooltip do campo
Serve para indicar qual o tooltip do campo.
Exemplo
: Nome para Licenciamento
Local onde será colocado o campo
A localização do objeto pode ser:
1) Página
No caso de ser página, é criada uma separação com o nome introduzido na opção
Nome da página
.
Exemplo
:
2) Topo do ecrã
Com esta opção ativa, o campo é o primeiro do registo, logo aparece no topo do ecrã.
3) Fundo do ecrã
Se esta for a opção escolhida o campo aparece no fundo do ecrã, ou seja após todos os objetos do ecrã.
Estilo dos CSS a utilizar
-
Form
O estilo Form é um ecrã de edição. Por exemplo, a introdução de encomendas no
Front Web
:
-
View
O estilo "View" é de apenas para leitura, como por exemplo as notícias:
Nota
: Conforme o tipo de ecrã em que está a ser introduzido o objeto, deve ser escolhida aqui a opção.
Tipo de Campo
Os campos podem ser de diferentes tipos: Inteiro; Numérico; Data; Memo; Caracter; Lógico e
Tabela
.
Nota
: Aconselha-se que o tipo do campo aqui definido seja do mesmo tipo que o campo na aplicação
PHC CS Desktop
.
Se o campo for do tipo:
Memo
tem a possibilidade de inserir o número de linhas e inserir plicas, para isso deve ativar a opção:
Permite plicas
e colocar no campo
Número de linhas
, as linhas desejadas.
Se o campo for do tipo:
Numérico
surge o campo
Máscara
, onde poderá definir uma máscara utilizando os carateres "#", "0", "." e "," ou qualquer outro carater para aparecer fixo no campo, tal como $ ou €. Se utilizar o #, o mesmo será substituído pelo número, caso não haja número, então fica em branco. Se utilizar o 0, este será substituído pelo número, mas quando não houver número, o campo ficará com zero.
Caso opte pelo tipo "Caratere" é apresentada a opção
Tem procura
onde poderá configurar os seguintes campos:
Tabela:
Tabela onde vai procurar os dados para mostrar na procura;
Campo para procura incremental:
Campo da tabela utilizado para a procura incremental;
Título da procura:
Título para a janela quando é clicado na lupa;
Campos para procura:
Campos da tabela onde se vai efetuar a procura, pode ser mais do que um (separados por virgula). Caso este campo não esteja preenchido é usado o campo da procura incremental;
Campos visíveis:
Campos visíveis na listagem dos resultado da pesquisa na janela de procura;
Títulos dos campos visíveis:
Títulos para as colunas da listagem dos resultados na janela de procura;
Campos de origem:
Campos de origem para atualizar no destino, ou seja, campo que irá ser colocado no campo
Campos a atualizar
;
Campos a atualizar:
Campos de destino a atualizar com os valores de origem, ou seja, são os campos onde se irá colocar o valor dos Campos de Origem. Os campos indicados também devem estar visíveis no form, ou seja, deve existir um objeto de ecrã para esses mesmos campos, caso contrário, a aplicação não realiza a atualização;
Filtro para procura:
Filtro a utilizar para a procura, este deverá ser uma expressão SQL;
Evento para procura:
Código que corre depois de efetuada a procura e escolhida a linha (esta opção só está disponível na gama Enterprise).
Coluna do campo
e
Linha da página
Estes campos servem para definir a posição (ordenação) do objeto no ecrã. O preenchimento do campo
Coluna do campo
é de preenchimento obrigatório e apenas se poderá inserir valores entre 1 e 4.
Nota
: Cada linha pode ter até 4 colunas, e apenas se poderá inserir valores entre 1 e 4, por exemplo:
O campo
Zona
tem definido na coluna 1 e na linha 1;
O campo
Licenciamento
tem definido na coluna 2 e na linha 1;
O campo
Nome
tem definido na coluna 3 e na linha 1;
O campo
1º Ano
tem definido na coluna 4 e na linha 1;
Preenchimento obrigatório
Este clique define se este campo é de preenchimento obrigatório ou não, no caso de ser definido como tal. Aquando da gravação, se o campo não estiver preenchido, junto ao mesmo, surge uma mensagem a informar a obrigatoriedade de preenchimento.
Só de leitura
Se o campo for definido como só de leitura, não permite a introdução ou alteração dos dados.
Titulo do campo na vertical
Permite que o Título do campo seja mostrado na vertical
Tamanho HTML do campo (terminado em % ou px)
O tamanho pode ser definido em % ou px, por exemplo: "90%" ou "100px".
Quando o
Tipo de campo
selecionado é tabela é necessário efetuar ainda algumas configurações.
Usa a expressão SQL para preenchimento dos itens do tipo de campo Tabela
Esta opção é utilizada quando se pretende preencher os itens da tabela, com o resultado obtido através de uma
query
feita ao SQL. Quando se ativa esta opção o campo
Qual o campo da expressão SQL que irá servir para preencher o texto dos itens do campo tipo Tabela
deve ser preenchido com o nome do campo que resulta da
query
construída no campo Expressão SQL.
Dois exemplos de preenchimento
:
Se na Expressão SQL estiver o seguinte:
1-
Select nome from cl (nolock) where cl.cass=´Lisboa´
Então, no campo
Qual o campo da expressão SQL que irá servir para preencher o texto dos itens do campo tipo Tabela
deverá ser preenchido com o valor =
nome
;
2-
Select nome as primeironome from cl (nolock) where cl.cass=´Lisboa´
O campo
Qual o campo da expressão SQL que irá servir para preencher o texto dos itens do campo tipo Tabela
já deverá ser preenchido com o valor =
primeironome
.
Valores da tabela separados por: ,
Este campo deve ser utilizado quando se pretende que os itens do campo tabela sejam preenchidos com texto fixo e não com o resultado de uma
query
ao SQL. O texto aqui colocado deve ser separado por vírgulas.
Por exemplo
: Norte, Centro, Sul
É ainda possível que o campo em tabela apresente o resultado de uma query, bem como os valores introduzidos neste campo, para isso basta preencher as duas situações.
O primeiro item do tipo de campo Tabela é vazio
Esta opção permite adicionar um item vazio à primeira posição da lista que o objeto irá apresentar, quer o seu resultado venha de uma
query
executada ao SQL, quer venha de valores fixos.
Código a executar quando alterar um valor
Nesta opção pode ser colocado um código de utilizador que irá ser executado quando o conteúdo do Objeto de ecrã for alterado, podendo definir um código em VB.NET a executar.
Este campo tem
intellisense
, ou seja, quando é colocada uma letra na caixa de texto é aberta uma caixa com todas as sugestões de código disponíveis para completar aquela palavra, à medida que se vai escrevendo as opções mostradas começadas pelas letras introduzidas vão reduzindo e aproximando do que se pretende. Também se pode pressionar as teclas ctrl + espaço ou ctrl + seta baixo para aparecer essa mesma caixa mas com todas as opções de código disponíveis, sendo que ao escrever texto as opções na caixa vão sendo filtradas.
As variáveis disponíveis são:
mPage
- Página onde está o objeto de ecrã;
mStamp
- Stamp do registo;
MainformDataset
- Dataset associado ao ecrã;
ObjPara
- Objeto de ecrã.
Neste exemplo vão ser apresentados dois Campos de Utilizador: um irá receber o valor por parte do utilizador e o outro que irá ser preenchido automaticamente com a execução do Código de Utilizador.
dim u_codigo as Object = ObjPara
dim u_desc as NossoCampoTextBox = mPage.Master.FindControl("conteudo").FindControl("u_desc")
Select Case u_codigo.Text
Case 1
u_desc.SetValue("Norte")
Case 2
u_desc.SetValue("Centro")
Case 3
u_desc.SetValue("Sul")
Case else
u_desc.SetValue("")
End Select
Compilar
Este botão irá validar o conteúdo do campo
Código a executar quando alterar um valor
, caso haja algum erro de sintaxe será indicado o número da linha e qual o erro encontrado.
Um objeto pode estar disponível nos diversos
packages
que o cliente tiver instalado, pode neste local definir onde aparecerá o menu criado.
Exemplo
:
Ecrã em modo de consulta
Em modo de consulta o utilizador tem a possibilidade de usufruir das
opções de registo
,bem como procurar um registo,
alterar
e/ou apagar o mesmo.
Framework Phc Cs Web
