---
title: Obtenha Dados do Dropbox a Partir da Framework Phc
source: obtenhadadosdodropboxapartirdaframeworkphc.htm
tipo: Manual Técnico
idioma: PT
---

# Obtenha Dados do Dropbox a Partir da Framework Phc

O
Dropbox
é um serviço para armazenamento e partilha de ficheiros. Podem ser armazenados os mais diversos tipos de ficheiros e podem ser acedidos em qualquer localização, desde que haja acesso à Internet.
A partir da
Versão 16
do
software
PHC CS
, caso possua
PHC ON
, é possível efetuar a transferência de ficheiros do repositório da
Dropbox
, a partir da conta que estiver autenticada nos parâmetros gerais da aplicação.
Para que exista a possibilidade de efetuar a transferência do repositório
Dropbox
é necessário que a
DLL "shareNetPHC"
(fornecida pela
PHC
) esteja registada de forma correta. Ao efetuar a instalação da
v16
a DLL já fica registada.
O repositório sobre o qual poderá efetuar a transferência de ficheiros é definido nos parâmetros gerais da aplicação, nomeadamente no parâmetro "Dropbox: Autenticação para comunicação Dropbox".
Ao escolher o parâmetro em cima referido, o utilizador deverá clicar no botão de autenticação e realizar autenticação da aplicação
PHC
no
Dropbox
. Esta autenticação, no repositório
Dropbox
, vai permitir a utilização das funções que a
Framework
disponibiliza para comunicação com esse mesmo repositório.
Caso a autenticação seja efetuada com sucesso, o utilizador irá visualizar uma mensagem de confirmação.
De seguida, apresentamos um possível cenário para utilização das funções que a
Framework
PHC disponibiliza.
Cenário:
As empresas de serviços que recebem o pagamento de faturação dos seus clientes por débito direto enviam o documento de faturação via
e-mail
.
Neste
e-mail
vem em anexo o documento de faturação em formato
PDF
.
Os clientes destas empresas depois têm de efetuar a transferência do ficheiro para sua organização, sendo que por vezes utilizam a
cloud
para guardar estes mesmos ficheiros.
Se o documento de faturação for rececionado via
link
do
Dropbox
, os clientes optam para a sua
Dropbox
ou se se desejam efetuar o download do mesmo.
A aplicação
PHC
agora permite que seja efetuado o
upload
de ficheiros para a
Dropbox
e depois estes podem ser partilhados com outras pessoas.
Este cenário é colmatado da seguinte forma:
Criação de uma tecla de utilizador no ecrã de documentos de faturação
A tecla de utilizador para o ecrã "Faturação" poderá ter o seguinte código:
Ou:
if not used("FT") or eof("FT")
*!* Não está a ser utilizada
return .f.
endif
local cLink,xFile
m.cLink = ""
m.xFile = "C:\Users\falmeida\Desktop\Fatura3.pdf"
*!* Vamos produzir o PDF
IduToPdf("FT","FI","FTCAMPOS","FICAMPOS","FTIDUC","FTIDUL",ft.fno,"Factura",xFile,"","NO",.f.,"ONETOMANY")
if file(m.xFile)
Vamos fazer upload de ficheiro
if uploadtodropbox(m.xFile,"/",justfname(m.xFile))
*!* Vamos obter link de partilha
if sharefiledropbox(justfname(m.xFile), @clink)
*!* Vamos construir o e-mail
if u_sqlexec("select email from cl (nolock) where cl.no = " + astr(ft.no), "tmpclmail")
local cBody, cTo
m.cTo = tmpclmail.email
fecha("tmpclmail")
m.cBody = "Para aceder ao documento de faturação aceda ao seguinte link: &ltbr/>" + m.clink
u_sendmail(m.cTo,"Documento de faturação",m.cBody,"",.f.,.f.)
endif
endif
endif
endif
Deste modo, é possível enviar para os clientes documentos de faturação via link de share do
Dropbox
.
Após aceder ao
link
o utilizador tem a possibilidade de efetuar download do ficheiro ou guardá-lo na sua
Dropbox
.
Gama e versão de software PHC em que foi testado: PHC Enterprise 16
