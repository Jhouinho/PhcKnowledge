---
title: Oe 2015 - Imposto sobre o Valor Acrescentado (iva)
source: oe2015-impostosobreovaloracrescentado(iva).htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2015 - Imposto sobre o Valor Acrescentado (iva)

Imposto Sobre o Valor Acrescentado (IVA)
Créditos de cobrança duvidosas
Passa a ser possível a recuperação do IVA, em situações de processo de insolvência de carácter pleno, a partir do momento do trânsito em julgado da sentença de verificação e graduação de créditos, prevista no Código da Insolvência e da Recuperação de Empresas.
Deixa de se exigir o "desreconhecimento" contabilístico para efeitos de recuperação do IVA dos créditos de cobrança duvidosa em mora há mais de 24 meses, para os créditos vencidos após 31 de Dezembro de 2012.
Nas situações em que haja transmissão da titularidade dos créditos de cobrança duvidosa ou considerados incobráveis após a recuperação do respetivo IVA, estabelece-se a obrigação de o cedente regularizar o imposto a favor do Estado, criando-se a possibilidade de o respetivo adquirente vir a recuperar o IVA, mediante prévio pedido de autorização à Autoridade Tributária.
Esta alteração deve ser tida em conta, quando da análise e tratamento das dívidas incobráveis de clientes.
Lista II Anexa ao Código do IVA
A aplicação da taxa intermédia de IVA à venda de petróleo e gasóleo, coloridos e marcados, fica dependente da sua comercialização nas condições e para as finalidades legalmente definidas.
No
PHC Gestão CS
, se efetuar transações de gasóleo comercial, deve aplicar a taxa intermédia de IVA à venda caso se destine às finalidades aceites pela lei.
Comunicação das faturas
Passa a exigir-se que o número do certificado atribuído ao programa de faturação seja incluído na comunicação de faturas a efetuar pelos sujeitos passivos à Autoridade Tributária até ao dia 25 do mês seguinte.
A
PHC
irá analisar a alteração da estrutura do ficheiro de comunicação de faturas à AT, de forma a incorporar o número do certificado, logo que tenhamos a atualização da estrutura por parte da AT - Autoridade Tributária.
Comunicação dos inventários
Passa a ser obrigatória a comunicação eletrónica à Autoridade Tributária, até ao dia 31 de Janeiro do ano seguinte, do inventário respeitante ao último dia do exercício anterior, para as entidades que estejam obrigadas à sua elaboração ficando, no entanto, dispensados os sujeitos passivos cujo volume de negócios do exercício anterior não exceda € 100.000.
A
PHC
está a analisar este ponto do OE 2015. Logo que tenhamos mais informação, por parte da AT - Autoridade Tributária, de qual o procedimento a seguir e da publicação da estrutura de ficheiro, informaremos mais pormenores.
Ato Isolado
Prevê-se no Orçamento de Estado para 2015 que os sujeitos passivos que pratiquem uma só operação tributável em IVA (ato isolado) poderem cumprir a sua obrigação de faturação mediante emissão de fatura no Portal das Finanças.
Apenas informativo, contudo, esta informação pode ser útil em outras áreas.
Regime dos bens em circulação
É clarificado o conceito de "bens"que, estando em circulação, serão destinados a objetos de uma prestação de serviços.
Adicionalmente, é alargado o conceito de "remetente" a qualquer pessoa que, por si ou através de terceiros em seu nome e por sua conta, coloque os bens à disposição do transportador para efetivação do respetivo transporte ou de operações de carga, e ainda outros sujeitos passivos cujos bens em circulação sejam objeto de prestações de serviços por eles efetuadas.
Quando uma empresa de serviços do tipo Assistência Técnica, que presta serviços de reparação ou de instalação, se transportar bens que sejam de aplicação no cliente, devem emitir uma guia de transporte antes da saída da viatura das instalações, no
PHC Gestão CS
.
Guias de Transporte - Alterações dos documentos e do local de destino
Os documentos de transporte globais e as alterações ao local de destino ocorridas durante o transporte, ou a não-aceitação da totalidade dos bens transportados, passam a ser comunicados por inserção no Portal das Finanças, ou por outra forma de transmissão eletrónica de dados, até ao 5.º dia útil seguinte ao do transporte, e não através do serviço telefónico, anteriormente, disponibilizado pela AT.
Atualmente ao efetuar um transporte de mercadorias, caso houvesse necessidade de se proceder à alteração do destino é necessário emitir uma Guia complementar e comunicar a mesma telefonicamente à AT.
Com a alteração descrita no OE de 2015, deixa de ser necessário efetuar-se a ligação, devendo apenas comunicar esses documentos à AT até 5º dia útil seguinte ao do transporte.
Regime de IVA de Caixa
Estabelece-se que os sujeitos passivos que pretendam optar pelo referido regime deverão comunicar tal facto à AT, por via eletrónica, no Portal das Finanças, apenas durante o mês de Outubro de cada ano (e não até 31 de Outubro de cada ano, conforme se previa anteriormente).
Apenas informativo, contudo esta informação é importante caso a sua empresa pretenda aderir ao Regime de IVA de Caixa.
Cessão Oficiosa da Atividade
Alarga-se a possibilidade de declaração oficiosa da cessação de atividade pela AT aos casos de encerramento de atividade de estabelecimento comercial declarada pelo tribunal em processo de insolvência, sem prejuízo do cumprimento das obrigações fiscais, nos períodos de imposto em que se verifique a ocorrência de operações tributáveis, onde devam ser efetuadas regularizações ou haja lugar ao exercício do direito à dedução.
Apenas informativo, contudo, esta informação pode ser útil em outras áreas.
Reparação de velocípedes (Reforma da Fiscalidade Verde)
Prevê-se a aplicação da taxa reduzida de IVA a serviços de reparação de velocípedes.
Caso a empresa tenha como atividade a reparação de veículos automóveis, quando estiver perante a reparação de um velocípede, a taxa de IVA a aplicar deverá ser de 6%.
Para regressar à pagina principal
clique aqui
.
