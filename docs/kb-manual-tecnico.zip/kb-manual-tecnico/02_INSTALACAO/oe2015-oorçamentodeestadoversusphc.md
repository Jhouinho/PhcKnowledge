---
title: Oe 2015 - o Orçamento de Estado Versus Phc
source: oe2015-oorçamentodeestadoversusphc.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2015 - o Orçamento de Estado Versus Phc

O Orçamento de Estado versus PHC
Aqui irá encontrar as alterações propostas pelo Orçamento do Estado que vão ter implicações na Aplicação ou perante as quais o PHC já cumpre com os requisitos legais.
Taxa de IRC
A taxa de IRC é reduzida de 23% para 21% conforme já mencionado na Reforma do IRC (Lei n.º 2/2014 de 16 de janeiro).
No
PHC Contabilidade CS
será alterado o mapa de gestão modelo 22 do IRC para que contemple a nova taxa de IRC.
Tributações Autónomas
A alteração das taxas respeitantes às tributações autónomas é alterada pela reforma da Fiscalidade Verde.
É proposto que sejam reduzidas as taxas de tributação autónoma relativamente a encargos com viaturas ligeiras de passageiros híbridas
plug-in
para:
São ainda reduzidas as taxas de tributação autónoma para as viaturas ligeiras de passageiras movidas a GPL ou GVN para:
Mantêm-se nas taxas atuais de tributação autónoma as restantes viaturas ligeiras de passageiros:
No
PHC Contabilidade CS
será alterado o mapa de gestão respeitante às Tributações Autónomas para que contemple as novas taxas aplicadas.
Comunicação das faturas
Passa a exigir-se que o número do certificado atribuído ao programa de faturação seja incluído na comunicação de faturas a efetuar pelos sujeitos passivos à Autoridade Tributária até ao dia 25 do mês seguinte.
O número do certificado atribuído ao PHC encontra-se incluído no ficheiro de comunicação de faturas..
Comunicação dos inventários
Passa a ser obrigatória a comunicação eletrónica à Autoridade Tributária, até ao dia 31 de Janeiro do ano seguinte, do inventário respeitante ao último dia do exercício anterior, para as entidades que estejam obrigadas à sua elaboração, ficando, no entanto, dispensados os sujeitos passivos cujo volume de negócios do exercício anterior não exceda € 100.000.
No PHC Gestão CS, a partir da versão 16, passa a ser possível a criação do ficheiro de inventários para entrega à AT - Autoridade Tributária e Aduaneira, até ao dia 31 de Janeiro de 2014, desde que possua PHC ON..
Para regressar à pagina principal
clique aqui
.
