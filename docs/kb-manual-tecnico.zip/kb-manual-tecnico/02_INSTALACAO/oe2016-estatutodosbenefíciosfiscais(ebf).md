---
title: Oe 2016 - Estatuto dos Benefícios Fiscais (ebf)
source: oe2016-estatutodosbenefíciosfiscais(ebf).htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2016 - Estatuto dos Benefícios Fiscais (ebf)

Rendimentos pagos por organismos de investimento coletivo aos seus participantes
Passa a estar expressamente previsto que a retenção na fonte, a título definitivo, sobre os rendimentos decorrentes do resgate de unidades de participação em fundos de investimento mobiliário e imobiliário, que se constituam e operem de acordo com a legislação nacional, é efetuada à taxa de 35% caso os titulares sejam residentes em país, território ou região sujeito a um regime fiscal claramente mais favorável constante de lista aprovada por portaria.
A taxa de 35% aplica-se, igualmente, aos rendimentos pagos ou colocados à disposição em contas abertas em nome de um ou mais titulares, mas por conta de terceiros não identificados, exceto quando seja identificado o beneficiário efetivo.
Estabelece-se, por fim, que o regime especial de tributação dos participantes não residentes passa a ser aplicável às entidades não residentes detidas, direta ou indiretamente, em mais de 25% por entidades ou pessoas singulares residentes em território nacional, caso tais entidades participantes sejam residentes noutro Estado-Membro da União Europeia, num Estado-Membro do Espaço Económico Europeu que esteja vinculado a cooperação administrativa no domínio da fiscalidade equivalente à estabelecida no âmbito da União Europeia, ou num Estado com o qual tenha sido celebrada e se encontre em vigor convenção para evitar a dupla tributação que preveja a troca de informações.
Fundos de investimento imobiliário em recursos florestais e em reabilitação urbana
No caso de se deixarem de verificar as condições para beneficiar da isenção de IRC, aplicável aos rendimentos auferidos por fundos de investimento imobiliário que tenham investido em recursos florestais ou na reabilitação urbana, passam a estar sujeitos ao enquadramento fiscal aplicável aos Organismos de Investimento Coletivo (OIC), considerando-se, para este efeito, como um período de tributação o período decorrido entre a data de cessação dos requisitos e o final do ano civil em que a mesma ocorreu.
Os rendimentos de unidades de participação pagos a partir da data de cessação desse regime que sejam colocados à disposição dos seus participantes, bem como as mais-valias realizadas após essa data que resultem da transmissão onerosa, resgate ou liquidação das mesmas, são sujeitos a tributação nos termos aplicáveis aos rendimentos pagos pelos OIC.
Mais-valias realizadas por não residentes
A limitação da aplicabilidade da isenção de IRS e de IRC às mais-valias realizadas com a transmissão onerosa de partes sociais e outros valores mobiliários emitidos por entidades residentes em território português, por entidades ou pessoas singulares que não tenham domicílio em território português e, aí, não possuam estabelecimento estável ao qual as mesmas sejam imputáveis quando sejam detidas direta ou indiretamente em mais de 25%, por entidades residentes, deixa de ser aplicável quando a sociedade alienante:
Seja residente noutro Estado-Membro da União Europeia ou do Espaço Económico Europeu que esteja vinculado a cooperação administrativa no domínio da fiscalidade equivalente à estabelecida na União Europeia, ou num Estado com o qual tenha sido celebrada e se encontre em vigor um Acordo de Dupla Tributação que preveja a troca de informações;
Esteja sujeita e não isenta de um imposto referido no artigo 2.º da Diretiva 2011/96/EU, ou de imposto de natureza idêntica ou similar ao IRC desde que a taxa aplicável a essa entidade não seja inferior a 60% da taxa normal de IRC;
Detenha uma participação não inferior a 10% no capital social ou dos direitos de voto da entidade objeto de alienação;
Detenha a referida participação de modo ininterrupto, durante o ano anterior à alienação.
Benefícios fiscais relativos a bens imóveis Isenções
A isenção de IMI aplicável às entidades públicas empresariais responsáveis pela rede pública de escolas, relativamente aos prédios ou parte de prédios destinados diretamente ou indiretamente à realização dos seus fins e os prédios exclusivamente afetos à atividade de abastecimento público de água às populações, de saneamento de águas residuais urbanas e de sistemas municipais de gestão de resíduos urbanos, cessa a sua aplicação logo que tais prédios deixem de estar afetos a esses fins.
Prédios de reduzido valor patrimonial de sujeitos passivos de baixos rendimentos
Para efeitos da atribuição da isenção de IMI aos prédios de reduzido valor patrimonial de sujeitos passivos de baixos rendimentos, considera-se prédio ou parte de prédio urbano afeto à habitação própria e permanente do sujeito passivo ou do seu agregado familiar aquele no qual esteja fixado o respetivo domicílio fiscal.
Prédios situados nas áreas de localização empresarial (ALE)
É estabelecido que o regime de isenção de IMT e IMI vigora para os imóveis adquiridos ou concluídos até 31 de dezembro de 2016.
Autorização legislativa
É concedida uma autorização legislativa ao Governo para alterar o enquadramento relativo às medidas de apoio ao transporte rodoviário de passageiros e de mercadorias, nos termos seguintes:
Eliminada a isenção de imposto sobre a diferença positiva entre as mais e as menos-valias resultantes da transmissão onerosa de veículos afetos ao transporte público de passageiros, veículos afetos ao transporte em táxi e veículos de mercadorias afetos ao transporte público de mercadorias;
Estabelecido que os gastos suportados com a aquisição, em território português, de combustíveis para abastecimento de veículos de transporte de mercadorias, transporte público de passageiros e de táxi são majorados até 120% da dedução como custos para efeitos de determinação do lucro tributável de sujeitos passivos de IRC ou IRS, com contabilidade organizada.
Orçamento de Estado de 2016
