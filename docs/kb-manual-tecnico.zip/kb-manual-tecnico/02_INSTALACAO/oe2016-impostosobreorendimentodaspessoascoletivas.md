---
title: Oe 2016 - Imposto sobre o Rendimento das Pessoas Coletivas
source: oe2016-impostosobreorendimentodaspessoascoletivas.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2016 - Imposto sobre o Rendimento das Pessoas Coletivas

Taxa de IRC
É reduzida para 21% (atualmente, 21,5%) a taxa de IRC aplicável às entidades que não exerçam, a título principal, atividade comercial industrial ou agrícola.
Prejuízos fiscais
O prazo de reporte dos prejuízos fiscais é reduzido de 12 para 5 anos.
Esta alteração aplica-se aos prejuízos fiscais apurados em períodos de tributação iniciados em ou após 1 de janeiro de 2017.
Isenções de IRC
Os rendimentos de capitais decorrentes de operações de reporte de valores mobiliários auferidos pelo Estado, através da Agência de Gestão da Tesouraria e da Dívida Pública, passam a estar isentos de IRC. Esta isenção abrangia até ao momento apenas os rendimentos de capitais resultantes de operações de swap e operações cambiais a prazo.
Isenção de retenção na fonte
Operações de reporte de valores mobiliários auferidos pelo IGCP
O Estado, através da atuação do IGCP, passa a estar isento de IRC nas operações de reporte de valores mobiliários.
Lucros pagos a entidades não residentes - Regime
participation exemption
É alterada a percentagem mínima para efeitos da aplicação da isenção sobre lucros pagos ou colocados à disposição de entidades não residentes, passando a ser apenas aplicável quando a participação no capital social da entidade portuguesa, que atribui os dividendos, não seja inferior a 10%, e se verifique um período mínimo de detenção de um ano.
Os novos requisitos aplicam-se às participações detidas à data da entrada em vigor do Orçamento do Estado para o ano de 2016, contando-se o período mínimo de detenção desde a data de aquisição da percentagem mínima de 10%.
Especial de Tributação dos Grupos de Sociedades (RETGS)
Passa a estar previsto que a renúncia à aplicação de uma taxa de IRC inferior à taxa normal mais elevada, para efeitos de aplicação do RETGS, deve ser mantida por um período mínimo de três anos.
Transferência de sede e direção efetiva em território português
É incluída uma clarificação, com natureza interpretativa, a determinar que o regime do
participation exemption
é igualmente aplicável às componentes positivas ou negativas relativas a partes de capital, no caso de transferência de residência de uma entidade fiscalmente residente em território português para outro Estado membro da União Europeia ou do Espaço Económico Europeu, bem como quando ocorra a cessação de atividade ou transferência de um estabelecimento estável de entidade não residente.
Regime de tributação de estabelecimento estável fora do território português
Em relação aos lucros e prejuízos de estabelecimento estável situado fora do território português, é ajustado, de 12 para os 5 períodos de tributação anteriores, o prazo de aplicação das regras de recaptura dos benefícios concedidos, por via da desconsideração dos lucros e prejuízos apurados por um estabelecimento estável.
Caso se deixe de aplicar o regime de isenção de lucros ou prejuízos de um estabelecimento estável em virtude da transformação do mesmo em sociedade, os lucros e reservas distribuídos, bem como as mais-valias decorrentes da transmissão onerosa das partes de capital ou liquidação dessa sociedade não poderão beneficiar do regime de participation exemption, até ao montante dos lucros e reservas do estabelecimento estável que não tenham sido incluídos no lucro tributável do sujeito passivo nos 5 períodos de tributação anteriores.
As novas regras serão apenas aplicáveis aos períodos de tributação que se iniciem a partir de 1 janeiro de 2017.
Tributação autónoma
No caso de incumprimento das condições para a não sujeição, a tributação autónoma dos prémios a gestores, administradores ou gerentes em virtude do seu pagamento estar subordinado ao diferimento de uma parte não inferior a 50% por um período mínimo de três anos, o valor correspondente à tributação autónoma que deveria ter sido liquidada é adicionado ao valor do IRC liquidado do período de tributação em que se verifique esse incumprimento.
Passa também a estar expressamente previsto na lei, com natureza interpretativa, que, no caso de ser aplicável o RETGS, o agravamento da taxa de tributação autónoma em 10 p.p deverá ser aplicável quando o grupo apure prejuízo fiscal.
Ainda com natureza interpretativa, passa a existir uma remissão expressa para as normas
quanto à competência, procedimento e forma de liquidação do IRC, relativamente ao cálculo da tributação autónoma.
Obrigações declarativas
Declaração periódica de rendimentos
É clarificado, com natureza interpretativa, que a não obrigação de entrega da declaração periódica de rendimentos é aplicável a entidades não residentes sem estabelecimento estável em território português e que neste território apenas aufiram rendimentos isentos ou sujeitos a retenção na fonte a título definitivo.
Manutenção do processo de documentação fiscal e obrigações contabilísticas
É reduzido, de 12 para 10 anos, o prazo de conservação do processo de documentação fiscal e conservação dos livros, registos contabilísticos e respetivos documentos de suporte, para períodos de tributação que se iniciem a partir de 1 de janeiro de 2017.
Informação financeira e fiscal de grupos multinacionais
As entidades residentes que integrem grupos multinacionais passam a estar obrigadas a apresentar uma declaração de informação financeira e fiscal que inclua, de forma agregada, por cada país ou jurisdição fiscal de residência das entidades que os integrem ou de localização de estabelecimentos estáveis, um conjunto alargado de informação.
A informação deve ser reportada até ao fim do décimo segundo mês posterior ao termo do período de tributação a que se reporta, por transmissão eletrónica de dados.
Resultados internos gerados durante a aplicação do regime de tributação pelo lucro consolidado
É introduzida uma norma transitória que determina que os resultados internos gerados durante a aplicação do regime de tributação pelo lucro consolidado (em vigor até 2000), cuja tributação se encontre ainda pendente no último dia do período de tributação de 2015, por não terem ocorrido até à data os factos que determinam a sua tributação, devem ser considerados para efeitos do apuramento do lucro tributável do Grupo, apurado ao abrigo do RETGS, em partes iguais, no período de tributação que se inicie em ou após 1 de janeiro de 2016 e nos dois períodos de tributação seguintes.
Para este efeito, deverá ser efetuado um pagamento por conta no mês de julho de 2016 ou, em caso de períodos de tributação não coincidentes com o ano civil, no 7.º mês do período de tributação de 2016, correspondente a um terço do respetivo montante, o qual será dedutível ao imposto a pagar na liquidação relativa ao período de tributação de 2016.
Em caso de cessação do RETGS, durante o período de reposição do montante dos referidos resultados internos, deve o valor pendente de reconhecimento ser incluído no último período de tributação em que aquele regime se aplique.
Resultados apurados pela Entidade Central de Armazenagem Nacional
É estabelecida a isenção de IRC sobre os resultados líquidos dos períodos realizados e contabilizados separadamente pela Entidade Central de Armazenagem Nacional, na gestão das reservas estratégicas de produtos de petróleo bruto e de produtos de petróleo.
Autorizações legislativas
São concedidas ao Governo as seguintes alterações legislativas para:
Alterar o regime de isenção parcial para os rendimentos de patentes e outros direitos de propriedade intelectual, de modo a garantir que os benefícios fiscais apenas abranjam rendimentos relativos a atividades de investigação e desenvolvimento do próprio sujeito passivo beneficiário. Para o efeito, o regime atual deverá deixar de ser aplicável a patentes e a desenhos ou modelos industriais registados a partir de 30 de junho de 2016, embora salvaguardando a manutenção da aplicação até 30 de junho de 2021 para os intangíveis registados até àquela data, para além de dever ser consagrado um novo regime aplicável aos ativos em apreço;
Alterar, com natureza interpretativa, as regras relativas à obrigação de entrega do pagamento especial por conta devido por cada uma das sociedades do grupo sujeito ao RETGS, determinando que o montante do pagamento especial por conta é calculado para cada uma das sociedades do grupo, deduzindo o montante dos pagamentos por conta que seria obtido a partir dos dados resultantes da declaração periódica individual;
Determinar que, quando for aplicável o RETGS e alguma das sociedades do grupo apresente uma declaração periódica de rendimentos de substituição, a sociedade dominante deve obrigatoriamente proceder à substituição da declaração do Grupo;
Estabelecer um regime facultativo de reavaliação do ativo fixo tangível e das propriedades de investimento que permita que, em 2016, os sujeitos passivos de IRC ou de IRS, com contabilidade organizada, reavaliem os referidos ativos, cuja vida útil remanescente seja igual ou superior a 5 anos. O regime deverá prever que a reserva de reavaliação fique sujeita a uma tributação autónoma especial de 14%, a pagar em partes iguais nos anos 2016, 2017 e 2018.
Orçamento de Estado de 2016
