---
title: Oe 2017 - Estatuto dos Benefícios Fiscais (ebf)
source: oe2017-estatutodosbenefíciosfiscais(ebf).htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2017 - Estatuto dos Benefícios Fiscais (ebf)

Remuneração convencional do capital social
No que respeita à dedução ao lucro tributável (em sede de IRC) da importância correspondente à remuneração convencional do capital social, a mesma passa a ser calculada mediante a aplicação de uma taxa de 7% (anteriormente 5%) ao montante das entradas realizadas até ao limite, agora fixado, de € 2.000.000,00.
Deixa de ser exigida a qualificação como micro, pequena ou média empresa da entidade beneficiária e que os sócios que participam na constituição ou no aumento do capital sejam exclusivamente pessoas singulares, sociedades de capital de risco ou investidores de capital de risco.
Em sentido oposto, prevê-se agora que a dedução em causa só possa ser concedida se a sociedade beneficiária não reduzir o respetivo capital social com restituição aos sócios, quer no período de tributação em que as entradas foram realizadas, quer nos cinco períodos de tributação seguintes. O incumprimento deste requisito implica a consideração como rendimento do período de tributação em que ocorra a redução do capital com restituição aos sócios, do somatório das importâncias deduzidas a título de remuneração convencional do capital social, majorado em 15%.
Adicionalmente, restringe-se o âmbito de aplicação da norma às entradas em dinheiro e às entradas em espécie resultantes da conversão de suprimentos e outros empréstimos dos sócios, excluindo-se assim as demais entradas em espécie.
No entanto, relativamente às entradas em espécie admitidas no âmbito deste regime, as mesmas apenas serão consideradas a partir de 1 de janeiro de 2017, ou a partir do primeiro dia do período de tributação que se inicie após essa data quando esta não coincida com o ano civil.
A dedução em causa passa a ser efetuada no apuramento do lucro tributável relativo ao período de tributação em que sejam realizadas as entradas e nos cinco períodos de tributação seguintes (em substituição dos três anos atualmente previstos).
Foi estabelecida ainda a redução do limite (de 30%) para 25% do "EBITDA" previsto para a dedutibilidade dos gastos de financiamento líquidos, quando os sujeitos passivos beneficiem da dedução em apreço.
Empréstimos de instituições financeiras não residentes
A isenção de IRC, aplicável a instituições financeiras não residentes, passa a abranger ganhos e juros de operações de
swap
e
forward
, e das operações com estas conexas, efetuadas com o Estado, quando anteriormente a isenção era apenas aplicável a ganhos decorrentes de operações de
swap
.
Benefício fiscal relativo à instalação de empresas nas regiões do interior
As PME localizadas nas regiões do interior, que exerçam a título principal uma atividade económica de natureza agrícola, comercial, industrial ou de prestação de serviços, passam a poder beneficiar de uma taxa de 12,5% relativamente aos primeiros € 15.000 de matéria coletável, por oposição à atual taxa de 17%.
As regiões beneficiárias desta medida serão definidas por portaria, com base em critérios como emigração e envelhecimento, atividade económica e emprego, empreendedorismo, entre outros.
RFAI
O limite de investimento elegível, que beneficia da aplicação de uma taxa de 25%, passa de € 5 milhões para € 10 milhões, mantendo-se taxa de 10% para investimentos superiores àqueles limites.
Os investimentos realizados no período de tributação que se inicie em ou após 1 de janeiro de 2016 poderá ainda beneficiar daquela dedução, desde que não tenham sido já integrados em qualquer um dos períodos.
SIFIDE
As despesas relacionadas com projetos de conceção ecológica de produtos passam a poder ser majoradas em 110%. A referida majoração fica dependente da submissão, e respetiva aprovação, do projeto à Agência
Portuguesa do Ambiente (APA).
Programa Semente
O OE de 2017 introduz o regime do "Programa Semente", nos termos do qual os sujeitos passivos de IRS, que efetuem investimentos elegíveis no âmbito do Programa Semente, não considerados no âmbito de atividades geradoras de rendimentos empresariais e profissionais, podem deduzir à coleta do IRS, até ao limite de 40% desta, um montante correspondente a 25% do montante dos investimentos elegíveis efetuados em cada ano.
Para efeitos da dedução referida, o montante anual dos investimentos elegíveis, por sujeito passivo, não poderá exceder € 100.000,00. O montante que não possa ser deduzido por exceder o limite mencionado pode sê-lo, nas mesmas condições, nos dois períodos de tributação subsequentes.
São considerados como investimentos elegíveis no âmbito do Programa Semente, as entradas em dinheiro efetivamente pagas em razão da subscrição de participações sociais, desde que:
A sociedade participada seja uma micro ou pequena empresa que não tenha sido formalmente constituída há mais de cinco anos;
Sejam de montante superior a € 10.000,00, por sociedade;
A participação social detida pelo subscritor, após a subscrição e durante os três anos subsequentes, não corresponda a mais de 30% do capital ou dos direitos de voto da sociedade;
A participação social subscrita seja mantida durante, pelo menos, 48 meses;
A percentagem do capital e dos direitos de voto detida por sociedades e outras pessoas coletivas, quer na data da subscrição, quer nos três anos anteriores, seja inferior a 50%;
As entradas sejam efetivamente utilizadas, até ao fim do terceiro período de tributação posterior ao da subscrição, em despesas de investigação ou desenvolvimento, na aquisição de ativos intangíveis ou na aquisição de ativos fixos tangíveis, com exceção de terrenos, edifícios, viaturas ligeiras de passageiros ou mistas, mobiliário e equipamentos sociais.
Para efeitos do Programa Semente são elegíveis os investimentos realizados em empresas que cumulativamente reúnam os seguintes requisitos:
Sejam qualificadas como micro ou pequena empresa;
Não tenham mais do que 20 trabalhadores e não detenham bens e direitos sobre bens imóveis cujo valor global exceda € 200.000,00;
Não estejam cotadas em mercado regulamentado ou não regulamentado de bolsa de valores;
Tenham a sua situação fiscal e contributiva regularizada;
Sejam certificadas pela Rede Nacional de Incubadoras.
Determina-se ainda que, as mais-valias provenientes da alienação onerosa das participações sociais correspondentes a investimentos elegíveis que tenham beneficiado da dedução prevista ao abrigo deste programa, desde que detidas durante, pelo menos, por um período de 48 meses, não são relevantes para efeitos de IRS caso o sujeito passivo reinvista, no ano da realização ou no ano subsequente, a totalidade dos respetivos valores de realização em investimentos elegíveis. Caso se verifique apenas o reinvestimento parcial do valor de realização, o benefício do reinvestimento referido aplica-se à parte da mais-valia realizada proporcionalmente correspondente ao valor reinvestido.
Em cumprimento das regras europeias, esclarece-se que o benefício fiscal do Programa Semente se encontra sujeito às regras aplicáveis em matéria de auxílios de
minimis
, não podendo o montante dos investimentos elegíveis exceder o limiar de
minimis
.
Orçamento de Estado de 2017
