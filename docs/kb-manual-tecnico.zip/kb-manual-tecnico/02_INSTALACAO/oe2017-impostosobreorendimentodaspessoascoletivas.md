---
title: Oe 2017 - Imposto sobre o Rendimento das Pessoas Coletivas
source: oe2017-impostosobreorendimentodaspessoascoletivas.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2017 - Imposto sobre o Rendimento das Pessoas Coletivas

Período de tributação
Foi introduzida a exigência de que, caso as entidades com sede ou direção efetiva em Portugal, bem como as pessoas coletivas que, não verificando aqueles requisitos, disponham neste território de um estabelecimento estável, optem por um período fiscal diferente do ano civil, o mesmo deverá ser obrigatoriamente coincidente com o período utilizado para efeitos de prestação de contas.
Variações patrimoniais negativas
Passam a concorrer, para a determinação do lucro tributável, as variações patrimoniais negativas relativas à distribuição de rendimentos de instrumentos de fundos próprios adicionais de nível 1 ou de fundos próprios de nível 2, que cumpram os requisitos do Regulamento (UE) n.º 575/2013, do Parlamento Europeu e do Conselho, de 26 de junho, relativo aos requisitos prudenciais para as instituições de crédito e empresas de investimento, exceto quando tais instrumentos atribuam, ao respetivo titular, o direito a receber dividendos, o direito de voto em assembleia geral de acionistas ou sejam convertíveis em partes sociais.
Regime de reinvestimento dos valores de realização
São excluídas do âmbito de aplicação do regime de reinvestimento dos valores de realização, o qual permite tributar o saldo positivo entre as mais e menos-valias apuradas com a sua transmissão em apenas 50%, as propriedades de investimento, ainda que contabilizadas como ativo fixo tangível.
Perdas por imparidade em partes sociais abrangidas pelo regime do participation exemption
Passam a ser consideradas componentes positivas do lucro tributável as perdas por imparidade e outras correções de valor de partes sociais ou de outros instrumentos de capital próprio, designadamente prestações suplementares, abrangidos pelo regime do
participation exemption
, que tenham sido fiscalmente relevantes para efeitos da determinação do resultado fiscal, nomeadamente na esfera das entidades sujeitas à supervisão do Banco de Portugal, no exercício em que ocorra a transmissão onerosa daqueles instrumentos.
Regime Simplificado
Para efeitos de apuramento da matéria coletável ao abrigo do regime simplificado de tributação, passa a estar definido que o coeficiente de 0,04 é aplicável apenas às vendas de mercadorias e produtos, bem como às prestações de serviços efetuadas no âmbito de atividades de restauração e bebidas e de atividades hoteleiras e similares, com exceção daquelas que se desenvolvam a atividade de exploração de estabelecimentos de alojamento local na modalidade de moradia ou apartamento. Assim, passa a estar prevista a aplicação de um coeficiente de 0,35 aos rendimentos da exploração dos referidos estabelecimentos de alojamento local.
Tributação autónoma
A previsão de sujeição a tributação autónoma das despesas de representação, bem como das ajudas de custo e dos encargos pela deslocação em viatura própria do trabalhador, passa a ser independente do regime de dedutibilidade destas despesas em sede de IRC, pelo que, ainda que não dedutíveis ao lucro tributável, serão tributadas autonomamente.
Passa a estar expressamente previsto que o facto tributário, para efeitos de tributação autónoma sobre os encargos relativos a viaturas, ajudas de custo e pela deslocação em viatura própria do trabalhador, é o momento da sua especialização económica (reconhecimento como gasto na contabilidade), independentemente deste momento coincidir ou não com o momento da realização da despesa.
Orçamento de Estado de 2017
