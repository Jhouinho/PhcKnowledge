---
title: Oe 2017 - Imposto sobre o Rendimento das Pessoas Singulares
source: oe2017-impostosobreorendimentodaspessoassingulares.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2017 - Imposto sobre o Rendimento das Pessoas Singulares

Subsídio de Refeição
O valor do subsídio de refeição diário aplicável a funcionários públicos é atualizado em € 0,25. O valor de subsídio de refeição não sujeito a IRS passa a ser de € 4,52 quando pago em dinheiro e € 7,23 quando pago através de vales de refeição.
Alojamento local
Atualmente, o rendimento decorrente do alojamento local, sendo enquadrado no regime simplificado da Categoria B, é englobado, para efeitos de tributação, às taxas gerais, em 15%. A proposta do Orçamento do Estado propõe uma alteração desta percentagem de englobamento - para 35% - nas situações de alojamento local de moradia ou apartamento.
Prevê-se, ainda, a possibilidade, por opção dos respetivos titulares, de serem tributados como rendimentos prediais (Categoria F) as importâncias relativas à exploração de estabelecimento de alojamento local na modalidade de moradia ou apartamento.
Entrega conjunta das declarações de IRS
Deixa de ser excluída a opção pela entrega conjunta da declaração de IRS por sujeitos passivos casados ou unidos de facto, no caso de declarações entregues fora do prazo legal.
Assim, independentemente da declaração anual de IRS ser entregue dentro ou fora do prazo legal, os contribuintes casados ou unidos de facto podem optar por entregar a declaração conjuntamente.
Prevê-se ainda que, no caso de não entrega de declaração anual de IRS, a emissão da liquidação oficiosa pela AT será feita com base no regime de tributação separada. Contudo, estabelece-se que, nestas situações, os contribuintes podem optar pela tributação conjunta até ao termo do prazo para reclamação da liquidação oficiosa, através de entrega da respetiva declaração de rendimentos.
Sujeitos Passivos com Deficiência
Os rendimentos brutos de cada uma das categorias A, B e H auferidos por sujeitos passivos com deficiência são considerados para efeitos de IRS:
Apenas por 85% nos casos das categorias A e B (anteriormente 90%);
Apenas por 90% no caso da categoria H (como já se verificava anteriormente).
Compensações e subsídios referentes a atividade voluntária
As compensações e subsídios, referentes à atividade voluntária, postos à disposição dos bombeiros, pelas associações humanitárias de bombeiros, são equiparadas a gratificações auferidas pela prestação ou em razão de prestação de trabalho, quando não atribuídas pela entidade patronal, ficando sujeitas a tributação à taxa autónoma de 10%, até ao limite máximo anual, por bombeiro, de três vezes o indexante de apoios sociais.
Sobretaxa de IRS
O regime de retenções na fonte, referentes à sobretaxa de IRS para rendimentos do trabalho dependente e pensões, será sujeito a um princípio de extinção gradual, mantendo-se as taxas aplicáveis em 2016. As taxas finais de sobretaxa são reduzidas.
Ao 2.º escalão são aplicáveis retenções na fonte aos rendimentos auferidos até 31 de março de 2017;
Ao 3.º escalão de rendimentos são aplicáveis retenções na fonte aos rendimentos auferidos até 30 de junho de 2017;
Ao 4.º escalão são aplicáveis retenções na fonte aos rendimentos auferidos até 30 de setembro de 2017;
Ao 5.º escalão são aplicáveis retenções na fonte aos rendimentos auferidos até 30 de novembro de 2017;
Escalão	Rendimento Coletável	Extinção	Sobretaxa de IRS
Normas transitórias sobre deduções à coleta
À semelhança das declarações de IRS de 2015, os sujeitos passivos poderão incluir na declaração de 2016 o valor das despesas incorridas com saúde, educação e formação, encargos com imóveis e com lares, os quais substituem os que constam do portal
e-fatura
.
Quando fizer uso desta faculdade, o sujeito passivo deverá manter os comprovativos dos montantes declarados.
Assim, no ano de 2016, os sujeitos passivos não podem usar o direito de reclamação sobre o valor das deduções à coleta que conste do Portal das Finanças, devendo utilizar o mecanismo de correção das despesas na sua declaração de IRS.
Prazo de Entrega da declaração de rendimentos
O prazo para entrega da declaração de rendimentos passa a ser compreendido entre os dias 1 de abril e 31 de maio, independentemente da natureza dos rendimentos auferidos.
Declaração automática de rendimentos
A Autoridade Tributária e Aduaneira (AT) disponibilizará, para os rendimentos obtidos a partir de 2016, uma declaração de rendimentos provisória e a correspondente liquidação provisória do imposto. Quando aplicável, será apresentada a liquidação de acordo com o regime da tributação conjunta e tributação separada.
A declaração será considerada entregue no momento da confirmação por parte do sujeito passivo. Simultaneamente, a respetiva liquidação converte-se em definitiva, aplicando-se o regime de tributação escolhido pelo sujeito passivo.
No caso de não se verificar a confirmação da declaração ou a entrega de qualquer outra declaração de rendimentos até ao final do prazo legal, a declaração de rendimentos provisória converte-se em declaração entregue, aplicando-se o regime de tributação separada.
Não obstante, o sujeito passivo pode entregar uma declaração de substituição nos 30 dias posteriores à liquidação do imposto, sem qualquer penalidade.
A partir de 1 de janeiro de 2018, os sujeitos passivos podem até 15 de fevereiro, indicar no Portal das Finanças os elementos pessoais relevantes, nomeadamente a composição do agregado familiar no último dia do ano a que o imposto respeite, mediante a autenticação dos próprios documentos comprovativos da sua informação de suporte, quando exigidos pela AT.
Para as declarações de IRS relativas ao ano fiscal de 2016, a AT terá como referência os elementos pessoais declarados no ano anterior e, na sua falta, considerará o sujeito passivo não casado e sem dependentes. O mesmo procedimento será igualmente seguido a partir de 1 de janeiro de 2018, sempre que o sujeito passivo não comunique a sua situação pessoal no portal das finanças até ao dia 15 de fevereiro.
Aplicabilidade da declaração automática de rendimentos
Para a aplicação da declaração automática de rendimentos relativamente aos rendimentos obtidos em 2016, os sujeitos passivos devem preencher cumulativamente as seguintes condições:
Apenas tenham auferido rendimentos do trabalho dependente ou de pensões (com exclusão de rendimentos de pensões de alimentos) e de rendimentos tributados a taxas liberatórias quando não pretendam optar pelo seu englobamento;
Apenas obtenham rendimentos em território português comunicados à AT;
Não aufiram gratificações tributadas à taxa autónoma de 10%;
Sejam considerados residentes durante a totalidade do ano a que o imposto respeita;
Não detenham o estatuto de residente não habitual;
Não usufruam de benefícios fiscais nem tenham acréscimos ao rendimento por incumprimento de condições relativas a benefícios fiscais;
Não tenham pago pensões de alimentos;
Não tenham dependentes a cargo, bem como deduções relativas a ascendentes.
Para o ano de 2017 e seguintes, o universo de sujeitos passivos abrangidos será fixado por decreto regulamentar.
Nas liquidações de IRS correspondentes às declarações automáticas de rendimentos referentes ao ano de 2016, não serão consideradas as deduções à coleta referente a: (i) dependentes e ascendentes que vivam em comunhão de habitação com o sujeito passivo; (ii)a pensões de alimentos;(iii) pessoas com deficiência;(iv) dupla tributação internacional e (v) benefícios fiscais.
A AT disponibilizará no portal e-fatura os elementos que servirão de base para o cálculo das deduções à coleta aplicáveis.
Regime Publico de Capitalização
É aumentado, de € 350 para € 400, o limite de dedução à coleta, em sede de IRS, para os sujeitos passivos de idade inferior a 35 anos, com aplicações em contas individuais geridas em Regime Público de Capitalização.
Programa Semente
É criado um benefício fiscal aplicável aos investidores individuais em startups, que permite a dedução à coleta, em sede de IRS, de 25% do investimento elegível. Este investimento terá que respeitar um limite referente às participações sociais, que não poderão ser superiores a 30% do capital ou dos direitos de voto da sociedade, têm que corresponder a entradas em dinheiro efetivamente pagas, o montante anual de investimento elegível não pode ser superior a € 100 mil, por sujeito passivo, entre outros requisitos;
A dedução é limitada a 40% da coleta, embora não se defina um montante específico, com possibilidade de dedução nos dois períodos subsequentes em caso de insuficiência de coleta, não podendo, contudo, o montante de investimentos elegíveis exceder o limiar de minímos.
As mais-valias decorrentes da alienação das participações não serão tributadas se as mesmas forem detidas durante, pelo menos, 48 meses e o valor de realização for reinvestido no próprio ano ou no ano seguinte ao da transmissão em participações elegíveis nos termos do regime.
É prevista também uma possibilidade de reinvestimento parcial.
Orçamento de Estado de 2017
