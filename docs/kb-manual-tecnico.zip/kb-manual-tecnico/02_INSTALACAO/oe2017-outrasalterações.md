---
title: Oe 2017 - outras Alterações
source: oe2017-outrasalterações.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2017 - outras Alterações

Contribuição sobre a indústria farmacêutica
É prorrogado o regime que cria uma contribuição sobre a indústria farmacêutica, mantendo-se, portanto, em vigor durante o ano de 2017.
Contribuição sobre o setor bancário
Mantém-se em vigor, durante o ano de 2017, a contribuição sobre o setor bancário.
Contribuição extraordinária sobre o setor energético
É prorrogado o regime que cria a contribuição extraordinária sobre o setor energético para o ano de 2017. Todas as remissões efetuadas no ano de 2015 vão ser consideradas como efetuadas no ano de 2017.
Contribuição sobre munições de chumbo
É criada uma contribuição sobre cartuchos de múltiplos projéteis, cujo material utilizado contenha chumbo, de €0,02 por cada unidade de munição.
Regime especial de tributação dos rendimentos de valores mobiliários representativos de dívida
As obrigações perpétuas passam a figurar, expressamente, no regime especial aplicável aos rendimentos de valores mobiliários representativos de dívida pública e não pública, auferidos por entidades não residentes (
Decreto-Lei nº 193/2005
, de 7 de novembro).
Adicionalmente, passam a estar abrangidos por esse regime os instrumentos de fundos próprios adicionais de nível 1 ou de fundos próprios de nível 2 que cumpram os requisitos previstos no
Regulamento UE n.º 575/2013
, do Parlamento Europeu e do Conselho, de 26 de junho.
Municipal de Direitos de Passagem
Para efeitos de liquidação da Taxa Municipal de Direitos de Passagem e da Taxa Municipal de Ocupação do Subsolo, as empresas titulares das infraestruturas devem comunicar a cada município, até 31 de março de 2017, o cadastro das suas redes nesse território, devendo proceder à atualização da informação prestada até ao final do ano.
A Taxa Municipal de Direitos de Passagem e a Taxa Municipal de Ocupação do Subsolo são pagas pelas empesas operadoras de infraestruturas, não podendo ser refletidas na fatura dos consumidores.
Orçamento de Estado de 2017
