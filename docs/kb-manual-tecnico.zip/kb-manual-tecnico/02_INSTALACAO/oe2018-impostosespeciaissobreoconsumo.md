---
title: Oe 2018 - Impostos Especiais sobre o Consumo
source: oe2018-impostosespeciaissobreoconsumo.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2018 - Impostos Especiais sobre o Consumo

Os artigos 11.º, 12.º, 33.º, 48.º, 71.º, 73.º, 74.º, 76.º, 78.º, 87.º-A, 87.º-C, 89.º, 92.º, 93.º, 103.º, 104.º, 104.º-A, 105.º e 114.º do Código dos Impostos Especiais de Consumo, adiante designado por Código dos IEC, aprovado pelo
Decreto-Lei n.º 73/2010
, de 21 de junho.
Alteração ao Código dos Impostos Especiais de Consumo
Artigo 247.º do OE 2018
Liquidação de Imposto
Os sujeitos passivos passam a ser notificados da liquidação do imposto, até ao dia quinze do mês da globalização, por via eletrónica, através de mensagem na plataforma dos Impostos Especiais sobre o Consumo no portal da Autoridade Tributária. Esta notificação considera-se efetuada no 5.º posterior à sua disponibilização. No entanto, mantém-se a notificação por via postal simples até ao dia vinte da globalização, sempre que não seja possível efetuar a notificação por via eletrónica.
No caso dos sujeitos passivos que não detenham nenhum dos estatutos previstos no Código dos IEC, são notificados da liquidação de imposto por via postal simples para o seu domicílio fiscal.
Esta informação legal não tem implicações no PHC CS.
