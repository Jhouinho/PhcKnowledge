---
title: Oe 2018 - outras Disposições de Caráter Fiscal
source: oe2018-outrasdisposiçõesdecaráterfiscal.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2018 - outras Disposições de Caráter Fiscal

Norma revogatória no âmbito da Reforma Aduaneira
Artigo 273.º do OE 2018
Taxas Aduaneiras - Abolição de taxas a mercadorias despachadas nas estâncias aduaneiras
É revogado o artigo 5.º da tabela anexa à Reforma Aduaneira aprovada pelo Decreto-Lei n.º 46311, de 27 de abril de 1965, na redação introduzida pelo
Decreto-Lei n.º 68/2007
, de 26 de março, deixando de haver as taxas referentes a todos os movimentos de mercadorias que são despachadas nas estâncias aduaneiras postais.
Esta informação legal não tem implicações no PHC CS.
