---
title: Oe 2018 - Procedimento e Processo Tributário
source: oe2018-procedimentoeprocessotributário.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2018 - Procedimento e Processo Tributário

Alteração ao Decreto-Lei n.º 433/99, de 26 de outubro
Artigo 269.º do OE 2018
Propõe-se a alteração ao Artigo 7.º do
Decreto-Lei n.º 433/99
, de 26 de outubro, passando a incluir os n.ºs 5), 6), 7), 8), 9) e 10).
Tributos administrados por autarquias locais
Determina-se que:
Mediante a celebração de protocolo, a cobrança coerciva de tributos administrados pelas freguesias possa ser atribuída ao município a cuja área pertençam;
Antes da realização de penhoras relativas a dívidas fiscais, as autarquias poderão consultar, nas bases de dados da AT, informação sobre a identificação do executado e sobre a identificação e a localização dos bens deste. Os termos desta consulta serão definidos por portaria.
Esta informação legal não tem implicações no PHC CS.
