---
title: Oe 2019 - Imposto sobre o Rendimento das Pessoas Singulares
source: oe2019-impostosobreorendimentodaspessoassingulares.htm
tipo: Manual Técnico
idioma: PT
---

# Oe 2019 - Imposto sobre o Rendimento das Pessoas Singulares

Alterações ao Código do IRS
Artigo 228.º do OE 2019
Os artigos 10.º, 12.º, 13.º, 43.º, 51.º, 57.º, 60.º, 71.º, 72.º, 78.º-B, 99.º-C, 101.º e 119.º do Código do Imposto sobre o Rendimento das Pessoas Singulares
Código do IRS
, aprovado pelo
Decreto-Lei n.º 442-A/88
, de 30 de novembro.
Mais-valias
Artigo 10.º do CIRS
Identificação das condições de aplicação e não aplicação do benefício de exclusão de tributação dos ganhos provenientes da transmissão onerosa de imóveis destinados a habitação própria e permanente do sujeito passivo ou do seu agregado familiar (alíneas a) a c) do n.º 5 deste mesmo artigo).
Esta informação legal não tem implicações no PHC CS.
