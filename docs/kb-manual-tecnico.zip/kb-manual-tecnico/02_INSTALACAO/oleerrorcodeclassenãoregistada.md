---
title: Ole Error Code ... Classe não Registada
source: oleerrorcodeclassenãoregistada.htm
tipo: Manual Técnico
idioma: PT
---

# Ole Error Code ... Classe não Registada

Problema:
Unknown
 member ….
“OLE
 error code ...: Classe não registada.
OLE
 object is being ignored.
Record
 number ...”
Solução:
Os
 erros deste tipo indicam que existem ocx mal instalados no computador. Nestes
 casos tem que se identificar o ocx em questão e instalá-lo de novo.
Passos
 para a instalação dos ocx:
1.
 Copiar o ficheiro xpto.OCX para a directoria c:\windows\system32
2.
 Correr o comando :
regsvr32
 c:\windows\system32\xpto.ocx
Existe
 ainda um problema idêntico que pode surgir aquando da instalação de uma
 aplicação de Fox que utilize algum dos ocx utilizados pelo software Phc, por
 exemplo, houve um ano que a aplicação de validação dos Quadros de Pessoal
 da DETEFP quando instalada alterava um ocx que o software Phc utilizava o que
 fazia com que existisse um erro na pesquisa de registos.
