---
title: Opções de Ecrã
source: opçõesdeecrã.htm
tipo: Manual Técnico
idioma: PT
---

# Opções de Ecrã

Esta opção permite ao utilizador acrescentar opções quer na
barra de ferramentas
dos ecrãs, como noutros locais dos ecrãs, tal como se poderá verificar.
Esta opção apenas estará disponível no menu da Framework PHC, se o parâmetro
Usa Opções de ecrã
estiver ativo em pelo menos num dos módulos da Intranet, Extranet e/ou Portal.
Dos campos que o utilizador dispõe para
introduzir/alterar
uma Opção de Ecrã, existem separadores dedicados à configuração do mesmo em:
Mainform
;
Monitor
;
Item de monitor
;
Dispõe também de mais dois separadores para definir
Acessos
, bem como o(s)package(s)
onde se poderá usufruir da Opção de Ecrã.
Quando o utilizador
consulta um registo
de Opções de Ecrã, tem à sua disposição as opções base dos registos.
No final da explicação das opções para a criação de uma Opção de Ecrã, serão dados como
exemplos
, a criação de uma Opção de Ecrã na consulta de artigos e outra na funcionalidade de "Próximas ações"
Ecrã em modo de introdução/alteração
Para introduzir, alterar e/ou configurar uma Opção de Ecrã o utilizador dispõe dos seguintes campos:
Nome do ecrã onde será colocado
Neste local é indicado o nome do ecrã onde a Opção de Ecrã será colocada (sem a parte
.ASPX
).
Por exemplo, o ecrã é
stview
.
Na eventualidade da Opção de Ecrã se destinar a um monitor ou a um item de monitor, deve ser colocado
mon
.
Resumo da opção
Pequeno resumo da opção criada.
Inativa
Esta configuração permite que a Opção de Ecrã deixe de aparecer.
Texto da opção
Qual o texto que vai aparecer no botão para o utilizador.
Exemplo
: Stock por Armazém 2.
Se usado em monitor pode colocar variáveis globais com o texto #G1#, por exemplo para a variável com o número 1.
Classe de CSS
Deve ser indicado qual a classe de CSS a utilizar. Pode ser utilizada classes de botões "bootstrap", como por exemplo "btn btn-danger btn-xs". Pode ainda usar outros formatos de botões das classes "btn-primary", "btn-warning" ou "btn-default". Se pretender alinhar a direita pode ainda adicionar a classe "pull-right". Se o campo estiver vazio, irá utilizar a classe por defeito.
Tooltip da opção
Neste local define-se o texto que aparece quando o utilizador coloca o rato em cima da opção criada.
Ordem
Este campo serve para ordenar as diversas opções de ecrã que possam existir por exemplo, num ecrã comum às mesmas.
Exemplo
: 2.
Programa com a reação a executar quando a opção é selecionada
É possível construir um programa em VB.Net. Este campo tem
intellisense
, ou seja, quando é colocada uma letra na caixa de texto é aberta uma caixa com todas as sugestões de código disponíveis para completar aquela palavra, à medida que se vai escrevendo as opções mostradas começadas pelas letras introduzidas vão reduzindo e aproximando do que se pretende. Também se pode pressionar as teclas ctrl + espaço ou ctrl + seta baixo para aparecer essa mesma caixa mas com todas as opções de código disponíveis, sendo que ao escrever texto as opções na caixa vão sendo filtradas.
Nota
:
Se usar em
Mainform
pode usar a variável STAMP para o stamp do registo em que está e o dataset MAINFORMDATASET para os dados do registo.
Se em
Monitor
ou
Item de monitor
o texto #STAMP# tem o stamp da coluna 1 e o texto #STAMP3# tem o stamp da coluna 3, o dataset MAINFORMDATASET tem os dados do Monitor em análise. Quando utilizado em monitor pode colocar variáveis globais com o texto #G1#, por exemplo para a variável com o número 1.
Caso o utilizador pretenda, ao clicar no botão
pode aceder ao
Editor de Código
. Após o preenchimento deste campo, o utilizador poderá
.
Posição para monitores e itens
Caso a opção seja definida para um monitor ou item de monitor, ela pode ser colocada em uma das seguintes posições:
- Topo e Fundo;
- Topo do Ecrã;
- Fundo do Ecrã.
Posição se num mainform
Caso a opção seja definida para um ecrã, ela pode ser colocada em uma das seguintes posições:
- Zona de ecrã nas opções;
- Zona de registo isolado;
- Zona de registo nas opções;
- Zona de próximas ações.
Número sequencial interno
O número sequencial interno é atribuído pela aplicação e este campo é apenas de leitura.
Invisível na edição, consulta e/ou no fim de ficheiro
Configurando estas opções define-se se a opção de ecrã criada está invisível na edição (introdução e alteração), na consulta e no fim de ficheiro, esta última opção é quando ainda não estão dados selecionados (no ecrã).
Nº Interno do Documento/Dossier
Permite definir um tipo de documento de faturação ou dossier interno onde irá aparecer a opção de ecrã.
Pode introduzir o nome de um monitor ou seleciona-lo através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caractere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Disponível no monitor quando
- Sempre
- Apenas quando algo selecionado na coluna 1
Neste local é necessário indicar qual o item de monitor em que a opção de ecrã irá ser colocada. Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo carater introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Disponível no monitor quando
A opção do ecrã pode estar disponível em um item de monitor nas seguintes situações:
- Apenas quando algo selecionado na coluna 1
- Apenas quando algo selecionado na coluna 2
Se pretender limitar o acesso dos utilizadores à Opção de Ecrã criada, pode ativar a opção
Tem que possuir um determinado acesso à tabela:
, indicar qual a tabela e indicar o
acesso
que o utilizador deverá ter.
A Opção de Ecrã pode estar disponível nos diversos
packages
que o cliente tiver instalado, pode neste local definir onde aparecerá o menu criado.
Exemplo
:
Pode também definir se terá acesso à Opção de Ecrã:
- Apenas a quem tem acesso ao módulo Gestão web
- Apenas a quem tem acesso ao módulo Colaborador web
- Apenas a quem tem acesso ao módulo Contabilidade web
- Apenas a quem tem acesso ao módulo Suporte web
- Apenas a quem tem acesso ao módulo Crm web
- Apenas a quem tem acesso ao módulo Equipa web
Ecrã em modo de consulta
Em modo de consulta o utilizador tem a possibilidade de usufruir das
opções de registo
, bem como
alterar
o registo e/ou apagar o mesmo.
Exemplos práticos
Exemplo de uma opção de ecrã presente na
zona de próxima ações
:
Ecrã onde este objeto será colocado:
ftform
Resumo da opção:
Notificar
Texto da opção:
Notificar o cliente
Programa com a reação a executar quando a opção é selecionada
dim txtemail as webcontrollib.nossocampotextbox
' Constrói uma string que vai ser o corpo do email
txtemail =mpage.master.findcontrol("conteudo").findcontrol("campos").findcontrol("no")
dim email as string = cdata.getumvalorstring("email", "cl", "cl.no='" & txtemail.value & "'")
dim mform as mainform=mpage
xcutil.GenEmail(xcuser.useremail, email, "", "", "Assunto", xcutil.formatnotification(txtemail))
Posição para monitores e itens:
Topo do ecrã
Package:
Intranet e Extranet
Framework Phc Cs Web
