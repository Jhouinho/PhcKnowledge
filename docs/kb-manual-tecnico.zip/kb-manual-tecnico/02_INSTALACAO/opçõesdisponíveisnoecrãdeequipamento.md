---
title: Opçõesdisponíveisnoecrãdeequipamento
source: opçõesdisponíveisnoecrãdeequipamento.htm
tipo: Manual Técnico
idioma: PT
---

# Opçõesdisponíveisnoecrãdeequipamento

Opções Disponíveis no Ecrã de Equipamento

|  |
| --- |
| Opções Disponíveis no Ecrã de Equipamento |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O tratamento de equipamento permite efectuar várias operações de análise na respectiva tabela. Assim existe possibilidade de executar diversas operações, que aliás funcionarão de forma idêntica nas restantes tabelas:    **Ícones**     Este ícone permite observar o historial de intervenções do equipamento. Neste local ficam registadas todas as intervenções feitas nos pedidos de assistência.  *Nota:* Os dados que ficam no histórico são os do pedido de assistência, mesmo que na ficha do equipamento e nas instalações exista dados diferentes.     Esta opção serve para observar os PATs (Pedidos de Assistência Técnica) existentes. Para mais informações consulte por favor o capítulo sobre [Pedidos de assistência](constituiçãodatabeladepats.htm).     Este ícone permite introduzir um novo PAT para este equipamento.  Esta é uma das formas de abrir um PAT, tendo a vantagem de ser aberto a partir da própria ficha do equipamento, preenchendo assim automaticamente os dados do equipamento no PAT. Para que este botão se encontre disponível, o utilizador necessita de ter [acesso de introduzir](acessosdospedidosdeassistência.htm) pedidos de assistência técnica.     Este ícone permite fazer cinco análises do equipamento, sendo que, estas análises só se encontram disponíveis para quem possui o módulo de Suporte e o de Equipamento.    **Horas de Mão-de-Obra em Intervenções**   Esta análise permite visualizar graficamente o número de horas de mão-de-obra, por tipo de intervenções e visualizar o Nº total de horas de todos o tipos de intervenções.    **Horas de deslocação em intervenções**  Permite visualizar graficamente o número de horas das deslocações.    **Tempo médio de Resposta de Pats**  Permite a visualização gráfica do número de Pats e o tempo que cada levou a ser fechado. Depois pode então fazer-se a média do tempo de resposta de cada tipo de Pat. Também é possível visualizar o tempo médio de resposta de todos os tipos de Pats.    **Totais por referência em Dossiers Internos**   Mostram uma grelha com os totais por referência, dos dossiers utilizados por este equipamento.    **Totais por Dossier Interno**  Mostram uma grelha com os totais por dossier, dos dossiers utilizados por este equipamento.    Para mais informações sobre esta opção é favor consultar o respectivo capítulo.     Este ícone permite imprimir a ficha.  Para mais informações sobre esta opção consulte por favor as [Impressões Definidas pelo utilizador.](impressõesdefinidaspeloutilizador(idu).htm).     Este ícone permite imprimir um texto [Processador de texto externo.](ligaçãoaprocessadordetextoexterno.htm).    *Nota:*   Os restantes ícones de carácter geral encontram-se explicados nas [Opções globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Opções Disponíveis no Ecrã de Equipamento' ) |