---
title: Opçõesdisponíveisnoecrãdeinstalações
source: opçõesdisponíveisnoecrãdeinstalações.htm
tipo: Manual Técnico
idioma: PT
---

# Opçõesdisponíveisnoecrãdeinstalações

Opções Disponíveis no Ecrã de Instalações

|  |
| --- |
| Opções Disponíveis no Ecrã de Instalações |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| No ecrã de instalações existem diversas opções:     Esta opção permite abrir ou [consultar um dossier interno](consultardossiersinternos.htm) com os dados da instalação.    Desta forma é possível registar no dossier os dados relacionados com a instalação. De notar que na configuração de dossiers é possível configurar a passagem dos dados do nome do [técnico](ConfiguraçãodeDossiers.htm#campos), bem como se pode activar os [números de série](ConfiguraçãodeDossiers.htm#agregar).    Os restantes dados como nº de série, marca, modelo, etc. também podem passar para o dossier, bastando para esse efeito criar [Valores por defeito](valorespordefeito.htm).     Para mais informações sobre Dossiers internos, consulte por favor o capítulo sobre [Dossiers](constituiçãodatabeladedossiers.htm).     Com esta opção é possível abrir um Pedido de assistência para um equipamento da instalação. Para esse efeito se não seleccionar nenhum equipamento previamente o PAt será preenchido com os dados que se encontram no ecrã de intervenções.  Por exemplo, o campo "Quem pediu" só é preenchido no PAT se existir um equipamento associado na intervenção.  Para mais informações sobre esta opção consulte por favor os [Pedidos de assistência](constituiçãodatabeladepats.htm).     Esta opção permite observar os Pedidos de Assistência referentes à instalação.        Como é possível verificar são apresentados a data do Pedido de assistência, o nº do pedido de assistência, o nome do técnico, o nome do cliente ou agente, o nome da entidade (caso o nome anterior seja do agente), a descrição do problema e a idade do pedido. Se fizer duplo clique em cima de um registo ou seleccionar um registo e clicar em OK, abre o ecrã de Pedidos de Assistência posicionado no respectivo registo.     Este ícone permite imprimir a ficha.  Para mais informações sobre esta opção consulte por favor as [Impressões Definidas pelo utilizador](impressõesdefinidaspeloutilizador(idu).htm).     Este ícone permite imprimir um texto [Processador de texto externo](ligaçãoaprocessadordetextoexterno.htm).    *Nota:*   Os restantes ícones de carácter geral encontram-se explicados nas [Opções globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Opções Disponíveis no Ecrã de Instalações' ) |