---
title: Opçõesdisponíveisnoecrãdetítulosdeclientes
source: opçõesdisponíveisnoecrãdetítulosdeclientes.htm
tipo: Manual Técnico
idioma: PT
---

# Opçõesdisponíveisnoecrãdetítulosdeclientes

Opções Disponíveis no Ecrã de Títulos de Clientes

|  |
| --- |
| Opções Disponíveis no Ecrã de Títulos de Clientes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| No ecrã de Títulos existem as seguintes opções:     Este ícone permite imprimir o título.  Para mais informações sobre esta opção consulte por favor no manual de Navegação o capítulo [Impressões Definidas pelo utilizador.](impressõesdefinidaspeloutilizador(idu).htm)     Esta opção serve para observar o documento que deu origem ao movimento, sendo assim possível aceder por exemplo à factura onde foi inserido o título.     Este ícone permite consultar o Talão de depósito onde o título foi inserido, se a tesouraria estiver instalada.      *Nota:*  Os restantes ícones de carácter geral encontram-se explicados na [Navegação nos ecrãs](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Opções Disponíveis no Ecrã de Títulos de Clientes' ) |