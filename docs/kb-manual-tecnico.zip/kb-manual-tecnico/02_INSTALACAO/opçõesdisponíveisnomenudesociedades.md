---
title: Opçõesdisponíveisnomenudesociedades
source: opçõesdisponíveisnomenudesociedades.htm
tipo: Manual Técnico
idioma: PT
---

# Opçõesdisponíveisnomenudesociedades

Opções Disponíveis no Menu de Sociedades

|  |
| --- |
| Opções Disponíveis no Menu de Sociedades |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Ao abrir o ecrã de Sociedades fica disponível uma Barra de Ícones de Programas, onde existem variadas opções. Nessa barra existe um ícone  de [opções](menudeopçõesdoecrã.htm) com várias acções, algumas delas já disponíveis através de ícones, nomeadamente a [Introdução](introduçãoderegistos.htm) e [Eliminação](apagarouanularregistos.htm) de registos, bem como [Mapas Definidos pelo Utilizador](mapasdefinidospeloutilizador.htm).    **Copiar de uma Base de dados**  Esta opção permite que sejam copiados dados entre as diversas empresas existentes, utilizando as mesmas potencialidades da instalação e manutenção. Para tal o utilizador ao se colocar na base de dados de destino deve indicar a origem dos dados que pretende copiar, preenchendo o servidor de origem e respectiva base de dados.    Posicionar na sociedade de destino, se ela não existir, ao criar uma a aplicação vai perguntar se pretende criar uma nova base de dados, esta situação acontece ao introduzir uma nova sociedade, colocando o servidor e o nome que se pretende dar á nova base de dados para copiar os dados. (obrigatório)    Pode agora, no ecrã seguinte, seleccionar os Dados pretendidos, utilizando as mesmas potencialidades da [Instalação e Manutenção](instalaçãoemanutenção.htm)    Obrigatório definir o **nome do server** e o **nome da base de dados de origem** a fim de copiar de lá os dados.    Existe a possibilidade de validar a opção **Não apagar os registos que já existem**, para que o utilizador defina se a cópia dos dados da Base de Dados de origem vai apagar ou não os dados já existentes na Base de Dados.    Ao premir **Instalar os ficheiros seleccionados** a aplicação vai criar ou actualizar as Bases de Dados e copiar a informação definida. (de Origem)      **Instalação e Manutenção**  Esta opção vai permitir executar as opções de [Instalação e Manutenção](instalaçãoemanutenção.htm) dentro das base de dados pretendidas sem ter de entrar em cada uma delas. A opção executa os testes e as validações sobre a Base de Dados definida no ecrã das Sociedades.    **Assistente de Criação de Mapas e Processamentos**  Este assistente permite ao utilizador efectuar a criação de Mapas e Processamentos a partir de Mapas e Processamentos já criados e devidamente configurados da Sociedade seleccionada no ecrã. Os novos Mapas e Processamentos a serem criados irão herdar as configurações efectuadas nos Mapas e Processamentos originais. O processo de cópia pode ser efectuado simultaneamente para todas ou qualquer uma das Sociedades existentes.      **Passo 1 de 4 - Mapas**  Permite seleccionar o(s) mapa(s) cujas defenições pretende utilizar para a criação do(s) novo(s) mapa(s).    **Passo 2 de 4 - Processamentos**  Permite seleccionar o(s) processamento(s) cujas defenições pretende utilizar para a criação do(s) novo(s) processamento(s).    **Passo 3 de 4 - Sociedades**  Permite seleccionar a(s) sociedade(s) para as quais pretende criar os novos mapas e/ou processamentos.    **Passo 4 de 4 - Resumo**  Apresenta o resumo das ordens efectuadas nos passos anteriores, podendo também apagar uma linha do mapa/processamento que não pretenda criar mas que foi escolhido nos passos anteriores.    Ao clicar em **Terminar** serão criados os Mapas e/ou Processamentos na(s) sociedade(s) respectivas.      **Importação das tabelas de IRS para várias Sociedades via Webservice**  Esta opção apenas está disponível para utilizadores com acesso de Supervisão à tabela "EC" (Sociedades).    Permite importar automaticamente as [tabelas de IRS](tabelasdeirs.htm) atualizadas para várias sociedades (o utilizador tem hipótese de escolher quais as Sociedades a actualizar).  As tabelas não serão importadas para Sociedades cuja base de dados não contenha dados do módulo Pessoal.     Se possuir [PHC ON](oqueéophcon.htm) poderá de forma fácil e eficaz importar as tabelas de IRS para vários clientes, permitindo actualizar diversas bases de dados, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=b4fe4gbf8e7.169c.ef75.1g%3a). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Opções Disponíveis no Menu de Sociedades' ) |