---
title: Opçõesdisponíveisnomenudetítulosdeclientes
source: opçõesdisponíveisnomenudetítulosdeclientes.htm
tipo: Manual Técnico
idioma: PT
---

# Opçõesdisponíveisnomenudetítulosdeclientes

Opções Disponíveis no Menu de Títulos de Clientes

|  |
| --- |
| Opções Disponíveis no Menu de Títulos de Clientes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Ao abrir o ecrã de Títulos fica disponível uma Barra de Ícones de Programas, onde existem variadas opções. Nessa barra existe um ícone  de [opções](menudeopçõesdoecrã.htm) com várias acções, algumas delas já disponíveis através de ícones, nomeadamente a [Introdução](introduçãoderegistos.htm) e [Eliminação](apagarouanularregistos.htm) de registos, bem como [mapas definidos pelo utilizador](mapasdefinidospeloutilizador.htm).    **Títulos vencidos**  Esta opção permite aceder a uma listagem que permite observar os títulos vencidos. Para esse efeito é necessário indicar o intervalo de datas pretendido.        **Relançar os títulos a partir dos documentos originais**  Esta opção permite relançar todos os títulos, criando-os novamente a partir dos documentos originais (facturas, recibos, etc.).   Relativamente aos títulos já depositados, que assumem a opção **Depositado em**  activa, ao serem relançados não perdem esta activação, de forma a manter coerente a informação.    **Consultar o talão de depósito onde o título foi inserido**  Esta opção permite observar o talão de depósito referente ao título. Só está disponível se tiver instalada a tesouraria. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Opções Disponíveis no Menu de Títulos de Clientes' ) |