---
title: O Regime de Iva na Faturação
source: oregimedeivanafaturação.htm
tipo: Manual Técnico
idioma: PT
---

# O Regime de Iva na Faturação

O Imposto sobre o Valor Acrescentado (IVA) é um imposto geral sobre o consumo que se repercute sobre o consumidor final de um bem transacionável. A particularidade deste imposto é que o sujeito passivo que adquire um produto com o imposto já pago por aquele que o alienou, fica investido no direito de dedução do imposto já suportado.
São dois os diplomas base que regem o IVA: o
Código do IVA
e o
RITI
(Regime do IVA nas Transmissões Intracomunitárias).
Sujeição Objetiva e Subjetiva
Estão sujeitas a IVA as seguintes operações:
Transmissões de bens e prestações de serviços realizadas a título oneroso;
Importação de bens;
Aquisições intracomunitárias de bens e serviços.
Existem ainda algumas operações que são assimiladas a transmissões de bens ou prestações de serviços realizadas a título oneroso e, como tal, são também sujeitas a IVA (exemplo: ofertas de bens e não devolução no prazo de 1 ano de bens enviados à consignação)
São sujeitos passivos de IVA, as pessoas singulares ou coletivas que exerçam uma atividade económica ou que, praticando uma só operação tributável, essa operação preencha os pressupostos de incidência real de IRS ou IRC.
O Estado e as demais pessoas coletivas de direito púbico não são sujeitos passivos de imposto quando realizem operações no exercício dos seus poderes de autoridade.
Obrigações
Os sujeitos passivos são obrigados à entrega de declaração de início de atividade quando iniciam a sua atividade. Quando tenham atingido, no ano civil anterior, um volume de negócios superior a 10.000€ deverão igualmente estar sujeitos ao regime geral de IVA. As entidades não residentes e sem estabelecimento estável no território nacional e que não estejam estabelecidas noutro Estado membro da UE, pelas operações realizadas em território nacional, estão obrigadas a nomear um representante para o cumprimento das obrigações em sede de IVA, nomeadamente pagamento do imposto.
Os sujeitos passivos estabelecidos em outros Estados membros da EU que transmitem bens no território nacional abrangidos pelo regime de vendas à distância e excedam o limite de 35.000€ devem entregar declaração de início de atividade, produzindo efeitos na data da sua apresentação.
As declaração periódicas deverão ser entregues mensalmente, até ao dia 10 do segundo mês seguinte, ou, se o volume de negócios anual for inferior a 650.000€, trimestralmente, até ao dia 15 do segundo mês seguinte.
Para além da declaração de início de atividade, os sujeitos passivos são também obrigados à entrega de declaração de alterações no prazo de 15 dias sempre que se verifique qualquer alteração à atividade, bem como de declaração de cessação em 30 dias quando se verifica a cessação da atividade.
Para além da declaração periódica, os sujeitos passivos também estão obrigados à entrega de mapas recapitulativos de clientes e fornecedores, onde conste o montante total das operações internas realizadas com cada um deles no ano anterior.
A contabilidade deve ser organizada, de forma a possibilitar o conhecimento dos elementos necessários ao cálculo do imposto com todos os dados necessários ao preenchimento da declaração periódica.
Podem ser aplicadas sanções pela falta ou atraso na entrega de declarações, bem como por outras contraordenações fiscais. Em regra, as contraordenações tributárias são puníveis a título de negligência sendo que, caso não haja distinção legal entre dolo e negligência, a coima só pode ser aplicada até metade do montante máximo estipulado. São igualmente devidos juros à taxa de 4%.
O Sistema Fiscal
Incidência do IVA
Estão sujeitas a IVA:
a) As transmissões de bens e as prestações de serviços efetuadas no território nacional, a título oneroso, por um sujeito passivo agindo como tal;
b) As importações de bens;
c) As operações intracomunitárias efetuadas no território nacional, tal como são definidas e reguladas no Regime do IVA nas Transações Intracomunitárias.
Quanto à
localização das operações
, são tributáveis as transmissões de bens que estejam situados no território nacional no momento em que se inicia o transporte ou expedição para o adquirente ou, no caso de não haver expedição ou transporte, no momento em que são postos à disposição do adquirente.
São também tributáveis as transmissões feitas pelo importador e as eventuais transmissões subsequentes de bens transportados ou expedidos de um país terceiro, quando as referidas transmissões ocorrerem antes da importação.
As transmissões de bens efetuadas a bordo de um navio, de uma aeronave ou de um comboio, durante um transporte intracomunitário de passageiros, só são tributáveis se o lugar de partida se situar no território nacional e o lugar de chegada no território de outro estado membro.
Sem prejuízo do disposto em casos especiais do CIVA, o imposto é devido e torna-se exigível:
Nas transmissões de bens, no momento em que os bens são postos à disposição do adquirente;
Nas prestações de serviços, no momento da sua realização;
Nas importações, no momento determinado pelas disposições aplicáveis aos direitos aduaneiros, sejam ou não devidos estes direitos ou outras imposições comunitárias estabelecidas no âmbito de uma política comum.
Taxas de IVA aplicadas em Portugal Continental e Regiões Autónomas
Configuração das Taxas de IVA no PHC Gestão CS
A configuração das taxas de IVA no PHC deve ser efetuada no menu Tabelas -" Taxas de IVA.
A configuração do Regime de IVA da empresa
O Regime de IVA diz respeito ao regime no qual a empresa se encontra enquadrada para efeitos fiscais, no que concerne à localização da sua sede ou estabelecimento estável e deve estar configurado nos parâmetros do sistema, para que ao emitir a sua faturação, a mesma possua essa informação para efeitos de informação à AT - Autoridade Tributária, prestada mensalmente através do ficheiro de comunicação de faturas (SAFT).
Transmissões no Mercado Nacional
Operações entre o Continente e as Regiões Autónomas
Face à legislação atual em território nacional existem três espaços fiscalmente distintos entre os quais podem existir trocas comerciais e/ou onde se podem localizar as prestações de serviços:
Continente
Açores
Madeira
O local onde uma determinada transmissão de bens ou prestação de serviços se localiza assume especial relevância, dado que é em função dessa mesma localização que será determinada a taxa de IVA a aplicar.
De forma a verificar qual o enquadramento para efeitos de aplicação da taxa de IVA pode sintetizar a questão em 3 questões:
Transmissão de Bens
Exemplos I:
A empresa Faz de Conta SA, com sede em Lisboa vende matérias de construção, sujeitos à taxa de IVA Normal, à empresa Aqui na Ilha SA, cuja sede se situa na Ilha de São Miguel, sendo que ambas as empresas são sujeitos passivos de IVA com direito à dedução.
Tendo por base o artigo 6º e 18º do Código do IVA, com o disposto no Decreto-lei 347/85 de 23 de Agosto, é necessário ter em atenção aos seguintes pontos:
- O local do início do transporte dos bens é em Lisboa
- Os bens são colocados à disposição do adquirente em Lisboa, à saída do Armazém
Resolução:
A operação considera-se localizada no Continente
A taxa a aplicar é de 23%
O transporte dos bens é isento de IVA
Como configurar no PHC
Dado que empresa "Faz de Conta SA" possui a sua sede no Continente, deve configurar o seu regime de IVA nos parâmetros gerais, parâmetro "Descrição do Regime de IVA" escolhendo a opção PT.
Em virtude de existirem transações efetuadas com o cliente "Aqui na Ilha SA", que são tributadas à taxa de IVA em vigor no Continente, na ficha do cliente o campo "Regime de IVA" não deve ser preenchido em virtude do valor inserido, nesse mesmo campo, se sobrepor ao Regime de IVA definido nos parâmetros gerais.
Assim ao emitir a Fatura ao cliente "Aqui na Ilha SA", o campo "Descrição Regime de IVA" no separador outros dados será preenchido com o valor "PT".
Exemplos II:
A empresa "Faz de Conta SA", com sede em Lisboa, comercializa materiais de construção e efetua uma venda de cofragem para a sociedade "O Encanto da Lagoa, Lda", nos Açores, para ampliação das suas instalações, sendo que esse material é entregue na sede da empresa adquirente através da filial existente da empresa "Faz de Conta" nos Açores.
Tendo em conta o disposto nos artigos 6º e 18º do CIVA e o Decreto-Lei 348/85 de 23 de Agosto e levando em consideração que:
O local do início de transporte é nos Açores
Os bens são colocados à disposição na sede da empresa O Encanto da Ilha Lda, nos Açores
A operação considera-se localizada nos Açores, pelo que a taxa a aplicar é de 18% e o regime de IVA que deve contar na fatura é o PT-AC.
Como configurar no PHC
Se todas as transmissões de bens e serviços efetuados ao cliente sediado no Faial tiverem como local de entrega os Açores o regime de IVA PT-AC, pode ser configurado diretamente na ficha do cliente, dado que o valor constante neste campo sobrepõe-se ao valor constante no "Regime de IVA" dos parâmetros gerais do sistema.
Com o regime de IVA configurado na ficha do cliente, sempre que é emitida uma fatura ao cliente o campo
Regime de IVA
será preenchido com PT-AC.
Nota:
Com esta configuração há que se ter em atenção, caso seja emitida uma fatura, que deve ser tributada à taxa de IVA do Continente. Nesta situação deve ser alterado o regime de IVA na emissão da fatura para PT.
Prestação de Serviços
As prestações de serviços relacionadas com:
Cessão ou concessão de direitos de autor, de brevets, licenças, marcas de comércio e/fabrico e outros direitos análogos;
Serviços de Publicidade;
Consultores, advogados, engenheiros, economistas e contabilistas:
Gabinetes de estudo;
Tratamentos de dados e fornecimento de informações;
Operações Bancárias, financeiras e de seguros, exceto a locação de cofres-fortes;
Colocação de pessoal à disposição.
São tributadas no local onde se localiza a sede ou domicilio do adquirente do serviço, independentemente da sede ou local do prestador do serviço.
Transmissões Intracomunitárias
Valor tributável e taxas
O valor tributável das aquisições intracomunitárias de bens será determinado mediante aplicação das regras do CIVA.
Nos casos das transmissões de bens e das prestações de serviços, o valor tributável é calculado pelo preço de aquisição dos bens ou de bens similares, ou, na sua falta, o preço de custo, reportados ao momento da realização das operações;
As taxas aplicáveis nas aquisições intracomunitárias são as do CIVA, vigentes no momento em que o imposto se torna exigível.
1ª Regra Geral - alínea a) do nº 6 do Artigo 6º do CIVA
Quando o adquirente dos serviços seja um sujeito passivo do IVA	, ou seja quando estamos perante uma operação B2B, as operações são tributáveis no lugar onde o adquirente tenha a sua sede, estabelecimento estável ou domicílio fiscal.
Exemplo:
Se um sujeito passivo de IVA sediado em Portugal Continental prestar um serviço a uma empresa Francesa, a operação é considerada localizada em França, pelo que a empresa Portuguesa não deve liquidar IVA cabendo à empresa Francesa liquida-lo em França à taxa de IVA ai vigente (Reverse-Charge).
2ª Regra Geral - alínea b) do nº 6 do Artigo 6º do CIVA
Quando uma prestação de serviços é efetuada a um sujeito não passivo - consumidor final - estamos perante uma operação B2C. Nesta situação as operações são localizadas na sede, estabelecimento estável ou domicílio fiscal do Prestador de Serviços, devendo liquidar o IVA.
Exemplo:
Se uma empresa Portuguesa prestar um serviço a um consumidor situado na Alemanha deverá a mesma liquidar o IVA em Portugal.
Exceção às Regras
Dada a diversidade que compõe o leque de operações qualificadas como prestações de serviços, as regras gerais, tal como na disposição legal anterior, abarcam um lote relativamente vasto de exceções.
As exceções aglomeram-se em exceções comuns às duas regras gerais e exceções aplicáveis aos serviços prestados a não sujeitos passivos.
Enquanto as primeiras se aglomeram nos nª 7 e 8, e alínea a) do n.º 12 do artigo 6.º do CIVA, as exceções aplicáveis à regra geral dos serviços prestados a não sujeitos passivos concentram-se nos nºs 9 a 11, e alíneas b) a d) do n.º 12 do artigo 6.º do CIVA.
De acordo com os nºs 7 e 8, e alínea a) do n.º 12 do artigo 6.º do CIVA, passam a existir exceções que abrangem, quer os serviços prestados a sujeitos passivos, quer os serviços prestados a não sujeitos passivos.
Independentemente da natureza do adquirente do serviço, são criadas regras próprias, e como tal, constituem exceções às regras gerais, os serviços enumerados abaixo, que serão localizados, isto é, tributáveis, no local onde são materialmente executadas:
Prestação de serviços com imóveis
Prestação de serviços de transporte de passageiros
Serviços de alimentação e bebidas, executadas a bordo de uma embarcação, de uma aeronave ou de um comboio, durante um transporte intracomunitário de passageiros.
Outras prestações de serviços de alimentação e bebidas em geral
Prestações de serviços de carácter cultural, artístico, científico, desportivo, recreativo, de ensino e similares, incluindo feiras e exposições, compreendendo as dos organizadores destas atividades e as prestações de serviços que lhes sejam acessórias
Locação de curta duração de um meio de transporte.
Locação de bens móveis corpóreos, com exceção dos meios de transporte
Como configurar no PHC o Regime de IVA nas Transmissões Intracomunitárias
No que diz respeito ao Regime de IVA, o mesmo deve ser sempre considerado o regime da empresa ou seja, para empresas com sede, estabelecimento ou domicílio fiscal em Portugal o regime de IVA é sempre PT, pelo que o mesmo deve ser configurado nos parâmetros do sistema.
Nota:
Na ficha do cliente o campo "Regime de IVA" não deve ser preenchido.
Gama e versão do software PHC em que foi testado: PHC Advanced15
