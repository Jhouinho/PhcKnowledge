---
title: Otimizarbasededadosparaacontabilidade
source: otimizarbasededadosparaacontabilidade.htm
tipo: Manual Técnico
idioma: PT
---

# Otimizarbasededadosparaacontabilidade

Otimizar Base de Dados para a Contabilidade

|  |
| --- |
| Otimizar Base de Dados para a Contabilidade |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A base de dados instalada na aplicação possui diversas tabelas que não são necessárias para o dia a dia do utilizador que trabalha apenas com o módulo PHC CS Contabilidade dektop, resultando numa redução de espaço disponível em disco, o que provoca um prolongamento de tempo de resposta por parte da aplicação.  Quem possuir exclusivamente o módulo PHC CS Contabilidade desktop ou o Módulo PHC CS Contabilidade desktop e PHC CS Interop desktop, poderá configurar a sua base de dados para que esteja pronta a trabalhar apenas com estes módulos e tenha melhor performance. Este processo é todo efetuado no "Assistente de Instalação e Manutenção" quando o utilizador entra na base de dados.  O "Assistente de Instalação e Manutenção" passará a disponibilizar duas opções ao selecionar a "Manutenção Personalizada": **Otimizar para a Contabilidade** e **Nova Empresa**. Ao ativar a opção **Otimizar para a Contabilidade**, será mostrada automaticamente a opção **Nova Empresa**, que aparece inativa por defeito. Caso seja ativada a opção **Nova Empresa**, o "Assistente de Instalação" terá 3 passos adicionais especifícos para preenchimento de informação relativa a dados da empresa, que juntando aos restantes 3 passos rotina do Assistente, faz um total de 6 passos de configuração para preparar a base de dados.  - *Passo 1 de 6:* Dados da Empresa - neste passo existem campos de preenchimento obrigatório, como **Nome**, **Morada**, **Contribuinte**, **Seg. Social** ou **País**, que serão gravados no estabelecimento **Sede** da "Ficha Completa da Empresa". Caso algum destes campos não estiver preenchido, não será feita nenhuma atualização à Ficha Completa da Empresa, se tiver a opção **Nova Empresa** inativa, não será apresentado este ecrã e os dados serão automaticamente carregados.  - *Passo 2 de 6:* Parâmetros a Definir - aqui são apresentados os parâmetros gerais essenciais para o funcionamento do módulo PHC CS Contabilidade desktop. Os parâmetros de opção aparecem todos ativos por defeito. O parâmetro [Código do Sistema Contabilístico](ParâmetrosGerais.htm#mchcsc) apresentará as opções de SNC para Portugal, POC para África e PGC para Espanha automaticamente, consoante a Base de dados que esteja a utilizar. Se inativar o parâmetro **Possui ano Fiscal igual ao Civil**, os campos para selecionar o 1º, 13º, 14º, 15º e 16º meses do ano poderão ser alterados manualmente. Baseando no valor escolhido para o 1º mês são preenchidos os parâmetros relativos aos primeiros 12 meses. Caso a opção **Nova Empresa** esteja inativa, os parâmetros serão automaticamente carregados.  - *Passo 3 de 6:* Mapas a Importar - Campos e Importação dos Mapas: são apresentados os campos para preencher o acesso ao WebService da PHC, ao clicar no botão "OK" serão apresentados os Mapas de Gestão baseados na norma contabilística escolhida no *Passo 1 de 6* e também os mapas que não tenham a norma preenchida.  - *Passo 6 de 6:* Confirmar as seleções anteriores - ao clicar em "Terminar" serão gravados os dados da "Ficha Completa da Empresa", os "Parâmetros", os "Mapas de Gestão" escolhidos e a seguir serão eliminadas todas as tabelas que não são necessárias. Irá surgir uma barra de progresso a indicar qual(ais) ou a(s) tabela(s) que estão a ser apagadas. Findado este procedimento será dado início ao processo normal de instalação e manutenção.  Quando se ativa a opção **Otimizar para Contabilidade**, no *Passo 4 de 6* - Selecionar Ficheiros - fica automaticamente selecionada a opção **Todos (apenas recomendado na instalação de software ou upgrade de versão)**, não sendo possível alterar para uma outra. No *Passo 5 de 6*  - "Operações de reconstrução" - todas as opções ficam ativas, não podendo desativar nenhuma.  *Notas:* A funcionalidade **Otimizar para Contabilidade** não deve ser usada numa base de dados criada de raiz no SQL, mas sim numa *demo* ou numa *csdefault*. É necessário ter muita atenção a este detalhe, porque este processo não foi preparado para criar tabelas, mas sim apagar tabelas que não sejam necessárias e para quem irá trabalhar apenas com o módulo PHC CS Contabilidade desktop. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Otimizar Base de Dados para a Contabilidade' ) |