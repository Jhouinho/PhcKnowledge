---
title: Outlookaddinparadocumentosdesktop
source: outlookaddinparadocumentosdesktop.htm
tipo: Manual Técnico
idioma: PT
---

# Outlookaddinparadocumentosdesktop

Outlook Addin para Documentos Desktop

|  |
| --- |
| Outlook Addin para Documentos Desktop |

|  |
| --- |
| O Documentos desktop, módulo de gestão documental agrega a possibilidade de anexar documentos a registos e tabelas do software PHC. Estes anexos podem assumir variados formatos de ficheiro, nomeadamente o formato mensagem, ou seja, e-mail. Para que seja possível anexar e-mail(s) ao sistema PHC existe um **Addin para o Microsoft Outlook 2003** e um **Addin para o Microsoft Outlook 2007** que devem ser [instalados](instalaçãodooutlookaddin.htm) aquando da instalação do software PHC.     Esta funcionalidade não só permite anexar e-mail(s) ao sistema PHC como também permite arrancar workflows.  O Addin para o Microsoft Outlook 2003/2007 encontra-se disponível nas três gamas. No entanto, em Corporate não disponibiliza as opções de Workflow, uma vez que esta funcionalidade não existe nesta gama.    Existem diversas configurações a ser efectuadas, nomeadamente a nível de tabelas no [Software PHC](configuraçãododocumentosdesktopparaaddin.htm) e a nível do [Addin instalado](configuraçãodooutlookaddin.htm) no Microsoft Outlook 2003/2007.    Relativamente ao [funcionamento desta rotina](funcionamentodooutlookaddinparadocumentosdesktop.htm) de introdução de e-mail(s) no sistema PHC, ela pode ser efectuada de duas formas distintas: **Online** e **Offline**. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Outlook Addin para Documentos Desktop' ) |