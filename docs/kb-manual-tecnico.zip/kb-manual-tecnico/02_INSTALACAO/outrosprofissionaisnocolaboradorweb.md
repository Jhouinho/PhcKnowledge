---
title: Outrosprofissionaisnocolaboradorweb
source: outrosprofissionaisnocolaboradorweb.htm
tipo: Manual Técnico
idioma: PT
---

# Outrosprofissionaisnocolaboradorweb

Outros Profissionais no Colaborador Web

|  |
| --- |
| Outros Profissionais no Colaborador Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite consultar as fichas de outro profissional a partir do utilizador que se encontra na aplicação, mediante os acessos próprios.    No ecrã "Outros profissionais" encontram-se as fichas individuais com toda a informação necessária sobre cada profissional, nomeadamente :    **Nome**  Nome do profissional.    **Número**  Número interno do Profissional.        ``` Dados Principais ```   Neste local podem ser consultados os dados correspondentes à **Morada** do profissional, **Localidade**, **Cód. postal** da morada do profissional, **Telefone**, **Fax**, **Nº B.I.**, **Data** e **Local** de emissão do bilhete de identidade, **Nº de contribuinte** do profissional e o código da repartição de finanças em que o profissional está inscrito.  *Nota:* Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação, caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    Existem ainda outros campos não menos importantes consultar:    **Categoria de Rendimentos**  Neste campo poderá consultar a categoria dos rendimentos auferidos pelo profissional de entre as seguintes:     **B** - Rendimentos Profissionais (categoria B legal);    **C** - Rendimentos Empresariais (categoria B legal);    **F** - Rendimentos prediais;    **H** - Pensões;    **R** - Retenções de IRC.       **Atividade**  Campo com a designação da atividade prestada pelo profissional.    **País de Origem**  País de origem do profissional.    **Retém IRS / IRC na fonte**  Esta opção encontra-se validada caso o profissional faça retenção de IRS ou de IRC.    **Debita IVA à taxa em vigor**  No caso de o profissional debitar IVA esta opção deve estar validada.    **IVA - Regime de isenção ( artº 53 )**  Na situação de o funcionário se encontrar isento de IVA esta opção deve estar validada.    **IVA - Isento ( artº )**  No caso de se encontrar isento de IVA, deverá encontra-se definido o **artigo** legal que abrange a situação profissional do funcionário.        ``` Outros Dados ``` **Informação Bancária**  Neste espaço constam as informações relativas ao **Banco**, o **Código do Banco**, o **Código do Balcão**, a **Conta bancária** e o **NIB** ( número de identificação bancária) do profissional.   No caso do profissional receber por transferência bancária, essa opção deve estar validada.  A informação **Banco de saída**, indica qual o banco utilizado pela empresa para a liquidação dos recibos.       **Classificação**    **Centro Analítico**  Campo do centro analítico a que pertence o profissional.    **Refª Interna**  Campo que indica a referência interna a que está associado o profissional.        ``` Dados Contabilísticos ``` No caso de possuir o módulo de Contabilidade estão definidas as contas a creditar e debitar:     **Conta para Custos**    **Conta de Adiantamentos**    **Conta de Adiantamentos para Despesas**    **Conta de I.V.A. Liquidado**    **Conta de I.V.A. Dedutível**       Neste ecrã ainda existe ainda a possibilidade de   [Procurar Recibos de Outros Rendimentos](consultaderecibosdeoutrosrendimentos.htm) . |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Outros Profissionais no Colaborador Web' ) |