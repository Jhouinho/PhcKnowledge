---
title: Parâmetros
source: parâmetros.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetros

Esta opção permite configurar diversas opções para que as aplicações autorizadas trabalhem mais de acordo com o funcionamento da sua empresa. Como por exemplo, opções que estejam no âmbito de:
Colaborador
Configuração geral
Contabilidade web
Crm web
Documentos intranet web
Equipa extranet web
Equipa intranet web
Extranet
Front web
Gestão web
Intranet
Colaborador web
Portal
Suporte extranet web
Suporte intranet web
Colaborador
Calcular os dias de férias no ano de admissão, de forma proporcional
Este parâmetro tem o seguinte comportamento:
Quando o parâmetro encontra-se inativo, a aplicação efetua os cálculos, tal como o código do trabalho indica, de dois dias úteis por cada mês de duração de contrato, até 20 dias;
Quando o parâmetro se encontra ativo, a aplicação efetua os cálculos de forma proporcional, atribuindo também no limite até 20 dias férias, referentes ao ano de admissão. No entanto, para clarificar esta questão, veja-se os seguintes exemplos práticos:
1) Um colaborador que entre na empresa no dia 01 de Março do ano N ou em data inferior a esta, terá 20 dias de férias relativas ao ano de admissão, tal como o código do trabalho indica, atribuirá dois dias úteis por cada mês de duração de contrato;
2) Um colaborador que entre o dia 02 e o dia 15 de Março terá direito a 19 dias de férias, referentes ao ano de admissão;
3) Um colaborador que entre o dia 16 e o último dia de Março, já não terá direito a qualquer dia de férias referentes ao mês de Março.
Configuração Geral
Centro Analítico
Permite indicar o nome do campo de "Centro Analítico".
Natureza
Este campo permite renomear o campo
Natureza
existente em todos os ecrãs principais da aplicação.
Número máximo de recentes
Este parâmetro permite ao utilizador escolher quantos itens pretende observar na área de
links
recentes.
Número máximo de registos a trazer nas pesquisas
Este parâmetro permite ao utilizador indicar quantos itens pretende visualizar, no máximo, por cada resultado nas pesquisas, através do botão
lupa
. A visualização obedece ao valor que está configurado nos parâmetros, por defeito, a aplicação está configurada para apresentar no máx. 100 registos, podendo este ser alterado pelo valor desejado.
Usa Log de Código de Utilizador
Este parâmetro quando ativo permite visualizar a informação relevante do código de utilizador que corre num determinado local. Por exemplo: Ao introduzir um pedido de assistência.
Nota:
Se no ficheiro
appSettings.config
o valor da Key
SESSIONERROR
for "S", ao executar código de utilizador, surge no fundo da página o texto
Log de código de utilizador:
seguido da informação respeitante ao código executado, como o tipo, o identificador e o
URL
, possibilitando navegar para o código executado através de um clique no identificador.
Contabilidade web
Descritivo
Caso esse parâmetro esteja ativo quando se está no
Contabilidade Web
a introduzir documentos contabilísticos, e se escolhe um documento predefinido, o campo descritivo das linhas do documento contabilístico que vêm do documento pré definido ficam com o valor igual á abreviatura do documento predefinido mais o número do documento contabilístico que estiver na página na altura.
Rúbrica
Neste parâmetro deve definir-se a designação do campo de utilizador nos movimentos (rúbrica).
Ver Centro Analítico
Ao ativar esta opção, permite visualizar o campo centro analítico nas linhas dos documentos contabilísticos.
Ver Identificação Interna
Ao ativar esta opção, permite visualizar o campo de identificação interna nas linhas dos documentos contabilísticos.
Ver Mapa Recapitulativo
Ao ativar esta opção, permite visualizar o campo dos mapas recapitulativos nas linhas dos documentos contabilísticos.
Ver Natureza
Este parâmetro quando está ativo permite visualizar o campo
Natureza
nos documentos contabilísticos.
Ver Rúbrica
Esta opção permite criar o nome da coluna Rubrica, podendo esta ser alterada pelo utilizador. Esta coluna ficará disponível nas linhas dos documentos contabilísticos.
Crm web
Na homepage aparece a procura de contactos CRM por nome
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Na homepage aparece a procura de produtos vendidos por referência
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Documentos Intranet web
Na homepage aparece a procura de anexos por nome
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Equipa extranet web
Campo adicional para lista de projetos no portfólio de projetos
Qual o campo da base de dados a apresentar na lista de projetos no ecrã de portfólio de projetos.
Ícone de notícias quando estas não têm imagem na extranet
Quando os parâmetros estão preenchidos com o caminho para a imagem, passa a surgir essa imagem quando as notícias não têm imagem. A imagem deve ter de preferência o tamanho de 100x100.
Equipa Intranet Web
Blogues: usa blogues
Define se são utilizados blogues nesta aplicação.
Nota:
Este parâmetro só está disponível quando o parâmetro:
Utiliza área pessoal
, também está.
Os parâmetros que se seguem estão diretamente relacionados com os
Contactos Pessoais
-
Informação Pessoal
. Os mesmos só se encontram disponíveis, se o utilizador ativar o parâmetro
Utiliza área pessoal
e podem ser personalizados de conforme a necessidade do utilizador:
Contactos pessoais: nome do campo "Categoria"
Contactos pessoais: nome do campo "E-mail 1"
Contactos pessoais: nome do campo "E-mail 2"
Contactos pessoais: nome do campo "Fax da Empresa"
Contactos pessoais: nome do campo "Fax de Casa"
Contactos pessoais: nome do campo "Morada da Empresa"
Contactos pessoais: nome do campo "Morada de Casa"
Contactos pessoais: nome do campo "Página Pessoal"
Contactos pessoais: nome do campo "Telefone da Empresa"
Contactos pessoais: nome do campo "Telefone de Casa"
Contactos pessoais: nome do campo "Telemóvel"
Contactos pessoais: nome dos contactos pessoais
Contactos pessoais: Template dos itens do EEMLIST
Nota:
Se o utilizador alterar estes campos deve reconstruir o dicionário de dados do PHC CS Web para a tabela
.EEM
.
Ícone de notícias quando estas não têm imagem na intranet
Quando os parâmetros estão preenchidos com o caminho para a imagem, passa a surgir essa imagem quando as notícias não têm imagem. A imagem deve ter de preferência o tamanho de 100x100.
Os próximos parâmetros também só se encontram disponíveis, se o utilizador ativar o parâmetro
Utiliza área pessoal
. Uma vez ativos, permitem ao mesmo definir um método de procura, utilizando o campo de
Pesquisa Avançada
:
Na homepage aparece a procura de contactos pessoais por nome;
Na homepage aparece a procura de contactos telefónicos;
Na homepage aparecem as chamadas telefónicas;
Na homepage aparecem as mensagens internas;
Na homepage aparecem as tarefas atrasadas;
Na homepage aparecem os leilões em aberto.
Na homepage aparecem as notícias de projetos de cada utilizador
Quando se possui o módulo PHC CS Equipa intranet web é neste local que se define se na homepage aparecem ou não, as
Notícias de Projetos
em que cada utilizador está envolvido.
Na homepage aparecem as tarefas marcadas pelo responsável de cada utilizador
Só depois de selecionar este parâmetro ficam disponíveis na
homepage
, as tarefas marcadas e em aberto que estão do lado do utilizador.
Na homepage aparecem os assuntos de cada utilizador
Quando ativo, este parâmetro disponibiliza os assuntos de Equipa de cada utilizador na homepage.
Na homepage aparecem os projetos favoritos a cada utilizador
Quando se possui o módulo PHC CS Equipa intranet web é neste local que se define se na homepage aparecem ou não, os
projectos favoritos
a cada utilizador.
Utiliza área pessoal
Ao ativar este parâmetro, o utilizador passa a ter acesso à sua área pessoal, como por exemplo:
Aceder a informação referente à
gestão interna
, permitindo:
- Efetuar
Manutenção das regras
;
- Consultar
Regras Internas
;
- Guardar
Contactos
;
Interagir com a sua
informação pessoal
:
- Inserir as suas
notas pessoais
;
- Gerir
Projetos pessoais
;
- Controlar
tarefas pessoais
.
E gerir
leilões internos
, nos quais todos os utilizadores podem participar.
Nota:
Este parâmetro está inativo por defeito.
Rede colaborativa: Nome atribuído à Rede Colaborativa
Neste parâmetro poderá definir qual o nome da sua rede colaborativa. Desta forma, todas as etiquetas referentes à Rede Colaborativa, assim como as dicas de ajuda, passarão a ser apresentadas com o nome configurado no parâmetro. No entanto, caso não altere, continuará a ser apresentado "Rede Colaborativa" para designar a sua rede.
Na homepage aparece a procura de contactos pessoais por nome
Se ativar este parâmetro, na caixa de seleção da Pesquisa global, será apresentada a opção de procura por contactos pessoais, caso também tenha o parâmetro "Uriliza área pessoal" ativo.
Na homepage aparece a procura de contactos telefónicos
Se ativar este parâmetro, na caixa de seleção da Pesquisa global, será apresentada a opção de procura por contactos telefónicos, caso também tenha o parâmetro "Uriliza área pessoal" ativo.
Extranet
Blogues: mensagem de boas vindas
Mensagem a dar na página de listagem de blogues BLOGMON para dar as boas vindas e instruções aos utilizadores.
Blogues: usa blogues
Define se são utilizados blogues nesta aplicação.
Dossiers: Código do script de utilizador para a listagem de procura de artigos
Este parâmetro deve ser preenchido com o código presente no script e que deve incluir os campos obrigatórios:
ststamp
Ref
design
qtt (com valor 0).
Executa eventos em Objetos Internos de grelhas de documentos
Executa eventos em objetos internos de grelhas em Dossiers Internos e Encomendas. No entanto, se o parâmetro estiver inativo, a aplicação não executa os eventos
FTAposAlterarValorEmLinha
e
BoAposAlterarValorEmLinha
destinados às grelhas e/ou eventuais objetos internos dedicados às grelhas dos ecrãs de Dossiers e Encomendas, tornando a aplicação mais rápida, uma vez que deixa de executar o "PostBack" nesses campos.
Header: Imagem/logotipo do cabeçalho
Neste local deve ser indicado o Path relativo ou completo, para a imagem a colocar no cabeçalho como por exemplo, o logotipo.
Por exemplo
: ../pimages/demologomaisritmoh.gif
Header: Template do Header
Deve ser utilizado para indicar qual o Template a utilizar para o Header dos ecrãs.
Header: Texto para cabeçalho
Neste parâmetro permite ao utilizador colocar texto em Html para colocar no cabeçalho. Se estiver preenchido não será usado o parâmetro de imagem/logotipo de cabeçalho.
Homepage: Altura máxima da caixa de notícias
Neste parâmetro deve-se definir a altura máxima que a caixa onde aparecem as notícias terá, medida em pixels. Se o utilizador colocar zero ocupará o espaço necessário para apresentar as últimas 10 notícias.
Homepage: Mensagem de HomePage
O utilizador pode personalizar uma mensagem para aparecer na Homepage da Extranet.
Homepage: Número de colunas
Neste parâmetro é possível configurar 2 ou 3 colunas. Ao selecionar, para passar a 2 colunas, a informação que consta na coluna 2 passa a estar visível na coluna 3.
Homepage: Posição das Notícias na Homepage
Neste parâmetro define-se qual a posição das Notícias na homepage, selecionando-se uma das seguinte opções: Centro, Esquerda ou Direita.
Homepage: TAGs para Homepage
Quando se publica um site na Internet torna-se interessante ter um conjunto de estatísticas de indexação do site, taxas de rastreamento, pagerank das páginas, estatísticas de pesquisa e a lista dos itens mais pesquisados que levam os utilizadores até às páginas do nosso site na web.
O Google fornece este tipo de serviços através do Google Sitemaps.
Este serviço permite ao motor de busca do Google conhecer melhor as páginas de um site e oferece ao dono do site o controlo dos processos de rastreamento e indexação do mesmo.
Contudo é necessário que a homepage do site contenha uma determinada tag fornecida pelo Google, para provar que esse site está sob controlo do respetivo dono.
Neste parâmetro pode-se criar uma determinada TAG, com os dados em HTML, que será sempre introduzida no HEAD da homepage do site mostrando ao Google quem é o dono do mesmo.
Template da Homepage
Neste local define-se qual o Template a utilizar para a página inicial.
Homepage: Template dos itens do #NOTICIAS#
Neste parâmetro o utilizador pode personalizar um template dos itens de notícias, quando são apresentadas na homepage (objeto #NOTICIAS# em HTML puro).
Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Template dos itens do #NOTICIASSOTEMPLATE#
Neste parâmetro o utilizador pode construir um template dedicado ao #NOTICIASSOTEMPLATE# em HTML puro. Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Título da caixa de Notícias
O texto definido neste campo aparecerá como título na caixa de notícias da página inicial.
Homepage: Título da homepage
O texto que o utilizador definir neste parâmetro aparecerá no título da homepage. Se não estiver preenchido utiliza o título de todas as páginas.
Homepage: Usa destaques com favoritos, páginas recentes, etc. no topo
Este parâmetro permite ao utilizador colocar um objeto de destaque nos Favoritos; Páginas recentes, etc. da aplicação PHC CS Web.
Homepage: Usa imagem de topo com horário
Este parâmetro permite ao utilizador colocar a imagem da aplicação PHC CS Web que contém o relógio e eventualmente a próxima ação do utilizador (por exemplo, uma marcação, etc).
Imagem de fundo
Neste parâmetro deve ser introduzido o caminho (path) relativo ou completo para a imagem a colocar no fundo de todas as páginas.
Login: Instruções
Neste parâmetro é possível definir a mensagem para aparecer no fundo do login, como por exemplo, instruções.
Login: Mantém o utilizador logado
Este parâmetro, quando ativo, permite que não seja necessário que o utilizador digitar as suas credenciais para entrar na aplicação, se utilizar sempre o mesmo dispositivo. Ou seja, caso o utilizador, após a primeira autenticação aceda à aplicação sempre com o mesmo dispositivo, não necessita de digitar ciclicamente a password para aceder à aplicação. No entanto, o efeito deste parâmetro termina sempre que efetuar logout ou expirar o cookie de autenticação. Voltará a ter o mesmo efeito após nova autenticação.
Login: Mensagem de introdução
Neste parâmetro é possível configurar uma mensagem para aparecer no Login, no Topo do ecrã. pode conter uma imagem ou logotipo.
Login: Saudação de manhã
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login: Saudação de noite
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login: Saudação de tarde
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login: Template
Neste parâmetro é possível definir qual o template a utilizar para o ecrã de login.
Login: Texto para Cliente
Neste parâmetro é possível definir o texto para o título do campo do cliente no ecrã de login.
Login: Texto para nome do utilizador
Neste parâmetro é possível definir o texto para o título do campo de nome do utilizador no ecrã de login.
Login: Texto para password
Neste parâmetro é possível definir um texto para o título do campo de password no ecrã de login.
Menu Central na página principal
Este campo permite ao utilizador ter o
Menu Central
na homepage. Ou seja, se este parâmetro estiver ativo, o Menu Central substitui a
homepage
.
No ecrã de "o que há de novo" mostra os últimos registos na base de dados técnica
Define se mostra a lista de últimos registos na base de dados técnica.
No ecrã de inquéritos e workflows usa página sem caixa
Este parâmetro permite definir se na página de inquérito é usada uma caixa à volta das questões.
No ecrã de manutenção de utilizadores não mostra as opções de acesso a produtos
No ecrã usclform.aspx não mostra as opções que dão acesso a produtos na Extranet, nomeadamente Front, Suporte, Equipa e acessos via estabelecimento.
No menu tem lista de RSS
Permite ao utilizador definir se aparece no menu da aplicação, uma opção para aceder à lista de feeds de RSS.
Pé de página da caixa de Notícias
Este parâmetro permite definir o texto que aparece no pé de página da caixa de Notícias da página inicial.
Quantos itens mostra o autocomplete
Permite ao utilizador escolher quantos itens são mostrados no elemento de preenchimento automático "autocomplete", mais especificamente nos campos de procura da aplicação.
SCRIPT para HEAD de todas as páginas
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas.
SCRIPT para HEAD de todas as páginas no IE
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE.
SCRIPT para HEAD de todas as páginas no IE 9 ou superior
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE versão 9 ou superior.
SCRIPT para todas as páginas
Este parâmetro permite definir um SCRIPT em Javascript para colocar em todas as páginas antes da tag de fim de BODY. Útil para google analytics.
Tema cromático: Permite ao utilizador mudar o seu tema
Permite ao utilizador definir se o utilizador externo, no ecrã de perfil, pode mudar o seu tema cromático (visual da aplicação).
Tema cromático: Qual o tema a usar por defeito
Define o visual que é apresentado por defeito na aplicação. Poderá definir um dos seguintes temas:
Normal
Cor
Escuro
Aqua
Glaciar
Anil
Coral
Prado
Nota:
Se não tiver o parâmetro
Tema cromático: Permite ao utilizador mudar o seu tema
ativo, o tema poderá ser alterado no ecrã
Meu Perfil
.
Template do Footer
Este parâmetro serve para definir o nome do template a utilizar no Footer para os ecrãs da aplicação.
Template dos itens do NWWWLIST
(Notícias)
Este parâmetro serve para definir um template para a lista de notícias ou seja, no ecrã: NWWWLIST.
É possível utilizar os seguintes campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota: Os campos são case-sensitive.
Template para TITLE
Se preenchido é usado para substituir o "TITLE" para o browser em cada página. Pode usar os campos #SITE# e #PAGINA# para os títulos do site e da respetiva página. Caso o parâmetro "título de homepage" esteja preenchido, este não é utilizado na homepage.
Título de todas as páginas
Aqui define-se o texto que aparece no título de todas as páginas, no browser.
Usa a Procura Global
Este parâmetro permite ativar ou desativar o uso da
Procura Global
.
Usa Menu Aplicacional
O utilizador pode definir se o utilizador externo dispõe do menu aplicacional.
Usa no menu a opção de documentos partilhados
A opção de menu Documentos Partilhados apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa Objetos de ecrã
Apenas são mostrados os
Objetos de ecrã
se este parâmetro se encontrar ativo.
Usa Opções de Ecrã
Apenas são mostradas as
Opções de ecrã
se este parâmetro se encontrar ativo.
Usa Templates
Apenas são mostrados os
Templates básicos
e os
Templates de tabela
se este parâmetro se encontrar ativo.
Validade em dias da password
Para uma maior segurança no software, foi criada a possibilidade de definir a validade das passwords. Por isso, neste campo o administrador/supervisor pode definir o número de dias limite para que a password de acesso à aplicação seja obrigatoriamente alterada.
Depois de definir uma validade em dias para a password, ao fazer login, a aplicação passa a verificar o nº de dias que falta para expirar a password.
Nota:
Quando faltarem menos de 15 dias, a aplicação passa a mostrar a informação de quantos dias faltam para expirar a password no ecrã de login. Como por exemplo:
A sua password expira em 10 dia(s).
.
Quando a password expirar, depois de fazer login, a aplicação direciona o utilizador para um ecrã onde deverá obrigatoriamente
alterar a sua password
, caso não seja alterada não é possível aceder a aplicação.
Front web
O
Front Web
é um módulo da
Extranet
, mas é na
Intranet
que se efetuam as respetivas configurações. Para tal, é necessário ter a chave do
Front Web
ativa, no ficheiro
appSettings.config
da
Intranet
.
Os parâmetros que existem para configuração do
Front Web
são:
Apresenta coluna de preços ao adicionar artigos
Se este parâmetro estiver ativo permite que o utilizador possa visualizar os preços dos artigos quando os está a adicionar a uma encomenda.
Apresenta encomendas em aberto na homepage
Quando este parâmetro se encontra ativo, a aplicação mostra uma lista de encomendas em aberto na página inicial.
Dias para Data de Entrega
Este parâmetro permite definir o número de dias a somar à data da encomenda de modo a calcular a sua data de entrega.
Encomendas: Código do script de utilizador para a listagem de procura de artigos
Este parâmetro deve ser preenchido com o código presente no script e que deve incluir os campos obrigatórios:
ststamp
Ref
design
qtt (com valor 0).
Financeira - Sub-menu configurável 1 (1) - Título
Esta opção permite definir o nome que se pretende dar ao novo submenu.
Financeira - Sub-menu configurável 1 (2) - Condição SQL Where
Esta opção permite efetuar uma condição de filtro de documentos de faturação a serem visualizados.
Exemplo
: ft.ndoc=1" só mostra os documentos do tipo 1. No campo de preenchimento não permite inserir o caratere "Plica".
Na procura de artigos usa a árvore vs objeto de navegação
Ao ativar este parâmetro, o utilizador está a definir que irá usufruir do novo formato (árvore) para pesquisar os artigos, em vez de utilizar o objeto de navegação.
Nota:
Os níveis de filtros existentes nesta "árvore" dependem da ativação dos parâmetros:
-
Utiliza o campo Família na procura de artigos
;
-
Utiliza o campo
"Linha de produto"
na procura de artigos
;
-
Utiliza o campo
"Marca"
na procura de artigos
;
-
Utiliza o campo
"Modelo"
na procura de artigos
;
-
Utiliza o campo
"Tipo de produto"
na procura de artigos
Para definir os textos que se encontram entre aspas, é necessário atribuir o texto nos parâmetros da aplicação PHC CS, no nó "Stocks" (serve o exemplo para demonstrar a funcionalidade):
- "Campo de utilizador 1" = "Marca";
- "Campo de utilizador 2" = "Modelo";
- "Campo de utilizador 3" = "Linha de produto"; e
- "Campo de utilizador 4" = "Tipo de produto"
Os valores atribuídos a estes campos serão utilizados também no PHC CS Web.
Nota:
Mediante a ativação destes, ou de alguns destes parâmetros, as opções: "Marca"; "Modelo"; "Linha de produto" e "Tipo de produto" também ficarão disponíveis na caixa de lista pendente nos ecrãs de
Listagem de Artigos/Serviços
, possibilitando uma maior escolha na ordenação da listagem de artigos apresentada ao utilizador.
Nº de artigos por página na procura para encomendas
Neste parâmetro pode definir-se o número de artigos por página na procura de artigos para introdução nas encomendas.
Nº máximo de artigos na procura para encomendas
Neste local define-se um número máximo de artigos a ser disponibilizados na procura de artigos na introdução de encomendas.
Os Descontos são recalculados na gravação
Com este parâmetro ativo, os descontos da encomenda são recalculados na gravação da mesma.
Paypal: Substituição da tooltip do botão "Continuar", que surge após pagamento Via PAYPAL com sucesso.
Este parâmetro permite substituir a tooltip do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
com sucesso.
Paypal: Substituição da tooltip do botão "Continuar", que surge após pagamento Via PAYPAL sem sucesso.
Este parâmetro permite substituir a tooltip do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
sem sucesso.
Nota:
Estes parâmetros têm como valor por defeito "" (vazio) e caso esteja preenchido poderá visualizar a seguinte tooltip:
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de " + valor do parâmetro "Financeira - Sub-menu configurável 1(1) - Título"
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de faturação."
Paypal: Substituição do endereço do botão "Continuar", que surge após pagamento Via PAYPAL com sucesso.
Este parâmetro permite substituir o endereço do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
com sucesso.
Paypal: Substituição do endereço do botão "Continuar", que surge após pagamento Via PAYPAL sem sucesso.
Este parâmetro permite substituir o endereço do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
sem sucesso.
Nota:
Estes parâmetros têm como valor por defeito "" (vazio) e caso esteja preenchido será reencaminhado para a seguinte página:
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido o utilizador é reencaminhado para a listagem de documentos de faturação filtrada pela clausula Where colocada no parâmetro "Financeira - Sub-menu configurável 1(2) - Condição SQL where".
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido o utilizador é reencaminhado para a listagem de documentos de faturação."
Paypal: Substituição do texto do botão "Continuar", que surge após pagamento Via PAYPAL com sucesso.
Este parâmetro permite substituir o texto do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
com sucesso.
Paypal: Substituição do texto do botão "Continuar", que surge após pagamento Via PAYPAL sem sucesso.
Este parâmetro permite substituir o texto do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
PAYPAL
sem sucesso.
Nota:
Estes parâmetro tem como valor por defeito "" (vazio) e caso esteja preenchido visualiza o texto "Continuar" no botão.
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de " + valor do parâmetro "Financeira - Sub-menu configurável 1(1) - Título"
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de faturação."
Paypal: Texto para colocar instruções debaixo do botão de PAGAR no Ftview.aspx
Este parâmetro permite personalizar o texto que se encontra debaixo do botão pagar.
Paypal: Texto para substituir a mensagem "Falha no pagamento. Pagamento não realizado."
Este parâmetro permite personalizar o texto que passará a ser apresentado no pagamento com um erro interno.
Paypal: Texto para substituir a mensagem "Pagamento efetuado com sucesso"
Este parâmetro permite personalizar o texto que passará ser apresentado após o pagamento com sucesso.
Se na busca de artigos usa a opção ver os artigos das ultimas encomendas
Permite ao utilizador definir utiliza a opção ver os artigos das últimas encomendas aquando da procura de artigos nas encomendas.
Tem coluna de imagem no stlist
Ao ativar este parâmetro permite ter uma coluna com a imagem do artigo no "stlist" desde que a imagem esteja configurada na base de dados.
Texto para o botão "Voltar à encomenda" na procura de artigos
Este parâmetro permite alterar o texto do botão "Voltar à encomenda" existente na procura de artigos e serviços.
O texto também é utilizado para a
tooltip
do botão.
Unicre: Substituição da tooltip do botão "Continuar", que surge após pagamento Via UNICRE com sucesso.
Este parâmetro permite substituir a
tooltip
do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
com sucesso.
Unicre: Substituição da tooltip do botão "Continuar", que surge após pagamento Via UNICRE sem sucesso.
Este parâmetro permite substituir a
tooltip
do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
sem sucesso.
Nota:
Estes parâmetros têm como valor por defeito "" (vazio) e caso esteja preenchido poderá visualizar a seguinte
tooltip
:
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de " + valor do parâmetro "Financeira - Sub-menu configurável 1(1) - Título"
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de faturação."
Unicre: Substituição do endereço do botão "Continuar", que surge após pagamento Via UNICRE com sucesso.
Este parâmetro permite substituir o endereço do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
com sucesso.
Unicre: Substituição do endereço do botão "Continuar", que surge após pagamento Via UNICRE sem sucesso.
Este parâmetro permite substituir o endereço do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
sem sucesso.
Nota:
Estes parâmetros têm como valor por defeito "" (vazio) e caso esteja preenchido será reencaminhado para a seguinte página:
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido o utilizador é reencaminhado para a listagem de documentos de faturação filtrada pela clausula "Where" colocada no parâmetro "Financeira - Sub-menu configurável 1(2) - Condição SQL where".
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido o utilizador é reencaminhado para a listagem de documentos de faturação."
Unicre: Substituição do texto do botão "Continuar", que surge após pagamento Via UNICRE com sucesso.
Este parâmetro permite substituir o texto do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
com sucesso.
Unicre: Substituição do texto do botão "Continuar", que surge após pagamento Via UNICRE sem sucesso.
Este parâmetro permite substituir o texto do botão "Continuar" que surge no ecrã após o pagamento de um documento de faturação via
UNICRE
sem sucesso.
Nota:
Estes parâmetro tem como valor por defeito "" (vazio) e caso esteja preenchido visualiza o texto "Continuar" no botão.
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de " + valor do parâmetro "Financeira - Sub-menu configurável 1(1) - Título"
- Caso o parâmetro de "Financeira - Sub-menu configurável 1(1) - Título" não esteja preenchido a tooltip é apresentada da seguinte forma: "Retorna à listagem de documentos de faturação."
Unicre: Texto para colocar instruções debaixo do botão pagar no Ftview.aspx
Este parâmetro permite personalizar o texto que se encontra debaixo do botão pagar.
Unicre: Texto para substituir a mensagem de erro genérico após o pagamento via UNICRE
Este parâmetro permite personalizar o texto que passará ser apresentado após o pagamento com um erro genérico.
Unicre: Texto para substituir a mensagem "Falha no pagamento. Pagamento não realizado. Erro Interno".
Este parâmetro permite personalizar o texto que passará a ser apresentado no pagamento com um erro interno.
Unicre: Texto para substituir a mensagem "Falha no pagamento. Pagamento não realizado.Transação inválida"
.
Este parâmetro permite personalizar o texto que passará a ser apresentado no pagamento com uma transação inválida.
Unicre: Texto para substituir a mensagem "Falha no pagamento. Pagamento não realizado.Transação recusada".
Este parâmetro permite personalizar o texto que passará a ser apresentado no pagamento com uma transação recusada.
Unicre: Texto para substituir a mensagem "Pagamento efetuado com sucesso"
.
Este parâmetro permite personalizar o texto que passará ser apresentado após o pagamento com sucesso.
Usa o menu da área financeira
Quando está ativo este parâmetro apresenta na página inicial o menu "Área Financeira".
Usa o menu de outros documentos - dossiers
Quando está ativo este parâmetro apresenta na página inicial o menu de outros documentos - dossiers.
Utiliza Descontos por Quantidade ou Valor
Quando está ativo, este parâmetro permite utilizar descontos por quantidade ou valor.
Utiliza o campo Família na procura de artigos
Este parâmetro quando se encontra ativo, permite efetuar uma procura de artigos para introdução nas encomendas por exemplo, utilizando para tal o campo Família.
Utiliza o campo Linha de produto na procura de artigos
Este parâmetro quando se encontra ativo, permite efetuar uma procura de artigos utilizando para tal o campo Linha de produto.
Utiliza o campo Marca na procura de artigos
Também o campo Marca pode ser utilizado na procura de artigos. Basta para tal, ativar este parâmetro.
Utiliza o campo Modelo na procura de artigos
O campo Modelo também pode ser utilizado na pesquisa de artigos. Para tal, basta ativar este parâmetro.
Utiliza o campo Tipo de produto na procura de artigos
Com este parâmetro ativo também é possível utilizar o campo Tipo de produto na pesquisa de artigos.
Gestão web
Adiantamentos visíveis no menu central e aplicacional
Este parâmetro quando ativo permite visualizar as opções
Recibos de adiantamento
e de
Adiantamentos a fornecedores
no menu central e no menu aplicacional.
Nota:
Por defeito, este parâmetro encontra-se inativo. Por essa razão, os botões acima referidos não são apresentados.
Compras: Código do script de utilizador para a listagem de procura de artigos
Este parâmetro deve ser preenchido com o código presente no script e que deve incluir os campos obrigatórios:
ststamp
Ref
design
qtt (com valor 0).
Faturação: Código do script de utilizador para a listagem de procura de artigos
Este parâmetro deve ser preenchido com o código presente no script e que deve incluir os campos obrigatórios:
ststamp
Ref
design
qtt (com valor 0).
Na homepage aparece a procura de movimentos de produtos vendidos por referência
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Na procura de artigos usa a árvore vs objeto de navegação
Ao ativar este parâmetro, o utilizador está a definir que irá usufruir do novo formato (árvore) para pesquisar os artigos, em vez de utilizar o objeto de navegação.
Nota:
Os níveis de filtros existentes nesta "árvore" dependem da ativação dos parâmetros:
-
Utiliza o campo Família na procura de artigos
;
-
Utiliza o campo
"Linha de produto"
na procura de artigos
;
-
Utiliza o campo
"Marca"
na procura de artigos
;
-
Utiliza o campo
"Modelo"
na procura de artigos
;
-
Utiliza o campo
"Tipo de produto"
na procura de artigos
Para definir os textos que se encontram entre aspas, é necessário atribuir o texto nos parâmetros da aplicação PHC CS, no nó "Stocks" (serve o exemplo para demonstrar a funcionalidade):
- "Campo de utilizador 1" = "Marca";
- "Campo de utilizador 2" = "Modelo";
- "Campo de utilizador 3" = "Linha de produto"; e
- "Campo de utilizador 4" = "Tipo de produto"
Os valores atribuídos a estes campos serão utilizados também no PHC CS Web.
Nota:
Mediante a ativação destes, ou de alguns destes parâmetros, as opções: "Marca"; "Modelo"; "Linha de produto" e "Tipo de produto" também ficarão disponíveis na caixa de lista pendente nos ecrãs de "
Escolha de Artigos/Serviços
", possibilitando uma maior escolha na ordenação da listagem de artigos apresentada ao utilizador.
Tem coluna de imagem no stlist
Ao ativar este parâmetro permite ter uma coluna com a imagem do artigo no stlist desde que a imagem esteja configurada na base de dados.
Tem coluna de imagem no stvlist
Ao ativar este parâmetro permite ter uma coluna com a imagem do artigo no stvlist desde que a imagem esteja configurada na base de dados.
Utiliza Movimentos ou Documentos de Tesouraria
Este parâmetro permite indicar se se utilizam os
Movimentos de Tesouraria
se
Documentos de Tesouraria
.
Utiliza o campo Família na procura de artigos
Este parâmetro quando se encontra ativo, permite efetuar uma procura de artigos para introdução nas encomendas por exemplo, utilizando para tal o campo Família.
Utiliza o campo Linha de produto na procura de artigos
Este parâmetro quando se encontra ativo, permite efetuar uma procura de artigos utilizando para tal o campo Linha de produto.
Utiliza o campo Marca na procura de artigos
Também o campo Marca pode ser utilizado na procura de artigos. Basta para tal, ativar este parâmetro.
Utiliza o campo Modelo na procura de artigos
O campo Modelo também pode ser utilizado na pesquisa de artigos. Para tal, basta ativar este parâmetro.
Utiliza o campo Tipo de produto na procura de artigos
Com este parâmetro ativo também é possível utilizar o campo Tipo de produto na pesquisa de artigos.
Intranet
Blogues: mensagem de boas vindas
Mensagem a dar na página de listagem de blogues BLOGMON para dar as boas vindas e instruções aos utilizadores.
Dossiers: Código do script de utilizador para a listagem de procura de artigos
Este parâmetro deve ser preenchido com o código presente no script e que deve incluir os campos obrigatórios:
ststamp
Ref
design
qtt (com valor 0).
Executa eventos em Objetos Internos de grelhas de documentos
Executa eventos em objetos internos de grelhas em Dossiers Internos e Documentos de Faturação. No entanto, se o parâmetro estiver inativo, a aplicação não executa os eventos
FTAposAlterarValorEmLinha
e
BoAposAlterarValorEmLinha
destinados às grelhas e/ou eventuais objetos internos dedicados às grelhas dos ecrãs de Dossiers Internos e Documentos de Faturação, tornando a aplicação mais rápida, uma vez que deixa de executar o "PostBack" nesses campos.
Header: Imagem/logotipo do cabeçalho
Neste local deve ser indicado o Path (caminho) relativo ou completo, para a imagem a colocar no cabeçalho como por exemplo, o logotipo.
Por exemplo
: ../pimages/demologomaisritmoh.gif
Header: Template do Header
Deve ser utilizado para indicar qual o Template a utilizar para o Header (cabeçalho) dos ecrãs.
Header: Texto para cabeçalho
Neste parâmetro permite ao utilizador colocar texto em Html para colocar no cabeçalho. Se estiver preenchido, este parâmetro tem precedência sobre o parâmetro: "Header: Imagem/logotipo do cabeçalho".
Homepage: Altura máxima da caixa de notícias
Neste parâmetro deve-se definir a altura máxima que a caixa onde aparecem as notícias terá, medida em pixels. Se o utilizador colocar zero ocupará o espaço necessário para apresentar as últimas 10 notícias.
Homepage: Mensagem de Homepage
É possível configurar uma mensagem para aparecer na Homepage, o conteúdo da mensagem aparece em cima, centrada na página inicial.
Homepage: Na homepage apresenta os apontamentos
Neste local define-se se os apontamentos são apresentados na homepage.
Homepage: Número de colunas
Neste parâmetro é possível configurar 2 ou 3 colunas. Ao selecionar, para passar a 2 colunas, a informação que consta na coluna 2 passa a estar visível na coluna 3.
Homepage: Pé de página da caixa de Notícias
Este parâmetro permite definir o texto que aparece no pé de página da caixa de Notícias da página inicial.
Homepage: Posição das Notícias na Homepage
Este parâmetro serve para definir a posição das notícias, por defeito assume Centro mas pode ser Esquerda, Centro e Direita.
Homepage: TAGs para Homepage
Neste parâmetro definem-se as
TAGs para colocar no HEAD da página
. Deve conter todos os dados HTML.
Homepage: Template dos itens do #NOTICIAS#
Neste parâmetro o utilizador pode personalizar um template dos itens de notícias, quando são apresentadas na homepage (objeto #NOTICIAS# em HTML puro).
Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Template dos itens do #NOTICIASSOTEMPLATE#
Neste parâmetro o utilizador pode construir um template dedicado ao #NOTICIASSOTEMPLATE# em HTML puro. Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Título da caixa de Notícias
O texto que o utilizador definir neste parâmetro, será apresentado na homepage, como título da caixa onde são apresentadas as notícias.
Homepage: Título da homepage
O texto que o utilizador definir neste parâmetro aparecerá no título da homepage. Se não estiver preenchido utiliza o título de todas as páginas.
Homepage: Usa destaques com favoritos, páginas recentes, etc. no topo
Este parâmetro permite ao utilizador colocar um objeto de destaque nos Favoritos; Páginas recentes, etc. da aplicação PHC CS Web.
Homepage: Usa imagem de topo com horário
Este parâmetro permite ao utilizador colocar a imagem da aplicação PHC CS Web que contém o relógio e eventualmente a próxima ação do utilizador (por exemplo, uma marcação, etc).
Imagem de fundo
Neste parâmetro deve ser introduzido o caminho (path) relativo ou completo para a imagem a colocar no fundo de todas as páginas.
Login: Instruções
Neste parâmetro é possível definir a mensagem para aparecer no fundo do login, como por exemplo, instruções.
Login: Mantém o utilizador logado
Este parâmetro, quando ativo, permite que não seja necessário que o utilizador digitar as suas credenciais para entrar na aplicação, se utilizar sempre o mesmo dispositivo. Ou seja, caso o utilizador, após a primeira autenticação aceda à aplicação sempre com o mesmo dispositivo, não necessita de digitar ciclicamente a password para aceder à aplicação. No entanto, o efeito deste parâmetro termina sempre que efetuar logout ou expirar o cookie de autenticação. Voltará a ter o mesmo efeito após nova autenticação.
Login: Mensagem de introdução
Neste parâmetro é possível configurar uma mensagem para aparecer no Login, no Topo do ecrã. pode conter uma imagem ou logotipo.
Login:Saudação de manhã
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login:Saudação de noite
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login:Saudação de tarde
Neste parâmetro é possível configurar uma mensagem para aparecer no topo do login. É possível colocar o campo hora (#hora#) para ser substituído pela hora do momento.
Login:Template
Neste parâmetro é possível definir qual o template a utilizar para o ecrã de login.
Login: Texto para nome do utilizador
Neste parâmetro é possível definir o texto para o título do campo de nome do utilizador no ecrã de login.
Login: Texto para password
Neste parâmetro é possível definir um texto para o título do campo de password no ecrã de login.
Menu Central na página principal
Este campo permite ao utilizador ter o
Menu Central
na homepage. Ou seja, se este parâmetro estiver ativo, o Menu Central substitui a
homepage
.
Na homepage aparecem as marcações
Se este parâmetro for ativo, as marcações serão mostradas ao utilizador na homepage da aplicação.
No ecrã de inquéritos e workflows usa página sem caixa
Este parâmetro permite definir se na página de inquérito é usada uma caixa à volta das questões.
Proteger dados com session storage
Ao ativar este parâmetro, caso o utilizador perca a ligação por exemplo, por fim de sessão ou mudança de url, o sistema guarda os dados em session storage. Estes dados ficam guardados até gravar, cancelar o registo ou sair da respetiva página de internet (separador do browser).
Quantos itens mostra o autocomplete
Permite ao utilizador escolher quantos itens são mostrados no elemento de preenchimento automático "autocomplete", mais especificamente nos campos de procura da aplicação.
RUC: Executa função nativa da aplicação na validação do RUC
(Apenas disponível no executável do Peru)
Esta opção permite indicar se executa a função por defeito da aplicação na validação do RUC, depois de aplicar a função em VB.Net do usuário.
RUC: Função em VB.NET para validar o RUC
(Apenas disponível no executável do Peru)
Este parâmetro permite indicar a função em VB.NET que será executada sempre que o RUC se valida. A função recebe como parâmetro a variável mstamp que, em este caso, esta completa com o RUC: Tem que devolver True ou False.
Exemplo:
if mstamp.lenght<&gt9 then
return False
else
return True
end if
SCRIPT para HEAD de todas as páginas
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas.
SCRIPT para HEAD de todas as páginas no IE
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE.
SCRIPT para HEAD de todas as páginas no IE 9 ou superior
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE versão 9 ou superior.
SCRIPT para todas as páginas
Este parâmetro permite definir um SCRIPT em Javascript para colocar em todas as páginas antes da tag de fim de BODY. Útil para google analytics.
Tema cromático: Qual o tema a usar por defeito
Define o visual que é apresentado por defeito na aplicação. Poderá definir um dos seguintes temas:
Normal
Cor
Escuro
Aqua
Glaciar
Anil
Coral
Prado
Nota:
Se não tiver o parâmetro
Tema cromático: Permite ao utilizador mudar o seu tema
ativo, o tema poderá ser alterado no ecrã
Meu Perfil
.
Template do Footer
Este parâmetro serve para definir o nome do
template
a utilizar no
Footer
da aplicação.
Template dos itens do NWWWLIST
Este parâmetro serve para definir um template para a lista de notícias do ecrã "NWWWLIST". É possível utilizar os seguintes campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Template para TITLE
Se preenchido é usado para substituir o "TITLE" para o browser em cada página. Pode usar os campos #SITE# e #PAGINA# para os títulos do site e da respetiva página. Caso o parâmetro "título de homepage" esteja preenchido, este não é utilizado na homepage.
Título de todas as páginas
Aqui define-se o texto que aparece no título de todas as páginas, no browser.
Usa a Procura Global
Este parâmetro permite ativar ou desativar o uso da
Procura Global
.
Usa assinaturas
A ativação deste parâmetro possibilita ao utilizador o uso de
assinaturas
em diversas ações, consoante a configuração deste objeto. Este parâmetro apenas está disponível se tiver a gama Advanced ou Enterprise.
Usa favoritos
Se este parâmetro estiver ativo o utilizador usufrui do atalho de Favoritos na
Página Inicial
.
Usa menu aplicacional
Neste parâmetro o utilizador define se a aplicação usa o menu aplicacional.
Usa no menu a opção de documentos partilhados
A opção de menu "Documentos Partilhados" apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa Objetos de ecrã
Apenas são mostrados os
Objetos de ecrã
se este parâmetro se encontrar ativo.
Usa Opções de Ecrã
Apenas são mostradas as
Opções de ecrã
se este parâmetro se encontrar ativo.
Usa Templates
Apenas são mostrados os
Templates básicos
e os
Templates de tabela
se este parâmetro se encontrar ativo.
Valida acessos a campos
Esta opção permite validar os grupos de acessos externos criados no software
PHC CS Supervisor web
.
Para poder retirar os acessos ao campos configurados no grupo de acesso externo criado, terá que ativar esta opção. Pois tendo o grupo de acesso criado no PHC CS e não tendo esta opção ativa a funcionalidade do grupo de acesso não é valida.
Validade em dias da password
Para uma maior segurança no software, foi criada a possibilidade de definir a validade das passwords. Por isso, neste campo o administrador/supervisor pode definir o número de dias limite para que a password de acesso à aplicação seja obrigatoriamente alterada.
Depois de definir uma validade em dias para a password, ao fazer login, a aplicação passa a verificar o nº de dias que falta para expirar a password.
Nota:
Quando faltarem menos de 15 dias, a aplicação passa a mostrar a informação de quantos dias faltam para expirar a password no ecrã de login. Como por exemplo:
A sua password expira em 10 dia(s).
.
Quando a password expirar, depois de fazer login, a aplicação direciona o utilizador para um ecrã onde deverá obrigatoriamente
alterar a sua password
, caso não seja alterada não é possível aceder a aplicação.
Loja
Artigos disponíveis para a loja web
Este parâmetro permite indicar quais os artigos que estão visíveis na loja e disponíveis para a criação das categorias. Deverá ser colocado uma query em SQL que é usado na condição
where
, por exemplo,
st.vaiwww=1
. Caso o campo esteja em branco são considerados todos os artigos existentes na tabela de stocks e serviços.
Campo da tabela de stocks que indica que não calcula custos extra
Este parâmetro permite configurar qual o campo da tabela de stock e serviços que indica que o artigo não tem custos extra. Poderá ser usado um campo de utilizador, e tem de ser do tipo Lógico (verdadeiro/falso).
Campo para a forma de pagamento
Este parâmetro permite indicar qual o campo da tabela do dossier interno, onde irá fica registado o modo de pagamento. Poderá ser usado um campo de utilizador.
Campo para o modo de entrega
Este parâmetro permite indicar qual o campo da tabela do dossier interno, onde irá fica registado o modo de entrega. Poderá ser usado um campo de utilizador.
Campos a efetuar a pesquisa
Este parâmetro permite definir quais os campos, da tabela de stock e serviços (ST), sobre os quais se irá efetuar a pesquisa.
Código a usar quando é concluído com sucesso
Este parâmetro permite indicar o código da página de internet que é usado quando o pedido da encomenda é realizado com sucesso.
Código a usar quando não é concluído com sucesso
Esta opção permite indicar o código da página de internet que é usado quando o pedido da encomenda é realizado sem sucesso.
Código da tabela de preços
Este parâmetro permite definir o código da tabela de preços que irá ser utilizada na loja.
CSS de utilizador para loja
Este parâmetro permite definir o CSS de utilizador a ser utilizado na Loja.
CSS para Loja
Este parâmetro permite definir o CSS a ser utilizado na Loja. Este parâmetro é utilizado pelo assistente de configuração quando se seleciona um tema e altera os estilos. Se for necessário adicionar funcionalidades devem ser efetuadas no parâmetro CSS de Utilizador.
Definição do Título de Ordenação dos Filtros
Este parâmetro permite configurar os títulos para a ordenação dos artigos.
Definição do Título dos Filtros
Este parâmetro permite configurar os títulos a serem utilizados para filtrar os artigos.
Definição dos Campos de Ordenação dos Filtros
Este parâmetro permite indicar quais os campos da tabela de stock e serviços (ST) a serem utilizados para a ordenação dos artigos.
Definição dos Campos dos Filtros
Este parâmetro permite indicar quais os campos, da tabela de stock e serviços (ST) a serem utilizados para filtrar os artigos.
Formas de pagamento
Este parâmetro permite configurar as várias formas de pagamento a utilizar na loja. As formas de pagamento são separador por vírgula.
Formatação campos data
Este parâmetro permite configurar qual a formatação a ser usada para os campos do tipo data da loja. Como por exemplo, yyyy/MM/dd.
Javascript para Loja
Este parâmetro permite indicar o código javascript a ser utilizado pela loja.
Mensagem de pesquisa do texto introduzido
Este parâmetro permite definir qual o texto que foi efetuado na pesquisa da loja. Para que apresente o texto pesquisado deverá conter {0} no local onde se pretende que seja apresentado o texto pela qual foi feita a pesquisa. Como por exemplo, "Efetuou a pesquisa por '{0}' ".
Mensagem de procura com registos
Este parâmetro permite definir qual o texto a apresentar quando são retornados resultados na pesquisa da loja. Para que apresente o número de registos retornados deverá conter {0} no local onde se pretende que seja apresentado. Como por exemplo, "Foram retornados {0} registos da pesquisa".
Mensagem de procura sem registos
Este parâmetro permite definir qual o texto a apresentar quando não são retornados resultados na pesquisa da loja.
Mensagem na listagem de encomendas sem registos
Este parâmetro permite definir a mensagem que é retornada quando não existem registos de encomendas efetuadas.
Mensagem na listagem faturas sem registos
Este parâmetro permite definir a mensagem que é retornada quando não existem registos de faturas processadas.
Mensagem para insucesso na aplicação do desconto
Este parâmetro permite definir a mensagem que é retornada quando a aplicação do código promocional foi efetuada sem sucesso.
Mensagem para sucesso na aplicação do desconto
Este parâmetro permite definir a mensagem que é retornada quando a aplicação do código promocional foi efetuada com sucesso.
Modo de entrega
Este parâmetro permite configurar os vários modos de entrega a utilizar na loja. Os modos de entrega devem ser separados por vírgula. Caso se pretenda usar os custos extra este campo deverá estar em branco.
Nº de casas decimais nas quantidades (0 a 3)
Este parâmetro permite definir o número de casas decimais a apresentar no carrinho. O número deverá ser um valor inteiro entre 0 e 3.
Preço cortado
Este parâmetro permite indicar qual o preço cortado a ser usado na loja. Este valor é um dos cinco disponíveis da tabela de stocks e serviços. O valor deverá ser um valor inteiro compreendido entre 1 e 5.
Preço de venda do artigo
Este parâmetro permite indicar qual o preço de venda a ser usado na loja. Este valor é um dos cinco disponíveis da tabela stocks e serviços. O valor deverá ser um valor inteiro compreendido entre 1 e 5.
Tabela para utilizadores da loja
Este parâmetro permite selecionar qual a tabela que irá guardar os dados dos utilizadores que se registam na loja web. Pode-se selecionar entre a tabela Clientes ou Entidades.
Tem coluna de imagem na Escolha de Artigos/Serviços (STVLIST)
Este parâmetro quando ativo permite indicar se apresenta a coluna de lotes na procura de artigos. Este parâmetro deve estar desativo quando efetuar pesquisas que retornam muitos artigos/lotes e possam ter um tempo elevado de resposta. O parâmetro apenas está disponível na gama Enterprise ou, com outra gama e simultaneamente com o módulo PHC CS Lotes intranet web.
Template para a listagem de encomendas
Este parâmetro permite indicar o código do template para a listagem de encomendas efetuadas.
Template para a listagem de fatura
Este parâmetro permite indicar o código do template para a listagem de faturas processadas.
Template para aplicar promoção
Este parâmetro permite indicar o código do template para o objeto da aplicação do código promocional que irá aparecer na página do checkout.
Template para artigo em grelha
Este parâmetro permite indicar o código do template para a página da listagem de artigos com vista em grelha.
Template para artigo em grelha na procura
Este parâmetro permite indicar o código do template para a visualização dos artigos em grelha na página de pesquisa.
Template para artigo em listagem
Este parâmetro permite indicar o código do template para a página da listagem de artigos com vista em lista.
Template para artigo em listagem na procura
Este parâmetro permite indicar o código do template para a visualização dos artigos em lista na página de pesquisa.
Template para cabeçalho de categoria
Este parâmetro permite indicar o código do template para o cabeçalho da categoria.
Template para cabeçalho na procura
Este parâmetro permite indicar o código do template para o cabeçalho da página de pesquisa.
Template para carrinho
Este parâmetro permite indicar o código do template para o objeto do carrinho.
Template para item de categoria
Este parâmetro permite indicar o código do template para o item da categoria.
Template para item de destaque
Este parâmetro permite indicar o código do template para o item da categoria que poderá estar em destaque na página principal.
Template para linha de carrinho
Este parâmetro permite indicar o código do template para a linha do carrinho.
Template para página de carrinho
Este parâmetro permite indicar o código do template para a página do carrinho.
Template para página de checkout
Este parâmetro permite indicar o código do template para a página do checkout.
Texto dos artigos retornados
Este parâmetro permite definir o texto do título que aparece quando são retornados artigos na pesquisa.
Texto na listagem de categorias da pesquisa
Este parâmetro permite definir o texto do título que aparece quando são retornadas categorias na pesquisa.
Texto no input de pesquisa
Este parâmetro permite definir o texto do título que aparece quando são retornadas categorias na pesquisa.
Texto para a saudação ao utilizador
Este parâmetro permite configurar o texto da saudação ao utilizador após este se autenticar na loja.
Texto para botão de aplicar promoção
Este parâmetro permite configurar o texto do botão que se clica para aplicar uma promoção.
Texto para formatação de valores em moeda
Este parâmetro permite configurar a formatação dos valores que tenham moeda, por exemplo,
€ #,##0.00
.
Texto para o botão de confirmar o pedido
Este parâmetro permite configurar o texto que aparece no botão quando se pretende confirmar a encomenda na página do checkout.
Texto para o botão de finalizar o pedido
Este parâmetro permite configurar o texto que aparece no botão quando se pretende finalizar a compra, na página do carrinho, ou seja, quando se clica no carrinho de compras.
Texto para o botão do carrinho
Este parâmetro permite configurar o texto que aparece no botão do carrinho quando se adiciona um artigo.
Texto para opção de login
Este parâmetro permite configurar o texto que aparece para chamar o ecrã de autenticação na loja.
Texto para página em construção
Este campo permite definir o texto a apresentar quando não existe um template definido para uma página.
Texto para placeholder do campo de introdução de código promocional
Este parâmetro permite configurar o texto que aparece na caixa de texto onde se irá colocar o código promocional.
Tipo de documento para dossier de entidade
Este parâmetro permite indicar qual o numero interno do dossier de encomendas associado à tabela de entidades.
Tipo de documento para encomenda de cliente
Este parâmetro permite indicar qual o número interno do dossier de encomendas associado à tabela de clientes.
Tooltip do botão de pesquisa
Este parâmetro permite configurar o texto de ajuda do botão onde se clica para efetuar a pesquisa.
Tooltip para o botão de logoff
Este parâmetro permite configurar o texto de ajuda do botão onde se efetua o encerrar da sessão.
Versão
Este parâmetro indica a versão da loja web.
Colaborador web
Na homepage aparece a procura de outros rendimentos por número
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Na homepage aparece a procura de recibo de vencimento por número
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Na homepage aparece a procura recibos diversos por número
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
Portal Web
É na Intranet que se efetuam as configurações relativas ao Portal. Para tal, é necessário ter a chave do
Portal
ativa, no ficheiro
appSettings.config
da
Intranet
.
Header: Imagem/logotipo do cabeçalho
Neste local deve ser indicado o Path (caminho) relativo ou completo, para a imagem a colocar no cabeçalho como por exemplo, o logotipo.
Por exemplo
: ../pimages/demologomaisritmoh.gif
Header: Texto para cabeçalho
Neste parâmetro permite ao utilizador colocar texto em Html para colocar no cabeçalho. Se estiver preenchido não será usado o parâmetro de imagem/logotipo de cabeçalho.
Homepage: Altura máxima da caixa de notícias
Neste parâmetro deve-se definir a altura máxima que a caixa onde aparecem as notícias terá, medida em pixels. Se o utilizador colocar zero ocupará o espaço necessário para apresentar as últimas 10 notícias.
Homepage: Mensagem de Homepage
É possível configurar uma mensagem para aparecer na Homepage, o conteúdo da mensagem aparece em cima, centrada na página inicial.
Homepage: Noticias têm link com URL amigável
Neste parâmetro define-se se o link para a página de noticias utiliza sempre o URL amigável. Exige que o campo "código" de cada notícia esteja sempre preenchido nas notícias.
Homepage: Número de colunas
Neste parâmetro é possível configurar 2 ou 3 colunas. Ao selecionar, para passar a 2 colunas, a informação que consta na coluna 2 passa a estar visível na coluna 3.
Homepage: Pé de página da caixa de Notícias
Este parâmetro permite definir o texto que aparece no pé de página da caixa de Notícias da página inicial.
Homepage: Posição das notícias na Homepage
Este parâmetro serve para definir a posição das notícias, por defeito assume "centro" mas pode ser "esquerda", "centro" e "direita".
Homepage: TAGs para Homepage
Neste parâmetro definem-se as TAGs para colocar no HEAD da página. Deve conter todos os dados
HTML
.
Homepage: Template da Homepage
Neste local define-se qual o
template
a utilizar para a página inicial.
Homepage: Template dos itens do #NOTICIAS#
Neste parâmetro o utilizador pode personalizar um template dos itens de notícias, quando são apresentadas na homepage (objeto #NOTICIAS# em HTML puro).
Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Template dos itens do #NOTICIASSOTEMPLATE#
Neste parâmetro o utilizador pode construir um template dedicado ao #NOTICIASSOTEMPLATE# em HTML puro. Na construção deste template, poderá utilizar os campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota
: Os campos são case-sensitive.
Homepage: Título da caixa de Notícias
O texto definido neste campo aparecerá como título na caixa de notícias da página inicial.
Homepage: Título da homepage
O texto que o utilizador definir neste parâmetro aparecerá no título da homepage. Se não estiver preenchido utiliza o título de todas as páginas.
Homepage: Usa footer na homepage com template
Neste parâmetro é possível definir se utiliza na homepage o footer (rodapé) de template genérico quando a homepage é constituída por um template.
Homepage: Usa header na homepage com template
Neste parâmetro é possível definir se utiliza na homepage o header (cabeçalho) de template genérico quando a homepage é constituída por um template.
Imagem de fundo
Parâmetro que permite definir o Path relativo ou completo para a imagem a colocar no fundo (body), por exemplo:
.../pimages/fundo.jpg
.
Login: Template
Neste parâmetro é possível definir qual o template a utilizar para o ecrã de login.
Login: Texto para o id do utilizador(E-mail)
Esta opção permite ao utilizador, configurar o texto que está visível no ecrã de login para identificar o campo de email.
Login: Texto para password
Neste parâmetro é possível definir um texto para o título do campo de password no ecrã de login.
No ecrã de busca usa página sem caixa
Permite ao utilizador definir se utiliza na página de busca "searchlist.aspx" uma caixa à volta da procura.
No ecrã de inquéritos e workflows usa página sem caixa
Este parâmetro permite definir se na página de inquérito é usada uma caixa à volta das questões.
Procura: Tem a procura no menu global
Este campo permite definir se na aplicação existe uma caixa para efetuar procuras, no menu global do Portal.
Título da procura no menu global
Neste parâmetro deve definir-se o título para a caixa de procura do menu global.
SCRIPT para HEAD de todas as páginas
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas.
SCRIPT para HEAD de todas as páginas no IE
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE.
SCRIPT para HEAD de todas as páginas no IE 9 ou superior
Permite ao utilizador construir um SCRIPT em Javascript para colocar no HEAD de todas as páginas se o browser for o IE versão 9 ou superior.
SCRIPT para todas as páginas
este parâmetro permite definir um
script
em
Javascript
para colocar em todas as páginas antes da tag de fim de "body". Útil para
google analytics
.
Template do Footer
Este parâmetro serve para definir o nome do template a utilizar no
Footer
da aplicação.
Template do Header
Este parâmetro serve para definir o nome do template a utilizar no
Header
da aplicação.
Template dos itens do NWWWLIST
(Notícias)
Este parâmetro serve para definir um template para a lista de notícias ou seja, no ecrã: NWWWLIST.
É possível utilizar os seguintes campos: #RESUMO#; #CATEGORIA#; #STAMP#; #HEADLINE#; #DATA#; #LINK# e #ICON#.
Nota: Os campos são case-sensitive
Template dos itens do SEARCHLIST
(Notícias)
Este parâmetro serve para definir um template para os itens do SEARCHLIST, em HTML puro.
É possível utilizar os seguintes campos: #TITULO#; #DESCRICAO#; #STAMP#; #TIPO# e #LINK#.
Nota: Os campos são case-sensitive
Template para TITLE
Se preenchido é usado para substituir o "TITLE" para o browser em cada página. Pode usar os campos #SITE# e #PAGINA# para os títulos do site e da respetiva página. Caso o parâmetro "título de homepage" esteja preenchido, este não é utilizado na homepage.
Título de todas as páginas
Aqui define-se o texto que aparece no título de todas as páginas, no browser.
Usa Menu Aplicacional
Com este parâmetro ativo, o
Portal
vai utilizar o menu lateral com opções definidas pelo utilizador.
Usa Menu Global
Com este parâmetro ativo, o
Portal
vai utilizar o menu global com opções definidas pelo utilizador.
Usa Objetos de ecrã
Apenas são mostrados os
Objetos de ecrã
se este parâmetro se encontrar ativo.
Usa Opções de Ecrã
Apenas são mostradas as
Opções de ecrã
se este parâmetro se encontrar ativo.
Usa Templates
Apenas são mostrados os
Templates básicos
e os
Templates de tabela
se este parâmetro se encontrar ativo.
Valida acessos a campos
Esta opção permite validar os grupos de acessos externos criados no
Supervisor
do
PHC CS Desktop
.
Para poder retirar os acessos ao campos configurados no grupo de acesso externo criado, terá que ativar esta opção. Pois tendo o grupo de acesso criado no
PHC CS Desktop
e não tendo esta opção ativa a funcionalidade do grupo de acesso não é valida.
Suporte extranet web
Anúncios - recentes aparecem na homepage
Os Anúncios são uma opção que apenas pode ser utilizada no Suporte extranet web se o utilizador possuir também o Suporte intranet web, módulo onde é configurada. Se este parâmetro se encontrar ativo, na homepage aparece uma caixa com os registos recentes dos anúncios criados ou alterados (últimos 15 dias).
Anúncios - TOP 10 aparecem na homepage
Os Anúncios são uma opção que apenas pode ser utilizada no Suporte Extranet web se o utilizador possuir também o Suporte intranet web, módulo onde é configurada.
Se este parâmetro se encontrar ativo na homepage aparece uma caixa com o TOP 10 dos anúncios mais vistos na homepage.
Classificação de PATs: Opções de resposta
Neste local devem digitar-se as várias opções de resposta à questão definida no parâmetro
Texto para pergunta sobre classificação de PAT's
que se pretende ter, separadas por vírgula.
Classificação de PATs: Texto para botão de gravar
Neste local deve escrever-se o texto que se pretende ver no botão de gravar a classificação de PAT´s pelo cliente.
Classificação de PATs: Texto para pergunta
Neste local o utilizador deve definir o texto da pergunta a colocar ao cliente para classificar o PAT.
Classificação de PAT: Usa classificação do cliente
Ao ativar este parâmetro a aplicação passa a
perguntar nos PAT's
a classificação do cliente para a
resposta do PAT
. Esta classificação permite que a empresa guarde uma opinião do cliente relativa ao Pedido de Assistência que este consultou no momento da classificação.
Comunidade: Botão inserção de código nas respostas
Permite ao utilizador definir se aparece o botão para inserção de código nas respostas.
Comunidade: Ecrã de Fóruns - Tem TOP de utilizadores com mais "Gostos"
Permite ao utilizador definir se quer que no ecrã de Fóruns seja apresentado uma listagem com o TOP de utilizadores com mais "Gostos".
Comunidade: Ecrã de Fóruns - Tem TOP de utilizadores com mais "Soluções"
Permite ao utilizador definir se quer que no ecrã de Fóruns seja apresentado uma listagem com o TOP de utilizadores com mais "Soluções".
Comunidade: Ecrã de Fóruns - Tem TOP de utilizadores com mais mensagens
Permite ao utilizador definir se quer que no ecrã de Fóruns seja apresentado uma listagem com o TOP de utilizadores com mais mensagens.
Comunidade : Emails de administradores
Permite definir uma Lista de emails, separados por ponto e virgula, dos administradores a quem será enviado um email em TODAS as operações realizadas na comunidade.
Por exemplo
: admin.A@maisritmo.com; admin.B@maisritmo.com; admin.C@maisritmo.com.
Comunidade : Emails para notificações
Permite definir uma Lista de emails, separados por ponto e virgula, a quem será enviado um email aquando da introdução de TODOS os tópicos e mensagens na comunidade.
Por exemplo
: dep.comercial@maisritmo.com; dep.logistica@maisritmo.com; dep.financeiro@maisritmo.com.
Comunidade : Na homepage aparecem os novos Tópicos na área de notícias
Permite ao utilizador definir se os novos Tópicos dos Fóruns são apresentados na área de notícias da homepage.
Comunidade : Texto para Bem-vindo à Comunidade
Com o preenchimento deste parâmetro, o utilizador poderá personalizar um texto que será apresentado na página inicial da comunidade com os Fóruns disponíveis.
Por exemplo
:
Bem vindo à Comunidade MaisRitmo.
Por favor escolha o fórum em que deseja participar e participe.
Ajude e seja ajudado.
Há sempre alguém disponível para o ajudar.
Comunidade : Texto para colocar no fim da introdução de tópico
Através do preenchimento deste parâmetro, o utilizador poderá personalizar um texto que aparece ao utilizador no momento da introdução de um tópico.
Por exemplo
: Se uma resposta resolver a sua questão, por favor clique na opção "É a solução" e dê-lhe um "Gosto!" para que esta informação possa beneficiar outros utilizadores.
Comunidade : Texto para colocar no topo da introdução de mensagem
Com o preenchimento deste parâmetro, o utilizador poderá personalizar um texto que aparece ao utilizador no momento da introdução de uma mensagem.
Comunidade : Texto para colocar no topo da introdução de um tópico
Com o preenchimento deste parâmetro, o utilizador poderá personalizar um texto que aparece ao utilizador no momento da introdução de um tópico.
Comunidade : Texto para Comunidade
Através deste parâmetro o utilizador pode personalizar a palavra que habitualmente é definida como: "Comunidade".
Comunidade: Texto para Fórum
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Fórum".
Comunidade: Texto para Fóruns
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Fóruns".
Comunidade: Texto para Novo Tópico
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Novo Tópico".
Comunidade: Texto para os tópicos fechados
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Tópicos fechados".
Comunidade: Texto para Tópico
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Tópico".
Comunidade: Texto para Tópicos
O texto contido neste parâmetro será utilizado para personalizar a palavra que habitualmente é definida como: "Tópicos".
Comunidade: Tipo de utilizador por defeito
O texto contido neste parâmetro será utilizado por defeito para o campo de "tipo de utilizador" na comunidade.
Por exemplo
: Membro
Comunidade: Título do novo tópico para ser usado na área noticias da homepage
Defina o título do novo tópico para ser apresentado nas notícias da homepage.
Por exemplo
: Novo Tópico na Comunidade
Comunidade: Top de tópicos mais vistos na homepage
Permite ao utilizador definir se quer que seja apresentada na homepage o TOP de Tópicos mais vistos.
Comunidade: Usa a opção de cliente moderador
Permite ao cliente introduzir tópicos reservados, destinados apenas ao moderador.
Nota
: Esta opção é configurável nas opções diversas da ficha do cliente, no "Utilizadores deste cliente - PHC CS Web".
Comunidade: Usa datas com a idade do tópico e mensagem
Caso o utilizador ative este parâmetro, em diversos locais, passará a aparecer a idade do tópico e da mensagem.
Nota
: Em sistemas com pouca frequência pode ser melhor este parâmetro estar inativo.
Comunidade: nº de dias para cálculo dos TOPs da página de fóruns
Permite definir o número de dias para o cálculo dos TOPs que aparecem no ecrã de Fóruns.
Conteúdos multimédia: nome no plural
Nome que o utilizador entender dar à opção designada por defeito de "Conteúdos multimédia".
Conteúdos multimédia: nome no singular
Nome que o utilizador entender dar à opção designada por defeito de "Conteúdo multimédia".
Conteúdos multimédia: subtítulo para lista
Neste parâmetro o utilizador poderá definir o texto para ser utilizado no subtítulo do ecrã de galeria multimédia.
Conteúdos multimédia: texto para lista
Neste parâmetro o utilizador poderá definir o nome para ser utilizado onde aparece "Lista de conteúdos Multimédia".
Documentos: instruções para o upload de ficheiros
Neste parâmetros o utilizador pode personalizar o texto a mostrar ao cliente, quando o mesmo pretenda efetuar um upload de um ficheiro.
Documentos: UpLoad de ficheiros dos PATs para a tabela Anexos
Permite ao utilizador definir se o Upload dos ficheiros é efetuado diretamente para a tabela de Anexos.
Equipamento visível
Com esta opção ativa os campos relativos ao equipamento são visíveis ao utilizador nos ecrãs e menus da aplicação Suporte Extranet web.
Homepage: Apresenta PAT's em aberto
Quando este parâmetro está ativo a aplicação mostra uma lista de PATs do cliente, em aberto, na página inicial.
Homepage: Apresenta últimos PAT's públicos na homepage
Quando ativo, este parâmetro permite que a aplicação mostre uma lista de PATs públicos na página inicial.
Homepage: Nº de PAT's Públicos
Este parâmetro (cujo valor por defeito é 10) serve para definir o número de pedidos de assistência visíveis na homepage.
É de salientar que um Pat público para aparecer na homepage do Suporte Extranet web tem de estar encerrado.
Multimédia - recentes aparecem na homepage
Os Conteúdos Multimédia são uma opção que apenas pode ser utilizada no Suporte extranet web se o utilizador possuir também o Suporte intranet web, módulo onde é configurada.
Se este parâmetro se encontrar ativo, na homepage aparece uma caixa com os registos de multimédia mais recentes (últimos 15 dias).
Multimédia - TOP 10 aparecem na homepage
Os Conteúdos Multimédia são uma opção que apenas pode ser utilizada no Suporte extranet web se o utilizador possuir também o Suporte intranet web, módulo onde é configurada.
Se este parâmetro se encontrar ativo na homepage aparece uma caixa com o TOP 10 de multimédia mais vista na homepage.
Multimédia - TOP 10 aparecem na homepage no centro
Os Conteúdos Multimédia são uma opção que apenas pode ser utilizada no Suporte extranet web se o utilizador possuir também o Suporte intranet web, módulo onde é configurada.
Se este parâmetro se encontrar ativo na homepage aparece uma caixa com o TOP 10 de multimédia mais vista na área central da homepage.
PATs: Lista de Tipo de Pedido
Permite ao utilizador, de forma personalizada, definir a lista de tipos de problemas nos Pedidos de Assistência.
Nota
: Os diferentes tipos indicados, devem ser separados por vírgula como por exemplo, Dúvida; Anomalia; Sugestão; Pedido de Orçamento
PATs: Tempo máximo após fecho que permite reabrir um PAT em dias
Neste parâmetro deve colocar o valor em dias para o tempo máximo após o fecho de um PAT, depois será possível reabrir o mesmo. Se o tempo definido for igual a zero não é efetuado nenhum controlo.
Perguntas Frequentes : Nome no plural
Nome que o utilizador entender dar à opção designada por defeito de perguntas Frequentes.
Perguntas Frequentes : Texto para Lista
Nome designado pelo utilizador para ser usado onde aparecem as palavras
lista de perguntas frequentes
.
Perguntas Frequentes : Texto para Pergunta
Nome designado pelo utilizador para ser usado onde aparece a palavra
pergunta
.
Perguntas Frequentes : Texto para Resposta
Nome designado pelo utilizador para ser usado onde aparece a palavra
Resposta
.
Pesquisa avançada: não limita nem pede intervalo de data
Este parâmetro define se ao aceder ao ecrã de pesquisa avançada, o resultado da mesma seja filtrado pela data dos registos.
Pesquisa avançada: não mostra as opções de tabelas a procurar
Se este parâmetro estiver ativo, as opções para escolher no monitor deixam de estar disponíveis. Ou seja, as procuras são efetuadas tendo em conta todas as opções, tornando a pesquisa mais lenta.
Pesquisa avançada: posição na homepage
Este parâmetro permite definir em que colunas pretendemos que a pesquisa passe a surgir, sendo que ao configurar o parâmetro com 0, não aparece, caso configure na coluna 1, 2 ou 3, passa a surgir na coluna configurada.
Pesquisa avançada: título na homepage
Neste parâmetro o utilizador pode definir o título que quer atribuir à Pesquisa Avançada, quando esta está na homepage.
Pesquisa avançada: usa dados da busca instantânea
Quando ativo este parâmetro faz com que o Monitor do conhecimento use a base de dados de busca instantânea para procurar os registos.
Template dos itens do EGALIST
Este parâmetro permite definir um template do
EGALIST
em
HTML
puro. Podem ser usados os campos:
#RESUMO#
,
#LINK#
,
#TITULO#
,
#STAMP#
,
#CATEGORIA#
,
#ICON#
. Estes campos são
case-sensitive
.
Usa no menu a opção de comunidade
Se este parâmetro estiver ativo, o utilizador está a definir que as opções sobre a comunidade aparecem no menu principal.
Usa no menu a opção de dossiers internos
A opção de menu
Dossiers Internos
apenas se encontra disponível no menu se este parâmetro se encontrar cativo.
Usa no menu a opção de galeria de anúncios
A opção de menu
Galeria de Anúncios
apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa no menu a opção de galeria multimédia
A opção de menu
Galeria Multimédia
apenas se encontra disponível no menu se este parâmetro se encontrar ativo. Esta opção, no entanto, apenas pode ser utilizada no
Suporte extranet web
se o utilizador possuir também o
Suporte intranet web
, módulo onde é configurada.
Usa no menu a opção de instalações
A opção de menu Instalações apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa no menu a opção de intervenções técnicas
A opção de menu Intervenções Técnicas apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa no menu a opção de perguntas frequentes
A opção de menu Perguntas Frequentes apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Suporte intranet web
Anúncios - recentes aparecem na homepage
Se este parâmetro se encontrar ativo, na homepage aparece uma caixa com os registos recentes dos anúncios criados ou alterados (últimos 15 dias).
Anúncios - TOP 10 aparecem na homepage
Se este parâmetro se encontrar ativo na homepage aparece uma caixa com o TOP 10 dos anúncios mais vistos na homepage.
Conteúdos multimédia: nome no plural
Nome que o utilizador entender dar à opção designada por defeito de "Conteúdos multimédia".
Conteúdos multimédia: nome no singular
Nome que o utilizador entender dar à opção designada por defeito de "Conteúdo multimédia".
Conteúdos multimédia: subtítulo para lista
Neste parâmetro o utilizador poderá definir o texto para ser utilizado no subtítulo do ecrã de galeria multimédia.
Conteúdos multimédia: texto para lista
Neste parâmetro o utilizador poderá definir o nome para ser utilizado onde aparece "Lista de conteúdos Multimédia".
Documentos: instruções para o upload de ficheiros
Neste parâmetros o utilizador pode personalizar o texto a mostrar ao cliente, quando o mesmo pretenda efetuar um upload de um ficheiro.
Documentos: UpLoad de ficheiros dos PATs para a tabela Anexos
Permite ao utilizador definir se o Upload dos ficheiros é efetuado diretamente para a tabela de Anexos.
Multimédia - recentes aparecem na homepage
Se este parâmetro se encontrar ativo, na homepage aparece uma caixa com os registos de multimédia mais recentes (últimos 15 dias).
Multimédia - TOP 10 aparecem na homepage
Se este parâmetro se encontrar ativo na homepage aparece uma caixa com o TOP 10 de multimédia mais vista na homepage.
Multimédia - TOP 10 aparecem na homepage no centro
Se este parâmetro se encontrar ativo aparece uma caixa com o TOP 10 de multimédia mais vista na área central da homepage.
Na homepage aparece a procura de pedidos de assistência técnica por número
Uma vez ativo, permitem ao utilizador definir este método de procura, utilizando o campo de
Pesquisa Avançada
No monitor do conhecimento não mostra as opções de tabelas a procurar
Quando este parâmetro se encontra ativo a aplicação não mostra nenhuma opção para escolher no monitor, procurando em todas as opções, o que torna a procura mais lenta.
Perguntas Frequentes : Nome no plural
Nome que o utilizador entender dar à opção designada por defeito de perguntas Frequentes.
Perguntas Frequentes : Texto para Lista
Nome designado pelo utilizador para ser usado onde aparecem as palavras
lista de perguntas frequentes
.
Perguntas Frequentes : Texto para Pergunta
Nome designado pelo utilizador para ser usado onde aparece a palavra
pergunta
.
Perguntas Frequentes : Texto para Resposta
Nome designado pelo utilizador para ser usado onde aparece a palavra
Resposta
.
No monitor do conhecimento usa dados da busca instantânea
Quando ativo este parâmetro faz com que o Monitor do conhecimento use a base de dados de busca instantânea para procurar os registos.
Pesquisa avançada: não limita nem pede intervalo de data
Este parâmetro permite filtrar a busca por data dos registos.
Pesquisa avançada: não mostra as opções de tabelas a procurar
Se este parâmetro estiver ativo, as opções para escolher no monitor deixam de estar disponíveis. Ou seja, as procuras são efetuadas tendo em conta todas as opções, tornando a pesquisa mais lenta.
Pesquisa avançada: posição na homepage
Este parâmetro permite definir em que colunas pretendemos que a pesquisa passe a surgir, sendo que ao configurar o parâmetro com 0, não aparece, caso configure na coluna 1, 2 ou 3, passa a surgir na coluna configurada.
Pesquisa avançada: título na homepage
Neste parâmetro o utilizador pode definir o título que quer atribuir à Pesquisa Avançada, quando esta está na homepage.
Pesquisa avançada: usa dados da busca instantânea
Quando ativo este parâmetro faz com que o Monitor do conhecimento use a base de dados de busca instantânea para procurar os registos.
Template dos itens do EGALIST
Este parâmetro permite definir um template do
EGALIST
em
HTML
puro. Podem ser usados os campos:
#RESUMO#
,
#LINK#
,
#TITULO#
,
#STAMP#
,
#CATEGORIA#
,
#ICON#
. Estes campos são
case-sensitive
.
Usa no menu a opção de galeria de anúncios
A opção de menu
Galeria de Anúncios
apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Usa no menu a opção de galeria multimédia
A opção de menu
Galeria Multimédia
apenas se encontra disponível no menu se este parâmetro se encontrar ativo. Esta opção, no entanto, apenas pode ser utilizada no
Suporte extranet web
se o utilizador possuir também o
> Suporte intranet web
, módulo onde é configurada.
Usa no menu a opção de Perguntas Frequentes
A opção de menu Perguntas Frequentes apenas se encontra disponível no menu se este parâmetro se encontrar ativo.
Framework Phc Cs Web
