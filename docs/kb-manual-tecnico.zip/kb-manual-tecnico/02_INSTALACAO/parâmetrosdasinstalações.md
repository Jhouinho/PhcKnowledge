---
title: Parâmetrosdasinstalações
source: parâmetrosdasinstalações.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdasinstalações

Parâmetros das Instalações

|  |
| --- |
| Parâmetros das Instalações |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu Sistema, permitem configurar diversas situações que definem a forma como certas características funcionam.      **Nome do campo Sub-Agente na ficha de instalação**   Serve para definir o nome deste campo, que existe na [ficha de Instalações](ConstituiçãodatabeladeInstalações.htm#agente) e na [tabela de Equipamentos](Constituiçãodatabeladeequipamento.htm#ibsubagente).    **Nome no plural do ficheiro de instalações**  Serve para definir o nome do ficheiro de instalações no plural, por exemplo Instalações.    **Nome no singular do ficheiro de instalações**  Serve para definir o nome do ficheiro de instalações no singular, por exemplo Instalação.    **Utiliza o ficheiro de instalações**   Esta opção permite definir se o ficheiro de instalações vai ser usado ou não.     *Nota:*  Os restantes parâmetros de carácter genérico encontram-se explicados nos [Parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros das Instalações' ) |