---
title: Parâmetrosdecontactos
source: parâmetrosdecontactos.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdecontactos

Parâmetros de Contactos

|  |
| --- |
| Parâmetros de Contactos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu Sistema, permitem configurar diversas situações que definem a forma como certas características funcionam.    Os parâmetros relativos ao funcionamento da tabela de contactos estão disponíveis no grupo **Contactos do Programa CRM Comercial**.    **Nome da tabela 1 (Potencial)**   Campo do tipo tabela que por defeito está parametrizado com o nome Potencial, mas ao qual pode ser dado outro nome. Está disponível na página **Dados principais** da tabela de contactos.    **Nome da tabela 2 (Tipo)**   Campo do tipo tabela que por defeito está parametrizado com o nome Tipo, mas ao qual pode ser dado outro nome. Está disponível na página **Dados principais** das tabelas de contactos e de clientes potenciais, deverá acrescentar-se que a informação deste campo também está disponível na página**Dados do Contacto** do ecrã de Pessoas;    **Nome da tabela 3 (Prioridade)**   Campo do tipo tabela que por defeito está parametrizado com o nome Prioridade, mas ao qual pode ser dado outro nome. Está disponível na página **Dados principais** da tabela de contactos.    **Nome do campo lógico 1, 2, 3**   Estes são campos tipo checkbox aos quais o utilizador pode dar o nome que desejar. Os campos estão disponíveis na página **Outros dados** da tabela de contactos.    **Nome do campo texto 1, 2, 3**   Estes são campos que podem conter informação constituída por carateres alfanuméricos e que estão disponíveis na página **Dados principais** das tabelas de contactos e de clientes potenciais.    **Procura incremental automática de contactos**  Permite na pesquisa de contactos, escrever apenas as primeiras letras do nome do contacto e o sistema procura automaticamente o nome mais próximo (que comece pelas letras indicadas).     **Sincronização automática de contactos com ficha de cliente (reinstalar triggers)**  Este parâmetro, uma vez ativo, faz com que, as alterações observadas em grande parte dos campos existentes na ficha do contacto se reflitam directamente nos campos correspondentes da ficha de cliente. Esta sincronização é bidirecional, pelo que, as alterações efetuadas na ficha do cliente, são automaticamente sentidas na ficha do contacto respetivo.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre como manter a sua base de dados atualizada de forma automática, através do nosso [filme](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=1f5%3a86egc3c.b%3ae9.fdc5.fe%3a) ou da nossa [idirecto](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=d%3a6cd4%3ae4d9.6bgc.3255.2g5).    **Utiliza Tabelas de preços em vez da tabela de artigos**  Ao ativar este parâmetro a aplicação vai disponibilizar o campo **Código da tabela de Preços** no ecrã de Contactos o que vai permitir definir uma [tabela de preços](tabeladepreços.htm) dinâmica para o mesmo contacto.    *Nota*: Os restantes parâmetros de carácter genérico encontram-se explicados nos [parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros de Contactos' ) |