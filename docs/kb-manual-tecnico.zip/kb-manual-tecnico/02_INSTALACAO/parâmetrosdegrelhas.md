---
title: Parâmetrosdegrelhas
source: parâmetrosdegrelhas.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdegrelhas

Parâmetros de Grelhas

|  |
| --- |
| Parâmetros de Grelhas |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu **Sistema**, permitem configurar diversas situações que definem a forma como certas características funcionam.    No grupo **Stocks** existem os seguintes parâmetros :    **Comprimento da cor no campo Refª+Cor+Tamanho**  Ver ponto anterior. Ou se indica o número de dígitos do campo cor, ou, se o comprimento do campo referência for de 18 caracteres, o comprimento do campo cor será zero.    **Comprimento da refª no campo composto Refª+Cor+Tamanho**  Serve para indicar o tamanho do campo referência, definindo desta forma se se vão utilizar os três campos num só código, ou se cada campo vai ser usado individualmente.     Por exemplo, para códigos de barras que contenham as três informações (referência do artigo, cor do artigo e tamanho do artigo) é possível colocar 8 + 5 + 5 caracteres, definindo desta forma que a Referência são os primeiros 8 caracteres, a cor os 5 seguintes e os últimos 5 caracteres correspondem ao tamanho. Quando se introduz a referência num documento, o programa preenche automaticamente os campos **Cor** e **Tamanho**.  As cores e os tamanhos que são indicados têm que possuir o comprimento correcto, ou seja, se o campo Cor está parametrizado com 5 caracteres, as cores devem ter 5 letras ou números como tamanho (i.e. se as cores forem definidas com números e se desejar utilizar a cor número 1 deverá escrever 00001).    O mesmo sucede se for utilizado um código de barras em vez do processo manual, ou seja, se passar um leitor num código de barras que contenha a referência, a cor e o tamanho do artigo, serão preenchidos os respectivos campos automaticamente.    **Comprimento do tamanho no campo Refª+Cor+Tamanho**   Ver ponto anterior. Ou se indica o número de dígitos do campo tamanho, ou, se o comprimento do campo referência for de 18 caracteres, o comprimento do campo tamanho será zero.    **Nº de cores e tamanhos**  Permite indicar o número máximo de cores e tamanhos que se podem utilizar para cada artigo.      **Utiliza grelhas de cor e tamanho ([re-instalar triggers](Funcionamentodainstalaçãoemanutenção.htm#sftriggers))**  Permite activar a utilização das grelhas. Na ficha do artigo deve definir se o mesmo possui [grelhas](Constituiçãodatabeladestockseserviços.htm#ibgrelhas) ou não.     A opção de re-instalar triggers serve para indicar que se deve executar essa operação imediatamente a seguir à activação/desactivação desta opção, pois de contrário, a respectiva alteração pode não funcionar.  *Nota final*:  Os restantes parâmetros de carácter genérico encontram-se explicados nos [parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros de Grelhas' ) |