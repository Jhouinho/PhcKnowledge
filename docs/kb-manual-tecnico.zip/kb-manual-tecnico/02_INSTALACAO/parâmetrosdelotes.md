---
title: Parâmetrosdelotes
source: parâmetrosdelotes.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdelotes

Parâmetros de Lotes

|  |
| --- |
| Parâmetros de Lotes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros de lotes, disponíveis no menu do grupo de Compras e Stocks, permitem configurar diversas situações que definem a forma como certas características funcionam.    **Comprimento da referência no campo composto Refª+Lote**  Este campo determina o nº de caracteres destinados ao campo "Referência", desta forma será assumido pela aplicação que os X primeiros caracteres do código de barras, representam a referência do artigo.    **Comprimento do lote no campo composto Refª+Lote**  Este campo determina o nº de caracteres destinados ao campo "Lote", desta forma será assumido pela aplicação que os X caracteres do código de barras, imediatamente a seguir aos caracteres destinados para o campo "Referência" representam o Lote do artigo.      Estes parâmetros serão utilizados aquando a introdução de dados nas linhas dos documentos de faturação, compras, dossiers internos e inventário físico.   Na linha do documento ao digitar a referência mais o lote do artigo ou efetuando a leitura através do código de barras, irá preencher a coluna referência e a coluna lote, com os respetivos dados.  Nos documentos de saída, caso o lote não exista a aplicação sugere um lote dos já existentes (Conforme a gestão de lotes utilizada, fifo fefo ou lifo), nos documentos de entrada a aplicação dá possibilidade de criação de um novo lote.    *Nota:*  Para esta funcionalidade não estar ativa, o primeiro parâmetro deverá ter o valor 18 (Dezoito) e o segundo parâmetro o valor 0 (Zero).  Caso possua o módulo de grelhas, esta funcionalidade, não tem prioridade sobre a funcionalidade idêntica "campo composto Refª+Cor+Tam", assim, desde que esta funcionalidade esteja configurada, será sempre executada em 1º lugar, se eventualmente retornar a existência de um código, neste caso teríamos dois códigos iguais um para a Cor+Tam e outro para o Lote, o software assumirá em 1º lugar o código Cor+Tam.    **Gestão de lotes em FIFO ou FEFO** *(grupo de Stocks)*  Define que os lotes são geridos em FIFO (First in first out), ou seja, o primeiro lote a entrar é o primeiro a sair ou em FEFO(First Expiring First Out), ou seja, o lote com prazo de validade menor é o primeiro a sair.     **Gestão de lotes em LIFO** *(grupo de Stocks)*  Define que os lotes são geridos em LIFO (Last in first out) último a entrar primeiro a sair    **Lote por defeito nas compras** *(grupo de Compras)*  Permite introduzir um lote a utilizar por defeito a quando de uma compra.    **Modificar a palavra para LOTE** *(grupo de Stocks)*  Permite mudar a palavra Lote dentro da aplicação.    **Modificar a palavra para LOTE (plural)** *(grupo de Stocks)*  Permite mudar a palavra Lote no plural dentro da aplicação.    **Nos artigos com lotes, utiliza o preço de custo do artigo nos Custos de Doc. de Faturação, Dossiers Internos e Inventários de Stocks**  Ao ativar este parâmetro o preço de custo utilizado nos Dossiers Internos, Documentos de Faturação e Inventário de Stocks é o preço de custo do artigo. Caso contrário, será utilizado o preço de custo que se encontra na ficha do lote.    **Só propõe saídas de lotes dentro da validade/limite de faturação** *(grupo de Stocks)*  Com este parâmetro ativo os lotes propostos para saída estão dentro da validade/limite de faturação.    **Utiliza Lotes (re-instalar triggers)** *(grupo de Stocks)*  Serve para ativar ou descativar a utilização dos lotes. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros de Lotes' ) |