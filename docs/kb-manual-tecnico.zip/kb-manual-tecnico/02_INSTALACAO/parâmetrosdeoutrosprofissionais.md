---
title: Parâmetrosdeoutrosprofissionais
source: parâmetrosdeoutrosprofissionais.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdeoutrosprofissionais

Parâmetros de outros Profissionais

|  |
| --- |
| Parâmetros de outros Profissionais |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros dos outros profissionais, permitem configurar diversas situações que definem a forma como certas características funcionam:    **Câmbio a utilizar para o lançamento de recibos de outros rendimentos na tesouraria**  Esta opção só se encontra disponível se possuir o Módulo de Pessoal e o Módulo de Gestão.  Permite determinar com que câmbio (Vendas ou Compras) são atualizados os movimentos de tesouraria resultantes de recibos de outros rendimentos em contas de tesouraria em moeda estrangeira.  Os câmbios utilizados são os registados à data para a tesouraria indicada em cada recibo.    **Código de tesouraria por defeito para os recibos de outros rendimentos**  Permite indicar qual o código de [tesouraria](lançamentoderecibosemdocumentosdetesouraria.htm) por defeito para os recibos de outros rendimentos.    **Documento de tesouraria por defeito para os recibos de outros rendimentos**  Permite indicar qual o [documento](lançamentoderecibosemdocumentosdetesouraria.htm) de tesouraria por defeito a utilizar para os recibos de outros rendimentos. Este documento não é mais que um documento pré-definido no módulo Contabilidade.    **Lança os recibos de outros rendimentos nos documentos de tesouraria (vs. movimentos de tesouraria) - (reinstalar triggers)**  Ao ativar esta opção permite o lançamento dos registos dos recibos de outros rendimentos nos [documentos](lançamentoderecibosemdocumentosdetesouraria.htm) de tesouraria no Módulo Gestão.  Ao desativar a opção os registos serão lançados nos movimentos de tesouraria.    **Local de emissão dos cheques**  Permite indicar o local de emissão dos cheques. ( p.ex: Lisboa.)    **Permite 2 profissionais com o mesmo número de contribuinte**  Por defeito este parâmetro aparece selecionado, pelo que, nesse estado, permite que sejam criados dois Profissionais com o mesmo nº de contribuinte.     **Permite lançar dados para a tesouraria**  Permite ativar a página de [Dados para a tesouraria](ConstituiçãodaTabeladeRecibosdeoutrosRend.htm#ardadostesouraria), no ecrã de Recibos de Outros Rendimentos. Este parâmetro está sempre disponível, mesmo que o utilizador não possua o Módulo de .  Com o módulo de Gestão - aparece a página de tesouraria quer o parâmetro esteja ativo ou inativo. Ao lançar um recibo de outro rendimento na tesouraria, o mesmo será refletido no ecrã de movimentos de tesouraria ou no ecrã de documentos de tesouraria, conforme o parâmetro.  Sem o módulo de Gestão - a página de dados de tesouraria apenas aparece quando o parâmetro **Permite lançar dados para a Tesouraria** se encontra ativo. Servindo apenas de uma página informativa, onde se podem introduzir os dados da tesouraria, neste caso não existe qualquer ligação com as tabelas de tesouraria, pois não se possui o módulo de gestão.    **Taxa de IRS a reter na fonte**  Permite definir a taxa de IRS a reter na fonte. (p.ex: 20.0%.)    **Taxa de IRS a reter para rendimentos de Categoria F ( Prediais)**  Permite definir a taxa de IRS a reter na fonte para rendimentos da Categoria F. (p.ex: 15.0%.)    **Taxa de IVA a debitar nos recibos**  Permite definir a taxa de IVA a debitar nos recibos. (p.ex: 17.0%.) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros de outros Profissionais' ) |