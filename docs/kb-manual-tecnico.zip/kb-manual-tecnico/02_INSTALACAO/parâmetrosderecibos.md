---
title: Parâmetrosderecibos
source: parâmetrosderecibos.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosderecibos

Parâmetros de Recibos

|  |
| --- |
| Parâmetros de Recibos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu Sistema, permitem configurar diversas situações que definem a forma como certas caraterísticas funcionam.      **Ao gravar um novo recibo não pergunta se quer processar se possuir título**  Se esta opção estiver ativa (com visto) e se estiver um título associado ao recibo, então ao gravar não é apresentada a possibilidade (janela) para efetuar o processamento do mesmo.    **Ao gravar um novo recibo pergunta se quer imprimir**  Se esta opção estiver ativa (com visto), será possível imprimir o recibo após gravação.    **Código de conta corrente para Desconto Financeiro (reinstalar triggers)**  Esta opção permite definir um código de conta corrente para o Desconto Financeiro, de forma a que este origine um movimento de conta corrente.    **Código de conta corrente para retenção de IRS (reinstalar triggers)**  Esta opção permite definir um código de conta corrente de forma a que o valor de IRS resultado do processamento de recibos dê origem a um movimento de conta corrente. Para mais informações consulte por favor o capítulo sobre [Retenção de IRS na fonte-Doc. de Faturação](retençãodeirsnafonte-docdefaturação.htm)    **Código de conta corrente para Séries de Recibos sem código atribuído (reinstalar triggers)**  Esta opção permite definir um código para séries de recibos que não tenham qualquer código de conta corrente definido.    **Código de Tesouraria por defeito**  Esta opção permite definir o código de Tesouraria para os recibos. Desta forma não será necessário definir o mesmo quando se emite o recibo.      **No recibo permite regularizar documentos de vários estabelecimentos**  Quando ativo, permite regularizar num só recibo, documentos de vários estabelecimentos.  Se nos clientes o parâmetro Guarda o estabelecimento na conta corrente, estiver ativo em simultâneo com o parâmetro em cima descrito, este último vai sobrepor-se e vai permitir regularizar num só recibo documentos de vários estabelecimentos.  Atenção, ao ativar este parâmetro, deixará de ser possível consultar saldos de conta corrente por estabelecimento.    Quando tem **Factoring**, este parâmetro determina também os documentos para as cessões de crédito. Ou seja, quando este parâmetro está ativo, ao seleccionar documentos para as cessões de crédito, pode-se escolher documentos de outros estabelecimentos, mesmo que esteja ativo o parâmetro de Clientes «Guarda o estabelecimento na conta corrente».     Se tiver [PHC ON](oqueéophcon.htm) saiba como controlar a conta-corrente de um cliente com vários estabelecimentos, carregando [aqui](http://on.phc.pt/onphce/programs/nwwwview.aspx?stamp=45d34352d18.82cc.g8d5.ee1).    **O recibo ao ser emitido fica automaticamente processado**  Esta opção permite emitir um recibo processando o mesmo automaticamente.  Uma vez desativado, sempre que se gravar um pagamento, surge uma mensagem que pergunta ao utilizador se quer ou não processar o recibo.    **Permite alterar o câmbio dos recebimentos**  Ao introduzir um recibo em Euros para regularizar um documento em moeda estrangeira ou um recibo em moeda estrangeira para regularizar um documento na mesma moeda, através desta opção é possível alterar o câmbio dessa linha do recibo.   Quando o documento é incluído no [recibo](ConstituiçãodaTabeladeRecibos.htm#mpscâmbio), esse campo está a 0, pelo que, ao se alterar esse valor para um valor diferente de 0, os valores (por regularizar e regularizados) em Euros são recalculados em função desse câmbio. Se o voltar a definir esse valor como 0, os valores em Euros são recalculados pela taxa de conversão à data do recibo.    **Utiliza receção e envio de documentos via XML**  Esta opção permite configurar os recibos para envio e receção de documentos via XML. Para mais informações sobre esta opção consulte por favor o capítulo sobre [Configurações Documentos XML](configuraçõesdocumentosxml.htm).    *Nota:*  Os restantes parâmetros de carácter genérico encontram-se explicados nos [Parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros de Recibos' ) |