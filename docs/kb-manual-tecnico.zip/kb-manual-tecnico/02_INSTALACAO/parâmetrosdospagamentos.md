---
title: Parâmetrosdospagamentos
source: parâmetrosdospagamentos.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdospagamentos

Parâmetros dos Pagamentos

|  |
| --- |
| Parâmetros dos Pagamentos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu Sistema, permitem configurar diversas situações que definem a forma como certas características funcionam.    **Ao gravar um pagamento pergunta se quer imprimir**  Quando esta opção está activa, tem a possibilidade de aparecer automaticamente o ecrã de impressão após ter processado o pagamento a fornecedores.    **Código de Conta-Corrente por defeito (1 a 49)**  Neste parâmetro é possível predefinir o código de Conta-Corrente para os pagamentos. Desta forma será assumido este código quando se introduz um pagamento novo. Para mais informações sobre esta opção consulte por favor o capítulo sobre [Códigos de Conta-Corrente](códigosdeconta-corrente.htm).    **Código de Conta-Corrente para desconto p.p. (1 a 50) (reconstruir triggers)**  Esta opção é semelhante à anterior, permitindo definir o código de Conta-Corrente para os descontos a pronto pagamento. Para que esta opção funcione correctamente é necessário utilizar a opção de reconstrução de triggers na [Instalação e Manutenção](instalaçãoemanutenção.htm).    **Código de Conta-Corrente para retenção de IRS (reinstalar triggers)**  Esta opção permite definir qual o [código de Conta-Corrente](códigosdeconta-corrente.htm) para a [retenção de IRS na fonte](retençãodeirsnafonte.htm).    **Local de emissão dos títulos**  Esta opção permite definir o local de emissão dos títulos, sendo esta informação depois preenchida automaticamente.    **No pagamento permite regularizar documentos de vários estabelecimentos**  Quando activo, permite regularizar num só pagamento, documentos de vários estabelecimentos.  Se nos fornecedores o parâmetro Guarda o estabelecimento na Conta-Corrente, estiver activo em simultâneo com o parâmetro em cima descrito, este último vai sobrepôr-se e vai permitir regularizar num só pagamento documentos de vários estabelecimentos.  Atenção, ao activar este parâmetro, deixará de ser possível consultar saldos de Conta-Corrente por estabelecimento.    **O pagamento ao ser efectuado fica automaticamente processado**  Esta opção permite efectuar o pagamento ficando o mesmo automaticamente processado.   Uma vez desactivado, sempre que se gravar um pagamento, surge uma mensagem que pergunta ao utilizador se quer ou não processar o pagamento.    **Utiliza recepção e envio de documentos XML**  Esta opção permite configurar os pagamentos para envio e recepção de documentos via XML. Para mais informações sobre esta opção consulte por favor o capítulo sobre [Configurações Documentos XML](configuraçõesdocumentosxml.htm).    *Nota:*  Os restantes parâmetros de carácter genérico encontram-se explicados nos [Parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros dos Pagamentos' ) |