---
title: Parâmetrosdospedidosdeassistência
source: parâmetrosdospedidosdeassistência.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosdospedidosdeassistência

Parâmetros dos Pedidos de Assistência

|  |
| --- |
| Parâmetros dos Pedidos de Assistência |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Os parâmetros da aplicação, disponíveis no menu Sistema, permitem configurar diversas situações que definem a forma como certas características funcionam.      **Após abrir um pedido pergunta se pretende introduzir uma intervenção**  Quando este parâmetro se encontra ativo, após abrir um pedido de assistência a aplicação pergunta ao utilizador se este pretende introduzir uma Intervenção. No caso de a resposta ser afirmativa a aplicação abre o ecrã de intervenções.    **Consome pontos só no fecho do Pedido de Assistência**  Quando este parâmetro está ativo, apenas quando o pedido de assistência é encerrado é que são movimentados os pontos do cliente.   Ao reabrir o Pedido de Assistência, são repostos os pontos movimentados.  Se este parâmetro estiver inativo, ao criar o Pedido de Assistência são movimentados os pontos.    **Código de movimento de pontos a debitar nos Pedidos de Assistência**  Este parâmetro permite definir um Código de Movimentos de Pontos que será atribuído por defeito ao criar novo Pedido de Assistência.  Por exemplo: Débito de pontos    **Minutos de intervalo entre as legendas (criação automática de legendas)**  Permite criar automaticamente os intervalos pretendidos, começando por 1 e com o tempo de intervalo indicado em minutos.  Se se indicar o intervalo 0 (zero), cabe ao utilizador indicar os intervalos de tempo a partir do ecrã de legendas.    **Nº de intervalos de tempo de legendas na atribuição de Pedidos de Assistência**  Este parâmetro permite definir quantas legendas de cor vão existir.    **Número de dias de validade dos pontos (a partir da data de crédito)**  Este parâmetro permite definir o prazo de validade dos pontos, assumindo por defeito 365 dias.  Ao consumir pontos, só são consumidos pontos cuja data de validade seja superior à data atual.  Ao definir no parâmetro o valor "0" (zero), a aplicação deixa de verificar a data de validade dos lotes.  Ao realizar um movimento de crédito, se o cliente não tiver nenhum lote, é criado um com data vazia.  Posteriormente, todos os movimentos de débito e crédito serão feitos sobre esse lote de pontos, não validando se a data é superior à data atual, para consumo.    **Obriga a ter saldo de pontos positivo para criar novo Pedido de Assistência**  Quando este parâmetro está ativo, não é possível inserir um pedido de assistência caso o cliente já não tenha pontos ou o número de pontos não seja suficiente para o movimento a realizar.  Quando inativo não é validado o número de pontos do cliente, podendo existir clientes com número de pontos a negativo.    *Nota:* Se tiver ativo o parâmetro **Consome pontos só no fecho do Pedido de Assistência**, este parâmetro não será utilizado, visto o consumo só ser realizado ao fechar o Pedido de Assistência, não fazendo sentido impedir a sua criação.    **Permite abrir Pedidos de Assistência sem Instalação associada**  Ao ativar este parâmetro que por defeito se encontra inativo, a aplicação passa a permitir abrir Pedidos de Assistência Técnica sem estarem ligados a nenhuma Instalação.  Por exemplo, se se efetuar Assistência Técnica remotamente, uma vez que não existe deslocação às Instalações do Cliente, passa a ser possível, com este parâmetro ativo, abrir um Pedido de Assistência Técnica a esse cliente.    **Somente o supervisor pode abrir Pedidos de assistência a clientes com a assistência cortada**  Ao ativar esta opção e se o cliente tem a assistência técnica cortada, então somente o supervisor poderá abrir pedidos de assistência técnica.    **Somente o supervisor pode reabrir/alterar um pedido de assistência fechado**  Ao ativar esta opção define-se que apenas o supervisor poderá reabrir ou alterar um pedido de assistência técnica fechado.     **Utiliza sistema de gestão de pontos de suporte (reinstalar triggers)**  Ao ativar este parâmero irá ser utilizado o sistema de gestão de pontos.  Quando inativo, não será utilizado o sistema de gestão de pontos.      *Nota:*  Os restantes parâmetros de carácter genérico encontram-se explicados nos [Parâmetros gerais](parâmetrosgerais.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros dos Pedidos de Assistência' ) |