---
title: Parâmetrosgerais Phc Manufactor
source: parâmetrosgerais-phc-manufactor.htm
tipo: Manual Técnico
idioma: PT
---

# Parâmetrosgerais Phc Manufactor

Parâmetros Gerais - Phc-manufactor

|  |
| --- |
| Parâmetros Gerais - Phc-manufactor |

|  |
| --- |
| O ecrã de Parâmetros Gerais é um dos pontos mais importantes a focar, com vista à correcta instalação e parametrização do software Manufactor.  É apresentado sobre a forma de estrutura hierárquica (árvore) e contém vários opções principais, e estas são constituídas por vários tópicos. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Parâmetros Gerais - Phc-manufactor' ) |