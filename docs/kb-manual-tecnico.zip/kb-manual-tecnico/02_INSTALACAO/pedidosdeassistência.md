---
title: Pedidos de Assistência
source: pedidosdeassistência.htm
tipo: Manual Técnico
idioma: PT
---

# Pedidos de Assistência

O ecrã "Pedidos de Assistência" possui a seguinte informação:
O botão
incorpora a opção de
. Esta última permite visualizar todos os dossiers existentes e poderá escolher o dossier a introduzir. Ao introduzir o novo dossier este ficará associado ao
N.º do PAT
em questão.
Nota:
Este botão só está disponível se o utilizador tiver ativo, no PHC CS Desktop, o acesso a introduzir Dossiers Internos através da opção Sistemas - Utilizadores - Acessos - Gestão - Dossiers Internos - Internet.Introduzir.
Ecrã em modo de introdução/alteração
Pedido sob o NOSSO controlo (espera resposta)
Define se o pedido de assistência está sob controlo da empresa.
Data e Hora
Estes campos indicam a data e a hora de introdução do PAT.
Data limite
Este campo serve para indicar até que dia o pedido deve ser satisfeito, podendo criar diversos avisos para esse efeito (a forma de executar um procedimento deste tipo encontra-se explicado neste capítulo na opção "Pedido muito urgente").
Cliente
Este campo permite observar / indicar o nome do cliente para o qual se abriu o ecrã "Pedidos de assistência técnica".
Ao introduzir um pedido de assistência técnica, se preencher este campo com o nome do cliente, ao clicar no campo número de série é possível ver os equipamentos apenas desse cliente.
Nº Cliente
Este campo indica o número do cliente para o qual se abriu o Pedidos de assistência técnica.
Entidade
Este campo permite observar / indicar o nome da entidade para o qual se abriu o ecrã de "Pedidos de assistência técnica". Os dados da entidade são preenchidos quando se tratar da seguinte situação:
Quando o equipamento não é vendido diretamente ao cliente, mas sim através de um revendedor ou distribuidor, então é preenchido o campo da entidade, sendo este o utilizador final.
O campo de cliente corresponde, nesse caso, ao nome do intermediário.
Nº Entidade
Este campo indica o número interno desta entidade.
Dados Principais
Quem é o utilizador que pede este PAT
Neste local fica registado o nome da pessoa que solicitou a assistência.
Vossa referência
Este campo permite registar a referência do pedido por parte do cliente.
Centro de assistência
Permite registar o "Centro de Assistência" respetivo.
Área
Permite introduzir a área de assistência.
Nossa referência
Permite introduzir nossa referência.
Nota
: Os nomes dos três campos anteriores são definidos nos parâmetros, pelo que podem não corresponder aos que aqui são apresentados.
Série
Permite introduzir o número de série do equipamento.
Quando inserir um pedido de assistência técnica, este ficará ligado ao
equipamento
com o número de série que se encontra definido neste campo.
Pode efetuar uma procura através do botão
ou introduzir um ou mais caracteres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caracter introduzido e conforme é introduzido mais caracteres esta procura vai sendo refinada.
Ao introduzir um pedido de assistência técnica, caso o cliente já esteja preenchido, ao clicar no campo
Série
, a aplicação apresenta os equipamentos apenas desse cliente.
Caso a introdução seja primeiramente no campo
Série
, o número do cliente ligado a série do equipamento será preenchido automaticamente.
Marca
Este campo define a marca do equipamento e é introduzido automaticamente após a introdução do campo
Série
.
Modelo
Este campo define o modelo do equipamento e é introduzido automaticamente após a introdução do campo
Série
.
Resumo
Este campo possibilita a introdução de texto, permitindo identificar a situação que está a ser reportada de uma forma mais sucinta.
Pedido muito urgente!
Esta informação indica que se trata de um pedido muito urgente, o qual deve merecer prioridade. Este campo é bastante útil, pois permite a criação de eventos (só em
Advanced
e
Enterprise
) do tipo: Se existe um pedido grave envia uma mensagem (interna,
E-mail
, etc.) para uma ou várias pessoas ou executa outro tipo de procedimento.
Descrição completa do problema
Este campo permite efetuar o registo detalhado do problema do equipamento.
Comportamento desejado
Este campo permite descrever qual o comportamento que se espera obter com a resolução do problema do equipamento.
Motivo para esta necessidade
Este campo possibilita descrever a necessidade do cliente para a resolução do problema do equipamento.
Por exemplo, poderá ser preenchido com um cenário onde o problema desse equipamento terá consequências.
Solução / resposta final para o problema apresentado
Este campo permite efetuar o registo detalhado da solução do problema do equipamento.
Diálogos
Após gravar, na página principal tem a possibilidade de
Adicionar Diálogo
e / ou
Adicionar um ficheiro
.
Ao clicar neste botão permite adicionar um diálogo ao PAT em questão. Após digitar o diálogo pretendido terá que clicar no botão
Gravar o Diálogo
de forma a gravar o mesmo.
Anexos
Para adicionar um ficheiro ao PAT em questão terá que digitar o caminho do ficheiro ou então clicar no botão
de forma a encontrar o ficheiro.
À medida que estes vão sendo carregados, fica logo disponível uma lista de todos os ficheiros, com informação sobre a data e a hora em que foi anexado, por quem, o tipo de ficheiro, a descrição e se é externo. Ao clicar no botão atualizar, a descrição e o tipo de ficheiro podem ser editados. Também existe a possibilidade de se apagar o registo.
Permite fazer o carregamento de ficheiros com as seguintes extensões: GIF, JPG, JPEG, BMP, DOC, XLS, PDF, ZIP, RAR, PNG, TXT, DOC, XLS, DOCX, XLSX, PPT, PPTX, PPTS.
Nota:
É possível anexar ficheiros ao Pedido de Assistência, mesmo sem ter o módulo PHC CS Documentos web, mas estes anexos não têm qualquer ligação ao módulo
PHC CS Documentos desktop
. Assim recomendamos que caso pretenda ter ligação ao módulo
PHC CS Documentos desktop
adquira o módulo
PHC CS Documentos web
.
Outros Dados
Tipo de pedido
Neste local fica registado o tipo de pedido. Trata-se de uma tabela do utilizador, onde se pode colocar por exemplo as seguintes opções: "Prioritário", "Urgente", "Standby", "Anomalia", "Dúvida", "Orçamento", "Formação", "Instalação", etc.
Este campo também pode ser útil para avisos automáticos. Por exemplo, se é inserido um pedido de determinado tipo, pode ser executada uma determinada ação (envio de
e-mail
, etc.), como já foi explicado anteriormente.
Status do pedido
Permite indicar em que situação se encontra o pedido, por exemplo: "em análise", "verificado", "stand-by", "a decorrer", etc.
Status Público
Permite indicar em que situação se encontra o pedido público.
Prioridade
Este campo permite indicar a prioridade do pedido de assistência.
Pedido PÚBLICO ?
Uma vez ativa, esta opção determina que o pedido de assistência em questão é um pedido público.
Nome do técnico
Permite registar o nome do técnico responsável. Esta informação é introduzida automaticamente, caso o técnico esteja definido na ficha de equipamento.
Também é possível escolher outro técnico, surgindo na listagem apresentada apenas os técnicos que se encontrem ativos.
Ao clicar em
o utilizador pode observar uma listagem dos "Pedidos de Assistência" em aberto por técnico e respetivos totais.
Departamento
Neste local fica registado o departamento ao qual o técnico pertence.
As opções das Intervenções estão explicadas no capítulo Intervenções da tabela de PATs.
Tipo de Técnico
Neste local é possível definir o tipo de técnico para débito de pontos ao movimentar a conta corrente de pontos do cliente.
Mov. Pontos
Esta opção permite definir o código de movimento de pontos do pedido de assistência
Pontos a atribuir
Esta opção apenas surge quando o código definido no campo
Mov. Pontos
tem a opção
Pode definir pontos ao atribuir?
ativa.
Neste campo é possível ser definido o número de pontos a movimentar.
Notas:
Ao criar um novo registo é atribuído o código de movimentos de pontos que esteja definido no parâmetro
Código de movimento de pontos a debitar nos Pedidos de Assistência
;
Se o número de pontos configurado no código de movimentos de pontos for "0" (zero) e a opção
Pode definir pontos ao atribuir?
estiver inativa, o número de pontos será calculado com base na Matriz de Pontos, consoante a prioridade e tipo de técnico definido.
Se o Pedido de Assistência já tiver técnico atribuído e for alterada a
Prioridade
ou
Tipo de Técnico
, surge uma mensagem ao utilizador impedindo a gravação do registo.
Ao gravar um Pedido de Assistência é verificado se o cliente tem pontos disponíveis, e caso não tenha é impedida a gravação do PAT;
Para mais informações consulte por favor o tópico
Funcionamento Sistema de Gestão de Pontos
.
Encerrado pelo departamento técnico
Permite dar um pedido de assistência como encerrado.
Nota
: Ao gravar não é efetuada nenhuma validação como acontece quando se introduz um novo PAT através do
Suporte extranet web
.
Ecrã em modo de consulta
Após
o documento, será apresentada a
Próxima ação
. O objeto
Próxima ação
poderá ser configurado através da Framework PHC onde poderá adicionar-lhe novas
Opções de Ecrã
definidas pelo utilizador.
Pode ainda efetuar uma
Consulta de Pedidos de Assistência
e observar uma listagem com as
Intervenções
, assim como criar uma nova intervenção diretamente, a partir do ecrã de Pedidos de Assistência Técnica.
Neste ecrã existe a opção
Criar nova Intervenção
, permitindo navegar para o ecrã de Intervenções, em modo de introdução, onde se encontram os dados do PAT em questão.
Suporte Intranet Web
