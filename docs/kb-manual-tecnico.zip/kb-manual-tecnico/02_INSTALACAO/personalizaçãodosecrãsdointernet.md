---
title: Personalização dos Ecrãs do Internet
source: personalizaçãodosecrãsdointernet.htm
tipo: Manual Técnico
idioma: PT
---

# Personalização dos Ecrãs do Internet

De uma forma simples pode-se configurar toda a internet através da framework do PHC CS Web. No exemplo apresentado irá mostrar-se o antes e o depois das várias configurações aos acrãs de acesso ao Internet que se podem fazer. Vai-se exemplificar as configurações dos ecrãs de login, registo e alteração de password. O exemplo apresentado é apenas uma amostra da potencialidade do que se pode desenvolver.
1.	Configurar o ecrã de Login
O primeiro exemplo é a configuração do ecrã de login da internet.
Por defeito o ecrã tem o seguinte aspeto:
No entanto pode-se configurar, neste exemplo vai-se incluir o logo da empresa, alterar a imagem de fundo e a posição do login no ecrã.
1º passo
- criar o template básico do login
Deve-se aceder à Framework na Intranet e criar um novo Template básico com os seguintes dados:
Titulo:
Template para o Login da Internet
Código de acesso a este registo:
Internet_Login
Tipo de Template Básico:
Login
Conteúdo da Página:
<div class="login_ext" style="background-color: rgba(255,255,255,0.9); color: #181818; font-size: 14px; position: absolute; top: 100px; left: 100px; padding: 30px; min-height: 500px; border-radius: 3px; ">
<img class="img-responsive" src="../pimages/Logoheader.jpg" />
<div class="row">
<p> </p>
<p class="Login_title">Email:</p>
<p>#??#USERFIELD#??#</p>
</div>
<div class="row">
<p class="Login_title">Palavra-passe:</p>
<p>#??#PASSFIELD#??#</p>
</div>
<div class="row">
<p class="login_bt">#??#INCLICK#??#</p>
<p>#??#MSGERRLABEL#??#</p>
</div>
<div class="row">
<p> </p>
<p>#??#FORGOTFIELD#??#</p>
<p>Regista-te <a href="../programs/register.aspx">aqui</a></p>
</div>
</div>
é HTML puro:
ativo
O Template tem Imagens na área do Conteúdo:
ativo
2º passo
- configurar os parâmetros
Nos Parâmetros no nó Internet é necessário configurar os seguintes parâmetros:
Usa Templates: ativo
Login: Template: Internet_login
3º passo
- configurar a imagem de fundo
Para configurar uma imagem de fundo pode ser efetuado através de CSS usando para isso o ficheiro
user.css
que existe na pasta
pimages
na instalação da internet ou também através do parâmetro no nó Internet
Imagem de fundo
.
Neste exemplo optou-se por colocar o seguinte código no ficheiro user.css:
body {
background-image: url(../pimages/MaisRitmo/Concerto_1.jpg);
background-size: cover;
}
Foi também colocado código CSS para o botão de login ficar mais destacado em relação ao restante conteúdo no ecrã de login:
input#ctl00_conteudo_tlogin {
padding: 10px;
font-weight: bold;
font-size: 12px;
}
4º passo
- reiniciar o IIS
Para que todos os passos sejam interpretados na Internet, deve-se reiniciar o IIS.
No fim destas configurações obtemos o seguinte resultado final:
2.	Configurar o ecrã de registo
Após configurar a página de login, que é a página principal quando o utilizador acede à Internet, segue-se a página para criar uma conta, ou seja o ecrã de registo. Tal como no exemplo anterior vai-se configurar o ecrã que por defeito tem o seguinte aspeto:
1º passo
- criar o template básico
Novamente na Framework na Intranet criar um novo Template básico com os seguintes dados:
Titulo:
Template para o Registo da Internet
Código de acesso a este registo:
Internet_Registo
Tipo de Template Básico:
Register
Conteúdo da Página:
<div class="login_ext" style="background-color: rgba(255,255,255,0.9); color: #181818; font-size: 14px; position: absolute; top: 100px; left: 100px; padding: 30px; width: 450px; border-radius: 3px;">
<img class="img-responsive" src="../pimages/Logoheader.jpg"/>
<div class="row">
<p> </p>
<p class="Login_title">Nome:</p>
<p>#??#REGISTERNAMECONTROL#??#</p>
</div>
<div class="row">
<p class="Login_title">Email:</p>
<p>#??#USERFIELD#??#</p>
</div>
<div class="row">
<p class="Login_title">Palavra-passe:</p>
<p>#??#PASSFIELD#??#</p>
</div>
<div class="row">
<p class="Login_title">Repetir a palavra-passe:</p>
<p>#??#CONFIRMPASSFIELD#??#</p>
</div>
<div class="row">
<p>#??#DISCLAIMER#??#</p>
<p>#??#MSGERRLABEL#??#</p>
<p class="login_bt">#??#REGISTERBUTTON#??#</p>
</div>
</div>
é HTML puro:
ativo
O Template tem Imagens na área do Conteúdo:
ativo
2º Passo
- configurar os parâmetros
Nos Parâmetros no nó Internet é necessário configurar o seguinte parâmetro:
Login: Template para criar conta : Internet_Registo
Após as alterações anteriores e reiniciar do IIS a página de registo fica com o seguinte aspeto:
3.	Configurar o ecrã de alteração da password
Segue-se a configuração do ecrã onde se altera a password, ou seja, o ecrã que aparece quando se clica no email recebido após se clicar na opção "Esqueci-me da Password" no ecrã de login. O ecrã por defeito tem o seguinte aspeto:
1º passo
- criar o template básico
Novamente na Framework na Intranet criar um novo template básico com os seguintes dados:
Titulo:
Template para a alteração da password da Internet
Código de acesso a este registo:
Internet_Password
Tipo de Template Básico:
Forgot
Conteúdo da Página:
<div class="login_ext" style="background-color: rgba(255,255,255,0.9); color: #181818; font-size: 14px; position: absolute; top: 100px; left: 100px; padding: 30px; width: 450px; border-radius: 3px;">
<img class="img-responsive" src="../pimages/Logoheader.jpg"/>
<p> </p>
<div class="row">
<p class="Login_title">Nome:</p>
<p>#??#REGISTERNAMECONTROL#??#</p>
</div>
<div class="row">
<p class="Login_title">Email:</p>
<p>#??#USERFIELD#??#</p>
</div>
<div class="row">
<p class="Login_title">Palavra-passe:</p>
<p>#??#PASSFIELD#??#</p>
</div>
<div class="row">
<p class="Login_title">#??#CONFIRMPASSLABEL#??#</p>
<p>#??#CONFIRMPASSFIELD#??#</p>
</div>
<div class="row">
<p class="login_bt">#??#FORGOTBUTTON#??#</p>
<p>#??#MSGERRLABEL#??#</p>
</div>
</div>
é HTML puro:
ativo
O Template tem Imagens na área do Conteúdo:
ativo
2º Passo
- configurar os parâmetros
Nos Parâmetros no nó Internet é necessário configurar o seguinte parâmetro:
Login: Template para alterar password: Internet_Password
Após as alterações anteriores e reiniciar do IIS a página de alterar a password fica com o seguinte aspeto:
Funcionalidade disponível nas gamas PHC CS:
Advanced e Enterprise
Subscrição de PHC On:
Não
Ambiente de teste:
Versão de software PHC CS Web: 22
Versão do browser: Chrome 62.0.3202.94
Versão do Android (ou IOS): 6.0
