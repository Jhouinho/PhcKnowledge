---
title: Pesquisaavançada(Interna)
source: pesquisaavançada(interna).htm
tipo: Manual Técnico
idioma: PT
---

# Pesquisaavançada(Interna)

Pesquisa Avançada (interna)

|  |
| --- |
| Pesquisa Avançada (interna) |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção permite ter acesso a toda a informação que existe na base de dados relativamente a um determinado assunto. Qualquer dúvida que exista sobre determinado assunto se houver resposta poderá ser esclarecida, bastando para tal escrever uma ou várias palavras-chave para executar a procura.    **Texto a procurar**  Neste local deve indicar qual o texto a procurar. É aqui que deve escrever uma ou várias palavras-chave que vão ser procuradas na base de dados.  Por baixo da caixa de texto passa a ser mostrado um histórico das pesquisas efetuadas.    O **Tipo de procura** pode ser feito por *Todas as palavras* (procura qualquer uma das palavras indicadas individualmente, sem qualquer ordem específica), *Qualquer palavra* (basta encontrar uma das palavras da frase) ou pela *Frase exata* (neste caso a frase indicada tem que existir no texto na sequência indicada) colocada no texto a procurar.    Nas **Opções avançadas**deve definir o tempo de procura, as opções disponíveis são: - Agrupa os resultados por área;  - Menos de um mês;  - Menos de seis meses;  - Menos de um ano;  - Mais de um ano.       A procura pode ser realizada mediante as áreas que se pretende:    * Base de dados técnica  * Fórum  * Pedidos de assistência Técnica  * Chamadas telefónicas  * Perguntas Frequentes  * Anúncios  * Conteúdos multimédia  * Notícias      Nos botões  poderá marcar e desmarcar todos, respetivamente.    Para utilizar o **Full text search** é necessário que esta opção esteja corretamente instalada e configurada no PHC CS Desktop. No PHC CS Web é necessário ativar os seguintes parâmetros:  **Suporte extranet web**   - Pesquisa avançada: usa dados da busca instantânea  **Suporte intranet web**   - Pesquisa avançada: usa dados da busca instantânea  - Pesquisa avançada: chave de procura de registos na busca instantânea (deve ser definida a mesma chave da aplicação PHC CS Desktop)  *Nota:* Quando está a ser utilizada a pesquisa com o Full text search, em cada resultado surge um botão "Ver mais", onde é possível ver a informação disponibilizada, sem ter a necessidade de ir para outro ecrã.    Para **Executar a procura** basta clicar nesta opção.  Ser-lhe-á apresentada uma grelha com os resultados encontrados.    Ao iniciar a Pesquisa Avançada a partir do menu, as várias áreas ficam sempre visíveis, isto é, o campo "Outras Opções" encontra-se aberto, para ser mais rápida a seleção das áreas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pesquisa Avançada (interna)' ) |