---
title: Pessoalpúblico(Módulodescontinuado)
source: pessoalpúblico(módulodescontinuado).htm
tipo: Manual Técnico
idioma: PT
---

# Pessoalpúblico(Módulodescontinuado)

Pessoal Público (módulo Descontinuado)

|  |
| --- |
| Pessoal Público (módulo Descontinuado) |

|  |
| --- |
| Dado que a Gestão dos Funcionários Públicos se baseia em procedimentos bastante diferentes dos utilizados para a Gestão dos Funcionários Não Públicos, existe o Módulo de Pessoal Público, para que a gestão destes Funcionários seja efectuada de forma adequada.    O Módulo de Pessoal Público, abarca um conjunto de opções que têm como objectivo primordial o envio da Relação Contributiva e da Guia de Pagamento para a Caixa Geral de Aposentações.    A Relação Contributiva e a Guia de Pagamento, são calculadas com base em [Códigos de Situação](códigosdesituaçãocga.htm), Códigos estes que se encontram, regra geral, associados ou ao [Status de Funcionários](tabeladestatusdefuncionários.htm), ou aos [Códigos para Vencimento](códigosparavencimentos(comomódulopessoalpúblico).htm).    Para mais informação acerca deste módulo, consulte [Requisitos para utilização do Módulo Pessoal Público](requisitosparautilizaçãodomódulopessoalpúblico.htm), [Parâmetros de Pessoal Público](ParâmetrosdoPessoal.htm#ppublico), [Tabelas Salariais da Função Pública](tabelassalariaisdafunçãopública.htm), [Tabela de Códigos de Situação Cga](tabeladecódigosdesituaçãocga.htm) e [Relações Contributivas Cga](relaçõescontributivascga.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pessoal Público (módulo Descontinuado)' ) |