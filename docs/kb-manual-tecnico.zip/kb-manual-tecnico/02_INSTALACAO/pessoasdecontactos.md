---
title: Pessoas de Contactos
source: pessoasdecontactos.htm
tipo: Manual Técnico
idioma: PT
---

# Pessoas de Contactos

Esta opção permite
introduzir
registos, com toda a informação relativa às Pessoas que estejam ou possam vir a estar relacionadas com os
Contactos
, no decorrer normal da atividade comercial.
Muitas vezes, pela ligação que estabelecem entre os vendedores da empresa e os Contactos, são consideradas como a "cara" dos Contactos registados na base de dados comerciais da empresa.
O utilizador ainda poderá interagir com o registo ao
consultar
o mesmo.
Nota
: Se os acessos estiverem a ser controlados por área, apenas aparecem ao utilizador, independentemente dos campos ou métodos utilizados na pesquisa, os registos que pertencem à sua área; ou seja, que pertencem à área definida na sua ficha de utilizador na aplicação em PHC CS Desktop.
Ecrã em modo de introdução/alteração
Quando se acede a este ecrã, em modo de introdução, o utilizador dispõe dos seguintes campos:
Ainda neste ecrã é possível, entre outras funcionalidades, criar um novo registo na tabela de pessoas.
Nome
Este local é de preenchimento obrigatório e permite guardar o nome da Pessoa que se está a registar.
Número
Número interno da Pessoa. Esta numeração é automaticamente atribuída pela aplicação e é apenas de leitura.
Tratamento da pessoa
Neste campo pode selecionar-se o tratamento a usar com a Pessoa, ou seja, qual a forma de tratar a Pessoa, se por Sr. ou por Sr. Dr., etc...
É também possível criar uma forma de tratamento nova através do botão
.
Nome do Contacto
Neste local pode digitar o nome do Contacto ao qual esta Pessoa pertence ou, caso essa informação não se encontre disponível, efetuar uma procura de Contactos através do botão
. Depois de gravado o registo, este campo assume a função de um Link, permitindo aceder diretamente à tabela de
Contactos
, ao registo do Contacto correspondente.
Número
Este é o número interno do Contacto, sendo apenas de leitura.
Função
Função que desempenha a Pessoa na empresa ou entidade que representa o Contacto em si. Neste campo, como recurso do botão
, é possível criar novos registos para a Função.
Morada
Campo para inserir a Morada completa da Pessoa.
Localidade
Campo para registar a Localidade da morada da Pessoa.
Código Postal
Este campo serve para introduzir o código postal da morada da Pessoa.
Telefone casa
Número de telefone de casa da Pessoa.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telefone da empresa
Número de telefone do trabalho da Pessoa.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telemóvel
Campo para registar o número de telemóvel.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Outro meio de contacto
Local para digitar outro meio de contacto.
Área do utilizador
O utilizador tem a possibilidade de organizar os seus contactos/pessoas por Área. Poderá selecionar uma área já existente, ou, através do ícone
criar um novo registo.
Quando o utilizador controla os acessos por área, na introdução de um novo registo, este campo é automaticamente introduzido pelo sistema, com a área que o utilizador tem definida na sua ficha de utilizador na aplicação PHC CS Desktop, não deixando gravar o registo caso o utilizador altere o seu valor.
Fax
Número do fax da Pessoa.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Site
Endereço do site na Internet.
E-mail
Endereço de correio eletrónico.
Permite introduzir um texto longo com as observações que o utilizador pretender sobre a pessoa.
Ecrã em modo de Consulta
Quando o utilizador acede, por modo de consulta, é possível através de
, realizar as seguintes ações:
Enviar Email
Nesta opção são mostrados os emails do cliente, após selecionar os destinatários é aberto o ecrã de envio de email, com os campos destinatários, Assunto e Mensagem já preenchidos, permitindo assim enviar um email com os dados do cliente selecionado.
Nota:
esta opção também está acessível na área de próximas ações quando se grava um registo.
Quando se acede à opção
Pessoas
pode efetuar-se a pesquisa de um registo pelos seguintes campos:
- Nome da Pessoa;
- Função;
- Nome do Contacto;
- Número da pessoa;
- Tratamento;
No ecrã de Pessoas, em modo de consulta, estão também disponíveis ao utilizador as seguintes opções:
Permite a consulta de visitas efetuadas e por realizar. É possível fazer esta consulta desde sempre ou entre datas. Após a validação do que se pretende basta clicar em
Visitas
.
Esta opção dá-lhe acesso à
introdução de visitas
.
O utilizador tem também a possibilidade de usufruir das
opções de registo
, bem como pesquisar,
alterar
e/ou apagar o registo. Poderá ainda introduzir e visualizar os comentários associados ao registo selecionado.
Contactos do Crm Web
