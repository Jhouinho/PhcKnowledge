---
title: "Phc Cs: Análise e Alterações do Despacho Nº 8632-2014"
source: phccsanáliseealteraçõesdodespachonº8632-2014.htm
tipo: Manual Técnico
idioma: PT
---

# Phc Cs: Análise e Alterações do Despacho Nº 8632-2014

Através do
Despacho nº 8632/2014 publicado em Diário da Republica,2ª série, nº 126 de 03 de Julho
, que revoga o
Ofício 50.001/2013
, a Autoridade Tributária e Aduaneira veio definir e esclarecer alguns pontos referentes aos programas de faturação, no que concerne ao registo e criação de documentos emitidos, e outras questões técnicas e requisitos a observar pela aplicação.
Tendo em conta a complexidade técnica do documento, e após análise do mesmo, apresentamos as novas exigências face ao Ofício 50.001/2013 de 04 de Julho, sendo que, no presente documento, nos focamos apenas nos novos pontos acrescentados no despacho acima identificado.
Em cada uma das zonas, para além de indicar quais as novas alterações deste despacho, são reforçados alguns pontos que achamos importante reter. Os pontos perante os quais o PHC já responde e que não haja especial atenção por parte do utilizador, serão omissos neste documento.
