---
title: Phccsdesktop
source: phccsdesktop.htm
tipo: Manual Técnico
idioma: PT
---

# Phccsdesktop

Phc Cs Desktop

|  |
| --- |
| Phc Cs Desktop |

|  |
| --- |
| Em conformidade com o software PHC, nesta versão em todas as suas gamas, também o manual, designado único, detém agora informação relativa a todos os módulos.   Assim, independentemente do módulo adquirido, o utilizador deparar-se-á com um manual geral com muita informação.     O manual encontra-se dividido em três grandes grupos: - Navegação e Supervisão  - Funcionalidades Principais  - Módulos     Os dois primeiros tópicos do manual centram-se na **navegação e supervisão** do software.   Relativamente à [navegação](opçõesglobais.htm), esta visa facilitar a aprendizagem inicial e a utilização rápida e eficaz do software no dia a dia. Encontram-se explicadas nesta área as opções do menu sistema, a forma mais rápida de trabalhar e se mover nos diversos ecrãs bem como outras opções que são comuns a todas as aplicações PHC.   No que diz respeito à [supervisão](supervisão.htm), é neste local que são introduzidas as funcionalidades e opções relativas à instalação, manutenção e parametrização da aplicação, comuns a todas as aplicações. A grande maioria destas funcionalidades são objecto da responsabilidade do administrador do sistema, que moldará a aplicação de acordo com as necessidades estruturais de cada organização.    De seguida, pertencem à estrutura deste manual os tópicos que explicam as funcionalidades principais comuns à maioria dos módulos, por área de negócio, como por exemplo a [Gestão de Clientes](gestãodeclientes.htm), de  [Fornecedores](fornecedores.htm), [Dossiers Internos](dossiersinternos.htm), etc...  No fim da linha deste grupo existem três ferramentas comuns com as quais o utilizador pode optimizar o uso do software, são elas as [Impressões definidas do Utilizador](impressõesdefinidaspeloutilizador(idu).htm), o Assistente de [E-mails](assistentedee-mails.htm) e a Tabela de [Códigos Postais](tabeladecódigospostais.htm).    O último grupo apresenta diversos manuais que expondo individualmente módulo a módulo se encontram ligados aos dois grupos anteriores já mencionados através dos respectivos links e notas explicativas.    Concluindo, o manual único sustenta uma estrutura simples e objectiva, de forma a proporcionar ao utilizador o conhecimento necessário à rápida utilização e eficaz manuseamento da aplicação. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Phc Cs Desktop' ) |