---
title: Phccsmanufactorephccsdesktopnamesmabasededados
source: phccsmanufactorephccsdesktopnamesmabasededados.htm
tipo: Manual Técnico
idioma: PT
---

# Phccsmanufactorephccsdesktopnamesmabasededados

Phc Cs Manufactor e Phc Cs Desktop na Mesma Base de Dados

|  |
| --- |
| Phc Cs Manufactor e Phc Cs Desktop na Mesma Base de Dados |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| De modo a simplificar a logística de backups (um só ficheiro mdf) e facilitar o código (x-base ou sql) das implementações que deixa de ter a referência às bases de dados quanto interagem com o SQL é possível incluir todas as tabelas do modelo de dados do PHC CS Manufactor na mesma base de dados SQL (ficheiros mdf e ldf) juntamente com as tabelas do PHC CS Desktop.     Além deste objetivo, existe outro relacionado com os templates que a PHCdisponibiliza para o PHC CS Web, pois estes vão por defeito programados nesta premissa.    Desta forma, para clientes atuais com as duas plataformas instaladas em separado, caso se pretenda juntar todas as tabelas numa só base de dados SQL, basta executar o PHC CS Manufactor, na linha de comando, com o parâmetro **ChangeDB**.    *Exemplo*:  No sistema operativo do computador através da opção Executar (Run) ou abrir o Command prompt e colocar o seguinte caminho:   C:\ManufactorXX\phcexecutive.exe CHANGEDB    Ao entrar na aplicação é disponibilizado um ecrã de confirmação.          Este processo (ChangeDB) é demorado e exige que o disco do computador tenha disponível espaço igual ao tamanho ocupado pelas duas bases de dados SQL. Convém realçar que não devem estar utilizadores a trabalhar em nenhuma das plataformas e é essencial a criação prévia de backups das bases de dados.    A configuração e instalação da integração entre as duas plataformas continua a ser necessária, pois todo o motor de integração (triggers de conexão) continuam a existir. Cada plataforma verá, no seu dicionário de dados, apenas as suas tabelas. No PHC CS Web o dicionário disponível é apenas o do PHC CS Desktop. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Phc Cs Manufactor e Phc Cs Desktop na Mesma Base de Dados' ) |