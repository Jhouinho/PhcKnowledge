---
title: Phccsweb
source: phccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Phccsweb

Phc Cs Web

|  |
| --- |
| Phc Cs Web |

|  |  |  |
| --- | --- | --- |
| O Software PHC CS Web contém ferramentas que permitem o acesso e controlo da informação através da Internet. Desde a informação de gestão à contabilidade, CRM, bem como encomendas de clientes ou suporte técnico, tudo poderá estar disponível com a máxima segurança a partir de qualquer local e de qualquer dispositivo.    Com as inúmeras vantagens que a aplicação proporciona aos utilizadores, continuamos a acreditar que podemos acrescentar mais valor com a existência de um Manual dedicado à aplicação. Com este, pretendemos explicar, ajudar e potenciar todas as vantagens já conhecidas pelos utilizadores.     Visando facilitar por exemplo, a instalação, a configuração e até mesmo a navegação, apresentamos a estrutura do manual PHC CS Web, organizado pelos seguintes temas:   [Navegação nas aplicações](navegaçãonasaplicações.htm)  [Instalação e Configurações do Phc Cs Web](instalaçãoeconfiguraçõesdophccsweb.htm)  [Menu da aplicação](menudaaplicação.htm)  [Análises](análises.htm)  [Framework PHC CS Web](frameworkphccsweb.htm)  [Configuração](configuração.htm)  [Minha opções](minhasopções.htm)  [Comunidade](comunidade.htm)        |  |  | |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Phc Cs Web' ) |