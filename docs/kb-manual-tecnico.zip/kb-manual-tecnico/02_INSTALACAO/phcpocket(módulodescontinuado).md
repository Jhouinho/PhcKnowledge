---
title: Phcpocket(Módulodescontinuado)
source: phcpocket(módulodescontinuado).htm
tipo: Manual Técnico
idioma: PT
---

# Phcpocket(Módulodescontinuado)

Phc Pocket (módulo Descontinuado)

|  |
| --- |
| Phc Pocket (módulo Descontinuado) |

|  |
| --- |
| Este manual visa explicar o funcionamento das aplicações PHC para PDA.         As aplicações disponíveis são as seguintes:  [Pocket Encomendas](pocketencomendas.htm)  [Pocket Análises](pocketanálises.htm)  [Pocket Crm](pocketcrm.htm)  [Pocket Suporte](pocketsuporte.htm)    Quando na aplicação windows existem validações de dois ou dos três módulos de Pocket, ao sincronizar, passam para o PDA as opções de todos os módulos adquiridos. Desta forma o PHC Pocket assume o formato de exa único concentrando no seu menu inicial as opções de todos os módulos.                     Existem ainda as opções comuns a todas as aplicações pocket:        Relativamente á **base de dados** as aplicações PHC Pocket utilizam o motor de base de dados SQLite.    A base de dados é criada na primeira vez em que a aplicação tenta aceder a esta e é composta apenas por um ficheiro com o nome **phcpocket.db** . Não é necessário instalar o motor do SQLite.    Ao abrir qualquer ecrã pela primeira vez após sincronização, não são mostrados quaisquer registos. É necessário seleccionar os critérios de pesquisa para visualizar os registos que se pretende. Nas vezes seguintes, os registos consultados e que couberam nos critérios definidos são disponibilizados automaticamente ao entrar no ecrã. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Phc Pocket (módulo Descontinuado)' ) |