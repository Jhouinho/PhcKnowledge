---
title: Planodecontasparalelo
source: planodecontasparalelo.htm
tipo: Manual Técnico
idioma: PT
---

# Planodecontasparalelo

Plano de Contas Paralelo

|  |
| --- |
| Plano de Contas Paralelo |

|  |
| --- |
| A Funcionalidade explicada neste tópico só se encontra disponível na gama Enterprise.    O Plano de Contas Paralelo do módulo de Contabilidade foi desenvolvido para gerir uma tabela suplementar de contas, sobre as quais se vão processar na contabilidade. Esta funcionalidade permite a inserção de todo o tipo de contas, similar ao P.O.C., e com as contas alternativas da Empresa.    Deverá inicialmente instalar o respectivo [acesso](AcessosdoContabilidade.htm#mcopcparalelo), através da rotina de [Instalação e Manutenção](instalaçãoemanutenção.htm).    Depois de criar as contas no plano de contas paralelo poderá associar uma conta do [Plano de contas](constituiçãodatabeladoplanodecontas.htm) ao Plano de contas Paralelo, conforme o exemplo.        Ao associar as contas, os movimentos que existem na conta do plano de contas passaram para o plano de contas paralelo.    A partir desta tabela, deverá criar as contas, preenchendo os campos **Conta**, com o nº da conta que pretende criar, **Descrição**, com a descrição da conta a criar, e eventuais **Observações**. Isto significa que pode criar um segundo plano de contas interno, para, por exemplo, possuir o plano de contas de outro país, com a possibilidade de executar lançamentos automáticos entre os dois.     Tem assim a possibilidade, através do ícone , de obter extractos de movimentos de contas, e, através da opção [Balancetes - Plano Paralelo](balancetes-planoparalelo.htm), obter balancetes entre contas.     Se existir uma conta do plano paralelo que esteja associada a várias contas do plano geral, ao gerar o extrato, através do botão no ecrã de Plano de Contas Paralelo, a aplicação apresenta nesse extrato o valor de todas as contas do plano de contas geral a que essa conta esteja associada.    A movimentação das contas do Plano Paralelo, é executada através da indicação destas contas no Plano de Contas, no campo **Conta no Plano Paralelo**.    O Plano de contas Paralelo é um plano anual, ou seja, todos os anos terá que ser criado um plano de contas, para tal, existe a rotina Criar Plano de Contas.  Deverá definir qual o Plano que pretende criar, se o Plano de Contas ou o Plano de Contas Paralelo.        O utilizador terá que digitar o ano da contabilidade de origem que pretende copiar para o(s) ano(s) da contabilidade destino.    *Exemplo*: O ano da contabilidade de origem terá que ser o ano de trabalho.  O ano de trabalho da contabilidade é 2003, logo o ano da contabilidade de origem será 2003. Supondo que quer criar o plano de contas ou o Plano de Contas Paralelo para o próximo ano (2004), terá que digitar o ano pretendido para o ano de contabilidade destino, conforme a imagem.    Basta clicar em OK e serão criadas todas as contas do plano de contas do ano de origem para o ano destino.  Ao entrar no ano 2004, ou seja contabilidade destino, terá o plano de contas criado tendo por base o plano de contas do ano 2003. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Plano de Contas Paralelo' ) |