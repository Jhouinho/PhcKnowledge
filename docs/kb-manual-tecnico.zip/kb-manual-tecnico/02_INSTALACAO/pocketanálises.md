---
title: Pocketanálises
source: pocketanálises.htm
tipo: Manual Técnico
idioma: PT
---

# Pocketanálises

Pocket Análises

|  |
| --- |
| Pocket Análises |

|  |
| --- |
| A aplicação PHC Pocket Análises permite:    Consultar análises avançadas com listagens;  Consultar snapshots de informação, ou seja, visualização de um único valor;  Sincronizar apenas uma das análises para informação no momento;  Consulta dos dados em off-line (desconectado com a sede), ou seja, dos dados da última vez em que actualizou a listagem;  Sincronizar com o sistema central via telefone-GPRS ou Activesinc.        No menu **Outros** existem ainda as seguintes opções:    [Impressora](impressõesnopocket.htm)  [Backup](backupdedadosdopocket.htm)  [Sincro](sincronizaranálises.htm)  [Personalização](personalizaçãopocket.htm)    For fim, é ainda através deste ecrã que se pode sair e fechar a aplicação Pocket.    Existem 3 componentes necessários ao correcto funcionamento da aplicação:    Sincronizador  Este componente é um Web Service chamado Pocket Services.    [Back Office](backofficepocketanálises.htm)  Este componente chamado de Back Office não é mais do que algumas opções existentes no módulo Supervisor, por exemplo a criação das análises avançadas.    PDA  Este componente é o próprio PDA onde irá ser instalada a aplicação PHC Pocket Análises.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre como controlar a sua empresa a partir das Análises do Pocket, através do nosso [filme](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=752335ge%3acf.f27c.6175.1g6) ou da nossa [idirecto](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=68c982fdb39.d63c.eg45.269). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pocket Análises' ) |