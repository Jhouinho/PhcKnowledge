---
title: Pocketcrm
source: pocketcrm.htm
tipo: Manual Técnico
idioma: PT
---

# Pocketcrm

Pocket Crm

|  |
| --- |
| Pocket Crm |

|  |
| --- |
| A aplicação PHC Pocket CRM permite:    Consultar, alterar e introduzir registos na tabela de Contactos do módulo Crm Comercial;  Consultar, alterar e introduzir registos na tabela de Pessoas;  Consultar, alterar e introduzir registos na tabela de Visitas;  Visualizar a agenda com as visitas agendadas.        No menu **Outros** existem ainda as seguintes opções:    [Impressora](impressõesnopocket.htm)  [Backup](backupdedadosdopocket.htm)  [Sincro](sincronizaçãonopocketcrm.htm)  [Personalização](personalizaçãopocket.htm)    For fim, é ainda através deste ecrã que se pode sair e fechar a aplicação Pocket.    Existem 3 componentes necessários ao correcto funcionamento da aplicação:    **Sincronizador**  Este componente é um Web Service chamado Pocket Services.    [Back Office](backofficepocketcrm.htm)  Este componente chamado de Back Office não é mais do que algumas opções existentes no módulo Supervisor.    **PDA**  Este componente é o próprio PDA onde irá ser instalada a aplicação PHC Pocket Encomendas.     Se tiver [PHC ON](oqueéophcon.htm) poderá aprender um pouco mais sobre todas as funcionalidades deste módulo, através do nosso [filme](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=%3ab92b462g6%3a.cfcc.2715.35%3a) ou da nossa [iDirecto](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=g8%3a76182g39.453c.44f5.7g8). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pocket Crm' ) |