---
title: Pocketencomendas
source: pocketencomendas.htm
tipo: Manual Técnico
idioma: PT
---

# Pocketencomendas

Pocket Encomendas

|  |
| --- |
| Pocket Encomendas |

|  |
| --- |
| A aplicação PHC Pocket Encomendas permite:  Consultar e alterar dados de [Clientes](clientesnopda.htm)  Consultar Contas Correntes não regularizadas de clientes  Consultar e alterar dados dos [Artigos](artigos.htm) (stocks)  Consultar promoções em vigor para cada artigo  Emitir e alterar [Encomendas](encomendas.htm) de Clientes  Criar [Recibos](recibosnopocketencomendas.htm).        No menu **Outros** existem ainda as seguintes opções:    [Impressora](impressõesnopocket.htm)  [Backup](backupdedadosdopocket.htm)  [Sincro](sincronização.htm)  [Personalização](personalizaçãopocket.htm)    For fim, é ainda através deste ecrã que se pode sair e fechar a aplicação Pocket.    Existem 3 componentes necessários ao correcto funcionamento da aplicação:    Sincronizador  Este componente é um Web Service chamado Pocket Services.    [Back Office](backofficepocketencomendas.htm)  Este componente chamado de Back Office não é mais do que algumas opções existentes no módulo Supervisor.    PDA  Este componente é o próprio PDA onde irá ser instalada a aplicação PHC Pocket Encomendas.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre «o Pocket Encomendas», carregando [aqui](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=d41c9%3a1c159.8879.e145.65g). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pocket Encomendas' ) |