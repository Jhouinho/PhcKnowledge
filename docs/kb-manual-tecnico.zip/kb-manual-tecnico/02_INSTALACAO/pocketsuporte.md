---
title: Pocketsuporte
source: pocketsuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Pocketsuporte

Pocket Suporte

|  |
| --- |
| Pocket Suporte |

|  |
| --- |
| A aplicação PHC Pocket Suporte permite:  Consultar [Pedidos de Assistência Técnica](patsnopocketsuporte.htm)  Consultar e alterar [Intervenções](intervençõesnopocketsuporte.htm)  Consultar, introduzir e alterar [Equipamentos](equipamentosnopocketsuporte.htm)  Consultar, introduzir e alterar [Dossiers Internos](dossiersnopocketsuporte.htm)  Consultar as [Instalações](instalaçõesnopocketsuporte.htm)  Consultar a  [Agenda](agendanopocketsuporte.htm)  Consultar os [Clientes](clientesnopocketsuporte.htm)  Consultar os [Artigos](artigosnopocketsuporte.htm)        No menu **Outros** existem ainda as seguintes opções:    [Impressora](impressõesnopocket.htm)  [Backup](backupdedadosdopocket.htm)  [Sincro](sincronizaçãonopocketsuporte.htm)  [Personalização](personalizaçãopocket.htm)    Por fim, é ainda através deste ecrã que se pode sair e fechar a aplicação Pocket.    Existem 3 componentes necessários ao correcto funcionamento da aplicação:    **Sincronizador**  Este componente é um Web Service chamado Pocket Services.    **Back Office**  Este componente chamado de Back Office não é mais do que um conjunto de opções existentes no módulo Supervisor.    **PDA**  Este componente é o próprio PDA onde irá ser instalada a aplicação PHC Pocket Encomendas.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre mobilidade e autonomia da sua equipa técnica, carregando [aqui](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=2%3a6g91b7634.b56c.beb5.f7c). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Pocket Suporte' ) |