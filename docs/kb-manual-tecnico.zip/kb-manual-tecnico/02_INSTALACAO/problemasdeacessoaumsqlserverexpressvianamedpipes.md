---
title: Problemasdeacessoaumsqlserverexpressvianamedpipes
source: problemasdeacessoaumsqlserverexpressvianamedpipes.htm
tipo: Manual Técnico
idioma: PT
---

# Problemasdeacessoaumsqlserverexpressvianamedpipes

Problemas de Acesso a um Sql Server Express Via Named Pipes

|  |
| --- |
| Problemas de Acesso a um Sql Server Express Via Named Pipes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico fornece-lhe uma dica que o vai permitir ultrapassar problemas de acesso a um SQL Server Express via Named Pipes.    Ou seja, no caso de ter named Pipes activos, na criação do ODBC, na 1ª página, no campo "Server" deve indicar o caminho para instância SQL, da seguinte forma:    Ex: \\ServerName\pipe\MSSQL$SQL2005\sql\query    No **ServerName** deve colocar o nome do computador onde está instalado o SQL. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Problemas de Acesso a um Sql Server Express Via Named Pipes' ) |