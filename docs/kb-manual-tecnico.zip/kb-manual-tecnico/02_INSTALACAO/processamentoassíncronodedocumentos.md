---
title: Processamentoassíncronodedocumentos
source: processamentoassíncronodedocumentos.htm
tipo: Manual Técnico
idioma: PT
---

# Processamentoassíncronodedocumentos

Processamento Assíncrono de Documentos

|  |
| --- |
| Processamento Assíncrono de Documentos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A aplicação PHC permite que os Documentos de Faturação, Documentos de Compra e Dossiers Internos sejam processados em modo assíncrono, o que confere uma maior rapidez, relativamente ao tempo que passa entre a ordem de gravação e o controlo da aplicação voltar ao utilizador.    É verdade que a gravação e consequente registo dos movimentos de stock e conta corrente, associados a um Documento, pode ser consumir tempo precioso. E isso torna-se tão mais notório quanto maior é a quantidade de informação existente nessa área. É por isso que pode ser tão importante, o facto de o utilizador poder ter o controlo da aplicação no momento quase imediato que se segue à ordem de gravação do documento.    Na prática, é precisamente isso que a aplicação PHC permite: após a ordem de gravação, enquanto "nos bastidores" a aplicação se encarrega de registar os movimentos de stock e conta corrente associados ao documento, o utilizador pode passar à ação seguinte, sem ter de esperar que o processo de gravação do documento esteja terminado. Quando finalmente o processo de gravação do documento está completo é apresentada uma breve mensagem que nem sequer interfere com as presentes ações do utilizador.    Para que isso seja possível, é necessário ativar o parâmetro da Configuração geral "Usa processamento assíncrono (Reentrar no Programa e reinstalar triggers)."        Importa salientar a importância da reinstalação dos triggers, uma vez que a alteração deste parâmetro tem influência direta na sua ação.    Para além disso, convém referir que este tipo de funcionamento pode dar origem a uma situação de lista de espera de documentos a serem processados, ou seja, se um utilizador (ou vários utilizadores) lançar muitos documentos de seguida, eventualmente estará a gravar uma introdução, quando alguns dos documentos anteriores ainda não se encontram processados (a execução da lista é FIFO). Isto pode originar uma situação em que o utilizador (por iniciativa própria, ou eventualmente, por um motivo inesperado), tenha de encerrar a aplicação sem que todos os documentos tenham sido processados.     Nesse caso, quando o utilizador (o mesmo, ou outro qualquer, no mesmo computador), voltar a entrar na aplicação, é emitida uma mensagem a indicar que existem documentos não processados e que a aplicação procederá ao seu processamento, sem que o trabalho do utilizador seja prejudicado.    Com a ativação daquele parâmetro, ficam disponíveis as opções "Monitor de Processamento de Documentos de Faturação" (desde que o utilizador tenha acesso a alterar Documentos de Faturação), "Monitor de Processamento de Dossiers Internos" (desde que o utilizador tenha acesso a alterar Dossiers Internos) e "Monitor de Processamento de Documentos de Compra" (desde que o utilizador tenha acesso a alterar Documentos de Compra), sob os menus "Gestão/Outras opções de clientes", "Gestão/Outras opções de Dossiers Internos" e "Gestão/Outras opções de Fornecedores", respetivamente.    Esses monitores de processamento de documentos servem para processar documentos que eventualmente não tenham sido processados por alguma razão inesperada (por exemplo, o facto de a tabela que guarda os documentos a serem processados - por se ter saído da aplicação sem que todos os documentos tivessem sido processados), ficar corrompida, e ter de ser eliminada, uma vez que se trata de um ficheiro do tipo DBF, que está sujeito a isso.    Concluindo, trata-se de mais uma funcionalidade das aplicações PHC, que serve para incrementar a performance e a produtividade. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Processamento Assíncrono de Documentos' ) |