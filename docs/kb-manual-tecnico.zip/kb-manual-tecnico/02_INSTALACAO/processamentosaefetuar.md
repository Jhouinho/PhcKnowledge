---
title: Processamentosaefetuar
source: processamentosaefetuar.htm
tipo: Manual Técnico
idioma: PT
---

# Processamentosaefetuar

Processamentos a Efetuar

|  |
| --- |
| Processamentos a Efetuar |

|  |
| --- |
| **Processamentos a Efetuar**    Os processamentos possíveis de efetuar são: - Instalação e Manutenção de Tabelas     Esta opção, na sua configuração é um pouco diferente da original, pelo que aqui ficam explicadas as principais diferenças.    Ao aceder ao ecrã as opções de instalação e manutenção utilizadas na última configuração de processamento aparecem logo selecionadas.        Através do ecrã de instalação e manutenção, o utilizador pode selecionar as tabelas e as opções que quer ver correr.  Conforme for procedendo à seleção das tabelas, de acordo com as opções de seleção: - Tabelas do utilizador  - Principais  - Apenas os IDUs  - Não configurações  - Apenas os Filtros  - Configurações  - Todas     As tabelas vão ficando automaticamente selecionadas, desaparecendo a forma de poder desselecioná-las manualmente.    Depois de efetuada a configuração, o utilizador pode ainda proceder à operação que pretende no momento, através da opção **Execução Automática**.    Para mais informações, aceda por favor ao tópico *Funcionamento da Instalação e Manutenção*.   - Instalar as Opções para Gestão de Acessos  - [Backup](backupdebasededados.htm) de Bases de dados         Se possuir o **Módulo de Contabilidade** estarão disponíveis os seguintes processamentos:   Atualização Cambial de Saldos  Apuramento de I.V.A.   Integrar a Facturação a Clientes  Integrar as Compras a Fornecedores  Integrar as Contas Correntes de Vendedores  Integrar as Operações de Alienação/Abate de Imobilizado  Integrar as Regularizações de Letras a Pagar  Integrar as Regularizações de Letras a Receber  Integrar as Transferências Bancárias de Ordenados  Integrar as Transferências Conta-Caixa  Integrar as Transferências Conta-Conta  Integrar Novos Clientes  Integrar Novos Fornecedores  Integrar Novos Funcionários  Integrar Novos Profissionais  Integrar Novos Vendedores  Integrar os Adiantamentos a Fornecedores  Integrar os Documentos de Tesouraria  Integrar os Movimentos de Letras a Pagar  Integrar os Movimentos de Letras a Receber  Integrar os Movimentos de Reavaliações de Imobilizado  Integrar os Movimentos de Depreciações de Imobilizado  Integrar os Movimentos de Stock  Integrar os Pagamentos a Fornecedores  Integrar os Pagamentos a Vendedores  Integrar os Pagamentos de Contribuições à Segurança Social  Integrar os Processos de Tesouraria (só Enterprise)  Integrar os Recibos de Adiantamentos para Clientes  Integrar os Recibos de Ordenados  Integrar os Recibos de Outros Rendimentos  Integrar os Recibos Diversos  Integrar os Documento de Tesouraria de Vencimentos  Integrar os Recibos para Clientes  Integrar os Talões de Depósito  Verificação de Consistência no Plano de Contas     Se possuir o **Módulo de Imobilizado** estarão disponíveis os seguintes processamentos:   Processamento de Reavaliações  Processamento de Depreciações     Se possuir o **Módulo de Pessoal** estarão disponíveis os seguintes processamentos:   Exportar para ficheiro e lançar transferência bancária  [Processamento de vencimentos](configuraçãodoprocessamentodevencimentos.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Processamentos a Efetuar' ) |