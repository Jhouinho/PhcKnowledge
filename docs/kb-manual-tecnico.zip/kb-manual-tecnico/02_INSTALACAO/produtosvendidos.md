---
title: Produtosvendidos
source: produtosvendidos.htm
tipo: Manual Técnico
idioma: PT
---

# Produtosvendidos

Produtos Vendidos

|  |
| --- |
| Produtos Vendidos |

|  |
| --- |
| A opção de Produtos Vendidos, tem como filosofia base assentar num registo para cada produto vendido.   Este ficheiro será automaticamente actualizado pelos documentos de facturação, caso o utilizador assim o desejar (para isso é necessário ter instalado o módulo de gestão).   Se os produtos vendidos forem actualizados por documentos de facturação, pode-se configurar os Recibos para actualizarem o pagamento do produto vendido.   O lançamento via facturação é optativo, no entanto torna-se necessário para o funcionamento correcto de Vendedores e comissões. Para mais informações sobre esta opção vamos explicar a [Constituição da Tabela de Produtos Vendidos](constituiçãodatabeladeprodutosvendidos.htm) e as [Opções Disponíveis no Menu](opçõesdisponíveisnomenudeprodutosvendidos.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Produtos Vendidos' ) |