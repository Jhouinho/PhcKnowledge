---
title: Produto Vendido
source: produtovendido.htm
tipo: Manual Técnico
idioma: PT
---

# Produto Vendido

O registo de Produtos Vendidos contém a informação de venda de artigos, de acordo com os registos provenientes da aplicação
PHC CS Desktop
. No entanto, é possível ao utilizador
introduzir/alterar
alguns campos.
Quando o utilizador
consulta
o registo também poderá efetuar algumas ações com o mesmo.
Ecrã em modo de introdução/alteração
Ao introduzir/alterar um registo neste ecrã o utilizador tem ao seu dispor os seguintes campos:
Designação
Designação da referência. Este campo aparece quando o registo é proveniente do um documento ou seja, quando se trata de uma introdução direta de um registo campo "Designação" não está disponível.
Referência
Referência do artigo que foi vendido.
Nome e nº do cliente
Identificação do cliente.
Documento e nº do documento
Permite observar os dados do documento original.
Vendedor
Neste campo fica registado o nome do vendedor do cabeçalho do documento, ou se por opção das linhas do documento, que prevalece ao cabeçalho.
Data
Informa a data do movimento.
Quantidade
Informa o número de unidades que foram vendidas.
Valor unitário
Este campo informa o preço unitário do artigo, sendo um campo de leitura. Ou seja, o utilizador não o pode alterar.
Data Pagamento
Permite saber se o cliente já pagou este movimento.
Base sem descontos
Este campo informa do valor antes de descontos.
Total Líquido
Valor pelo qual o artigo foi vendido.
Total de Custo
Indica o total do custo para venda deste artigo.
Os campo que se indicam de seguida são apenas de leitura. Ou seja, o utilizador não os pode editar. Aparecem ao utilizador quando efetivamente contêm informação.
Movimento já pago em
Permite saber se o cliente já pagou este movimento. Este é um campo de leitura ou seja, o utilizador não o pode alterar.
Tabela de comissões
Serve para indicar a tabela de comissões que foi utilizada.
Valor Extra-comissão
Informa o valor da comissão extra do vendedor.
Valor já processado para comissão
Permite observar o valor das comissões processadas.
Classificação do documento
Indica a classificação de documentos de faturação do cliente.
Segmento de Mercado
Indica o Segmento de mercado do cliente.
Marca
Informação opcional que pode ou não ser utilizada na tabela do artigo.
Modelo
Informação opcional que pode ou não ser utilizada na tabela do artigo.
Linha de produto
Informação opcional que pode ou não ser utilizada na tabela do artigo.
Tipo de produto
Informação opcional que pode ou não ser utilizada na tabela do artigo.
Categoria
Informação opcional que pode ou não ser utilizada na tabela do artigo.
Data
Este campo data refere-se á data de Instalação.
Refª interna
Informa aqui qual a referência interna a que está associado o artigo.
(campo de renomeação nos Parâmetros Gerais da aplicação PHC CS Desktop)
Centro Analítico
Informa a que centro analítico pertence o artigo.
(campo de renomeação nos Parâmetros Gerais da aplicação PHC CS Desktop)
Ecrã em modo de Consulta
Tem a possibilidade de usufruir das
opções de registo
, bem como pesquisar,
alterar
e/ou apagar o registo. Poderá ainda introduzir e visualizar os comentários associados ao registo selecionado.
Contactos do Crm Web
