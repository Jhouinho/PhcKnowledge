---
title: Recalcularostockpordataehora
source: recalcularostockpordataehora.htm
tipo: Manual Técnico
idioma: PT
---

# Recalcularostockpordataehora

Recalcular o Stock por Data e Hora

|  |
| --- |
| Recalcular o Stock por Data e Hora |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este tópico tem como principal objetivo explicar como funciona o recalculo do stock por data e hora.    Para recalcular o stock por data e hora deve começar por ativar o [parâmetro](ParâmetrosdeStockseServiços.htm#PLRValoriza) **Utiliza valorização de Stocks por Data e Hora quando o custeio de stock é «Preço de Custo Ponderado» (re-instalar triggers)**, que vai permitir que cada movimento de stock guarde a informação do preço de custo ponderado, quantidade total e quantidade entrada até ao momento.    Os dados gerais, são gravados nos campos **Preço Custo Ponderado Geral**, **Stock Total** e **Total de Entradas** na tabela de Movimentos de Stock.    Os dados específicos, são guardados noutros campos na tabela de Movimentos de Stock, tendo em conta as seguintes configurações: - Se tiver o [parâmetro](ParâmetrosDeStocksEServiços.htm#PLRprcusto) **Utiliza o pr.custo ponderado por armazém (re-instalar triggers)** ativo, os dados por armazém são gravados nos campos **Preço Custo Ponderado por Armazém**, **Stock Total por Armazém** e **Total de Entradas por Armazém**.    - Se tiver o [parâmetro](ParâmetrosDeLotes.htm#PLRLotes) **Utiliza lotes (re-instalar triggers)** ativo, os dados por lote são gravados nos campos **Preço Custo Ponderado por lote**, **Stock Total por lote** e **Total de Entradas por lote**.    - Se tiver os parâmetros **Utiliza lotes (re-instalar triggers)** e **Utiliza o pr.custo ponderado por armazém (re-instalar triggers)** ativos, os dados por lote e armazém são gravados nos campos **Preço Custo Ponderado por Lote e Armazém**, **Stock Total por Lote e Armazém** e **Total de Entradas por Lote e Armazém**.     *Nota:* Estes campos são utilizados internamente e não estão vísiveis no ecrã de Movimentos de Stock.    Desta forma, a rotina de correção de stocks fica otimizada, pois a aplicação deixa de verificar todos os movimentos de stock para calcular o preço de custo ponderado atual e respetivas quantidades dos artigos.    Por exemplo, se aceder ao ecrã de **Verificação de Erros deste Artigo** ou ao ecrã de **Verificação de Erros no Stock Actual** e preencher o [campo](OpçõesDisponíveisNoMenuDeStocksEServiços.htm#PLRDtinicial) **Data inicial dos Movimentos de Stock** com "01.05.2012", a aplicação irá verificar todos os movimentos a partir dessa data e os movimentos anteriores que ainda não tenham os campos que guardam a informação do preço de custo ponderado, quantidade total e quantidade entrada preenchidos (isto porque a aplicação tem sempre de ir verificar os movimentos anteriores para conseguir atualizar corretamente os movimentos posteriores).    A rotina de correção de stocks atualiza esses campos, assim como o trigger da tabela de movimentos de stock (exceto se existirem movimentos com data e hora superior, nesse caso é necessário executar a rotina de correção de stocks para atualizar os novos campos).    Quando o [parâmetro](ParâmetrosDeCompras.htm#ascorrige) **Corrige custo de vendas de artigos comprados quando grava a compra (muito lento)** está ativo, ao gravar uma Compra ou ao executar a rotina de correção de stocks a aplicação considera a **Hora para stock** definida na Compra. Caso todos os movimentos de stock tenham os novos campos já atualizados, a rotina apenas verifica os movimentos a partir dessa data e hora mais o imediatamente anterior. O mesmo se verifica para a [opção de menu](OpçõesDisponíveisNoMenuDeCompras.htm#PLRCusto) **Actualizar o custo das vendas dos artigos desta compra** do ecrã de Compras.    Se o Dossier Interno está configurado com a [opção](ConfiguraçãodeDossiers.htm#ascorrigeaogravar) **Corrige custo de vendas de artigos quando grava o dossier**, ao gravar um dossier ou ao executar a rotina de correção de stocks a aplicação considera a **Hora para stock** definida no Dossier Interno. Caso todos os movimentos de stock tenham os novos campos já atualizados, a rotina apenas verifica os movimentos a partir dessa data e hora mais o imediatamente anterior. O mesmo se verifica para a [opção de menu](OpçõesDisponíveisnoMenudeDossiers.htm#actualizarcusto) **Actualizar o custo nas vendas dos artigos deste dossier** do ecrã de Dossiers Internos. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Recalcular o Stock por Data e Hora' ) |