---
title: Receber Faturas Phc em Xml
source: receberfaturasphcemxml.htm
tipo: Manual Técnico
idioma: PT
---

# Receber Faturas Phc em Xml

Este artigo explica realizar a importação de documentos de faturação enviados pela PHC em XML em compras.
A PHC vai passar a enviar documentos de faturação em XML, para que tal funcione é necessário configurar o sistema de acordo com as orientações fornecidas neste artigo.
Nos parâmetros gerais, na pasta compras, deve ser ativada a opção "Utiliza a receção e envio de documentos XML".
Deve criar uma pasta para a colocação dos ficheiros XML que serão enviados pela PHC. Por exemplo a pasta "c:\temp\".
Deve ser definido um código de conta-corrente para a importação de compras, como o código 55 ou outro à escolha. Este código deverá ter a configuração habitualmente usada em documentos de compras, e dever ter a configuração de documentos XML associada a este código de conta-corrente.
Na imagem seguinte, verificamos que existe uma configuração de documentos XML com o nome "Compras" associado ao código de conta-corrente Nº 55 com descrição "V/Fatura".
Na configuração do documento XML vamos usar como método de receção "ficheiro" e definir qual a pasta estipulada para os ficheiros XML enviados pela PHC.
No separador "Integração" da configuração de "Documentos XML", associaremos as configurações de ficheiros externos necessárias para importar as linhas e os cabeçalhos dos documentos. Por exemplo, vamos usar as duas configurações "XMLFN" e "XMLFO", respetivamente.
A "Configuração de Ficheiros Externos" para cabeçalhos nos "Dados Principais" deve estar configurado como tipo dados igual a "XML" e no separador "XML", deve ter a seguinte configuração:
Na configuração apresentada vamos ter funções x-base a aplicar em dois campos.
No campo moeda, para garantir que os documentos exportados com moeda "PTE ou Euro" são importados com a moeda correta, vamos ter o seguinte programa:
LPARAMETERS retval
if Upper(retval)="PTE OU EURO"
retval=m.ge_pteoueuro
endif
RETURN retval
No campo "NO" também vamos aplicar um programa. Isto porque a PHC deverá estar aberta como fornecedor com o número de contribuinte corretamente preenchido. O mesmo não deverá apresentar espaços. A função
x-base
visa verificar a existência do fornecedor PHC na tabela de fornecedores e caso não exista, cria o mesmo com um conjunto mínimo de dados. O código é o seguinte:
LPARAMETERS retval
LOCAL m.msel
m.retval=0
m.msel=""
If ExistCheck("502199326","fl.ncont","",.T.,"no")
m.retval=temp.no
Else
m.retval=U_nextno("fl.no","fl")
Do While .t.
If Existcheck(m.retval,"fl.no","",.T.,"no")
m.retval=m.retval+1
Else
Replace fl.no With m.retval
Exit
Endif
Enddo
Text To m.msel Noshow Textmerge
Insert Into fl (flstamp,no,estab,nome,morada
,local,codpost,ncont,nome2,telefone,nib)
Values ('<&ltu_stamp()>>',<&ltm.retval>>,0,'PHC-Software, S.A.','Lagoas Park, Edifício 3, Piso 2'
,'Porto Salvo','2740-266 Porto Salvo','502199326','PHC, SA','214724340','003300000004043992767')
endtext
If Not u_sqlexec(m.msel)
Messagebox("Erro ao criar o fornecedor PHC")
m.retval=0
Endif
Endif
fecha("temp")
RETURN retval
A configuração de ficheiros externos respeitante à importação de linhas também deverá ser estar configurada com o tipo de dados "XML" e ter na página "XML", a seguinte configuração:
As referências serão criadas de forma automática caso não existam na base de dados.
Para utilizar referências existentes, as referências PHC devem ser colocadas como códigos de barras principais e na configuração de linhas, trocar o campo "REF" pelo campo "CODIGO".
As referências PHC encontram-se disponíveis no seguinte
FTP
Para poder observar todos os descontos do documento de faturação emitido, deve colocar no parâmetro geral "Número de descontos nas linhas dos documentos de compra (0 a 3) (Fazer Instalação e Manutenção à tabela FO)", o "Valor da Variável Escolhida" como sendo 3, para usar 3 descontos nas linhas de compras.
Depois dos ficheiros serem gravados na pasta definida, a importação de documentos deve ser feita no menu de "Opções Diversas" no ecrã de "Compras", escolhendo a opção "Receber documentos via XML".
À medida que são importados, os ficheiros são renomeados acrescentando-se a extensão ".lido".
Para facilitar estas configurações é facultado um
template
com as mesmas. O ficheiro
ZIP
deverá ser importado em
templates
utilizando o botão "Importar" existente nesse ecrã. Após importação deverá apresentar os seguintes registos:
Gama e versão de software PHC em que foi testado: PHC Corporate 15
