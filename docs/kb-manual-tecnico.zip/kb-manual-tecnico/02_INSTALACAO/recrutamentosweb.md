---
title: Recrutamentos Web
source: recrutamentosweb.htm
tipo: Manual Técnico
idioma: PT
---

# Recrutamentos Web

O ecrã "Recrutamentos", apenas disponível nas gamas Advanced e Enterprise, permite configurar a informação de um recrutamento.
Para ter acesso a este ecrã, é necessário uma das seguintes configurações:
Se tiver a opção "Este utilizador é administrador do package Recursos Humanos", no separador "Dados Principais", no ecrã "Utilizadores do PHC CS Desktop, terá acesso a introduzir, alterar, consultar e apagar os vários recrutamentos;
Se for um interveniente registado no ecrã "Colaboradores" do PHC CS Desktop e for responsável num recrutamento, pode introduzir, alterar, consultar e apagar os recrutamentos de que é responsável;
Se apenas for um interveniente registado no ecrã "Colaboradores" do PHC CS Desktop, apenas visualiza os recrutamentos em que é interveniente e permite introduzir novos recrutamentos, não pode alterar ou apagar;
Se não for interveniente e apenas tenha a validação ao módulo Recrutamento Intranet, no ecrã "Utilizadores", separador "PHCS CS Web", pode introduzir novos recrutamentos.
Ecrã em modo de introdução
Título
Neste campo deve preencher o nome que designará o recrutamento e que aparecerá externamente.
Identificação do recrutamento
Neste campo deve preencher o nome que designará o recrutamento para efeitos de organização interna.
Subtítulo
Neste campo pode preencher uma especificação sobre o recrutamento, como a localicação, e que aparecerá externamente.
Empresa
Neste campo deve preencher qual a empresa que irá fazer recrutamentos. Na opção de pesquisa
pode procurar pela empresa existente ou procurá-la através de busca incremental colocando as primeiras letras do nome da empresa. As empresas são preenchidas no ecrã "Ficha Completa da Empresa" do PHC CS Desktop.
Função
Neste campo deve preencher qual a função para este recrutamento. Na opção de pesquisa
pode procurar pela empresa existente ou procurá-la através de busca incremental colocando as primeiras letras do nome da função. As funções são configuradas no ecrã "Funções" do PHC CS Desktop.
Local
Neste campo deve optar pelo local onde se irá passar o recrutamento ou criar um novo registo de localização a partir do botão
.
Departamento
Neste campo deve optar pelo departamento onde se irá recair o recrutamento ou criar um novo registo de localização a partir do botão
.
Situação
Neste campo deve optar pelo departamento onde se irá recair o recrutamento ou criar um novo registo de localização a partir do botão
.
Data de abertura
Neste campos deve preencher a data de início das candidaturas ao recrutamento.
Data de fecho das candidaturas
Neste campos deve preencher a data de fecho das candidaturas ao recrutamento.
Template do recrutamento
Neste campo deve preencher qual o
template
a usar para este recrutamento. Na opção de pesquisa
pode procurar pelo template já existente ou procurá-lo através de busca incremental colocando as primeiras letras do nome do template. Os templates são configuradas no ecrã "Templates de recrutamentos".
Requisitos de Recrutamento
Idade mínima
Neste campo poderá indicar uma idade mínima admíssivel do candidato.
Idade máxima
Neste campo poderá indicar uma idade máxima admíssivel do candidato.
Idade como requisito obrigatório
Ao ativar esta opção, estará a indicar que apenas os candidatos que tiverem a sua idade entre a idade mínima e máxima preenchidas são admissíveis ao recrutamento.
Habilitações
Nesta grelha deverá identificar as habilitações, formações e certificações que o candidato deverá possuir.
Habilitações Académicas
Neste campo poderá optar pelo registo de habilitação académica criado na tabela "Habilitações Académicas" do PHC CS Desktop, acessível a partir do menu "Tabelas" > "Recursos Humanos" > "Habilitações Académicas". Para adicionar um ou mais registos de habilitações académicas apenas terá de clicar no botão
Adicionar nova linha
, poderá ainda apagar as linhas existentes, se assim o pretender.
Grupo de seleção
Nesta opção poderá selecionar o grupo do qual faz parte a habilitação académica. O grupo de seleção é criado na configuração do registo da habilitação académica na tabela "Habilitações Académicas" do PHC CS Desktop, acessível a partir do menu "Tabelas" > "Recursos Humanos" > "Habilitações Académicas".
Obr.
Ao ativar esta opção, está a indicar que a habilitação académica que consta na llinha é obrigatória.
Outras Habilitações
Neste campo poderá optar pelo registo de outras habilitações criado na tabela "Outras Habilitações" do PHC CS Desktop, acessível a partir do menu "Tabelas" > "Recursos Humanos" > "Outras Habilitações". Para adicionar um ou mais registos de outras habilitações apenas terá de clicar no botão
Adicionar nova linha
, poderá ainda apagar as linhas existentes, se assim o pretender.
Grupo de seleção
Nesta opção poderá selecionar o grupo do qual faz parte a outra habilitação. O grupo de seleção é criado na configuração do registo da outra habilitação na tabela "Outras Habilitações" do PHC CS Desktop, acessível a partir do menu "Tabelas" > "Recursos Humanos" > "Outras Habilitações".
Obr.
Ao ativar esta opção, está a indicar que a outra habilitação que consta na linha é obrigatória.
Características do Recrutamento
Nesta grelha poderá optar pelas características para o recrutamento e colocar a respetiva informação que pretende do candidato.
Característica
Neste campo poderá optar pelo registo de características de recrutamento criado na tabela "Características de Recrutamento" do PHC CS Desktop. Para adicionar um ou mais registos de características apenas terá de clicar no botão
Adicionar nova linha
, poderá ainda apagar as linhas existentes, se assim o pretender.
Grupo de seleção
Nesta opção poderá selecionar o grupo do qual faz parte a característica do recrutamento. O grupo de seleção é criado na configuração do registo da característica do recrutamento na tabela "Características do recrutamento" do PHC CS Desktop, acessível a partir do menu "Tabelas" > "Recursos Humanos" > "Características do recrutamento".
Operação
Nesta opção poderá escolher o tipo de operação a atribuir à característica de recrutamento.
Valor
Neste campo poderá atribuir um valor à característica de recrutamento.
Obr.
Ao ativar esta opção, está a indicar que a característica do recrutamento é obrigatória.
Características das Entrevistas
Nesta grelha são apresentadas as características das entrevista criadas no ecrã "Características de Entrevistas", a partir do menu "Tabelas" > "Recursos Humanos" do PHC CS Desktop. Na criação das características de entrevista são configuradas as formas de avaliação da entrevista que deverão ser preenchidas nas respetivas linhas das seguintes colunas:
Característica
V.Mín.
Só poderá preencher este campo se o tipo de valor configurado na característica de entrevista for numérico.
V.Ref.
Só poderá preencher este campo se o tipo de valor configurado na característica de entrevista for numérico.
V.Max.
Só poderá preencher este campo se o tipo de valor configurado na característica de entrevista for numérico.
Ponderação
Neste campo poderá inserir o valor de ponderação a atribuir ao candidato. Apenas é possível preenchê-lo se o tipo de valor configurado nas características de entrevista for numérico.
Como avaliar
Este campo é apenas de leitura e apresenta a informação de como deve preencher a avaliação do candidato. A informação de ajuda é preenchida no campo
Como avaliar
ao criar a característica de entrevista ou aquando a configuração da característica da entrevista no ecrã "Recrutamentos".
Por baixo da grelha são apresentados os campos
Valor mínimo
,
Valor de referência
e
Valor máximo
com o total de valores que nestas características cada candidato deve ter.
Intervenientes
Nesta grelhas deve inserir os intervenientes do recrutamentos que correspondem aos registos criados no ecrã "Colaboradores" do PHC CS Desktop.
Nome
Nesta opção poderá optar pelo interveniente que irá fazer parte deste recrutamento, sendo que poderá existir um ou mais intervenientes que poderão intervenientes e também os responsáveis pelo recrutamento.
Responsável
Ao ativar esta opção, estará a indicar que o interveniente deste recrutamento, é também responsável por ele.
Ecrã em modo de consulta
Com o ecrã em modo consulta tem disponíveis os seguintes botões:
Candidatos
: Este botão permite visualizar a listagem dos candidatos para um determinado recrutamento;
Entrevistas Realizadas
: Este botão permite visualizar a lista de entrevista já realizadas aos candidatos, quem as realizou e quando se realizaram;
Fechar o recrutamento
: Este botão encerra o recrutamento e coloca essa indicação no recrutamento. Depois de fechar o recrutamento não é possível associar mais candidatos ao recrutamento. Mas, se se justificar, poderá sempre voltar a reabrir um recrutamento já fechado.
Recrutamento Web
