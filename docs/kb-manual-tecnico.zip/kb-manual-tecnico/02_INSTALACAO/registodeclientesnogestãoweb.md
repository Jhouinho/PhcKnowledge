---
title: Registo de Clientes no Gestão Web
source: registodeclientesnogestãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Clientes no Gestão Web

A opção de clientes permite o acesso aos registos da tabela de clientes.
Na barra de ferramentas deste ecrã existem variadas opções. Algumas destas são comuns a todos os ecrãs, nomeadamente a procura de registos.
Ecrã em modo de introdução/alteração
Nome
Permite registar o nome completo identificativo do cliente e é de preenchimento obrigatório.
Número
Número interno atribuído a cada cliente. O programa atribui um número automaticamente, embora o utilizador o possa alterar.
Notas:
Quando a numeração do cliente mais o prefixo da conta SNC passarem o limite definido no parâmetro de "Clientes" na aplicação
PHC CS Desktop
"N.º de dígitos das contas SNC", a aplicação apaga os valores das contas SNC e deixar gravar sem as contas preenchidas.
Quando o cliente já tem documentos certificados emitidos e não tem Nome ou Morada preenchido mas tem o Número de Contribuinte, é possível averbar o Nome e a Morada do cliente mas não é possível alterar o Número de Contribuinte.
Se o cliente tem o Nome e Morada preenchido mas não tem o Número de Contribuinte definido na sua ficha, pode apenas preencher o Número de Contribuinte não sendo possível alterar o Nome ou a Morada.
Saldo c\c neste momento
Total do saldo existente em conta corrente.
Ao entrar na ficha de cliente, em modo de consulta, através deste campo existe a possibilidade de aceder mais rapidamente e de forma intuitiva à respetiva listagem de conta corrente.
Esta funcionalidade aplica-se apenas em
modo de consulta
.
Nota:
Na criação de um estabelecimento e na ficha do mesmo, este campo fica indisponível.
Plafond de Crédito
Limite máximo de crédito a conceder a este cliente. Não deverá ser preenchido se não existir limite. Na criação de um estabelecimento e na ficha do mesmo, este campo fica indisponível pois o
plafond
de crédito é o mesmo da sede.
Faturação Cancelada
A ativação desta opção permite que a aplicação impeça que se emita mais faturas a determinado cliente.
Cliente com dificuldade de cobrança
Esta opção faz com que na emissão de novo documento de faturação alerte o utilizador que o cliente está com dificuldade de cobrança.
Nome abreviado
Campo que permite ao utilizador introduzir a abreviatura do nome do cliente.
Inativo
Este campo inativa os respetivos registos, de modo a não surgirem nas opções dos ecrãs (Listagens / Procura, ... ). Assim, não se conseguem emitir novos documentos (por exemplo faturas, recibos, dossiers) para clientes que estão inativos. No entanto, os clientes que passaram a inativos continuam a estar disponíveis nas análises, consultas de documentos emitidos.
Morada
Este campo permite inserir a morada completa do cliente.
Localidade
Neste campo deve-se inserir a Localidade da morada do cliente.
Código Postal
Este campo serve para introduzir o código postal.
Código de Província
Este campo permite adicionar o código da província
Província
Este campo permite inserir o nome da província
Nota:
Os campos referentes à província apenas estão disponíveis no executável de Espanha.
País do Nº Cont.
Código do país relacionado com o número de contribuinte do cliente.
Número de Contribuinte
Este campo guarda o número fiscal do cliente.
Associado ao número de contribuinte, encontra-se um campo que permite selecionar e/ou criar o país correspondente ao número de contribuinte digitado.
Ao clicar em
terá a possibilidade de criar um novo código para o país.
Se o parâmetro "
Permite introduzir 2 clientes com o mesmo n.º de contribuinte
" da plataforma
PHC CS Desktop
" encontrar-se inativo, ao gravar um novo cliente, a aplicação
Gestão Web
verifica se já existe algum cliente na base de dados com o mesmo nº de contribuinte, e no caso de já existir, avisa o utilizador e não deixando gravar o novo registo.
Quando o parâmetro "
Permite introduzir clientes com o número de contribuinte em branco
" da plataforma
PHC CS Desktop
se encontra inativo, no
Gestão Web
não é possível gravar um novo cliente sem preencher este campo. Mas se estiver ativo, de acordo com o ponto 3 do Despacho n.º 8632/2014 - 03/07, a aplicação assume o seguinte comportamento:
Se o cliente já tiver documentos certificados e não tiver o Número de Contribuinte preenchido na sua ficha de cliente, a aplicação não permite alterar o nome do cliente, mas uma vez que o Número de Contribuinte esteja preenchido na ficha do cliente, a aplicação já permite alterar o nome do mesmo.
Se o cliente já tiver documentos certificados emitidos em seu nome, o Número de Contribuinte da ficha de cliente só poderá ser alterado, caso o mesmo esteja vazio ou preenchido com o NIF do cliente genérico "999999990".
Fax
Campo para inserir o número do fax do cliente.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telefone
Neste campo deve registar-se o telefone do cliente.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telemóvel
Este campo guarda o número de telemóvel do cliente.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
e-Mail
Neste local deve-se digitar o endereço do correio eletrónico.
Site Internet
Neste local fica guardado o endereço do
site
na Internet.
Idioma
Este campo permite definir qual o idioma a utilizar, na descrição dos artigos na faturação e dossiers internos.
Ao clicar em
terá a possibilidade de criar um novo idioma.
Moeda habitual
Moeda a utilizar na faturação a este cliente. A faturação, nesta aplicação é feita em euros, como tal este campo deve estar como PTE ou EURO (este campo passa automaticamente para os documentos de faturação).
Tabela de preços
Neste campo é determinada a tabela de preços (1,2,3,4 ou 5) do ficheiro de
stocks
à qual cliente está sujeito, aquando da emissão da faturação.
Observações
Campo "texto" para informação adicional respeitante ao cliente em questão. Este campo permite ainda a introdução de "Emotions", por exemplo:
:-) ou :)
:-D ou :d()
:-O ou :o()
:-P ou :p()
;-)
:-( ou :(
:-S ou :s()
:-| ou :|
:$ ou :-$
(H) ou (h)
:-@ ou :@
(A) ou (a)
Zona do Cliente
Zona interna da morada do cliente. Este é um campo de tabela do utilizador, onde se poderá colocar as várias zonas utilizáveis (este campo passa automaticamente para os documentos de faturação).
Ao clicar em
terá a possibilidade de criar uma nova zona.
Tipo de Cliente
Tipo interno a definir pelo utilizador. Utiliza a mesma filosofia do campo
Zona
.
Nome do Vendedor
Identificação do vendedor responsável pelo cliente. Esta identificação consta na tabela de vendedores do
PHC CS
.
Área
Área geográfica da localização habitual do cliente.
Centro Analítico
Neste campo são apresentados os diversos centros analíticos criados na aplicação
PHC CS Desktop
. O nome deste campo depende da configuração feita na aplicação.
Informação
Contactos
Estes campos destinam-se a guardar os nomes, funções, telefones e fax dos contactos do cliente.
Estes contactos podem ser "Comerciais", "Administrativos" e de "Cobranças".
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
País Origem
Neste campo fica definido qual o país de origem do cliente, ou seja:
Nacional
U.E.
Outros
Esta informação é importante para a eventual integração na contabilidade.
Número de B.Identidade
Número do bilhete de identidade do cliente.
Data de B.Identidade
Data de emissão do bilhete de identidade do cliente. Ao clicar no campo terá acesso ao calendário de forma a escolher a data pretendida.
Local Emissão do B.Identidade
Local de emissão do bilhete de identidade do cliente.
Passaporte
Número do passaporte do cliente.
Naturalidade
Naturalidade do cliente.
Nascimento
Data de nascimento do cliente. Ao clicar no campo terá acesso ao calendário de forma a escolher a data pretendida.
Local de Descarga
Local habitual para descargas de mercadorias deste cliente (este campo passa automaticamente para os documentos de faturação para o campo Local de descarga).
Dados Financeiros
Modo de Cobrança
Modo de cobrança a utilizar com o cliente, por ex: transferência bancária, cobrador, etc..
Esta informação passa para o recibo quando este é emitido.
Cobrador
Nome do cobrador para este cliente. Ao clicar em
terá a possibilidade de criar um novo cobrador.
Rota de Cobrança
Nome ou número da rota de cobrança deste cliente.
Condições de Pagamento
Modo de Pagamento deste cliente (este campo passa automaticamente para os documentos de faturação).
Ref. Interna
Este campo permite introduzir a referência interna do cliente.
Segmento de Mercado
Segmento de mercado a que o cliente pertence. Ao clicar em
terá a possibilidade de criar um novo segmento de mercado.
N.I.B
Número de identificação bancária do cliente.
I.B.A.N
.
Número internacional de identificação bancária.
Endereço para enviar documentos por via eletrónica
Endereço para enviar documentos por via eletrónica. Neste local deve ser definido qual o endereço de
e-mail
ou caminho, conforme o método de envio escolhido.
Por exemplo se o método de envio é por ficheiro neste campo deve ser colocado o caminho. O caminho colocado tem de existir.
Método de envio
Esta opção serve para definir para cada cliente qual o método de envio de documentos por via eletrónica, entre os seguintes:
Ficheiro
- Neste caso o endereço deve ser preenchido com a diretoria para exportar os ficheiros (A exportação dos documentos é feita para ficheiros numa determinada diretoria);
e-Mail
- Neste caso o endereço deve ser preenchido com o endereço de mail (Envio dos documentos por E-mail como attachment);
Web Service
- Neste caso deve ser preenchido com o endereço URL do Serviço para onde deve ser enviado o documento (Envio dos documentos para um site que disponibilize a receção utilizando um Web Service)
Tipo de Descontos
Por Quantidade/ Por Valor/ Nenhum
Descontos a conceder ao cliente. Poderão ser descontos por quantidade, por valor ou mesmo nenhum desconto comercial.
Desconto Habitual
Desconto habitual a efetuar nas vendas a este cliente.
Desconto Financeiro
Desconto a conceder ao cliente se existirem as condições de pronto pagamento.
Tabela de IVA fixa
Tabela de IVA fixa em todos os artigos a utilizar com este cliente.
Tipo de Descontos
Esta tabela do utilizador permite definir o tipo de cliente para os descontos Cliente/Artigo/Família. Ao clicar em
terá a possibilidade de criar um novo tipo de desconto.
Classificação dos documentos de faturação
Permite classificar o cliente segundo um determinado critério. Sempre que for criado um novo documento para o cliente na tabela de documentos de faturação, a informação contida neste campo é automaticamente copiada. Ao clicar em
terá a possibilidade de criar uma nova classificação de vendas.
Local de tesouraria para recibos
Este campo permite selecionar o local de tesouraria para os recibos pelo que, uma vez feita a seleção, este é automaticamente atualizado nos recibos de c/c.
Vencimento em dias
Número de dias para considerar vencido um débito a este cliente.
Limite de Crédito em dias
Número máximo de dias que é permitido para além do vencimento, impedindo a emissão quando o cliente deve um documento de faturação há mais dias do que está especificado neste local.
Atraso médio para previsões em dias
Número de dias além do vencimento em que é previsto o recebimento deste cliente.
Cliente é particular
Indicação se o cliente é particular ou empresa.
Não recebe mailing de c/c
Indicação se o cliente recebe periódica ou ocasionalmente
mailing
de contas correntes.
Cliente genérico
Indicação se o cliente é genérico. Esta opção permite ao utilizador criar um cliente "geral", não tendo de estar a cadastrar os clientes sempre que se efetua uma venda.
Consumidor final
Indicação se o cliente é Consumidor final ou empresa.
Motivo de isenção de imposto
Ao selecionar
é apresentada a lista de todos os motivos de isenção existentes na lei em vigor. Ou poderá introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme são introduzidos mais carateres, esta procura vai sendo refinada.
Descrição do Reg. IVA
Este campo permite selecionar a Descrição do Regime de IVA deste cliente.
Nota:
Poderá configurar nos parâmetros da aplicação PHC CS a
Descrição do Regime de IVA
que seja utilizada por definição aquando da criação de fichas de novos clientes. Mas uma vez alterada no ecrã de Clientes, a informação da respetiva ficha tem precedência sobre o parâmetro.
Cliente isento de Ecovalor
Esta opção permite indicar se o Cliente tem isenção de
Ecovalor
..
Diversos
Conta SNC para c/c
Número da conta SNC para posterior integração no programa de
Contabilidade
.
Conta SNC Letras na Contabilidade
Número da conta SNC para a rubrica de "Letras" para posterior integração no programa de
Contabilidade
.
Conta Letras Descontadas na Contabilidade
Número da conta SNC para posterior integração no programa de
Contabilidade
de movimentos de descontos de letras a receber.
Conta SNC, Envio a Desconto de Letras
Número da conta SNC para posterior integração no programa de
Contabilidade
de movimentos de envio a descontos de letras a receber.
Conta SNC, Adiantamentos c/preço incerto
Número da conta SNC para a rubrica de adiantamentos (preços não contratados entre as partes) para posterior integração no programa de
Contabilidade
.
Conta SNC, Adiantamentos c/preço certo
Número da conta SNC para a rubrica de adiantamentos (preços contratados entre as partes) para posterior integração no programa de
Contabilidade
.
Conta SNC, Dívidas tituladas
Número da conta SNC para a rubrica de dívidas tituladas.
Esta conta deverá ser usada quando o utilizador pretender efetuar a integração de recibos de c/c que foram recebidos por cheque, sendo a conta debitada a conta para dívidas tituladas do cliente em vez da conta caixa.
Estas contas são apenas informativas, pois só é possível efetuar a integração de documentos na contabilidade do
PHC CS Desktop
.
Grupo de Acesso Externo
Deve definir neste local qual o grupo a que pertence este cliente, tendo em conta os campos que pretende sincronizar.
No Front Web só pode encomendar os artigos que estiverem definidos no seu dossier de preços por cliente
Como o próprio nome indica, caso este campo esteja ativo o cliente deverá ter associado um dossier de preços por cliente onde serão criados os artigos que ele poderá encomendar na aplicação Front Web.
Assim ao escolher os artigos para introduzir na encomenda o utilizador só tem acesso aos artigos que estiverem definidos no seu(s) dossier(s) de preço por cliente.
Agente de Perceção
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa é um agente de perceção.
Agente de Retenção
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa é um agente de retenção.
Bom Contribuinte
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa está incluída no Regime de Bons Contribuinte.
Ecrã em modo de consulta
Quando o utilizador acede, por modo de consulta, à ficha de um cliente, é possível através de
, realizar as seguintes ações:
Enviar Email
Nesta opção são mostrados os emails do cliente, após selecionar os destinatários é aberto o ecrã de envio de email, com os campos destinatários, Assunto e Mensagem já preenchidos, permitindo assim enviar um email com os dados do cliente selecionado.
Nota:
esta opção também está acessível na área de próximas ações quando se grava um registo.
Criar Estabelecimento
À semelhança do funcionamento na aplicação PHC CS Desktop, esta opção duplica a ficha do cliente, incrementando a numeração do campo estabelecimento.
Relativamente aos estabelecimentos, estes podem ser apagados desde que não haja movimentos de conta corrente.
Nota:
Não é possível apagar um cliente (sede) se existir um movimento de conta corrente para a sede e/ou estabelecimentos.
Conta Corrente
Permite ao utilizador consultar a Listagem de c/c de Cliente de forma rápida. Podendo posteriormente, consultar o extrato, definir uma pesquisa de movimentos entre datas e navegar para visualizar os documentos de origem.
Documentos de Faturação
Permite ao utilizador consultar uma Listagem dos Documentos de Faturação emitidos àquele cliente específico.
Podendo posteriormente navegar para os respetivos documentos de origem.
Recibos
O utilizador acede de forma rápida à Listagem de Recibos de conta corrente, possibilitando também a navegação direta para um registo específico do ecrã de Recibos de C/C.
Evolução
Permite ao utilizador um acesso rápido à consulta do Painel de Vendas
análise anual de vendas
. Desta forma, poderá analisar e retirar elações da evolução anual das relações comerciais com aquele cliente.
Responder a inquérito
Esta opção permite ao utilizador aceder de forma rápida uma Listagem de Inquéritos que aquele cliente para verificar se eventualmente terá algum por responder, ou quais ainda estrão por responder.
Dossiers
Permite ao utilizador consultar os Dossiers Internos emitidos aquele cliente específico.
Podendo posteriormente navegar para os respetivos documentos de origem.
Introduzir Doc. de Faturação
Permite que a partir do ecrã de clientes, o utilizador possa introduzir de forma rápida um Documento de Faturação para o cliente. Embora ainda tenha que escolher a série do mesmo, uma vez a criação do documento tem origem na ficha do cliente, existem dados que ficam automaticamente preenchidos no Documento de Faturação.
Nota:
Ao selecionar esta opção, caso exista uma série de faturação em que o último registo esteja por assinar digitalmente, a respetiva série de faturação não aparece na lista disponibilizada ao utilizador.
Introduzir Recibo
Permite que a partir do ecrã de clientes, o utilizador possa introduzir de forma rápida um Recibo de C/C para o cliente. Embora ainda tenha que escolher a série do Recibo, uma vez a criação do documento tem origem na ficha do cliente, existem dados que ficam automaticamente preenchidos no mesmo.
Introduzir Dossier
Permite ao utilizador de forma rápida a introdução de um Dossier a partir do ecrã de clientes. Embora ainda tenha que escolher a série do Dossier, uma vez a criação do mesmo tem origem na ficha do cliente, existem dados que ficam automaticamente preenchidos no Dossier Interno.
Criar Contacto
Esta opção está disponível se tiver instalada a aplicação CRM Web e permite transformar um cliente em contacto, criando um novo contacto com os dados comuns do cliente selecionado.
Criar Entidade
Esta opção permite transformar um cliente em entidade, criando uma nova entidade com os dados comuns do cliente selecionado.
Nota:
Esta opções podem não aparecer se já tiver um registo associado ao ecrã. Por exemplo, se já tiver associado uma entidade ao cliente, esta opção deixa de estar disponível em
Outras Opções
.
A partir deste ecrã é possível
imprimir
a ficha com os dados do cliente.
Clientes no Gestão Web
