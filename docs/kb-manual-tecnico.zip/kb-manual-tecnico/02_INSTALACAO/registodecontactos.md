---
title: Registo de Contactos
source: registodecontactos.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Contactos

Neste ecrã o utilizador tem a possibilidade de
introduzir
registos de toda a informação necessária, relativa a Contactos / Entidades com as quais possam, muito provavelmente, ocorrer atividade comercial.
Também com o ecrã em modo de
consulta
, são disponibilizadas diversas funcionalidades, com o intuito de promover uma rápida capacidade de resposta do vendedor para com o Contacto.
Nota
: Se os acessos estiverem a ser controlados por área, apenas aparecem ao utilizador, independentemente dos campos ou métodos utilizados na pesquisa, os registos que pertencem à sua área. Ou seja, os que pertencem à área definida na sua ficha de utilizador na aplicação em PHC CS Desktop.
Ecrã em modo de introdução/alteração
Quando o utilizador introduz um registo dispõe dos seguintes campos:
Nome
Este campo permite registar o nome do contacto.
Número
Número interno atribuído a cada contacto. O programa atribui um número automática e sequencialmente.
Número de Contribuinte
Número fiscal do contacto.
Nota
: Quando o contacto já tem documentos certificados emitidos e não tem Nome ou Morada preenchido mas tem o Número de Contribuinte, é possível averbar o Nome e a Morada do contacto mas não é possível alterar o Número de Contribuinte.
Se o contacto tem o Nome e Morada preenchido mas não tem o Número de Contribuinte definido na sua ficha, pode apenas preencher o Número de Contribuinte não sendo possível alterar o Nome ou a Morada.
Vendedor
Nome do vendedor associado ao contacto.
Este campo é introduzido automaticamente pela aplicação.
Telemóvel
Número de telemóvel do contacto.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telefone
Número de telefone do contacto.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Fax
Número do fax do contacto.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
e-Mail
Endereço de correio eletrónico
Site
Endereço do site na Internet.
Resumo da próxima visita
Neste campo deve ser selecionado o resumo pretendido para a próxima visita. Este campo apenas fica disponível em modo de consulta.
Num cenário em que o contacto em questão já tenha sido visitado pelo vendedor (cuja visita esteja configurada como realizada) e tenha também visitas agendadas para o futuro, o utilizador poderá ver esta informação na ficha de Contacto.
Esta informação, de acordo com as datas, estará presente nos campos
Próxima visita
e
Última visita
.
Periodicidade
Número de dias de intervalo, entre as visitas realizadas ao contacto.
Se o utilizador estiver em modo de edição, ao premir o botão
Adicionar uma nova pessoa
, é colocada uma linha onde se pode introduzir os dados referentes à pessoa diretamente no ecrã "Contactos". Se estiver em modo de consulta, ao premir o botão, navegará para o ecrã
Pessoas
em modo de introdução, onde pode introduzir o registo da pessoa que, por defeito, a aplicação preenche o campo
Contacto
do ecrã de Pessoas com a respetiva informação.
Nota:
Se os acessos estiverem a ser controlados por área, apenas aparecem ao utilizador neste local, as pessoas que pertencem ao contacto e têm a mesma área existente no contacto e definida para o utilizador.
A informação existente no ecrã do contacto, referente à(s) Pessoa(s) associada(s) ao contacto será:
Tratamento
- Forma de tratamento da pessoa (i.e. Dr.).
Nome
- Nome da pessoa.
Função
- Cargo exercido pela pessoa (i.e. secretária).
Telefone
- Telefone da pessoa.
Telemóvel
- Nº de telemóvel da pessoa.
E-mail
- Endereço de E-mail da pessoa.
Através dos Contactos pode sempre aceder ao ecrã de Pessoas, posicionando-se no registo da respetiva Pessoa. Ou seja, assim que clicar no botão:
a aplicação navegará para o registo da Pessoa relacionada com esse contacto.
Url do Facebook
Campo com o link para a página do Facebook do contacto. Deverá preencher no campo o endereço web incluíndo o http, como por exemplo, "http://www.facebook.com/PHCsoftware". Ao consultar o contacto, caso pretenda visualizar a página do Facebook basta clicar sobre a ligação que é aberto num outro separado do browser a página introduzida.
Url do Linkedin
Campo com o link para a página do LinkedIn do contacto. Deverá preencher no campo o endereço web incluíndo o http, como por exemplo, "http://www.linkedin.com/company/phc-software-s.a.". Ao consultar o contacto, caso pretenda visualizar a página do linked basta clicar sobre a ligação que é aberto num outro separado do browser a página introduzida.
Morada
Morada completa do contacto.
Nota
: Quando o contacto já tem documentos certificados emitidos e não tem Nome ou Morada preenchido mas tem o Número de Contribuinte, é possível averbar o Nome e a Morada do contacto mas não é possível alterar o Número de Contribuinte.
Se o contacto tem o Nome e Morada preenchido mas não tem o Número de Contribuinte definido na sua ficha, pode apenas preencher o Número de Contribuinte não sendo possível alterar o Nome ou a Morada.
Localidade
Localidade da morada do contacto.
Código Postal
Este campo serve para introduzir o código postal da morada do contacto.
País
País do contacto.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caractere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Iniciais do País de Origem
Código do país relacionado com o número de contribuinte do contacto.
Caso o utilizador precise de introduzir novas iniciais ou seja, um novo país poderá fazê-lo através do botão:
.
Zona
O utilizador tem a possibilidade de organizar os seus contactos por zona. Poderá selecionar uma zona já existente, ou, através do ícone
criar um novo registo.
Observações
Campo do tipo "memo" que permite introduzir um texto longo com observações acerca do contacto.
Concorrência
Campo do tipo "memo" que permite introduzir um texto longo com observações acerca da concorrência no que diz respeito ao contacto.
Tipo
Campo de tabela parametrizável. Permite classificar os contactos segundo um determinado critério, i.e. idade, origem).
Segmento de mercado
Permite enquadrar cada contacto num segmento de mercado. Neste caso o utilizador poderá criar novos Segmentos de mercado, utilizando o botão:
.
Tab. Preços
Neste campo define-se qual a tabela de preços (1, 2, 3, 4 ou 5) do ficheiro de stocks utilizada quando se vendem produtos ou serviços.
Área do Utilizador
Este campo permite selecionar a área do contacto.
Quando o utilizador controla os acessos por área, na introdução de um novo registo, este campo é automaticamente introduzido pelo sistema, com a área que o utilizador tem definida na sua ficha de utilizador, na aplicação PHC CS Desktop, não deixando gravar o registo se o utilizador alterar o seu valor.
Data especial
Permite indicar na ficha do contacto uma data que assinale algo importante e que diz respeito ao contacto (i.e. aniversário). Clicando sobre o campo, o utilizador poderá aceder ao calendário, e escolher o dia pretendido, sendo o mesmo preenchido automaticamente.
Significado da data especial
Significado da data indicada como especial.
Ref. Interna
Campo parametrizado na aplicação PHC CS Desktop. Cada contacto pode fazer parte de um projeto, sendo possível saber, por exemplo, quantos e quais os contactos envolvidos num determinado projeto.
Endereço eletrónico para envio de documentos
Endereço para enviar documentos por via eletrónica.
Método de envio de documentos via endereço eletrónico
Esta opção serve para definir para cada contacto qual o método de envio de documentos por via eletrónica, pode ser:
-
Ficheiro -
Neste caso o endereço deve ser preenchido com a diretoria para exportar os ficheiros (A exportação dos documentos é feita para ficheiros numa determinada diretoria);
-
E-Mail -
Neste caso o endereço deve ser preenchido com o endereço de mail (Envio dos documentos por E-mail como attachment);
-
Web Service -
Neste caso deve ser preenchido com o endereço Url do Serviço para onde deve ser enviado o documento (Envio dos documentos para um site que disponibilize a receção utilizando um Web Service).
Consumidor final
Define se o contacto é consumidor final.
Se esta opção estiver ativa, significa que corresponde a um sujeito não passivo de IVA e por isso encontra-se excluído da obrigação de comunicação de documentos de transporte, de acordo com o Regime de Circulação de Bens.
Ecrã em modo de Consulta
Quando o utilizador entra no ecrã de Contactos, em modo de consulta e clica no botão:
, dispõe de diversas opções que permite ao vendedor efetuar várias ações perante o Contacto.
Enviar Email
Ao selecionar esta opção são mostrados os emails do contacto, pessoas associadas ao contacto e do vendedor. Após selecionar os destinatários é aberto o ecrã de envio de email com os campos
Destinatários
,
Assunto
e
Mensagem
já preenchidos, permitindo assim enviar um email com os dados do negócio selecionado.
Enviar Mensagem
Ao selecionar esta opção é aberto o ecrã
Mensagens
em modo de introdução com os campos
Resumo
e
Descrição
já preenchidos, permitindo assim enviar uma mensagem interna com os dados do negócio selecionado.
Criar Pessoa
Ao selecionar esta opção, é aberto o ecrã
Pessoas
em modo de introdução, com o campo
Nome do Contacto
já preenchido, permitindo assim criar uma pessoa para o contacto do negócio selecionado.
Criar Marcação
Ao selecionar esta opção, é aberto o ecrã
Marcações
em modo de introdução com os campos
Utiliza a tabela
e
Com quem vai ser a marcação
já preenchidos, permitindo assim criar uma nova marcação para o contacto definido no negócio.
Criar uma Visita
Ao selecionar esta opção, é aberto o ecrã
Visitas
em modo de introdução com os campos
Nome do contacto
,
Nº. do Contacto
,
Descrição resumida do negócio
e
Negócio
já preenchidos, permitindo assim criar uma nova Visita com os dados do negócio selecionado.
Criar um Dossier
Esta opção dar-lhe-á acesso a
introduzir um dossier
diretamente ao Contacto.
Criar Chamada Telefónica
Ao selecionar esta opção, é aberto o ecrã
Chamadas Telefónicas
em modo de introdução com os campos
Origem da chamada
e
Nome da Empresa
já preenchidos, permitindo assim criar uma nova chamada telefónica para o contacto do negócio selecionado. Esta opção apenas está disponível se tiver acesso ao módulo PHC CS Equipa web.
Criar um Negócio
Ao selecionar esta opção é aberto o ecrã "Negócios" em modo de introdução com os campos
Contacto
e
Número do Contacto
já preenchidos, permitindo assim criar um novo negócio para o contacto do negócio selecionado.
Dossiers
Permite a consulta dos
dossiers
do contacto que se encontra em modo de consulta. Nesta opção é possível consultar todos os dossiers do contacto, filtrar por datas ou ainda só observar os dossiers abertos. Após a validação do que se quer basta clicar em
Dossiers
.
Visitas
Permite a consulta a
listagem de visitas
marcadas. É possível fazer esta consulta desde sempre ou entre datas, é ainda possível observar visitas já realizadas. Após a validação do que se pretende basta clicar em
Visitas
.
Análise Global
Através desta opção, poderá ter acesso à
Análise Global do Contacto
, que contém os dossiers internos e as visitas relativas ao contacto em consulta.
Exemplo:
No ecrã que se dedica-se à análise global, o utilizador pode através do ícone
aceder ao respetivo dossier interno ou visita.
Dispõe ainda de mais três botões:
- Permite o acesso ao ecrã de procura de contactos, onde poderá selecionar um outro contacto para execução desta análise.
- Permite a introdução de
uma visita
.
- Permite o acesso ao ecrã de procura de
Dossiers internos
.
Produtos Vendidos
Através desta opção poderá aceder à
lista de produtos vendidos
a este contacto. Aí, terá também a possibilidade de consulta de produtos vendidos a outros contactos/clientes.
Negócios
Permite a consulta de negócios efetuados. É possível fazer esta consulta desde sempre ou entre datas, é ainda possível "Não Observar negócios encerrados". Após a validação do que se pretende basta clicar em Negócios.
No entanto, se o utilizador também usufruir do módulo PHC CS Gestão web, terá acesso a mais quatro opções no botão:
Criar Cliente
Esta opção permite transformar um contacto em cliente, criando um novo cliente com os dados comuns do contacto selecionado.
Criar Entidade
Esta opção permite transformar um contacto numa entidade, criando uma nova entidade com os dados comuns do contacto selecionado.
Conta-corrente
Esta opção permite consultar a conta corrente do contacto,
desde que seja também Cliente
.
Para que o utilizador tenha acesso a esta opção deve ter definido o acesso de Internet.consultar à tabela de
Contas-Correntes de Clientes
e
Entidades
na aplicação PHC CS Desktop.
Faturação
Esta opção permite consultar os documentos de faturação do contacto,
desde que seja também Cliente
.
Para que o utilizador tenha acesso a esta opção deve ter definido o acesso de Internet.consultar à tabela de
Documentos de Faturação
na aplicação PHC CS Desktop.
Nota:
Esta opções podem não aparecer se já tiver um registo associado ao ecrã. Por exemplo, se já tiver associado um cliente ao contacto, esta opção deixa de estar disponível em
Outras Opções
.
Tem a possibilidade de usufruir das
opções de registo
, bem como pesquisar,
alterar
e/ou apagar o registo. Poderá ainda introduzir e visualizar os comentários associados ao registo selecionado.
Próxima ação
Neste local fica registada a data da próxima visita criada no ficheiro de visitas para o contacto. Este campo apenas fica disponível em modo de consulta.
Contactos do Crm Web
