---
title: Registo de Dossiers
source: registodedossiers.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Dossiers

O conceito de Dossier interno surge, como uma ferramenta que permite ao utilizador adaptar-se, de uma forma simples, às suas necessidades mais específicas.
O utilizador poderá definir e caracterizar
Dossiers internos
que vão ser constituídos por documentos internos adaptados ao modo de funcionamento da Empresa em questão, podendo desta forma informatizar áreas que normalmente não fazem parte da gestão.
No âmbito do
CRM Web
, um Dossier pode por exemplo, conter o conjunto das encomendas recebidas, onde cada registo
introduzido
representará uma encomenda com os diversos artigos encomendados por um Contacto.
Também com o ecrã em modo de
consulta
, são disponibilizadas diversas funcionalidades, que permitem ao utilizador interagir com um registo de um Dossier.
Ao ceder ao ecrã, o primeiro passo que o utilizador deve fazer é selecionar o
Dossier
sobre o qual pretende imitir um registo.
Nota:
Os dossiers são configurados na aplicação
PHC CS Desktop
para que possam estar disponíveis para consulta e emissão nas aplicações do PHC CS Web. Essa configuração em conjunto com o acesso "Internet.Consultar", determina se o dossier está disponível nas listas de seleção que aparecem nos ecrãs "Dossiers Internos", Consulta/Listagem de Dossiers Internos e Cópia de Dossiers Internos.
Ecrã em modo de introdução/alteração
Quando o utilizador pretende introduzir um dossier, tem à sua disposição os seguintes campos:
Ao clicar nesta opção (apenas quando o ecrã está em modo de introdução) a aplicação disponibiliza um ecrã que tem inúmeras
opções
para que o utilizador possa copiar os dados de outro dossier interno para dentro do dossier que está a criar.
Dossier
Indica qual a série de Dossier selecionada pelo utilizador, para emitir um registo. Em modo de introdução este é um campo de leitura ou seja, o utilizador não poderá editar.
Número
Nº sequencial do registo, no respetivo dossier.
Este campo é preenchido automaticamente pela aplicação aquando da gravação do registo.
Contacto
Este campo é de preenchimento obrigatório.
Aqui deverá inscrever o nome do Contacto/Cliente/Entidade ou selecioná-lo através da opção de procura
, que será efetuada com base na introdução do nome que pretende procurar (começado por).
Este campo dispõe de procura incremental ou seja, à medida que o utilizador for escrevendo os carateres pretendidos, a aplicação vai mostrando as possibilidades de escolha. Neste sentido, ao digitar os carateres o resultado da será cada vez mais assertivo.
Pode também criar um novo contacto/cliente/entidade, assim, caso introduza no campo o nome que ainda não exista, aparece por baixo do campo uma mensagem com um caminho que permite criar o novo registo. Ao clicar no caminho é aberto o ecrã "Contactos"/"Clientes"/"Entidades" com o nome preenchido, ao gravar os dados retorna ao Dossier Interno com os dados atualizados.
Número
Este campo é de preenchimento obrigatório e corresponde ao Número do
Contacto/Cliente/Entidade
escolhido pelo utilizador.
Caso o utilizador opte por preencher inicialmente este campo, a aplicação preenche automaticamente o campo
Contacto/Cliente/Entidade
.
Est
Identifica com que estabelecimento é que o cliente está relacionado. O preenchimento é automático quando se escolhe o
Contacto/Cliente/Entidade
e é de preenchimento obrigatório.
Moeda habitual
Caso estejam configuradas
Moedas estrangeiras
e
Taxas de Conversão para o Euro
na aplicação PHC CS Desktop, o utilizador dispõe das mesmas neste campo, permitindo-lhe indicar a moeda utilizada no dossier.
Assim que o utilizador alterar a moeda do documento, a aplicação disponibiliza as colunas:
-
Pr.Unit.Moeda
e
Total Moeda
nas linhas do documento;
Ref. Interna
Informa qual a referência interna a que está associado o dossier.
(campo de renomeação nos Parâmetros Gerais da aplicação
PHC CS Desktop
)
Vendedor
Este campo permite identificar o vendedor que está associado à operação comercial.
Área
Permite identificar a área onde se situa o cliente.
Observações
Campo de observações.
A introdução de linhas no documento é efetuada através das seguintes opções:
Ao selecionar esta opção, terá acesso à
Escolha de Artigos/serviços
de artigos disponíveis.
A designação de Produto e Subproduto não é fixa, depende da configuração feita nos parâmetros da aplicação
PHC CS Desktop
, poderá ser por exemplo Marca e Modelo.
Pode definir qual a ordenação pretendida para a listagem, se por
Referência
,
Designação
,
Família
,
Produto
ou
Subproduto
, assim como quantos artigos deverão ser listados por página.
Depois de adicionar o(s) artigo(s), quando o utilizador clicar em
Voltar
, os artigos serão colocado nas linhas do dossier, com a quantidade definida pelo utilizador.
Adiciona uma linha ao dossier. Nesta linha o utilizador poderá o início do valor da referência ou da designação que, automaticamente, após o segundo caractere, apareçam no máximo, os sete primeiros registos. À medida que vão sendo colocados mais carateres, mais restrita vai ficando a pesquisa. Após selecionar um dos campos, são automaticamente preenchidos os restantes campos, ou seja, se preencher a referência ao selecionar o valor pretendido, é automaticamente preenchida a designação e preço unitário, o mesmo se passa com a descrição. Para que a pesquisa incremental funcione é necessário, na aplicação PHC CS Desktop, ter o parâmetro geral "Usa "autocomplete" em todos os campos texto ativo.
Se o utilizador tiver configurada a possibilidade de utilizar artigos com características específicas (como por exemplo:
Cor
e
Tamanho
) ou seja, utilize a funcionalidade de
Grelhas
, aparecerá nas linhas do documento as respetivas colunas para que o utilizador defina concretamente nos artigos que está a incluir no documento, qual a cor e tamanho.
Nota:
Ao ativar a opção "Utiliza desconto nas linhas", na aplicação
PHC CS Desktop
, o utilizador poderá introduzir descontos comerciais nas linhas do documento. Esta opção permite ainda definir a quantidade de descontos a utilizar, podendo-se definir até 6 descontos. Desta forma, também serão visíveis quando for lançado um Dossier Interno através do Gestão Web.
Quando esta opção se encontra ativa e se encontram descontos definidos, passa a existir nas opções das linhas dos dossiers duas outras opções relacionadas com a atribuição de descontos.
Ao introduzir dossier interno certificado apenas é possível definir uma percentagem de desconto entre 0% e 100%. Caso a percentagem seja inferior a 0% ou superior a 100%, a aplicação altera automaticamente a percentagem para 0% e 100%, respetivamente.
Uma vez que a aplicação valida o acesso
Acesso a Preços de Venda e Descontos
de determinado Dossier, caso o mesmo esteja inativo, as colunas de Preço Unitário e dos Descontos não podem ser alteradas pelo utilizador.
Em qualquer uma das linhas do dossier, independentemente da forma como foi introduzida, existe sempre a opção de Apagar
.
Nota:
Nos documentos certificados esta opção deixa de estar visível aquando da alteração do documento.
Após as alterações necessárias ao campo quantidade deverá
Gravar
o dossier.
Data
Data do dossier.
Modo de Pagamento
Aqui deverá ser selecionado qual o modo de pagamento acordado.
Data/Hora de expedição
Os campos
Data
e
Hora de Expedição
passam a estar disponíveis para dossiers internos configurados com o Tipo para SAF-T diferente de "DC" e que este não esteja vazio. Estes campos ficam preenchidos, por defeito, ao introduzir.
Ao gravar, a aplicação verifica se os campos
Data
e
Hora de Expedição
se encontram preenchidos e caso não estejam, impede a gravação e avisa o utilizador.
Local habitual da carga de mercadorias
Permite indicar qual o local de carga da mercadoria.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caractere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Data efetiva de entrega
Por questões legais este campo foi criado, mas é de preenchimento facultativo. É a Data em que os bens ou serviços faturados foram prestados e colocados à disposição do adquirente.
Quando o dossier cumprir os requisitos para que a informação seja entregue no Ficheiro SAFT, caso este campo esteja vazio é comunicado a data do Dossier.
Nota:
Na aplicação PHC CS Web, quando os campos não têm informação (estão vazios), por definição em modo de consulta, ficam omissos.
Local habitual de descarga de mercadoria
Permite indicar o local de descarga da mercadoria. Este campo fica automaticamente preenchido com a informação que se encontra na ficha do cliente.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caractere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Nota:
Ao clicar na lupa existente tanto no campo "Local habitual da carga de mercadorias" como no "Local habitual de descarga de mercadoria" e de seguida clicar em procurar, visualizará os registos com a respetiva morada.
Código de identificação atribuído pela AT
Este campo apenas surge quando o dossier tem tipo para SAFT igual a "GT", "GR", "GA", "GC" ou "GD" e indica o código de identificação do documento de transporte atribuído pela AT (Autoridade Tributária).
Consumidor final
Define se é consumidor final. Se esta opção estiver ativa, significa que corresponde a um sujeito não passivo de IVA e por isso encontra-se excluído da obrigação de comunicação de documentos de transporte, de acordo com o Regime de Circulação de Bens.
Motivo de Anulação
Caso o Dossier seja anulado, este campo deverá conter a informação que indique o motivo de anulação. No entanto, este campo só é de preenchimento obrigatório, quando se trata de um documento certificado.
Total antes de I.V.A.
Valor total sem IVA.
Mas se o utilizador selecionar uma moeda estrangeira, a aplicação também disponibiliza o campo
Total Moeda antes de I.V.A.
, com a respetiva conversão efetuada.
Nota:
Por fim, pode alterar a data do dossier introduzida pela própria aplicação, observar as colunas "Cor" e "Tamanho" (que apenas se encontram disponíveis se o dossier estiver configurado para permitir grelhas de cor e tamanho) em modo read-only (apenas de leitura) e ao gravar pode observar as somas do total antes de IVA, o valor do Iva e o Total.
Cod. Negócio
Este campo, estabelece a ligação entre o dossier a ser criado e um negócio através do código do próprio negócio. O utilizador poderá utilizar o botão
para procurar o Negócio pretendido.
Descrição Resumida do Negócio
Este campo diz respeito à descrição resumida do negócio criada aquando da introdução do negócio. Ao selecionar este campo, tanto o
Cód. Negócio
como o
Status
são automaticamente preenchidos. O utilizador poderá utilizar o botão
para procurar a descrição do negócio que pretende.
Status
Este campo identifica o status do Negócio associado. O utilizador poderá alterar o mesmo, procurando o status desejado através do botão:
.
Nota
: Quando se adiciona um artigo ou se altera a quantidade de determinada linha, o software calcula as promoções que possam estar definidas no artigo.
As opções sobre
Ecovalor
, só estarão disponíveis se utilizar o Módulo
Ecovalor Gestão
na aplicação
PHC CS Desktop
. Assim, ao ativar o módulo Ecovalor e depois de configurar o dossier (também na aplicação PHC CS Desktop) ficam visíveis nas linhas do dossier as seguintes opções:
Ecovalor
Este campo indica que o artigo tem ecovalor.
Não calcula Ecovalor
Ao ativar esta opção o valor total do documento não está sujeito a ecovalor, como tal esta opção deve ser utilizada para os artigos em que o ecovalor é suportado pela empresa.
Apenas será possível retirar o ecovalor do total do dossier, quando o artigo está a adicionar o ecovalor ao preço de venda.
Total Ecovalor (a adicionar)
Este campo indica o valor do ecovalor da linha em questão que será adicionado ao preço de venda do artigo.
Total Ecovalor (já incluído)
Este campo indica o valor do ecovalor da linha em questão que já se encontra incluído no preço de venda do artigo.
Após
o dossier, será apresentada a "Próxima ação". O objeto "Próxima ação" poderá ser configurado através da Framework PHC onde poderá adicionar-lhe novas
Opções de Ecrã
definidas pelo utilizador.
Ecrã em modo de consulta
Quando o ecrã se encontra em modo consulta, aparece o botão
, que permite fechar o dossier, caso o dossier já esteja fechado, aparece o botão
, que permite reabrir o dossier.
O utilizador passa também a dispor das
opções de registo
, através do botão
, onde terá a possibilidade
Anular o documento
através da opção:
.
Poderá também pesquisar,
alterar
e/ou apagar o registo.
Enviar Email
Nesta opção são mostrados os emails do cliente, após selecionar os destinatários é aberto o ecrã de envio de email, com os campos Destinatários, Assunto e Mensagem já preenchidos, permitindo assim enviar um email para o cliente, de uma forma mais rápida, com a informação mais pertinente sobre o Dossier. Para que a informação seja mais completa, o email contém tanto do cabeçalho do Dossier (tabela: ".bo"), como das respetivas linhas (tabela: ".bi").
Nota:
esta opção também está acessível na área de próximas ações quando se grava um registo.
Caso o Dossier esteja configurado para ter natureza de um documento certificado, a aplicação questiona o utilizador quanto à anulação do mesmo, disponibilizando o campo
Motivo de anulação
. Este campo só é de preenchimento obrigatório, quando se trata de um documento certificado.
Após a anulação do dossier, o campo
Motivo de Anulação
fica preenchido e junto da identificação do Dossier e do respetivo número, fica registado: "Documento Anulado", tal como sugere a imagem:
Nota:
Quando o utilizador tem PHC On ativo e documento eletrónicos, a aplicação comunica imediatamente com a AT a sua anulação e respetivo motivo.
Dossiers no Phc Cs Web
