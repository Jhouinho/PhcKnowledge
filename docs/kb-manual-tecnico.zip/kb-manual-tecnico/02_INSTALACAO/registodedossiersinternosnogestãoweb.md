---
title: Registo de Dossiers Internos no Gestão Web
source: registodedossiersinternosnogestãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Dossiers Internos no Gestão Web

O "Registo de Dossiers" é o local onde pode efetuar lançamentos de artigos ou serviços, com a opção destes abaterem o
stock
ou movimentarem os campos de reservas nas fichas dos artigos, dependendo das configurações dos dossiers efetuadas na aplicação
PHC CS Desktop
.
Se o dossier estiver configurado para ter descontos nas linhas, estes serão aplicados na introdução de linhas no dossier desde que o cliente ou fornecedor tiver configurado na sua ficha descontos habituais.
A validação da existência de
stock
nos dossiers é realizada nos seguintes casos:
Artigos que não sejam serviços;
Só para as linhas de dossiers que não sejam de produção;
Para dossiers que estejam configurados como:
Movimenta stock
,
Avisa stocks negativos e/ou não deixa gravar com stock negativo
;
O 1º código de movimento de stock do dossier tem que ser superior a 50
;
O dossier não seja de produção
.
Ecrã em modo de introdução/alteração
Ao introduzir ou alterar um dossier são apresentados os seguinte items:
Copiar de outro dossier
Ao premir esta opção, apenas quando o ecrã está em modo de introdução, a aplicação disponibiliza um ecrã que tem inúmeras opções para que o utilizador possa copiar os dados de outro dossier interno para dentro do dossier que está a criar.
Se no dossier destino já se encontrar o cliente preenchido, na procura do dossier, pode definir se apenas pretende ver dossiers desse utilizador ou se pretende ver qualquer dossier independentemente de quem o criou.
Para procurar o dossier que se pretende copiar, o utilizador precisa de, em primeiro lugar, selecionar o
Tipo de Dossier
que pretende e pode mesmo definir que quer
Observar apenas os dossiers abertos
.
Pode ainda definir o
Nº de unidades a copiar
. Ao premir o botão
é apresentada uma listagem com os dossiers encontrados. Pode também, sem selecionar nenhum dossier a copiar,
.
Qual o dossier a copiar
Neste local são visíveis os dossiers encontrados na pesquisa. É apenas necessário selecionar o dossier que se pretende copiar e selecionar as
opções sobre a cópia
que melhor servem cada propósito.
Cliente
Este campo é de preenchimento obrigatório.
Para pesquisar o nome do cliente/entidade, poderá colocar o nome deste diretamente ou selecioná-lo através da opção de procura
. Ao começar a introduzir as primeiras letras do nome do cliente, automaticamente são retornados os registos que começam pelos carateres colocados, sendo apenas mostrados os registos ativos da tabela a que o dossier interno está ligado. Após a sua introdução, o número do cliente/entidade é automaticamente preenchido.
Dossier
Este campo disponibiliza, por ordem alfabética, os tipos de dossier presentes no
Gestão Web
, permitindo a seleção do tipo que se pretende emitir.
Os dossiers são configurados na aplicação
PHC CS Desktop
para que possam estar disponíveis para consulta e emissão nas aplicações digitais. Essa configuração em conjunto com o acesso "Internet.Consultar", determina se o dossier está disponível nas listas de seleção que aparecem nos ecrãs "Dossiers Internos", "Consulta/Listagem de Dossiers Internos" e "Cópia de Dossiers Internos".
Número
Nº do dossier.
Após o documento estar finalizado surge por cima deste campo o botão
indicando que este documento é um documento certificado.
Est
Identifica com que estabelecimento é que o cliente está relacionado.
Moeda habitual
Caso estejam configuradas
Moedas estrangeiras
e
Taxas de Conversão para o Euro
na aplicação PHC CS Desktop, o utilizador dispõe das mesmas neste campo, permitindo-lhe indicar a moeda utilizada no dossier.
Assim que o utilizador alterar a moeda do documento, a aplicação disponibiliza as colunas:
-
Pr.Unit.Moeda
e
Total Moeda
nas linhas do documento;
Ref. Interna
Informa qual a referência interna a que está associado o dossier.
(campo de renomeação nos "Parâmetros Gerais" da aplicação
PHC CS Desktop
)
Área
Permite identificar a área onde se situa o cliente.
Nº do PAT
Este campo só está visível quando o Dossier Interno foi introduzido a partir de um PAT e mostra o número do PAT a que foi associado.
Observações
Campo de observações.
A introdução de linhas no documento é efetuada através das seguintes opções:
Ao selecionar esta opção, terá acesso ao ecrã de "
Escolha de Artigos/Serviços
" disponíveis.
Quando o utilizador
Voltar
, depois de adicionar o(s) artigo(s), o mesmo será colocado nas linhas do dossier, na quantidade definida.
Adiciona uma linha ao dossier. Nos campos "Referência" ou "Designação", à medida que for adicionando carateres, serão apresentados as referências passíveis de serem escolhidas, sendo a pesquisa filtrada até ao limite de sete registos. Após selecionar um dos campos, são automaticamente preenchidos os restantes campos, ou seja, se preencher a referência ao selecionar o valor pretendido, é automaticamente preenchida a designação e preço unitário, o mesmo se passa com a descrição. Para que a pesquisa incremental funcione é necessário, na aplicação PHC CS Desktop, ter o parâmetro geral
Usa "autocomplete" em todos os campos texto
ativo.
Este botão permite que seja copiada uma estrutura de dados a partir de um ficheiro com extensão .xls.
Este ficheiro deve conter na primeira linha os nomes dos cabeçalhos da grelha, sendo que abaixo devem ser inseridos os respetivos valores a importar.
Ao copiar os dados, a aplicação verifica se é passado um campo de referência e vai buscar os respetivos valores configurados para essa mesma referência.
Após esse processo, atribui os valores do ficheiro a cada um dos campos facultados, formatando os campos tendo em conta as formatações dos respetivos campos (se existentes), sendo por fim atualizados os totais dos documentos.
Nota:
Este botão apenas está disponível se tiver subscrito o PHC On.
Se o utilizador tiver configurada a possibilidade de utilizar artigos com características específicas (como por exemplo:
Cor
e
Tamanho
) ou seja, utilize a funcionalidade de
Grelhas
, aparecerá nas linhas do documento as respetivas colunas para que o utilizador defina concretamente nos artigos que está a incluir no documento, qual a cor e tamanho.
Nota:
Ao ativar a opção "Utiliza desconto nas linhas", na aplicação
PHC CS Desktop
, o utilizador poderá introduzir descontos comerciais nas linhas do documento. Esta opção permite ainda definir a quantidade de descontos a utilizar, podendo-se definir até 6 descontos. Desta forma, também serão visíveis quando for lançado um Dossier Interno através do Gestão Web.
Quando esta opção se encontra ativa e se encontram descontos definidos, passa a existir nas opções das linhas dos dossiers duas outras opções relacionadas com a atribuição de descontos.
Ao introduzir dossier interno certificado apenas é possível definir uma percentagem de desconto entre 0% e 100%. Caso a percentagem seja inferior a 0% ou superior a 100%, a aplicação altera automaticamente a percentagem para 0% e 100%, respetivamente.
Uma vez que a aplicação valida o acesso
Acesso a Preços de Venda e Descontos
de determinado Dossier, caso o mesmo esteja inativo, as colunas de Preço Unitário e dos Descontos não podem ser alteradas pelo utilizador.
Caso possua artigos compostos são introduzidas linhas com o artigos e os respetivos componentes. Na coluna
C
é possível identificar qual/is o(s) componentes(s) do artigo composto visto que a opção na linha fica ativa. Se alterar o preço, os descontos ou a quantidade do artigo composto, os componentes são atualizados. O contrário não se verifica, ou seja, se alterar o preço, desconto ou quantidade do componente, não atualiza o artigo composto. Se num artigo composto tiver a opção
Permite incluir componentes durante a edição dos documentos
, é ainda apresentado o botão
onde é possível acrescentar uma linha a seguir ao último componente do produto composto. Esta opção apenas está disponível se a opção de configurar Dossiers Internos
Permite incluir novos componentes
estiver ativada.
Se a opção de configuração do dossier
Recalcula o custo dos produtos compostos
estiver ativa, o campo
Preço de Custo
do artigo composto é atualizado.
Ao faturar o dossier, são copiados os componentes do artigo composto, mesmo que o documento de destino não utilize produtos compostos. Neste caso, a opção da na coluna
C
é desmarcada nos componentes do documento de destino.
Nota:
Este comportamento é diferente do PHC CS Desktop.
Para poder usufruir desta funcionalidade é necessário que tenha um artigo composto configurado no PHC CS Desktop e a opção de configuração de Dossiers Internos
Utiliza produtos composto
ativada.
Saiba mais sobre a funcionalidade dos artigos compostos,
aqui
.
Em qualquer uma das linhas do dossier, independentemente da forma como foi introduzida, existe sempre a opção de Apagar
.
Nota:
Nos documentos certificados esta opção deixa de estar visível aquando da alteração do documento.
Após as alterações necessárias ao campo quantidade deverá
Gravar
o dossier.
Total antes de I.V.A.
Valor total sem IVA.
Mas se o utilizador selecionar uma moeda estrangeira, a aplicação também disponibiliza o campo
Total Moeda antes de I.V.A.
, com a respetiva conversão efetuada.
Se alterar a designação da moeda no parâmetro de PHC CS Desktop
Nome da moeda Euro para extenso (plural)
, os campos
Total sem IVA
,
Total IVA
e
Total
apresentam-se com a descrição da moeda à frente.
Por exemplo:
Se utilizarmos o Dólar Australiano (AUD) a aplicação apresenta:
Total sem IVA AUD
Total IVA AUD
Total AUD
Nota:
Por fim, pode alterar a data do dossier introduzida pela própria aplicação, observar as colunas "Cor" e "Tamanho" (que apenas se encontram disponíveis se o dossier estiver configurado para permitir grelhas de cor e tamanho) em modo read-only (apenas de leitura) e ao gravar pode observar as somas do total antes de IVA, o valor do Iva e o Total.
Data
Data do dossier.
Modo de Pagamento
Aqui deverá ser selecionado qual o modo de pagamento acordado.
Data/Hora de expedição
Os campos
Data
e
Hora de Expedição
passam a estar disponíveis para dossiers internos configurados com o Tipo para SAF-T diferente de "DC" e que este não esteja vazio. Estes campos ficam preenchidos, por defeito, ao introduzir.
Ao gravar, a aplicação verifica se os campos
Data
e
Hora de Expedição
se encontram preenchidos e caso não estejam, impede a gravação e avisa o utilizador.
Local habitual da carga de mercadorias
Permite indicar qual o local de carga da mercadoria.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Local habitual de descarga de mercadoria
Permite indicar o local de descarga da mercadoria. Este campo fica automaticamente preenchido com a informação que se encontra na ficha do cliente.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Nota:
Ao clicar na lupa existente tanto no campo "Local habitual da carga de mercadorias" como no "Local habitual de descarga de mercadoria" e de seguida clicar em procurar, visualizará os registos com a respetiva morada.
Código de identificação atribuído pela AT
Este campo apenas surge quando o dossier tem tipo para SAFT igual a "GT", "GR", "GA", "GC" ou "GD" e indica o código de identificação do documento de transporte atribuído pela AT (Autoridade Tributária).
Data efetiva de entrega
Por questões legais este campo foi criado, mas é de preenchimento facultativo. É a Data em que os bens ou serviços faturados foram prestados e colocados à disposição do adquirente.
Quando o dossier cumprir os requisitos para que a informação seja entregue no Ficheiro SAFT, caso este campo esteja vazio é comunicado a data do Dossier.
Nota:
Na aplicação PHC CS Web, quando os campos não têm informação (estão vazios), por definição em modo de consulta, ficam omissos.
Os seguintes campos apenas se encontram disponíveis mediante o consumo do módulo
PHC CS CRM web
e caso o utilizador tenha configurado o dossier para ser um dossier ligado a Negócios.
Negócio
Os seguintes campos apenas se encontram disponíveis mediante o módulo
PHC CS CRM web
e caso o utilizador tenha configurado o dossier para ser um dossier ligado a Negócios.
Cod. Negócio
Este campo permite inserir um negócio através do seu código e fazer a respetiva pesquisa seja através do botão
ou através da busca incremental. Caso insira em primeira instância o código do negócio, irá preencher automaticamente os restantes campos associados ao negócio.
Descrição resumida do negócio
Este campo permite inserir o título do negócio e fazer a respetiva pesquisa seja através do botão
ou através da busca incremental. Caso insira em primeira instância a descrição resumida do negócio, irá preencher automaticamente os restantes campos associados ao negócio.
Status
Este campo identifica o status do Negócio associado.
Nota
: Quando se adiciona um artigo ou se altera a quantidade de determinada linha, o software calcula as promoções que possam estar definidas no artigo.
As opções do Módulo Ecovalor só estarão disponíveis se possuir o Módulo Ecovalor Gestão. Assim, ao ativar o módulo Ecovalor fica visível nas linhas dos documentos de faturação as seguintes opções:
Ecovalor
Este campo indica que o artigo tem ecovalor.
Total Ecovalor (a adicionar)
Este campo indica o valor do ecovalor da linha em questão que será adicionado ao preço de venda do artigo.
Total Ecovalor (já incluído)
Este campo indica o valor do ecovalor da linha em questão que já se encontra incluído no preço de venda do artigo.
Não calcula Ecovalor
Ao ativar esta opção o valor total do documento não está sujeito a ecovalor, como tal esta opção deve ser utilizada para os artigos em que o ecovalor é suportado pela empresa.
Apenas possível retirar o ecovalor do total do documento, quando o artigo está a adicionar o ecovalor ao preço de venda.
Após
o dossier, será apresentada a "Próxima ação". O objeto "Próxima ação" poderá ser configurado através da Framework PHC onde poderá adicionar-lhe novas
Opções de Ecrã
definidas pelo utilizador.
Ecrã em modo de consulta
Quando o utilizador acede, por modo de consulta, é possível através de
, realizar as seguintes ações:
Enviar Email
Nesta opção são mostrados os emails do cliente, após selecionar os destinatários é aberto o ecrã de envio de email, com os campos Destinatários, Assunto e Mensagem já preenchidos, permitindo assim enviar um email para o cliente, de uma forma mais rápida, com a informação mais pertinente sobre o Dossier. Para que a informação seja mais completa, o email contém tanto do cabeçalho do Dossier (tabela: ".bo"), como das respetivas linhas (tabela: ".bi").
Nota:
Esta opção também está acessível na área de próximas ações quando se grava um registo.
O botão
permite fechar o dossier, caso o dossier já se encontre fechado, surge o botão
, que permite reabrir o dossier.
Também em modo de consulta, o utilizador passa a dispor das
opções de registo
, onde terá a possibilidade
Anular o documento
através da opção:
.
Caso o Dossier esteja configurado para ter natureza de um documento certificado, a aplicação questiona o utilizador quanto à anulação do mesmo, disponibilizando o campo
Motivo de anulação
. Este campo só é de preenchimento obrigatório, quando se trata de um documento certificado.
Após a anulação do documento, o campo Motivo de Anulação fica preenchido e junto da identificação do Dossier e do respetivo número, fica registado: "Documento Anulado", tal como sugere a imagem:
Nota:
Quando o utilizador tem PHC On ativo e documento eletrónicos, a aplicação comunica imediatamente com a AT a sua anulação e respetivo motivo.
Dossiers Internos no Gestão Web
