---
title: Registo de Fornecedores no Gestão Web
source: registodefornecedoresnogestãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Fornecedores no Gestão Web

A opção de fornecedores permite o acesso aos registos da tabela de Fornecedores.
Na barra de ferramentas deste ecrã existem várias opções. Algumas destas são comuns a todos os ecrãs, nomeadamente a procura de registos.
Ecrã em modo de introdução/alteração
Nome
Permite indicar o nome completo do fornecedor.
Número
Número interno atribuído a cada fornecedor.
O programa dará um número automaticamente, embora o utilizador o possa alterar. Quando a numeração do fornecedor mais o prefixo da conta passarem o limite definido no parâmetro de fornecedores em "Windows"
N.º de dígitos das contas SNC
, a aplicação apaga os valores das contas SNC e deixa gravar sem as contas preenchidas.
Nota
: Quando o fornecedor já tem documentos certificados emitidos e não tem Nome ou Morada preenchido mas tem o Número de Contribuinte, é possível averbar o Nome e a Morada do fornecedor mas não é possível alterar o Número de Contribuinte.
Se o fornecedor tem o Nome e Morada preenchido mas não tem o Número de Contribuinte definido na sua ficha, pode apenas preencher o Número de Contribuinte não sendo possível alterar o Nome ou a Morada.
Saldo de c\c
Total do saldo existente em conta corrente.
Ao entrar na ficha de Fornecedor, em modo de consulta, através deste campo existe a possibilidade de aceder mais rapidamente e de forma intuitiva à respetiva listagem de conta corrente.
Esta funcionalidade aplica-se apenas em
modo de consulta
.
Nota:
Na criação de um estabelecimento e na ficha do mesmo, este campo fica indisponível.
Plafond
Limite máximo de crédito concedido pelo fornecedor. Não deverá ser preenchido se não existir limite.
Inativo ?
Este campo quando selecionado coloca o fornecedor como inativo de modo a não surgir nas opções dos ecrãs (Listagens / Procura, ... ). Assim, não se conseguem emitir novos documentos (por exemplo dossiers, compras, pagamentos) para os fornecedores inativos.
Compras Canceladas
Este campo quando selecionado impede o utilizador de efetuar compras ao respetivo fornecedor.
Nome abreviado
Campo que permite ao utilizador introduzir a abreviatura do nome do fornecedor.
Morada
Campo para identificar exatamente o endereço do fornecedor (Rua, Avenida…).
Localidade
Localidade da morada do fornecedor.
Código Postal
Este campo serve para a introdução do Código postal da morada do fornecedor.
País do Nº contribuinte
Permite selecionar e/ou criar o país correspondente ao número de contribuinte digitado.
Ao clicar em
terá a possibilidade de criar um novo código para o país.
Número Contribuinte
Número fiscal do fornecedor.
Se o parâmetro
Permite introduzir 2 fornecedores com o mesmo nº de contribuinte
da plataforma Windows se encontrar inativo, ao gravar um novo fornecedor, a aplicação verifica se já existe algum fornecedor na base de dados que tenha o mesmo nº de contribuinte e no caso de já existir, avisa o utilizador para tal facto não deixando gravar o novo registo.
Quando o parâmetro
Permite introduzir fornecedores com o nº de contribuinte em branco
da plataforma Windows se encontra inativo, no
Gestão web
não é possível gravar um novo fornecedor sem preencher este campo. Mas se estiver ativo, de acordo com o ponto 3 do Despacho n.º 8632/2014 - 03/07, a aplicação assume o seguinte comportamento:
Se o fornecedor já tiver documentos certificados (Autofatura) e não tiver o Número de Contribuinte preenchido na sua ficha de fornecedor, a aplicação não permite alterar o nome do fornecedor, mas uma vez que o Número de Contribuinte esteja preenchido na ficha do fornecedor, a aplicação já permite alterar o nome do fornecedor.
Fax
Campo para guardar o número do fax do fornecedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telefone
Este campo permite guardar o telefone do fornecedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Telemóvel
Campo para guardar o telemóvel do fornecedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
e-Mail
Neste campo deve ser colocado o endereço do correio eletrónico.
Site Internet
Este campo serve para guardar o endereço do site na Internet.
Moeda Habitual
Moeda a utilizar nas compras a este fornecedor. A moeda selecionada passa automaticamente para os documentos de compra e dossiers internos.
Observações
Campo "texto" para informação adicional respeitante ao fornecedor em questão. Este campo permite ainda a introdução de "Emotions", por exemplo:
:-) ou :)
:-D ou :d()
:-O ou :o()
:-P ou :p()
;-)
:-( ou :(
:-S ou :s()
:-| ou :|
:$ ou :-$
(H) ou (h)
:-@ ou :@
(A) ou (a)
Zona
Zona interna da morada do fornecedor. Este é um campo tabela do utilizador, onde se poderá colocar as várias zonas utilizáveis e criar novas através do botão
. O valor deste campo passa automaticamente para os documentos de compra.
Tipo de Fornecedor
Tipo interno a definir pelo utilizador. Utiliza a mesma filosofia do campo Zona e também permite criar novos tipos através do botão
.
Centro Analítico
Este campo é configurado pelo utilizador nos parâmetros gerais da plataforma Windows e permite definir que o fornecedor pertence a determinado centro analítico.
Informação
Contacto
Este campo permite guardar o nome do contacto comercial do fornecedor.
Telefone do 1º/2º/3º Contacto
Este campo permite guardar o nº de telefone do contacto comercial do fornecedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Fax do 1º/2º/3º Contacto
Este campo destina-se a guardar o fax do contacto do fornecedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
Função do 1º/2º/3º Contacto
Campo que guarda a função do contacto do fornecedor.
Cont. Administrativo (1) e (2), Telefone, Fax, Função
Este conjunto de campos funciona da mesma forma que os já explicados no contexto do
Contacto Comercial
.
País de origem do fornecedor
Neste campo fica definido qual o país de origem do cliente, ou seja:
Nacional
U.E.
Outros
Mapas Recapitulativos
Esta opção encontra-se relacionada com o tratamento de IVA. Se neste campo estiver selecionada a opção UE e caso o fornecedor esteja sujeito à inversão de sujeito passivo de iva, deve ativar também a opção Mapas Recapitulativos. Esta opção permite indicar que o fornecedor em causa não é da União Europeia, mas sim um fornecedor nacional com IVA no adquirente.
Número do B. Identidade
Número do bilhete de identidade do fornecedor.
Data do B. Identidade
Data de emissão do bilhete de identidade do fornecedor.
Local de Emissão do B. Identidade
Local de emissão do bilhete de identidade do fornecedor.
Passaporte
Número do passaporte do fornecedor.
Naturalidade
Naturalidade do fornecedor.
Nascimento
Data de nascimento do fornecedor.
NIB
Regista o número de identificação bancária do fornecedor.
Se o parâmetro
Valida NIB
da plataforma windows se encontrar ativo, ao gravar um novo fornecedor, a aplicação vai validar se o NIB se encontra de acordo com a legislação Portuguesa(com 21 dígitos). Caso não se pretenda qualquer tipo de validação do número introduzido para o NIB, bastará desativar este parâmetro.
I.B.A.N
Número internacional de identificação bancária.
Nacionalidade
Este campo serve para registar a nacionalidade do fornecedor. Através do botão
pode criar novos registos de nacionalidades.
Dados Financeiros
Vencimento
Número de dias para considerar vencido um crédito a este fornecedor (este campo passa automaticamente para os documentos de compra).
Tabela de IVA Fixa
Tabela de IVA fixa em todos os artigos a utilizar com este fornecedor.
Neste campo deve ser definida a tabela de IVA fixa para o fornecedor, para que, todos os documentos emitidos a este fornecedor utilizem esta taxa nas linhas dos documentos. Assim, a todos os artigos que vigorem em documentos emitidos a este fornecedor é obrigatoriamente aplicada a taxa de IVA fixa definida neste campo.
Desconto
Desconto habitual a efetuar nas compras a este fornecedor.
Desconto Financeiro
Desconto a que temos direito por parte do fornecedor se existirem as condições de pronto pagamento.
Desconto mão de obra
Desconto que o fornecedor dá na mão de obra.
Condições de Pagamento
Modo de Pagamento deste fornecedor (este campo passa automaticamente para os documentos de compra).
Ref. Interna
Este campo pode ser utilizado para diversos fins, tais como: filtro para mapas e listagens ou informação complementar para outras tabelas, já que o conteúdo deste campo transita para outras tabelas.
Tipo de Empresa
Este campo permite selecionar qual o tipo de fornecedor que está a introduzir.
Nota:
Esta tabela permite criar os registos associados a vários tipos de empresa. Esta tabela apenas está disponível se possuir o Módulo PHC CS Contabilidade web ou o Módulo PHC CS Gestão web, com o parâmetro da contabilidade de gabinete ativo.
Por defeito esta tabela já possui os tipos de empresa necessárias para uma correta configuração dos clientes e fornecedores, de acordo com o Sistema de Normalização Contabilística.
Conta na Contabilidade
Número da conta SNC para posterior integração no programa de Contabilidade.
Conta Letras na Contabilidade
Número da conta SNC para a rubrica de "Letras" para posterior integração no programa de Contabilidade.
Conta Adiantamentos c/ preço incerto na Contabilidade
Número da conta SNC para a rubrica de adiantamentos para posterior integração no programa de Contabilidade.
Fornecedor para compras a dinheiro
Tal como nos Clientes é possível definir se um fornecedor é o genérico para as compras.
Sujeito a retenção de IRS
Permite definir se é um fornecedor sujeito a retenção de IRS na fonte. Se assim for, todos os movimentos de compras e respetivos pagamentos, debitam a informação relativa à retenção do IRS na fonte nos Movimentos de conta-corrente de fornecedores.
Motivo de isenção de imposto
Este campo permite definir o motivo de isenção de imposto.
Quando preenche este campo e ao criar uma compra para um fornecedor com acordo de autofaturação, os campos de motivo de isenção e respetivo código passam da ficha do fornecedor para a compra.
Pode efetuar uma procura através do botão
ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.
Nota:
O preenchimento do motivo de isenção de imposto é obrigatório num documento de faturação quando o mesmo tem linhas com taxa de Iva 0 (zero) e o documento é assinado digitalmente de acordo com as regras de certificação de
Software
.
Diversos
Agente de Perceção
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa é um agente de perceção.
Agente de Retenção
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa é um agente de retenção.
Bom Contribuinte
(Apenas disponível no executável do Peru)
Este campo permite indicar que a empresa está incluída no Regime de Bons Contribuinte.
Internet
Nº no Front Web
Neste local deve definir o seu número de cliente na base de dados do seu fornecedor.
Método de envio de documentos via endereço eletrónico
Esta opção serve para definir para cada fornecedor qual o método de envio de documentos por via eletrónica:
Ficheiro
Neste caso o endereço deve ser preenchido com a diretoria para exportar os ficheiros (A exportação dos documentos é feita para ficheiros numa determinada diretoria);
E-Mail
Neste caso o endereço deve ser preenchido com o endereço de mail (Envio dos documentos anexados no E-mail);
Web Service
Neste caso deve ser preenchido com o endereço
URL
do serviço para onde deve ser enviado o documento (Envio dos documentos para um site que disponibilize a receção utilizando um Web Service).
Endereço eletrónico para enviar documentos por via eletrónica
Endereço para enviar documentos por via eletrónica.
Nome para login
Neste campo deve ficar o nome para login.
Password para autenticação
Neste campo deve ficar a password para autenticação.
Em modo de consulta através do botão
é possível efetuar várias opções com o fornecedor.
C. Corrente
Através desta opção é possível consultar uma listagem de conta-correntes do fornecedor no qual o utilizador se encontra posicionado. Nesta listagem é possível observar os
Movimentos não regularizados
ou
Todos os Movimentos de Conta-Corrente
.
É ainda possível pedir o extrato entre datas.
Compras
Esta opção permite consultar uma
Listagem de documentos de compra
ao fornecedor no qual o utilizador se encontra posicionado. É possível visualizar esta listagem entre datas.
Pagamentos
Esta opção permite consultar uma
Listagem de Pagamentos
ao fornecedor no qual o utilizador se encontra posicionado. É possível visualizar a listagem entre datas e definir o nº de
Movimentos por página
visíveis para consulta.
Evolução
Esta opção permite visualizar uma
Análise anual de compras
do fornecedor no qual o utilizador se encontrava posicionado.
Criar estabelecimento
Esta opção permite criar um novo estabelecimento para o fornecedor em causa.
Dossier Interno
Esta opção permite navegar para a Listagem de Dossiers, caso exista algum dossier.
Introduzir Compra
Através desta opção, é possível navegar para o ecrã de Compras, em modo de introdução.
Introduzir Compra
Permite que a partir do ecrã de fornecedores, o utilizador possa introduzir de forma rápida uma Compra ao Fornecedor. Os dados necessários para o registo da compra ficam automaticamente preenchidos na mesma, podendo o utilizador definir qual o tipo de documento a utilizar.
Introduzir Pagamento
Permite que a partir do ecrã de fornecedores, o utilizador possa registar um pagamento de forma rápida sobre as Compra ao Fornecedor. Os dados necessários para o registo da compra ficam automaticamente preenchidos na mesma, podendo o utilizador definir qual o tipo de documento a utilizar.
Introduzir Dossier
Permite ao utilizador de forma rápida a introdução de um Dossier a partir do ecrã de Fornecedores. Embora ainda tenha que escolher a série do Dossier, uma vez a criação do mesmo tem origem na ficha do Fornecedor, existem dados que ficam automaticamente preenchidos no Dossier Interno.
Fornecedores no Gestão Web
