---
title: Registo de Vendedores
source: registodevendedores.htm
tipo: Manual Técnico
idioma: PT
---

# Registo de Vendedores

Esta opção permite ao utilizador
introduzir
e
consultar
registos que contém informação sobre os vendedores. Desta forma, permite assim reunir num só local a informação individualizada sobre os comerciais da empresa.
Ecrã em modo de introdução/alteração
O ecrã "Vendedores" é constituído pelos seguintes campos:
Nome
Identificação do vendedor.
Inativo
Caso ative esta opção, o vendedor passa a não aparecer na listagem de vendedores que fazem referência a este campo nos diversos ecrãs da aplicação.
Número
Número interno atribuído automaticamente ao vendedor.
Nome Completo
Nome Completo do vendedor. Este campo é de preenchimento obrigatório
Morada
Morada completa do vendedor.
Localidade
Localidade da morada do vendedor.
Cód.Postal
Código postal da morada do vendedor.
Telefone
Número de telefone do vendedor.
Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.
e-Mail
Endereço do correio eletrónico do vendedor.
Área
Serve para poder catalogar os vendedores por áreas.
Ecrã em modo de Consulta
Tem a possibilidade de usufruir das
opções de registo
, bem como pesquisar,
alterar
e/ou apagar o registo. Poderá ainda introduzir e visualizar os comentários associados ao registo selecionado.
Crm Web
