---
title: "Relatório Único: Anexo D"
source: relatórioúnicoanexod.htm
tipo: Manual Técnico
idioma: PT
---

# Relatório Único: Anexo D

## Parâmetros

| 6.1.1 Total de exames de admissão | shrpt3.nexmadm18h + shrpt3.nexmadm1849h +
shrpt3.nexmadm50h + shrpt3.nexmadm18m + shrpt3.nexmadm1849m
+ shrpt3.nexmadm50m | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Exames de admissão. A aplicação soma os valores dos seguintes
campos da tabela. Homens: "8.1.1.1 - Nº de exames de admissão - H inferior a 18 anos" "8.1.1.1 - Nº de exames de admissão - H entre os 18 e os 49 anos" "8.1.1.1 - Nº de exames de admissão - H superior a 49 anos" Mulheres: "8.1.1.1 - Nº de exames de admissão - M inferior a 18 anos" "8.1.1.1 - Nº de exames de admissão - M entre os 18 e os 49 anos" "8.1.1.1 - Nº de exames de admissão - H superior a 49 anos" (Este tem
de se colocar sugestão pois deveria ser "8.1.1.1 - Nº de exames de
admissão - M superior a 49 anos", só está mal a descrição) |
| --- | --- | --- |
| 6.1.2 Total de exames periódicos | shrpt3.nexmoca18h1 + shrpt3.nexmoca1849h1 +
shrpt3.nexmoca50h1 + shrpt3.nexmoca18m1 + shrpt3.nexmoca1849m1 +
shrpt3.nexmoca50m1 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de
exames - Mudança
de posto. A aplicação soma os valores dos seguintes campos da tabela. Homens: "8.1.1.3.1 - Nº de exames ocasionais 1 - H inferior a 18 anos" "8.1.1.3.1 - Nº de exames ocasionais 1 - H entre os 18 e os 49 anos" "8.1.1.3.1 - Nº de exames ocasionais 1 - H superior a 49 anos" Mulheres: "8.1.1.3.1 - Nº de exames ocasionais 1 - M inferior a 18 anos" "8.1.1.3.1 - Nº de exames ocasionais 1 - M entre os 18 e os 49 anos" "8.1.1.3.1 - Nº de exames ocasionais 1 - H superior a 49 anos |
| 6.1.3.2 Alterações no posto de trabalho | shrpt3.nexmoca18h2 + shrtp3.nexmoca1849h2 +
shrpt3.nexmoca50h2 + shrpt3.nexmoca18m2 + shrtp3.nexmoca1849m2 +
shrpt3.nexmoca50m2 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Alterações no posto. A aplicação soma os valores dos seguintes campos
da tabela. Homens: "8.1.1.3.2 - Nº de exames ocasionais 2 - H inferior a 18 anos" "8.1.1.3.2 - Nº de exames ocasionais 2 - H entre os 18 e os 49 anos" "8.1.1.3.2 - Nº de exames ocasionais 2 - H superior a 49 anos" Mulheres: "8.1.1.3.2 - Nº de exames ocasionais 2 - M inferior a 18 anos" "8.1.1.3.2 - Nº de exames ocasionais 2 - M entre os 18 e os 49 anos" "8.1.1.3.2 - Nº de exames ocasionais 2 - H superior a 49 anos" |
| 6.1.3.3. Regresso ao trabalho após
ausência superior a 30 dias |  |  |
| 6.1.3.3.1 Pós baixa por acidente de
trabalho | shrpt3.nexmoca18h6 + shrpt3.nexmoca1849h6 +
shrpt3.nexmoca50h6 + shrpt3.nexmoca18m6 + shrpt3.nexmoca1849m6 +
shrpt3.nexmoca50m6 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Baixa por acidente. A aplicação soma os valores dos seguintes campos
da tabela. Homens: "8.1.1.3.6 - Nº de exames ocasionais 6 - H inferior a 18 anos" "8.1.1.3.6 - Nº de exames ocasionais 6 - H entre os 18 e os 49 anos" "8.1.1.3.6 - Nº de exames ocasionais 6 - H superior a 49 anos" Mulheres: "8.1.1.3.6 - Nº de exames ocasionais 6 - M inferior a 18 anos" "8.1.1.3.6 - Nº de exames ocasionais 6 - M entre os 18 e os 49 anos" "8.1.1.3.6 - Nº de exames ocasionais 6 - H superior a 49 anos" |
| 6.1.3.3.2 Pós baixa por doença | shrpt3.nexmoca18h7 + shrpt3.nexmoca1849h7 +
shrpt3.nexmoca50h7 + shrpt3.nexmoca18m7 + shrpt3.nexmoca1849m7 +
shrpt3.nexmoca50m7 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Baixa por doença. A aplicação soma os valores dos seguintes campos da
tabela. Homens: "8.1.1.3.7 - Nº de exames ocasionais 7 - H inferior a 18 anos" "8.1.1.3.7 - Nº de exames ocasionais 7 - H entre os 18 e os 49 anos" "8.1.1.3.7 - Nº de exames ocasionais 7 - H superior a 49 anos" Mulheres: "8.1.1.3.7 - Nº de exames ocasionais 7 - M inferior a 18 anos" "8.1.1.3.7 - Nº de exames ocasionais 7 - M entre os 18 e os 49 anos" "8.1.1.3.7 - Nº de exames ocasionais 7 - H superior a 49 anos" |
| 6.1.3.4 Iniciativa do médico | shrpt3.nexmoca18h4 + shrpt3.nexmoca1849h4 +
shrpt3.nexmoca50h4 + shrpt3.nexmoca18m4 + shrpt3.nexmoca1849m4 +
shrpt3.nexmoca50m4 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Iniciativa do médico. A aplicação soma os valores dos seguintes
campos da tabela. Homens: "8.1.1.3.4 - Nº de exames ocasionais 4 - H inferior a 18 anos" "8.1.1.3.4 - Nº de exames ocasionais 4 - H entre os 18 e os 49 anos" "8.1.1.3.4 - Nº de exames ocasionais 4 - H superior a 49 anos" Mulheres: "8.1.1.3.4 - Nº de exames ocasionais 4 - M inferior a 18 anos" "8.1.1.3.4 - Nº de exames ocasionais 4 - M entre os 18 e os 49 anos" "8.1.1.3.4 - Nº de exames ocasionais 4 - H superior a 49 anos" |
| 6.1.3.5 Pedido de trabalhador | shrpt3.nexmoca18h5 + shrpt3.nexmoca1849h5 +
shrpt3.nexmoca50h5 + shrpt3.nexmoca18m5 + shrpt3.nexmoca1849m5 +
shrpt3.nexmoca50m5 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de
exames - Pedido do trabalhador. A aplicação soma os valores dos
seguintes campos da tabela. Homens: "8.1.1.3.5 - Nº de exames ocasionais 5 - H inferior a 18 anos" "8.1.1.3.5 - Nº de exames ocasionais 5 - H entre os 18 e os 49 anos" "8.1.1.3.5 - Nº de exames ocasionais 5 - H superior a 49 anos" Mulheres: "8.1.1.3.5 - Nº de exames ocasionais 5 - M inferior a 18 anos" "8.1.1.3.5 - Nº de exames ocasionais 5 - M entre os 18 e os 49 anos" "8.1.1.3.5 - Nº de exames ocasionais 5 - H superior a 49 anos" |
| 6.1.3.6 Por cessação do contrato de
trabalho | shrpt3.nexmoca18h8 + shrpt3.nexmoca1849h8 +
shrpt3.nexmoca50h8 + shrpt3.nexmoca18m8 + shrpt3.nexmoca1849m8 +
shrpt3.nexmoca50m8 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de
exames - Pedido do trabalhador. A aplicação soma os valores dos
seguintes campos da tabela. Homens: "8.1.1.3.8 - Nº de exames ocasionais 8 - H inferior a 18 anos" "8.1.1.3.8 - Nº de exames ocasionais 8 - H entre os 18 e os 49 anos" "8.1.1.3.8 - Nº de exames ocasionais 8 - H superior a 49 anos" Mulheres: "8.1.1.3.8 - Nº de exames ocasionais 8 - M inferior a 18 anos" "8.1.1.3.8 - Nº de exames ocasionais 8 - M entre os 18 e os 49 anos" "8.1.1.3.8 - Nº de exames ocasionais 8 - H superior a 49 anos" |
| 6.1.3.7 Outras razões | shrpt3.nexmoca18h9 + shrpt3.nexmoca1849h9 +
shrpt3.nexmoca50h9 + shrpt3.nexmoca18m9 + shrpt3.nexmoca1849m9 +
shrpt3.nexmoca50m9 | Relatórios SHST - 6. Atividades de saúde - 6.1 Nº de exames
- Outras razões. A aplicação soma os valores dos seguintes campos da
tabela. Homens: "8.1.1.3.9 - Nº de exames ocasionais 9 - H inferior a 18 anos" "8.1.1.3.9 - Nº de exames ocasionais 9 - H entre os 18 e os 49 anos" "8.1.1.3.9 - Nº de exames ocasionais 9 - H superior a 49 anos" Mulheres: "8.1.1.3.9 - Nº de exames ocasionais 9 - M inferior a 18 anos" "8.1.1.3.9 - Nº de exames ocasionais 9 - M entre os 18 e os 49 anos" "8.1.1.3.9 - Nº de exames ocasionais 9 - H superior a 49 anos" |
| 6.2 Foram realizados exames
complementares? | shrpt4.examescomplementares | Relatórios SHST - 6. Atividades de saúde - 6.2-3
Exames complementares - Foram realizados exames complementares |
| 6.2.1 Exame |  | Relatórios SHST - 6. Atividades de saúde - 6.2-3 Exames
complementares - Tipo de exame ( Hemograma; Urina II; Espirometria; RX
tórax; TAC; Audiograma; Biomarcadores; Exame oftalmológico;
Outros) |
| 6.2.2 Total de
exame | shrpt3.ntotexmsan; shrpt3.ntotexmuri;shrpt3.ntotexmexp;
shrpt3.ntotexmrxt; shrpt3. ntotexmtac; shrpt3.ntotexmaud;
shrpt3.ntotexmoft; shrpt3.ntotexmout | Relatórios SHST - 6. Atividades de saúde - 6.2-3 Exames
complementares - Total ( Hemograma; Urina II; Espirometria;
RX tórax; TAC; Audiograma; Biomarcadores; Exame oftalmológico; Outros) |
| 6.2.3 Fator de
risco | shrpt4.sanguerisco1;shrpt4.sanguerisco2;
shrpt4.sanguerisco3; shrpt4.sanguerisco4; shrpt4.sanguerisco5;
shrpt4.sanguerisco6 shrpt.4.urinarisco1; shrpt.4.urinarisco2;
shrpt.4.urinarisco3; shrpt.4.urinarisco4; shrpt.4.urinarisco5;
shrpt.4.urinarisco6; shrpt4.exprisco1;shrpt4.exprisco2;
shrpt4.exprisco3; shrpt4.exprisco4; shrpt4.exprisco5; shrpt4.exprisco6;
shrpt4.raioxrisco1; shrpt4.raioxrisco2; shrpt4.raioxrisco3;
shrpt4.raioxrisco4; shrpt4.raioxrisco5; shrpt4.raioxrisco6;
shrpt4.tacrisco1; shrpt4.tacrisco2; shrpt4.tacrisco3; shrpt4.tacrisco4;
shrpt4.tacrisco5, shrpt4.tacrisco6; shrpt4.audiorisco1;
shrpt4.audiorisco2; shrpt4.audiorisco3; shrpt4.audiorisco4;
shrpt4.audiorisco5; shrpt4.audiorisco6; shrpt4.oftrisco1;
shrpt4.oftrisco2; shrpt4.oftrisco13; shrpt4.oftrisco14;
shrpt4.oftrisco15; shrpt4.oftrisco1 6 e shrpt4.outrisco1;
shrpt4.outrisco2; shrpt4.outrisco3; shrpt4.outrisco4; shrpt4.outrisco5;
shrpt4.outrisco6 | Relatórios SHST - 6. Atividades de saúde - 6.2-3
Exames complementares - Fator de risco |
| 6.3 Foram realizadas ações de
imunização? | shrpt4.examesimunizacoes | Relatórios SHST - 6. Atividades de saúde - 6.2-3 Exames
complementares - Foram realizadas ações de imunização |
| 6.3.1 Vacina | shrpt3.tipovaci1; shrpt3.tipovaci2; shrpt3.tipovaci3;
shrpt3.tipovaci4; shrpt3.tipovaci5 | Relatórios SHST - 6. Atividades de saúde - 6.2-3
Exames complementares - Descrição do tipo de vacinas (Tétano e difteria
(1); Gripe (2); Hepatite B (3); Imunizações específicas(4) e Outras
Vacinas(5)) |
| 6.3.2 Nº de
inoculações | shrpt4.consaccmedshrpt3.ninoc1; shrpt3.ninoc2;
shrpt3.ninoc3; shrpt3.ninoc4; shrpt3.ninoc5 | Relatórios SHST - 6. Atividades de saúde - 6.2-3 Exames
complementares - Nº de inoculações |
| 6.3.3 Nº de trabalhadores | Shrpt3.ntrabh1; Shrpt3.ntrabm1 | Relatórios SHST - 6. Atividades de saúde - 6.2-3 Exames
complementares - Nº de trab. H e M |
| 6.4.1 Atividade desenvolvida | shrpr4.codactividade1; shrpr4.codactividade2;
shrpr4.codactividade3; shrpr4.codactividade4; shrpr4.codactividade5;
shrpr4.codactividade6 | Relatórios SHST - 6. Atividades de saúde - 6.4
Promoção da saúde e educação - Código catividade |
| 6.4.2 Nº de ações de promoção da saúde
realizadas | shrpt4.numactividade1; shrpt4.numactividade2;
shrpt4.numactividade3; shrpt4.numactividade4; shrpt4.numactividade5;
shrpt4.numactividade6 | Relatórios SHST - 6. Atividades de saúde - 6.4 Promoção da
saúde e educação - Nº de ações realizadas |
| 6.4.3 Nº de
trabalhadores abrangidos | shrpt4.nhactividade1; shrpt4.nmactividade1
shrpt4.nhactividade2; shrpt4.nmactividade2; shrpt4.nhactividade3;
shrpt4.nmactividade3; shrpt4.nhactividade4;
shrpt4.nmactividade4; shrpt4.nhactividade5;
shrpt4.nmactividade5; shrpt4.nhactividade6; shrpt4.nmactividade6 | Relatórios SHST - 6. Atividades de saúde - 6.4 Promoção da
saúde e educação - Nº de trabalhadores abrangidos H e M |
