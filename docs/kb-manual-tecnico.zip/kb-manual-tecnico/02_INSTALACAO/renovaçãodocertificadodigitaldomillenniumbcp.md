---
title: Renovaçãodocertificadodigitaldomillenniumbcp
source: renovaçãodocertificadodigitaldomillenniumbcp.htm
tipo: Manual Técnico
idioma: PT
---

# Renovaçãodocertificadodigitaldomillenniumbcp

Renovação do Certificado Digital do Millennium Bcp

|  |
| --- |
| Renovação do Certificado Digital do Millennium Bcp |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O Certificado digital do Millennium BCP é necessário para a utilização da plataforma B2B, quando este certificado expira é necessário efetuar determinados procedimentos. Para quem já se encontra a utilizar esta funcionalidade o certificado expira no dia 8 de Fevereiro de 2010.    Para que os clientes continuem a utilizar a plataforma B2B dentro do software PHC, devem ser assegurados os seguintes passos:  1- Instalação do certificado digital do Millennium BCP (chave pública), na máquina a partir da qual se estabelece a ligação com o banco;    2- Configuração do novo certificado digital do Millennium BCP (chave pública) no software PHC na máquina que é utilizada para estabelecer a ligação ao Banco.  A substituição do certificado digital do Millennium BCP é um procedimento ciclicamente necessário para a continuidade da disponibilização dos serviços através da plataforma B2B, e que só voltará a ocorrer novamente em Fevereiro de 2013.       - **Passo 1**   Deve dirigir-se ao site do banco na área de empresas (pode usar o link em baixo) e fazer os seguintes passos:   https://corp.millenniumbcp.pt/pt/private/OutrosServicos/Pages/CertificadoDigitalB2B.aspx        a- Escolher nesta página o link **apresentação do Millennium BCP**, conforme assinalado pela seta na imagem;  b- No documento disponibilizado deve efetuar os passos descritos no ponto 7.2 (página 26);  c- Não é necessário executar os restantes passos do documento disponibilizado.     - **Passo 2**   Deve entrar no software PHC, no ecrã de utilizadores e clicar no botão de **configuração**, que se encontra no fundo do ecrã do lado esquerdo, de forma a poder configurar quais os Certificados de servidor para os serviços bancários online a utilizar com este utilizador.        No ecrã que surge deve encontrar os certificados existentes, deve efetuar as seguintes escolhas:  . No certificado da sua própria empresa deve ativar o visto na coluna **Cliente**;  . No certificado com o nome "Plataforma B2B Millennium BCP" deve ativar o visto na coluna **Servidor**.    Em seguida deve gravar as alterações efetuadas, ficando o ecrã tal como exemplifica a imagem em baixo.        *Nota importante:* Os nomes e datas podem não ser exatamente os mesmos da imagem.      Após estes procedimentos pode voltar a utilizar os serviços bancários dentro do seu Software PHC.      Gama de Software PHC onde foi testado: PHC Advanced 2010. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Renovação do Certificado Digital do Millennium Bcp' ) |