---
title: Resource File Version Mismatch
source: resourcefileversionmismatch.htm
tipo: Manual Técnico
idioma: PT
---

# Resource File Version Mismatch

Problema:
Ao
 entrar no exe dá o erro "resource file version mismatch "
Solução:
Existe
 algum software que também utiliza fox instalado nessa máquina e colocou
 erradamente o seu caminho na Path, fazendo com que ao tentar correr
o nosso software, em vez de procurar como é habitual, vai directamente
 a esse caminho indicado na Path.
O
 problema prende-se com o facto dessa aplicação utilizar uma versão do
 Visual Fox diferente da nossa.
Deste
 modo para poder contornar o problema existem duas hipóteses, retirar a
 directoria da outra aplicação do path (que será a melhor pois não sabemos
 que mais conflitos pode gerar), ou no shortcut da nossa aplicação colocar um
 parâmetro a seguir ao exe, por exemplo:
pgestão.exe -L FOXUSER.
