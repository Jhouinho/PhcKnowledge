---
title: Rgpd Web - Enviar um E-mail a Solicitar Consentimento
source: rgpdweb-enviarume-mailasolicitarconsentimento.htm
tipo: Manual Técnico
idioma: PT
---

# Rgpd Web - Enviar um E-mail a Solicitar Consentimento

Após instalar o módulo RGPD, surge a necessidade de notificar todos os clientes, informando das alterações à política de tratamento de dados, sendo necessário solicitar a autorização para a utilização dos seus dados.
Este artigo técnico, apresenta uma das possibilidades para efetuar este mesmo desenvolvimento. O código aqui apresentado, permitirá enviar um e-mail para todos os clientes a solicitar a aceitação das nova política de tratamento de dados.
Posteriormente, caso o cliente não aceite, o utilizador poderá proceder ao esquecimento dos dados desse mesmo cliente.
Para dar início ao processo, foi criado um aviso legal, específico, para solicitar o consentimento dos dados.
Será este o aviso legal, que será usado neste circuito. No separador "Dados Pessoais (RGPD)", foram adicionadas as seguintes tabelas:
- Clientes (CL);
- Fornecedores (FL);
- Funcionários (PE)
Após a criação do aviso legal, será necessário criar uma página de internet. O acesso a esta página irá aparecer no menu da aplicação e concentrará duas opções:
- enviar e-mail para todos os clientes a solicitar a aceitação da nova política de privacidade de dados;
- esquecer todos os clientes, que não tenham aceite a nova política de privacidade de dados.
No menu, deverá aceder às páginas de internet e criar um novo registo:
Título da página:
Notificações RGPD
Código de acesso a este registo:
sendrgpd
O título não aparece no conteúdo da página:
activo
É HTML puro:
ativo
Conteúdo da página:
&lttd bgcolor="#E5E7E7" style="padding:10px 20px;">
&lth2 class="w3-wide w3-center" style="text-align: center;"&gtRGPD</h2>
&ltp&gtA partir deste ecrã, tem a possibilidade de enviar um e-mail para todos os seus clientes(que estejam ativos), para que possam aceitar a alteração à nova política de tratamento de dados.</p>
&ltp&gtNo e-mail enviado, irá um link, que navega para o portal, onde o cliente terá a possibilidade de aceitar a disponibilização dos seus dados.</p>
&ltp> </p>
&ltp style="text-align: center;">
&lta href="../programs/gensel.aspx?cscript=enviamail">&ltbutton class="btn btn-primary" id="btnSen" type="button"&gtEnviar e-mail para todos os clientes (ativos)</button></a>
</p>
&ltp> </p>
&ltp&gtCaso pretenda esquecer todos os clientes, que até à data não tenham aceite a nova política de tratamento de dados, poderá fazê-lo por aqui. Ao selecionar o botão, a aplicação irá ler todos os clientes, que têm e-mail preenchido, que estejam ativos e que ainda não tenham sido esquecidos, esquecendo-os.</p>
&ltp style="text-align: center;">
&lta href="../programs/gensel.aspx?cscript=esquececl">&ltbutton class="btn btn-primary" id="btnSen" type="button"&gtEsquecer os clientes que não autorizaram a nova política de privacidade</button></a>
</p>
&ltp> </p>
&ltp> </p>
