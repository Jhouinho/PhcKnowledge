---
title: Seleçõesderecrutamento
source: seleçõesderecrutamento.htm
tipo: Manual Técnico
idioma: PT
---

# Seleçõesderecrutamento

Seleções de Recrutamento

|  |
| --- |
| Seleções de Recrutamento |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A tabela de Seleções de Recrutamento contém a seguinte informação:    **Recrutamento**  Qual o nome do recrutamento sobre o qual será feito a seleção.    **Candidato**  Permite indicar o candidato que será associado ao recrutamento.    **Análise Qualitativa**  Permite inserir texto sobre a análise da seleção em questão.    **Estado da candidatura**  Este campo permite que tenha mais informação da fase em que um candidato se encontra no recrutamento. Além, disso permite adicionar novos estados ou selecionar estados já existentes.     **Condições preferenciais satisfeitas**  Este campo apresenta as condições satisfeitas da seleção, ou seja, atendendo às condições exigidas pelo recrutamento (habilitações académicas, outras habilitações, características de recrutamento e idade), confrontando com o candidato em causa, irá verificar quais as condições satisfeitas pelo candidato.    *Exemplo 1*    Se tiver um Candidato:    * com 28 anos de idade;  * com uma Licenciatura em Informática de Gestão;  * com as Características de Recrutamento:     + Disponibilidade=Imediata;    + Região=Grande Porto e    + Anos de Experiência Profissional=2.      E um Recrutamento com os requisitos:    * Idade compreendia entre 25 e os 30 anos - Obrigatória;  * Habilitações Académicas = Licenciatura em Informática de Gestão - Não obrigatória;  * Características de Recrutamento:     + Disponibilidade=Imediata - Não obrigatória;    + Região=Grande Porto - Não obrigatória;    + Anos de Experiência Profissional=2 - Não obrigatória.      Condições preferenciais satisfeitas= 4 requisitos do recrutamento satisfeitos / 4 requisitos do recrutamento = 1 = 100%    *Nota*: Apenas se trata de 4 requisitos do recrutamento, porque os requisitos obrigatórios não entram para este cálculo.      *Exemplo 2*    Se tiver um Candidato:    * com 28 anos de idade;  * com uma Licenciatura em Informática de Gestão;  * com as Características de Recrutamento:     + Disponibilidade=Curto Prazo;    + Região=Grande Porto;    + Anos de Experiência Profissional=2.        E um Recrutamento com os requisitos:    * Idade compreendia entre 25 e os 26 anos - Não obrigatória;  * Habilitações Académicas = Licenciatura em Informática de Gestão - Não obrigatória;  * Características de Recrutamento:     + Disponibilidade=Imediata - Não obrigatória;    + Região=Grande Porto - Não obrigatória;    + Anos de Experiência Profissional=2 - Não obrigatória.      Condições preferenciais satisfeitas= 3 requisitos do recrutamento satisfeitas / 5 requisitos do recrutamento = 0.6 = 60%      **Candidato apurado**  Ao ativar esta opção, significa que o candidato em questão ficou aprovado na seleção de recrutamento. Após gravar a seleção apurada, terá a possibilidade de criar um colaborador e um funcionário (caso tenha o Módulo Pessoal) do candidato apurado.   Ao ser criado o Colaborador, o campo Nome e o e-mail provenientes do candidato são atualizados na ficha do colaborador. Ao ser criado o Funcionário, este é criado com os campos Nome, e-mail, Morada, Localidade, Código Postal, Nº B.I., Data de Nascimento, Telefone e Telemóvel, provenientes do candidato do colaborador.    No Ecrã de Seleções de Recrutamento encontram-se disponíveis as seguintes opções:     Este ícone permite imprimir a ficha.  Para mais informações sobre esta opção consulte por favor as [Impressões Definidas pelo utilizador](impressõesdefinidaspeloutilizador(idu).htm).     Este ícone permite imprimir um texto num processador de texto.  Para mais informações sobre esta opção consulte por favor no manual de Navegação o capítulo Ligação a [Processador de texto externo](ligaçãoaprocessadordetextoexterno.htm).     Este ícone permite consultar e inserir entrevistas.      *Nota*:  Os restantes ícones de caráter geral encontram-se explicados nas opções [globais](navegaçãonosecrãs.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Seleções de Recrutamento' ) |