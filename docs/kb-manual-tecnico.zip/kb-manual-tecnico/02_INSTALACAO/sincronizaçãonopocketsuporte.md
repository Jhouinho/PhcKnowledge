---
title: Sincronizaçãonopocketsuporte
source: sincronizaçãonopocketsuporte.htm
tipo: Manual Técnico
idioma: PT
---

# Sincronizaçãonopocketsuporte

Sincronização no Pocket Suporte

|  |
| --- |
| Sincronização no Pocket Suporte |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A opção de Sincronização permite que o PDA comunique com o Back Office e desta forma sincronize a informação.    Existem três formas de sincronização (que podem ou não depender do tipo de PDA que o utilizador tem):   - Utilizando o ActiveSync. Neste caso o PDA tem que ser ligado ao PC e é absolutamente necessário que o PC tenha ligação à Internet;      - Utilizando Rede Wireless. Neste caso o PDA tem que ter uma placa de rede wireless e basta ao utilizador estar no domínio da rede interna da empresa para poder comunicar ;     - Utilizando GPRS. Neste caso o PDA tem que ter GPRS ou forma de se conectar via GPRS. Desta forma o utilizador pode sincronizar em qualquer lugar a qualquer hora.         **URL**  Neste local tem que ser indicada a localização da aplicação PocketServices que é o elemento sincronizador neste processo.  No caso da forma de sincronização ser do tipo 1, o endereço da aplicação PocketService tem que ser por IP.    **Utilizador**  Este campo serve para definir qual o utilizador da aplicação PocketServices.    **Password**  Este campo serve para definir qual a password do utilizador da aplicação PocketServices.    **Ident. PDA**  Neste local é indicada a identificação do dispositivo (PDA). Esta identificação é definida no Back Office (na tabela de dispositivos móveis no módulo Supervisor).    **Inicialização**  Esta opção serve para sincronizar como se fosse a primeira vez.    Sem a opção de Inicialização     do Back Office para o PDA é enviada: - OS Dossiers Internos, Artigos e Promoções novos e alterados ; - Os Pedidos de Assistência novos e alterados, do técnico ; - Todos os Equipamentos e Instalações ou apenas aqueles que dizem respeito aos PATs sincronizados, sejam novos ou alterados ; - Todas as Intervenções agendadas do técnico ou as Intervenções relativas aos PATs sincronizados, sejam registos novos ou alterados ;      do PDA para o Back Office são enviados: - As Intervenções alteradas ; - Os Equipamentos novos ou alterados ; - Os Dossiers novos ou alterados .      Sempre que se sincroniza com esta opção activa, os registos são eliminados paralelamente ao processo de envio de informação. Esta rotina permite que em vez de serem adicionados registos aos já existentes, sejam eliminados os registos anteriores. Assim, por exemplo, se um pocket passar de um vendedor para outro, os clientes, equipamentos, etc... do primeiro são apagados, passando a vigorar no pocket os clientes e os equipamentos do outro vendedor.    Se se pretender sincronizar novos campos para algum dos ecrãs do pocket é necessário efectuar sincronização inicial de modo a passar o conteúdo do campo para o pocket.      **Opções**        Uma vez seleccionada a opção de mostrar relatório não é possível sair do ecrã de sincronização sem visualizar primeiro o relatório.      **Tabelas Internas**        Esta página da sincronização apresenta as diversas tabelas da aplicação e estas, por sua vez, os respectivos campos para consulta. Apresenta ainda a opção Parâmetros, na qual se pode consultar os parâmetros provenientes da sincronização, configurados no Back Office. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Sincronização no Pocket Suporte' ) |