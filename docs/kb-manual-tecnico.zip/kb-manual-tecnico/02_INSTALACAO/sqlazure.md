---
title: Sql Azure
source: sqlazure.htm
tipo: Manual Técnico
idioma: PT
---

# Sql Azure

Este artigo descreve as configurações e os passos necessários para alojar uma base de dados do PHC CS no SQL Azure. O SQL Azure apenas está disponível nas gamas Advanced e Enterprise do PHC CS.
Configurações da subscrição Azure
Em primeiro lugar, é necessário configurar um servidor SQL na subscrição Azure:
Passo 1:
Para criar um servidor SQL na sua subscrição, é necessário clicar na opção "New", da barra lateral esquerda, e procurar por "SQL Server (Logical Server)", selecionar e depois clicar no botão "Create". Para facilitar o acesso futuro, pode clique na opção "Pin to Dashboard" que está junto do botão "Create".
Passo 2:
Configure a Firewall para indicar os IP autorizados a aceder ao servidor SQL. Para isso, deve aceder ao servidor que acabou de criar, através da opção "All Resources", disponível na barra lateral esquerda, aceder à opção "Firewall" e adicionar os IP que pretende autorizar. Pode adicionar os IP manualmente ou utilizar o botão "Add Client IP" que adiciona automaticamente o IP que está a utilizar.
Passo 3:
Crie um
blob
(local de alojamento de ficheiros) para receber o ficheiro da base de dados. Quando passar o ficheiro compactado da base de dados para o Azure, tem do alojá-lo temporariamente até à importação da base de dados para o SQL Azure. No final de todo o processo, o
blob
deverá ser eliminado para não ficar sobrecarregar desnecessariamente a subscrição do Azure.
Para isso, deve aceder à opção "Storage accounts", disponível na barra lateral esquerda, e clicar no botão "+ ADD". Preencha os campos obrigatórios, tendo em atenção que no campo "Account kind" deve escolher a opção "BLOB Storage".
Depois de criado o
blob
, tem de guardar o endereço (URL) do blob, que está disponível através da opção "Overview" com a designação "Blob service endpoint".
Além disso, é necessário guardar a key de acesso ao
blob
, que está disponível através da opção "Access keys", na barra lateral esquerda, com a designação "key1".
Preparar a base de dados e enviar o SQL Azure
Depois de efetuadas as configurações necessárias para o servidor SQL em Azure, é necessário colocar a base de dados nesse mesmo servidor.
Passo 4:
Faça um backup da base de dados para salvaguardar a base de dados antes de se iniciar o processo de migração.
Os
Passo 5
e o
Passo 6
são opcionais. O objetivo é reduzir o tamanho da base de dados, garantindo que o processo de
deploy
é menos demorado e que o consumo de tráfego no Azure é o estritamente necessário.
Passo 5:
Elimine tabelas de
backup
que existam na base de dados.No SQL Management Studio, crie uma nova
query
para a base de dados em causa e executar as seguintes instruções:
DECLARE @tabela varchar(200)
declare @sql varchar(200)
DECLARE db_cursor CURSOR FOR
select name from sys.all_objects where type = 'U' and schema_id = 1 and name like 'BackUp%'
OPEN db_cursor
FETCH NEXT FROM db_cursor INTO @tabela
WHILE @@FETCH_STATUS = 0
BEGIN
set @sql = 'drop table [' + rtrim(@tabela) + ']'
print(@sql)
exec(@sql)
FETCH NEXT FROM db_cursor INTO @tabela
END
CLOSE db_cursor
DEALLOCATE db_cursor
go
