---
title: Sql para Phc
source: sqlparaphc.htm
tipo: Manual Técnico
idioma: PT
---

# Sql para Phc

Os melhores procedimentos no SQL para a utilização e manutenção de bases de dados PHC.
Pontos mais importantes da instalação:
A instalação de uma instância de
SQL
para alojar bases de dados
PHC
, deverá ter em conta algumas premissas para facilitar a posterior manutenção e performance das mesmas, de acordo com as linhas de desenvolvimento da nossa aplicação.
Assim, no passo da "Configuração da Instância" será importante atribuir um nome (sem carateres especiais - cedilhas, acentos etc.) que seja claro para o administrador da mesma, e no caso existirem mais, deve apresentar-se um diferenciador.
Quando o processo de instalação estiver na "Configuração do Servidor", aconselha-se que todos os serviços fiquem configurados com o arranque automático (se possível), assim a conta de arranque poderá ser mantida.
É também fundamental aceder ao separador "Collation" e garantir que para o motor de bases de dados seja
SQL_Latin1_General_CP1_CI_AI
, e para os serviços de análise seja a equivalente
Latin1_General_CI_AI
.
Estas configurações devem-se ao fato do
PHC
ser uma aplicação desenvolvida para interpretar carateres latinos, e é no seu "código fonte" que são tratadas as maiúsculas/minúsculas, assim como os acentos. Caso a configuração da
collation
seja diferente, estas características do
PHC
ficam comprometidas.
No passo seguinte, "Configuração do Motos de Bases de Dados", aconselhamos a utilização do
Mixed Mode
. Neste ponto é necessário escolher um utilizador (normalmente é o administrador ) e executar: "Add Current User". É também obrigatório introduzir uma password, que será a password de acesso a esta instância com o
SA (System Administrator)
.
Para o
PHC
funcionar apenas é necessária a instalação de:
Database Engine Services
Client Tools Connectivity
SQL Server Books Online
Management Tools Complete
Configuração e otimização
O
SQL Management Studio
é uma ferramenta que executa muitas das tarefas necessárias à "Otimização e Manutenção" do próprio
SQL
ou de bases de dados à sua responsabilidade.
Desta forma, através do
SQL Server Management Studio
podemos efetuar as seguintes otimizações na instância que acabou de ser criada (clique direito sobre o nome da mesma e escolher Propriedades):
Memory
O
SQL
gere a memória da máquina conforme o servidor vai utilizando a mesma dentro dos Parâmetros estabelecidos, se não, aloca para si toda a memória e devolve a restante ao S.O..
Assim, dependendo se o servidor é dedicado (pode disponibilizar toda a memória ao SQL) ou não (para que as restantes aplicações também funcionem, terá que existir gestão da memória), poderá ser necessário definir uma limitação no
Maximum Server Memory
e no
Minimum Memory per query
, como por exemplo, 1024Mb. Desta forma, limita-se o acesso a esta instância à memória, para que as restantes aplicações possam trabalhar em simultâneo.
Processors
Neste grupo também é necessário ter em conta se o servidor é dedicado ou não.
Se durante a instalação não for escolhido o modo de acesso
Mixed Mode
(
SQL Server and Windows Authentication mode
), este poderá ser alterado no grupo
Security
.
Connections
É importante manter o parâmetro "Allow remote connections to this server" ativo e o "Remote Query Time-Out" com 600.
Database Settings
Neste ponto, é ideal que o
Default índex fill factor
seja 70 no
PHC
, porque só faz a manutenção dos índices. Abaixo deste valor, o
SQL
automaticamente refaz os índices não otimizados, o que não é desejável.
Advanced
De entre todas as opções configuráveis, que poderão ficar com o seu valor original, evidenciamos a propriedade "Allow triggers to fire others" que deverá necessariamente estar ativa (
True
).
Deve-se ter em conta no
SQL Server Management Studio
, as seguintes propriedades nas bases de dados
PHC
(clique direito sobre o nome da mesma e escolher Propriedades e dentro destas as Opções):
Collation: SQL_Latin1_General_CP1_CI_AI
Recovery Model: Simple (Aconselhamos Simple, mas poderá também ser Full em situações excecionais)
Compatibility Level, sempre de acordo com a versão do
SQL
em que a base de dados está alocada e não de versões mais antigas.
Autoclose = False
Auto Create Statistics= True
Auto Shrink = False (esta manutenção - shrink à base de dados - deve ser feita no SQL, periodicamente, não de forma automática, e numa altura em que ninguém esteja a utilizar a base de dados, de seguida deverá ser utilizada uma ferramenta que existe no PHC para desfragmentar tabelas).
Auto Update Statistics= True
Ansi Nulls Default= False
Ansi Nulls Enabled= False
Ansi Paddings= False
Ansi Warnings= False
Use Quoted Identifiers= False
Recursive Triggers Enabled= True
Manutenção:
Nome da Base de Dados
Com o intuito de evitar futuros problemas, aconselhamos que o nome da base de dados não contenha carateres especiais (acentos, cedilhas, espaços, sinais de pontuação e símbolos) e não comece por algarismos.
Firewall
Em alguns ambientes é necessário criar exceções às portas 1433 e 1434, TCP e UDP, ao nível da
Firewall
.
TEMPDB
Além destes aspetos e ainda dentro da melhoria de performance, é importante que a tempdb (base de dados de sistema) tenha um tamanho que represente metade da maior Base de Dados existente nesse servidor de
SQL
. Por exemplo, se esse servidor tiver 4 Base de Dados, e se a maior dessas Base de Dados tiver um tamanho de 100Gb, então a tempdb deverá ter um tamanho de 50Gb.
Autogrowth
A
PHC
aconselha um "File growth by percent" de 10% e "Unrestricted file growth" que poderá ser ajustado em "Management Studio - Propriedades de cada BD - Files - Autogrowth".
Por defeito o
SQL
não coloca estas configurações, por isso deverão ser alteradas.
Em algumas situações pode ser aconselhável utilizar 20%. A melhor opção para esta alteração será quando não acontece nenhum acesso à base de dados (por exemplo durante a noite). Neste caso convém ir verificando o crescimento, pois se o espaço em disco for atingido a Base de Dados pode ficar irrecuperável.
Exemplo:
A mensagem "Could not allocate space for object... The primary filegroup is full" indica que o crescimento das tabelas está restrito, e acontece pelo fato da configuração do
Autogrowth
não estar "Unrestricted file growth", ou por já não existir espaço suficiente no disco do servidor onde está a base de dados.
