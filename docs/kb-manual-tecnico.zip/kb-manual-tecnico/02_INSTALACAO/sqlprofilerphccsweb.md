---
title: Sqlprofilerphccsweb
source: sqlprofilerphccsweb.htm
tipo: Manual Técnico
idioma: PT
---

# Sqlprofilerphccsweb

Sql Profiler Phc Cs Web

|  |
| --- |
| Sql Profiler Phc Cs Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo técnico visa explicar como se pode usar o SQL Profiler no PHC CS Web. O SQL Profiler pode ser ativado de duas formas:    * Através do monitor de sistema;   ou   * Através da Configuração da chave &ltadd key="SQLProfiler" value="S"/&gt no appSetting.config.        **Monitor de Sistema**  Para ativar o SQL Profiler deverá aceder ao Monitor de Sistema, e para ver as consultas deve clicar no separador "SQL Profiler".     Quando é ativado o SQL Profiler, ficam registados em memória todos os pedidos feitos ao SQL Server pela sessão corrente. Para desabilitar este log basta encerrar a sessão corrente sendo que, para ativá-lo novamente, é preciso voltar a aceder o Monitor de Sistema.        A informação é atualizada automaticamente e esta ação irá mostrar todos os pedidos feitos ao SQL deste a ativação do SQL Profiler.   A sintaxe da informação mostrada é a seguinte:    **p: horário - Descrição da Consulta - Status da Consulta**  Exemplo:   p:16:26:23.27 - UPDATE efk SET txtinfo=@txtinfo WHERE efk.efkstamp=@efkstamp  No error    Onde:  **p:** - Localizado sempre no início da linha, indica que é uma linha de pedido ao SQL;  **6:26:23.27** - Indica o horário do pedido;  **UPDATE efk SET txtinfo=@txtinfo WHERE efk.efkstamp=@efkstamp** - É a descrição do pedido  **No error** - É o status do pedido que pode assumir também o texto With error.  O botão **Limpar conteúdo**, irá limpar toda a informação sobre os pedidos que foram feitos ao SQL Server, equivalente ao Clear Trace Window do Profiler do SQL Server.     *Nota:* O monitor de sistema pode ser acedido a partir do menu "Configurações", ecrã "Monitor de Sistema" ou através da opção *../programs/gensel.aspx?opcoes=sim*.      **Configuração da chave &ltadd key="SQLProfiler" value="S"/&gt no appSetting.config**    Quando configuramos a chave &ltadd key=" SQLProfiler" value="S"/&gt no appSetting.config, o SQL Profiler fica ativo para todos os utilizadores, não sendo necessário voltar a aceder ao monitor de sistemas. Para o desligar será necessário alterar a chave e colocar o value="N".  A vantagem de utilizar o SQL Profiler é dar a possibilidade ao utilizador de em qualquer local ou dispositivo aceder as consultas SQL, sem a necessidade de ter o SQL Server Instalado ou fazer alguma configuração.  A desvantagem é que a informação vai sendo exibida no ecrã e não há possibilidade de filtros ou procura. Assim, o utilizador deve estar atento à data/hora para poder encontrar a consulta pretendida.      Gama e versão de software PHC em que foi testado: PHC CS Web 18 |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Sql Profiler Phc Cs Web' ) |