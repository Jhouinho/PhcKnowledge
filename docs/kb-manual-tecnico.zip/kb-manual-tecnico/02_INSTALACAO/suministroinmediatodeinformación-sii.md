---
title: Suministro Inmediato de Información - Sii
source: suministroinmediatodeinformación-sii.htm
tipo: Manual Técnico
idioma: PT
---

# Suministro Inmediato de Información - Sii

O SII - Suministro Inmediato de Información - é o novo sistema de gestão do IVA em Espanha, no qual as empresas devem proceder à comunicação online de faturas de vendas e de compras.
Neste novo sistema são reportados à Agência Tributária de forma eletrónica os seguintes livros:
Libro registro de facturas expedidas;
Libro registro de facturas recibidas;
Libro registro de bienes de inversión;
Libro registro de determinadas operaciones intracomunitarias.
Esta informação é enviada de forma eletrónica por XML via Webservice da AEAT - Agencia Estatal de Administración Tributaria.
A quem se destina esta obrigação
Grandes Empresas (faturação superior a 6 milhões de euros);
Grupos de Entidades;
Inscritos no REDEME (Registo de Devolução Mensal de IVA).
O SII também poderá ser aplicado pelas empresas com faturação inferior a 6 milhões de euros que assim o pretendam, desde que comuniquem a sua vontade durante o mês de junho de 2017 no Modelo 036, não necessitando de confirmação por parte da Agencia Tributária. Esta decisão surte efeitos automáticos a partir de julho 2017, sendo que a permanência mínima recai sobre o próprio ano em que optaram por comunicar os dados.
A comunicação de faturas do SII obriga a entrega mensal do IVA, deixando de ser obrigatório a entrega dos Modelos 390, 340 e 347.
Desta forma, todas as empresas são obrigadas a entregar o Modelo 303, sendo opcional:
A entrega dos Modelos 390 e 347, por parte das Grandes Empresas, do Grupo de Entidades e do Resto (Regime Geral);
A entrega dos Modelo 347. por parte das Pequenas Empresas (ou Redeme).
Prazos de entrega e início do novo sistema
O SII entra em vigor a 1 de julho de 2017.
Os documentos de faturação emitidos entre dia 01 a 30 de junho 2017, devem ser entregues entre 01 de julho e 31 de dezembro do ano 2017.
O SII no PHC CS Desktop
Procedimento para atualização da versão
Aceder ao PHC CS Desktop na nova versão e correr a "Instalação e manutenção";
Adicionar o módulo PHC CS Documentos Eletrónicos desktop no separador "Validações", do ecrã "Grupos de Utilizadores", acedido através do menu "Sistema", a fim de poder comunicar as faturas via Webservice;
Aceder ao ecrã "Parâmetros" no menu Sistema, nó "Configuração geral", ativar o parâmetro
Utiliza SII - Suministro Inmediato de Información
.
Instalar o certificado digital para a comunicação via Webservice
Para obter o certifcado digital para a comunicação via Webservice deverá aceder ao
site
da Agencia Tributária e efetuar a respetiva transferência.
Caso seja a primeira vez que esteja a a instalar o certificado, após a transferência, deverá clicar duplamente no ficheiro "certificado.fpx" e seguir os seguintes passos:
Escolher a diretoria para a importação do certificado:
Colocar a password associada ao certificado fornecido pela Agencia Tributaria. Além disso, ative as opções:
Mark this key as exportable. this will allow you to back up or transport your keys at a later time.
Include all extend properties.
Após carregar em "Next", ative a opção
Automatically select the certificate store, or you can specifiy a location for certificate
e termine a instalação.
Terminada a instalação, deverá aceder aos certificados, a partir da pesquisa do Windows escrevendo "certificados" ou "certificates", e clique em "Manage user certificates". Na aplicação "Manage user certificates", aceda à pasta "Personal", fazer duplo clique no certificado anteriormente corrido e copiar o nome do certificado que se encontra no separador "Details" em "subject" para o parâmetro
SII - Nome do certificado para comunicação com os Webservices
, acedido através do menu "Sistema" do PHC CS Desktop.
Nos três parâmetros relativos ao SII não necessita de alterar os URL's existentes pois após a atualização assumem os endereços corretos:
SII: Webservice Comunicação de faturas Emitidas - Url da AEAT para comunicação de faturas emitidas
;
SII: Webservice Comunicação de faturas Recebidas - Url da AEAT para comunicação de faturas recebidas
;
SII: Webservice Comunicação de operações intracomunitárias - Url da AEAT para comunicação de operações intracomunitárias
.
Para que sejam validados os documentos de compras e vendas que foram feitos no período de janeiro a julho de 2017, uma vez que é obrigatório enviar as faturas de janeiro a junho, e posteriormente inclui-los no SII, deve solicitar via PAT a tecla que faz esta validação.
No ecrã "Configuração de Documentos de Faturação" e "Configuração de Documentos de Compras" passa a estar disponível a caixa de seleção
Tipo para SII
. Através deste campo, o utilizador pode definir uma das seguintes opções:
F1 | Fatura;
F2 | Fatura simplificada (ticket);
R1 | Fatura rectificativa (Art 80.1 e 80.2 e erro fundado em direito);
R2 | Fatura rectificativa (Art. 80.3);
R3 | Fatura rectificativa (Art. 80.4);
R4 | Fatura rectificativa (Resto);
R5 | Fatura rectificativa em faturas simplificadas;
R6 |"Importações (DUA) - apenas para Compras.
Ainda no ecrã "Configuração de Documentos de Faturação" é necessário preencher a opção
Modalidade por defecto
com a opção
Clave 01 Operación de régimen común
Nos ecrãs "Clientes" e "Fornecedores" é necessário preencher os seguintes campos:
Modalidade (separador Vários);
Motivo exención impuesto (separador Datos Financieros);
Tipos de Identificação
novos:
01: NIF(País de origem Nacional)
02: NIF-IVA (País de origem U.E.)
03: Pasaporte (País de origem U.E. e Outros)
04: Documento oficial de identificación expedido por el país o territorio de residência (País de origem U.E. e Outros)
05: Certificado de residencia (País de origem U.E. e Outros)
06: Otro documento probatório (País de origem U.E. e Outros)
Relativamente à forma como se deve colocar os NIF dos clientes / fornecedores é importante que se respeite a seguinte estrutura:
Identificação
: NIF-IVA (operações intracomunitárias):
Identificação
: NIF restantes:
Todas as faturas/compras que estejam com o campo
Tipo para SII
preenchido (configuradas para serem comunicadas) têm de ter sempre:
Número de identificação fiscal;
Modalidade;
Motivo de isenção, quando as linhas do documento tenham taxa de iva 0% sem a modalidade "Régimen general".
Operações não sujeitas
Sempre que existam operações não sujeitas nas vendas e compras no PHC CS desktop , são consideradas sempre como
Importe en euros si la sujeción es por el art. 7,14, otros
é necessário:
Ativar a opção
Operación no sujeta
no separador outros dados;
Nenhuma linha pode ter taxa diferente de 0%.
Eliminar documentos
Após a comunicação de um documento em que o resultado tenha sido efetuado com sucesso para o webservice da AEAT, já não é possível apagar esse documento, uma vez que o registo já foi enviado.
Sempre que se queira retificar documentos já comunicados, o utilizador terá de fazer uma Fatura retificativa.
Livros do SII suportados pelo PHC CS Desktop
Libro registro de facturas expedidas;
Libro registro de facturas recibidas;
Libro registro de determinadas operaciones intracomunitarias.
Modalidades suportadas pelo PHC CS Desktop
Faturas de Venda:
01 Operación de régimen común
02 Exportación
03 Operaciones a las que se aplique el régimen especial de bienes usados, objetos de arte, antigüedades y objetos de colección (135-139 LIVA);
04 Régimen especial oro de inversión;
05 Régimen especial agencias de viajes;
06 Régimen especial grupo de entidades en IVA (nivel avanzado).
Faturas de Compra:
01 Operación de régimen común;
03 Operaciones a las que se aplique el régimen especial de bienes usados, objetos de arte, antigüedades y objetos de colección (135-139 LIVA);
04 Régimen especial oro de inversión;
05 Régimen especial agencias de viajes;
06 Régimen especial grupo de entidades en IVA (nivel avanzado);
09 Adquisiciones intracomunitarias de bienes y prestaciones de servicios.
Comunicação no PHC CS Desktop
A Comunicação dos documentos é feita a partir do "Monitor de Comunicação SII" disponível em:
Módulo PHC CS Gestão desktop (Menu Gestão - Monitor de Comunicação do SII);
Módulo PHC CS Contabilidade Desktop (Menu Contabilidade - Monitor de obrigações declarativas - Gestão - Monitor de Comunicação do SII).
Neste monitor encontra 2 separadores:
"Lista de documentos de clientes" quando os documentos são gerados no ecrã "Faturação a clientes";
"Lista de documentos de fornecedores" quando os documentos são gerados no ecrã "Compras a fornecedores";
Pode enviar um ou vários documentos ao mesmo tempo selecionando quais os documentos a enviar e seguidamente clicar no botão "Enviar", após a mensagem de envio "CORRECTO", os documentos deixam de aparecer no monitor.
Se por sua vez foi dado como não aceite ou aceite com erros, continua a ser listado na respetiva grelha, para poder ser modificado e enviado novamente.
Resultado das comunicações à AEAT
Após comunicar as faturas/compras, se posteriormente pretender consultar o resultado dessas comunicações, pode aceder a partir dos ecrãs "Vendas" e "Compras", e nas opções diversas selecionar a opção "Resultado de comunicação por Webservice a la AEAT" daquela fatura/compra, conforme imagem:
Neste local o utilizador pode consultar todas as tentativas de comunicação daquele documento, assim como visualizar a data e a hora que foram efetuadas.
Plataforma a que corresponde esta funcionalidade:
PHC CS Desktop
Esta funcionalidade está disponível na seguinte localização:
Espanha
Gama em que está disponível:
Advanced e Enterprise
Versão de software:
21
Subscrição de PHC On:
Sim
