---
title: Supervisão
source: supervisão.htm
tipo: Manual Técnico
idioma: PT
---

# Supervisão

Supervisão

|  |
| --- |
| Supervisão |

|  |
| --- |
| Neste local irão ser explicadas algumas funcionalidades comuns a todos os módulos. Estas funcionalidades devem ser na sua maioria da responsabilidade do administrador de sistema, sendo elas:     * [Tabelas de Códigos](tabelasdecódigosdosupervisor.htm);  * [Instalação e Manutenção](instalaçãoemanutenção.htm);  * [Importar dados de software PHC](importardadosdesoftwarephc.htm);  * [Dicionário de Dados](dicionáriodedados.htm);  * [Campos do Utilizador](camposdoutilizador.htm);   [Regras do Utilizador](regrasdoutilizador.htm); * [Valores por Defeito](valorespordefeito.htm);  * [Teclas do Utilizador](teclasdoutilizador.htm). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Supervisão' ) |