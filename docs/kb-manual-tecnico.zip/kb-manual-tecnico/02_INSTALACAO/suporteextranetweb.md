---
title: Suporteextranetweb
source: suporteextranetweb.htm
tipo: Manual Técnico
idioma: PT
---

# Suporteextranetweb

Suporte Extranet Web

|  |
| --- |
| Suporte Extranet Web |

|  |
| --- |
| O **Suporte extranet web** é um módulo que permite uma interação da atividade da empresa com clientes da mesma via *Internet*.  O "Suporte técnico" passa assim a assumir uma vertente de comunicação, que passa pela colocação de pedidos de assistência, diálogos, e partilha de informação entre estes dois intervenientes.    Assim, este módulo encontra-se dividido em três menus principais:    [Equipamento](equipamentopróprio.htm)  Esta vertente permite que o utilizador cliente consulte os seus equipamentos e instalações.    [Informação](procuradeinformação.htm)  Esta vertente permite a partilha de informação do foro técnico.    [Suporte](suporte.htm)  Por fim, esta área permite efetivar toda a área de suporte técnico da empresa, nomeadamente consultar as intervenções resultantes dos pedidos introduzidos pelos clientes.    A configuração deste módulo é efetuada no módulo**Suporte**, da plataforma *PHC CS Desktop* e também nos respetivos [Parâmetros](Parâmetros.htm#DGSPara8) do módulo, em PHC CS Web.  Este módulo é auto suficiente no seu propósito, pelo que funciona sozinho, sem o módulo [Suporte intranet web](suporteintranetweb.htm). No entanto, quando os dois módulos coexistem, o **Suporte extranet web** assume novas opções e vê as suas funcionalidades tornarem-se mais completas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Suporte Extranet Web' ) |