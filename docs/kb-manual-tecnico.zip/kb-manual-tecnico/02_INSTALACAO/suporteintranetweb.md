---
title: Suporteintranetweb
source: suporteintranetweb.htm
tipo: Manual Técnico
idioma: PT
---

# Suporteintranetweb

Suporte Intranet Web

|  |
| --- |
| Suporte Intranet Web |

|  |
| --- |
| O **Suporte intranet web** é uma ferramenta muito completa na gestão de equipamentos, assistência e de toda a informação relacionada.    No que diz respeito à Informação, através desta aplicação o utilizador pode criar uma [Galeria de Anúncios](galeriadeanúncios.htm) das mais variadas categorias. Qualquer utilizador, mediante os respetivos acessos pode inserir e [anúncios](registodeanúncios.htm) e responder a outros existentes. Na **Extranet** ainda é possível disponibilizar estes anúncios que também podem ser respondidos.    Existe ainda uma ferramenta que agrupa informação variada sobre conteúdos definidos por categorias. Esta chama-se [Galeria Multimédia](galeriamultimédia.htm) e permite inserir *links* para filmes explicativos de determinados assuntos e texto. Mediante acessos respetivos, o utilizador pode inserir novos [conteúdos multimédia](conteúdosmultimédia.htm) e comentários aos já existentes.    O **Suporte intranet web** permite a consulta e troca de informação através do [Fórum Técnico](fórumtécnico.htm).  Através da opção [Chamadas Telefónicas](consultadechamadastelefónicas.htm) pode aceder a todas as suas informações facto que se revela de extrema importância na resolução dos [pedidos de assistência](pedidosdeassistência.htm).  Pode ainda introduzir [Intervenções Técnicas](intervençõestécnicas(suporteintranetweb).htm) a realizar de acordo com os pedidos de assistência efetuados, intervenções cujo registo pode ser consultado na [Agenda de Marcações](agenda.htm).  Para além da [Consulta de Pedidos](consultadepedidos.htm) de Assistência existem outras opções tais como; [Base de Dados Técnica](consultarbasededadostécnica.htm), [Pesquisa Avançada (Interna)](pesquisaavançada(interna).htm), [Wikis](wikis.htm), [Perguntas Frequentes](listadeperguntas.htm) e [Lista de Perguntas](listadeperguntas.htm) que constituem um apoio muito grande à informação, à comunicação, pedidos de esclarecimento, arquivo de dados técnicos, etc...    Existem ainda as opções de [Equipamentos](equipamentos.htm) e [Instalações](ficheirodeinstalações.htm) as quais permitem gerir a situação de todos os equipamentos e respetivas instalações.    Os [Chats](chats.htm) são uma ferramenta que permite estabelecer de uma forma mais direta e eficaz a comunicação interna entre utilizadores. É possível no **Suporte intranet web** criar e manter "Salas de Chat" bem como conversar nas "Salas Ativas".    Através do **Suporte intranet web** o utilizador também pode inserir [Dossiers Internos](dossiersnophccsweb.htm) relacionados com os seus clientes.    No plano analítico, esta aplicação apresenta ao utilizador as seguintes opções:  [Monitor de Pats em Aberto](monitordepatsemaberto.htm)  [Totais de Pats em Aberto](totaisdepatsemaberto.htm) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Suporte Intranet Web' ) |