---
title: Tabelasdeirs
source: tabelasdeirs.htm
tipo: Manual Técnico
idioma: PT
---

# Tabelasdeirs

Tabelas de Irs

|  |
| --- |
| Tabelas de Irs |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| As Tabelas de IRS são utilizadas no [processamento de ordenados](emissãoautomáticaderecibosdevencimento.htm), para determinar os valores de IRS a reter. Esta tabela, após a instalação do programa, vem atualizada com os valores do ano em que adquiriu o software, no entanto, todos os anos estes valores são alterados. Assim, no início de cada ano o utilizador tem as seguintes hipóteses de atualizar as Tabelas:  - se possuir o [PHC On](FuncionalidadesExclusivascomPhcOn.htm#tgrirs) ativo, pode atualizar as tabelas de IRS de uma forma automática, clicando botão  ; - pode também atualizar as Tabelas de IRS manualmente, selecionando a(s) respetiva(s) tabela(s) a alterar; - ou então pedir ao seu Revendedor as tabelas atualizadas, efetuando a [importação](importaçãodenovastabelasdeirs.htm) das mesmas.        Depois de importar as tabelas de IRS, o campo  **Tabela** fica preenchido de acordo com a localização das tabelas de IRS, por exemplo: - as Tabelas de IRS que são aplicadas no Continente, o campo  **Tabela** fica preenchido com o valor Continente; - as Tabelas de IRS que são aplicadas na Madeira, o campo  **Tabela** fica preenchido com o valor Madeira; - as Tabelas IRS que são aplicadas nos Açores, o campo **Tabela** fica preenchido com o valor Açores. - A tabela apresenta a coluna "Sobretaxa" que é automaticamente preenchida com a percentagem de [sobretaxa](cálculodasobretaxamensaldeirs.htm) para cada escalão segundo o Despacho n.º 352-A/2016. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Tabelas de Irs' ) |