---
title: Tabelasmoradasdecargaedescarganogestãoweb
source: tabelasmoradasdecargaedescarganogestãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Tabelasmoradasdecargaedescarganogestãoweb

Tabelas Moradas de Carga e Descarga no Gestão Web

|  |
| --- |
| Tabelas Moradas de Carga e Descarga no Gestão Web |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta funcionalidade tem como principal objetivo fazer a gestão das várias moradas, de forma a poder expedir mercadoria de um documento para uma das moradas de entrega do cliente ou então expedir a mercadoria de um documento para outra morada de entrega.    Esta tabela destina-se ao registo das várias moradas de clientes.     **Descrição**  Neste campo deve indicar a descrição da morada de carga e descarga.  Ao criar um novo registo a aplicação preenche automaticamente com o nome do cliente/fornecedor/entidade/contacto de acordo com a tabela escolhida. O campo continua a ficar editável para caso o utilizador deseje alterar.    **Inativo**  Este campo inativa os respetivos registos, de modo a não surgirem nas opções de procura dos documentos de faturação e nos dossiers internos    **Origem**  Neste campo é possível criar moradas associadas à empresa, utilizando a opção "Outras", ou moradas associadas a Clientes, Fornecedores, Contactos e Entidades.     **Nome**  Neste campo deve indicar o nome do cliente.  Pode efetuar uma procura através do botão  ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.    **Morada**  Neste campo deve indicar a morada de carga e descarga.    **Código Postal**  Este campo serve para introduzir o código postal da morada de carga e descarga.    **Localidade**  Neste campo deve indicar a localidade da morada de carga e descarga.    **Distrito**  Neste campo deve indicar o distrito da morada de carga e descarga.    **País**  Este campo permite indicar o país da morada de carga e descarga.  Pode efetuar uma procura através do botão  ou introduzir um ou mais carateres diretamente no campo, assim irá surgir uma lista com todos os resultados da procura iniciados pelo caratere introduzido e conforme é introduzido mais carateres esta procura vai sendo refinada.    Outros dados    **Contacto**  Este campo permite indicar o nome da pessoa a contactar na morada de entrega em questão.    **Telefone**  Este campo permite indicar o número de telefone na morada de entrega.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Telemóvel**  Este campo permite indicar o número de telemóvel da morada de entrega.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **Fax**  Este campo permite indicar o número de fax na morada de entrega.  Se o campo estiver em modo de consulta, ao clicar será feita automaticamente a marcação caso o utilizador tenha instalado um programa para fazer chamadas ou esteja a utilizar o smartphone.    **E-mail**  Este campo permite indicar o endereço de correio eletrónico da morada de entrega    **Observações**  Neste campo pode introduzir indicações de como chegar à morada de entrega do cliente.      Quando se introduz um documento de faturação ou dossier interno o utilizador pode ver a morada do contacto que pretende inserir, basta para tal efetuar uma pesquisa nos campos de preenchimento de morada de carga e descarga existentes nesse ecrã.  Ao eliminar um registo se o mesmo tiver referenciado num documento de faturação ou num dossier interno, a aplicação proíbe a eliminação e é apresentada uma mensagem ao utilizador. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Tabelas Moradas de Carga e Descarga no Gestão Web' ) |