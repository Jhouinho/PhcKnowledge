---
title: Tesourariaresumidanopos
source: tesourariaresumidanopos.htm
tipo: Manual Técnico
idioma: PT
---

# Tesourariaresumidanopos

Tesouraria Resumida no Pos

|  |
| --- |
| Tesouraria Resumida no Pos |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este capítulo visa explicar o modo de funcionamento da Tesouraria Resumida no POS. Esta funcionalidade vai fazer com que os lançamentos nos Movimentos de Tesouraria apenas sejam realizados aquando o Fecho de Caixa.    Para que a aplicação tenha este comportamento tem de começar por activar o [parâmetro](ParâmetrosdoPOS.htm#PLRtesresumida) **Utiliza tesouraria resumida (reinstalar triggers)** para que os movimentos de tesouraria deixem de ser gravados documento a documento para ser gravados no fecho de caixa por tipo de pagamento. Depois deve preencher o [parâmetro](ParâmetrosdoPOS.htm#PLRclaresumida) **Classificação de tesouraria a utilizar quando se utiliza tesouraria resumida** para que ao fechar a caixa sejam lançados os respectivos movimentos de tesouraria com a classificação definida neste último parâmetro.    Sendo assim, ao gravar os Documentos de Facturação não são lançados os [Movimentos de Tesouraria](constituiçãodatabelademovimentosdetesouraria.htm), estes apenas serão lançados aquando o [fecho da caixa](fecharacaixa.htm), pelos totais declarados nos modos de pagamento. Ou seja, vai ser criado um movimento de tesouraria por cada modo de pagamento que tiver valor no fecho de caixa e por moeda.    Posteriormente, pode exportar caixas fechadas e ainda não exportadas da Loja para a Sede, bastando para isso abrir o ecrã de [Exportação de Dados para a Sede](exportaçãodedadosparaasede.htm) e activar a opção **Exportar Caixas**. Neste ecrã, também pode activar a opção de **Controlar Exportação pelo campo EXPORTADO** que vai verificar que registos ainda não foram exportados da tabela Caixas, ou seja, vai exportar os registos que tenham o campo exportado a false. Depois apenas tem de na Sede aceder ao ecrã de [Importação de Dados de Lojas](importaçãodedadosdelojas.htm) e activar a opção **Importar Caixas** para que sejam importadas as caixas e respectivos fechos de caixa exportados pelas Lojas.    *Nota:* Se tiver o [acesso](AcessosDoPosBack.htm#PLRCaixas) **Não permite Alterar/Apagar Caixas já Exportadas** activo, garante que as caixas exportadas não serão alteradas nem eliminadas. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Tesouraria Resumida no Pos' ) |