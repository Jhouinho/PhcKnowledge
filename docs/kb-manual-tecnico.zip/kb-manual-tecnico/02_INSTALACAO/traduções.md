---
title: Traduções
source: traduções.htm
tipo: Manual Técnico
idioma: PT
---

# Traduções

Traduções

|  |
| --- |
| Traduções |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta é a tabela que guarda todas as entradas de texto e respectivas traduções nos diferentes idiomas.    Cada entrada de texto é identificada pela coluna **Chave**. Um exemplo de uma **chave** numa entrada de texto, pode ser:  - NomeCampo.Decimais do parâmetro     Imaginando que se encontra definido o idioma Francês na tabela de idiomas, existem na tabela de traduções dois registos correspondentes entre si:    **1º - Entrada dos textos de possível tradução**:    **Idioma**: Este campo assume o idioma criado na tabela de idiomas. Quando se trata dos textos originais de possível tradução, importados pela instalação e manutenção, o campo idioma encontra-se vazio.    **Chave** : NomeCampo.Decimais do parâmetro    **Texto Original**: Decimais do parâmetro    **Texto Traduzido**: Decimais do parâmetro    **2º - Textos criados para um Idioma**:    **Idioma**: Francês    **Chave** : NomeCampo.Decimais do parâmetro    **Texto Original**: Decimais do parâmetro    **Texto Traduzido**: Décimales du paramètre    O segundo registo da tabela de traduções (2º - Textos criados para um Idioma) é um registo proveniente da opção [Criar Traduções](idiomas.htm), da tabela de Idiomas. Esta opção é utilizada, após definição de um idioma, para criar o registo correspondente à entrada que já existe, sem idioma definido.    *Nota*: A tabela de traduções tem milhares de registos. Quantos mais idiomas forem criados na aplicação, mais registos tem esta tabela. Logo, não é aconselhável efectuar procuras de registos, que possam retornar um número muito elevado de registos encontrados.     Para criar traduções deve premir este botão  , através do qual, acede directamente ao [Monitor de Traduções](monitordetraduções.htm) . |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Traduções' ) |