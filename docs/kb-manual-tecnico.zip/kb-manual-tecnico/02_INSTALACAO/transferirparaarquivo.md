---
title: Transferir para Arquivo
source: transferirparaarquivo.htm
tipo: Manual Técnico
idioma: PT
---

# Transferir para Arquivo

Este assistente permite reduzir o tamanho das bases de dados, porque serve para transferir dados da base de dados real para uma base de dados de arquivo.
Deve ter em atenção que as análises da aplicação não têm em conta os dados que estão na base de dados de Arquivo, por isso faz sentido passar dados antigos que já não sejam necessários. Além disso, a rotina para a emissão do ficheiro COPE é incompatível com a transferência para arquivo por se tratar de uma opção de obrigatoriedade fiscal com uma rotina específica para o caso. Por esta razão, a Emissão do Ficheiro COPE apenas tem em conta os documentos na base de dados e não do arquivo.
Existem pressupostos importantes a ter em conta antes de proceder ao arquivo de dados:
Deve ser criada uma base de dados vazia e corrida a instalação e manutenção na mesma
Se existirem campos de utilizador nas tabelas a transferir, os mesmos devem ser criados na base de dados destino
Não deve estar ninguém a utilizar o sistema
Deve fazer seguranças de tudo antes de executar este assistente
O utilizador deve ter direitos de Supervisão na base de dados destino
No passo 1 de 3 do assistente é onde se escolhem quais as
tabelas
a transferir e o respetivo
intervalo de datas
.
Ao executar esta ação serão transferidas para arquivo apenas as tabelas principais e não os movimentos das mesmas, ou seja (por exemplo): ao passar documentos de faturação não serão passados os movimentos de conta corrente ou de stock; estes mantêm-se na base de dados real de modo a manter a congruência nos saldos de clientes e artigos respetivamente.
Na tabela abaixo poderá ver quais são as tabelas que serão transferidas consoante a opção selecionada.
Anexos do PHC CS Documentos desktop
ANEXOS (Anexos)
Campos do Utilizador
CAMPOS (Campos de tabelas)
Configuração de Documentos de Faturação
TD (Configuração de Documentos de Faturação)
Configuração de Dossiers Internos
TS (Configuração de Dossiers Internos)
Configuração de Recibos de c/c para Clientes
TSRE (Configuração de Recibos de c/c para Clientes)
Correspondência
CR (Correspondência)
Datas de Projetos
TDA (Datas de Projetos) e TDAUS (Utilizadores de Datas de Projetos)
Documentos Contabilísticos
DO (Documentos Contabilísticos), ML (Movimentos Contabilísticos)
Documentos de Compra
FO (Compras a Fornecedores), FN (Linhas de Compras a fornecedores), FOFC (Pagamentos de Documentos de Compra), FOPD (Adiantamentos de Documentos de Compra)
Documentos de Faturação
FT (Documentos de Faturação), FT2 (Documentos de Faturação – Outros Dados), FI (Linhas de Documentos de Faturação), FTCC (Pagamentos de Documentos de Faturação), FTRD (Regularização de Documentos de Faturação), e FTT (Totais dos Documentos de Faturação)
Dossiers Internos /td>
BO (Dossiers Internos), BO2 (Dossiers Internos – Outros Dados), BI (Linhas de Dossiers Internos), e BOT (Totais dos Dossiers Internos)
Hits Páginas PHC CS Web
EHT (Hits a Páginas Web)
Intervenções Técnicas
MH (Intervenções Técnicas)
Log de Utilizadores
NLOG (Log de Utilizadores)
Marcações
MX (Marcações)
Pagamentos de adiantamento
PD (Adiantamentos a Fornecedores)
Pagamentos de c/c
PO (Pagamentos a Fornecedores), PL (Linhas de Pagamentos a Fornecedores), e POT (Totais dos Pagamentos a Fornecedores)
Pedidos de Assistência
PA (Pedidos de Assistência)
Plano de Contas
PC (Plano de Contas)
Plano de Contas – Saldos
PCSA (Plano de Contas – Saldos)
Projetos
TPO (Projetos), TPOUS (Utilizadores de Projetos), TTA (Tarefas), TTAPA (Passos de Tarefas),TIT ( Itens de Projetos), TLI (Ligações de Projetos), TMR (Valores Reais), TBU (Budget), TNO (Notícias de Projetos), TFO (Fórum de Projetos)
Recibos de Vencimento
PR (Recibos de vencimento), PRRE (Recibos de Vencimento - remunerações), PRDE (Recibos de Vencimento - descontos), PRCC (Distribuição por Centro de Custo nos Recibos de Ordenados), PRH (Recibos de Vencimento - horas extra), PRF (Recibos de Vencimento - faltas)
Recibos de adiantamento
RD (Recibos de adiantamentos)
Recibos de c/c
RE (Recibos para Clientes), RL (Linhas de Recibos para Clientes), e RET (Totais dos Recibos para Clientes)
Visitas
VI (Visitas)
Notas
Só serão passados para arquivo os Documentos de Compras que utilizem
códigos de conta-corrente configurados
para tal.
Só serão passados para arquivo os Documentos de Faturação que estejam
configurados
para tal.
Só serão passados para arquivo os Dossiers Internos que estejam
configurados
para tal.
A transferência para arquivo da tabela de Intervenções Técnicas é feita pela Data de Intervenção
A transferência para arquivo da tabela de Pedidos de Assistência é feita pela Data do Pedido
A transferência para arquivo das tabelas de Plano de Contas e Plano de Contas - Saldos são feitas pelo(s) ano(s) da contabilidade compreendidos entre as datas introduzidas nos campos Data inicial e Data final no Passo 1 de 3 do Assistente
A transferência para arquivo do Projeto é feita pela data de encerramento do projeto, pelo que este deve estar encerrado
Se transferir para arquivo os Recibos de c/c, deverá ter em atenção que, posteriormente, se tirar a Agenda de dívidas de clientes com a opção "na seguinte data" ativa ou do ecrã de "Clientes" a opção "na seguinte data "dd.mm.aaaa(lento)", a mesma deixará de considerar como regularizados os movimentos que tenham sido regularizados com recibos já transferidos para arquivo.
No passo 2 de 3 deve ser indicado o
Nome da base de Dados de arquivo
e o
Sentido da operação a executar com o arquivo
, o que a aplicação faz é a introdução dos registos na base de dados de arquivo e a correspondente eliminação da base de dados real, ou vice-versa conforme a opção escolhida.
Em relação às tabelas de configurações, estas são transferidas para o Arquivo de modo a que a Base de Dados de histórico fique pronta para se consultar de imediato mas não são eliminadas na Base de Dados de Origem.
No passo 3 de 3 o utilizador pode optar por observar os registos antes de ser efetuada a transferência.
Para iniciar a transferência basta escolher a opção
Terminar
.
Se existir um erro toda a operação é cancelada. Esta operação pode ser muito lenta e absorver totalmente os recursos do disco, processador e memória do servidor.
No fim desta operação é possível recuperar o espaço da base de dados origem; para tal, deve ser efetuada uma desfragmentação da mesma.
Nota:
A passagem de dados para a base de dados destino é incremental, ou seja, não são apagados os dados já existentes.
