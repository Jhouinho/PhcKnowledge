---
title: Tratamentodebasesdedados
source: tratamentodebasesdedados.htm
tipo: Manual Técnico
idioma: PT
---

# Tratamentodebasesdedados

Tratamento de Bases de Dados

|  |
| --- |
| Tratamento de Bases de Dados |

|  |
| --- |
| Nesta área do software poderá encontrar as seguintes opções:    [Importar dados de software Phc](importardadosdesoftwarephc.htm)  Esta opção ajuda-o a importar dados das versões PHC Standard.    [Criação de base de dados](criaçãodebasededados.htm)  Esta opção permite criar facilmente uma cópia da base de dados.    [Tipo de Login deste computador](tipodelogindestecomputador.htm)  Esta opção permite configurar um login único no SQL Server.    [Transferir para arquivo](transferirparaarquivo.htm)  Esta opção permite ao utilizador reduzir o tamanho das suas bases de dados.    [Backup de Base de Dados](backupdebasededados.htm)  Esta opção permite guardar num ficheiro os registos da base de dados em uso pela aplicação.    [Instalação e Manutenção](instalaçãoemanutenção.htm)  Esta opção permite-lhe executar diversas opções nas tabelas da base de dados.    [Análise Dimensional do Sistema](análisedimensionaldosistema.htm)  Esta opção permite visualizar a dimensão do sistema instalado numa determinada data.    Desfragmentar Tabelas Principais  Esta opção permite desfragmentar as tabelas principais da base de dados. A desfragmentação é um processo que deve ser feito periódicamente de forma a aumentar a perfomance nos acessos aos dados das tabelas da base de dados. Caso tenha a gama Enterprise pode executar esta função via Alerta do Utilizador.    [Dicionário de Dados](dicionáriodedados.htm)  Esta opção permite consultar os diversos campos de uma determinada tabela.     Se possuir [PHC ON](oqueéophcon.htm) poderá obter mais informação sobre como optimizar a performance da sua aplicação, através do nosso [filme](http://vantagem.phc.pt/Clientes/ass/emuview.aspx?stamp=de525b6gf6%3a.%3ab89.69c5.95%3a) ou da nossa [idirecto](http://vantagem.phc.pt/Clientes/ass/egaview.aspx?stamp=f7fb44%3a1f98.662c.7825.2b8). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Tratamento de Bases de Dados' ) |