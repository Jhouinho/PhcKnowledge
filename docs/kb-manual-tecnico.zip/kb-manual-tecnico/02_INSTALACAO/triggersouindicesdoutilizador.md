---
title: Triggersouindicesdoutilizador
source: triggersouindicesdoutilizador.htm
tipo: Manual Técnico
idioma: PT
---

# Triggersouindicesdoutilizador

Triggers ou Indices do Utilizador

|  |
| --- |
| Triggers ou Indices do Utilizador |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção dá ao utilizador a possibilidade de definir triggers e/ou índices para qualquer tabela do software.   Estes triggers ou Indices são criados quando se correr a instalação e manutenção via ecrã normal ou via Assistente, com as respectivas opções activadas.    **Título**  Este campo serve para indicar o nome que pretende dar ao registo.    **Tipo**  Neste campo poderá selecionar o tipo de registo que pretende criar, se é um Trigger ou um Indice.    **Inactiva**  Ao serve para desabilitar o trigger/indice, assim, se o utilizador podera não utilizar um trigger que tenha criado. O trigger permanecera no entanto na tabela de **Trigeers ou Indices de Utilizador**, de forma a que um dia mais tarde possa ser novamente utilizado.  Para desabilitar o trigger ou índice do SQL Server, para além de ter que activar esta opção deverá executar a respectiva opção na instalação e manutenção.    **Tabela**  Neste campo deverá indicar qual a tabela associada ao registo em questão.    **Tipo de trigger**  Este campo só se encontra disponível se o tipo de registo for Trigger. Servido assim para identificar qual o tipo de trigger que pretende criar:  Inserted - Ao seleccionar esta opção irá criar um trigger de introdução, que será despoletado quando se cria um registo na tabela indicada.  Deleted - Ao seleccionar esta opção irá criar um trigger ao apagar, que será despoletado quando se apaga um registo na tabela indicada.  Updated - Ao seleccionar esta opção irá criar um trigger de alteração, que será despoletado quando se altera um registo na tabela indicada.    **Expressão**  Este campo serve para digitar a expressão do Trigger/Indice.    **Indice Único**  Este campo só se encontra disponível se o tipo de registo for Indice. Servido assim para identificar se o indice é ou não único na tabela em questão.      *Exemplo:*  Supondo que o utilizador tem uma tabela de utilizador (usertabx) com os campos (no, nome,morada) que fica ligada a tabela de clientes. Logo cada vez que se cria, apaga ou altera um registo na tabela de clientes(CL), essa alteração deverá ser repercutida na tabela de utilizador.  Para que tal aconteça deverá criar os seguintes Triggers:    Trigger do INSERT  Insert into u\_usertabx (u\_usertabxstamp,no,nome,morada) select inserted.clstamp,inserted.no,inserted.nome,inserted.morada from inserted    Trigger do UPDATED  update u\_usertabx set u\_usertabx.morada = inserted.morada from inserted inner join deleted on inserted.clstamp = deleted.clstamp where u\_usertabx.u\_usertabxstamp = deleted.clstamp    Trigger do DELETED  delete from u\_usertabx from deleted where u\_usertabx.u\_usertabxstamp = deleted.clstamp    *Nota:*  Depois de criar o registo do trigger/indice deverá correr a instalação e manutenção para que o trigger/indice seja criado na base de dados na tabela respectiva.  Caso o registo seja Trigger deverá correr a opção de Re-instalar triggers, se for Indices deverá correr a opção criar Indexes (se não existirem). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Triggers ou Indices do Utilizador' ) |