---
title: U_criaqinrm
source: u_criaqinrm.htm
tipo: Manual Técnico
idioma: PT
---

# U_criaqinrm

## Descrição

Esta função cria e calcula Registos de Monitorização baseado nos Indicadores do Quadro de Gestão ativo. Os registos de monitorização podem ser criados num registo só, caso o
campo de periodicidade esteja vazio (0) ou em blocos de X em X dias (X = nº de dias de periodicidade), caso o campo de periodicidade seja
maior que 0. A função vai correr todos os Indicadores dos Objetivos do Quadro de Gestão ativo que o Tipo de cálculo do Indicado seja 1 (Automático (fornecidos pela aplicação)) ou 2 (Automáticos com cálculo numa expressão), e que a Data da monitorização do indicador seja menor ou igual que a data do sistema.

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Expressão Lógica - Força cálculos | .T. ou
.F. | Opcional
- Se for .T. força os cálculos e
registo de monitorização caso a periodicidade seja superior a data do
sistema. |
| 2 | Expressão
de Caracteres - Stamp do QIN. | "QINSTAMP" | Opcional
- Indica qual o Stamp do Indicador a ser
calculado e registado. Se não vier preenchido calcula para todos os
Indicadores. |
| 3 | Expressão
Lógica - lSilent | .T. ou . F. | Opcional
- Se for
. F.
mostra os erros caso existam durante o processo de cálculo e criação de
registos de monitorização. |

## Exemplo

```foxpro
if U_CRIAQINRM (.F., "QINStamp", .F.) mensagem ("Cálculo e registo de Registos de Monitorização efetuado com sucesso.") else mensagem ("Erro ao efetuar o Cálculo e registo de Registos de Monitorização.") endif
```

## Notas

- Se o Tipo de cálculo do Indicado for 1 (Automático (fornecidos pela aplicação)), a expressão Xbase é da total responsabilidade do utilizador que a criou. Tem que retornar sempre um valor Numérico até 4 Dígitos. - A função apenas vai fazer cálculos para os Indicadores de Objetivos, os outros indicadores (Outros Indicadores do Quadro de Gestão) são meramente informativos.

## Plataformas

Advanced Enterprise

## Versões testadas

2013
