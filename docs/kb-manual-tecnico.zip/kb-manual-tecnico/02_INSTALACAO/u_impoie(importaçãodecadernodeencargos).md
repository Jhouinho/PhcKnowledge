---
title: U_impoie (importação de Caderno de Encargos)
source: u_impoie(importaçãodecadernodeencargos).htm
tipo: Manual Técnico
idioma: PT
---

# U_impoie (importação de Caderno de Encargos)

## Descrição

Esta função cria um Dossier Interno de
Orçamento baseado num ficheiro XLS tendo em conta uma configuração de
caderno de encargo.

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Expressão Numérica –
Nº interno do D.I. | 6 | Obrigatório - Indica
qual o Nº Interno do D.I. (Orçamento) a criar. |
| 2 | Expressão de
Caracteres - Processo | 'Nº do Processo' | Obrigatório - Indica
qual o Processo a associar ao D.I. |
| 3 | Expressão Numérica –
Nº Interno da configuração | 1 | Obrigatório – Indica
qual o Nº interno da configuração de caderno de encargo a importar
(OIE). |
| 4 | Expressão de
Caracteres – Caminho do ficheiro | 'Caminho do ficheiro' | Obrigatório - Indica
o caminho do ficheiro onde vai importar os dados. (*. XLS) |
| 5 | Expressão Lógica –
Estrutura de custos | .T. ou . F. | Opcional – Se for . T. indica que vai importar estrutura de
custos. (OCI) |
| 6 | Expressão Lógica –
Animação | .T. ou . F. | Opcional – Se for . T. indica se vai visualizar uma animação
enquanto importa o ficheiro. |
| 7 | Expressão Lógica –
Mostra erros | .T. ou . F. | Opcional – Se for . T. indica que vai mostrar os erros caso
existam durante o processo de importação. |
| 8 | Expressão de
Caracteres –
Nome do ecrã (interno) | SBO | Obrigatório – Nome
do ecrã onde está a correr a função. |

## Exemplo

```foxpro
U_IMPOIE (6 ,
"05.0004", 1, "C:\Orçamento.xls", .t., .t., .t.,SBO)
```

## Notas

Tem que ter o "Microsoft
Excel" instalado. Relativamente
às regras de certificação só irá criar o documento assinado caso tenha
a opção de "Série de documento a ser assinada digitalmente" ativa e o
último documento da série esteja assinado. Independentemente da opção
"Assina digitalmente apenas ao imprimir". Caso não crie
o documento por causa da inconformidade de umas destas regras é
adicionado ao cursor de erros a mensagem: "Não foi possível gerar o
Dossier Interno devido a inconformidades de Assinatura Digital."
