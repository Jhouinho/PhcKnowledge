---
title: Utilizadores
source: utilizadores.htm
tipo: Manual Técnico
idioma: PT
---

# Utilizadores

Utilizadores

|  |
| --- |
| Utilizadores |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Uma aplicação multiutilizador deve sempre ter uma forma de os gerir.          Não sendo exceção à regra, o PHC Manufactor CS possui um ecrã no qual possibilita ao gestor do sistema, realizar os procedimentos habituais de administração das contas de utilizadores.   Para cada utilizador dos programas o supervisor deve definir o seguinte:    **Nome**: Nome do utilizador (até 80 carateres alfanuméricos).    **Iniciais**: até 3 carateres.    **Nome para login**: Corresponde ao nome pedido na entrada do programa.    **Administrador do sistema**  Ao ativar esta opção, define-se que o utilizador tem acesso a diversas opções que estão interditas a outros utilizadores do programa, como por exemplo: Parâmetros, Instalação e Manutenção, Tabela de utilizadores, Campos do utilizador, Utilizadores, Grupos de Utilizadores, etc.  Um utilizador definido como "Administrador de Sistema" tem sempre acesso ao Módulo Supervisor, mesmo que este utilizador se encontre associado a um Grupo de Utilizador que não tenha acesso a quaisquer Programas.    **E-mail**: Permite definir o E-mail do utilizador.    **Planeador**  Ao ativar esta opção, define-se que o utilizador tem acesso a planear ordens de fabrico.    **Atualmente a planear**  Quando esta opção estiver ativa significa que o utilizador se encontra de momento a planear.    **Utiliza perfil global**  Significa que é um utilizador planeador global, ou seja, tem apenas acesso de consulta a todos os planeamentos existentes.    *Nota*: Esta opção apenas está disponível se o parâmetro [usar perfis de planeador](Parâmetros-OpçãoPlaneamento.htm#rvusarperfisdeutilizador) estiver ativo.    **Perfil**  Permite definir o perfil a que o utilizador pertence.    **Com acesso de editar qualquer perfil de planeamento**  Esta opção permite ao utilizador planeador global editar qualquer perfil de planeamento.  Quando o planeador acede ao planeamento (seja o Gráfico de Gantt ou o planeamento de ordens de fabrico) passa a ser apresentado no canto superior direito o campo "Perfil de planeamento" para o planeador escolher o perfil que deseja utilizar.    *Nota*: Esta opção apenas está disponível com PHC Executive e com [PHC ON](funcionalidadesexclusivascomphcon.htm).    Neste ecrã de utilizadores, para além de criar, alterar ou apagar um perfil, o gestor pode assignar um, o qual irá condicionar a forma como utilizador final irá ver a informação, bem como definir através do botão "Gestão acessos" as áreas poderá ter acesso.        Mais uma vez, não fugindo à regra, a aplicação permite organizar os utilizadores em grupos, sendo que os acessos destes irão ser os acessos do grupo.   Poder-se-á obviamente ajustar um acesso particular de um utilizador específico tendo por base a matriz de acessos do grupo.     Uma das tarefas principais na gestão de utilizadores é a criação dos mesmos. Através do botão "Opções diversas" a aplicação disponibiliza várias ferramentas para que, tendo por base os utilizadores da aplicação, sejam automaticamente criados acessos ao nível do motor de base de dados. Isto facilita a gestão de contas.        Durante a criação do utilizador, é possível navegar para a definição do grupo associado, bastando para isso realizar um duplo clique sobre o campo de grupo. Após esta ação, a aplicação chamará o registo correspondente, permitindo a sua alteração sem que tenha sido necessário usar os menus da aplicação.   A aplicação permite copiar e/ou duplicar os grupos bem como os seus acessos, facilitando a criação de matrizes de acessos, bem como copiar os acessos de um utilizador para outro.   Esta última opção abre as portas para a criação de utilizadores padrão os quais na criação de um novo são usados como base. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Utilizadores' ) |