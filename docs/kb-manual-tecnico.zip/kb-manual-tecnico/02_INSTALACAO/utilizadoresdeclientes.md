---
title: Utilizadoresdeclientes
source: utilizadoresdeclientes.htm
tipo: Manual Técnico
idioma: PT
---

# Utilizadoresdeclientes

Utilizadores de Clientes

|  |
| --- |
| Utilizadores de Clientes |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Esta opção só está disponível de tiver instalado o PHC CS Web.    Serve para criar os utilizadores das aplicações externas do PHC CS Web.  Não é mais do que a criação de um utilizador mas não de uma aplicação PHC CS Desktop.    **Nome**  Deve indicar o nome do utilizador. Estes são numerados internamente.    **Último Login**  Estes campos, data e hora, permitem saber quando foi feito o último acesso por parte deste utilizador.    **Iniciais**  Este campo só permite 3 caracteres e define as iniciais da cada utilizador.  Não deve criar dois utilizadores com iniciais iguais, dado que algumas tabelas são criados em função das iniciais e se houver duas iguais existirão erros imprevisíveis.    **E-mail**  Endereço de e-mail deste utilizador.    **Telemóvel**  Número de telemóvel do utilizador. Ao clicar no botão , será aberto o ecrã de [Mensagens Sms](mensagenssms.htm).    **Nome para login**  Este é o nome que o utilizador vai usar para fazer o login à aplicação.    **Password para autenticação**  Neste local é definida a password para o login. A password de acesso tem de ser composta, no mínimo, por 8 caracteres.    **Este utilizador é Supervisor do cliente**  Este clique permite que o utilizador tenha acesso, no PHC CS Web, a criar novos utilizadores deste cliente.     **Este utilizador no Front Web só tem acesso a documentos do estabelecimento especificado**  No Front Web é possível gravar encomendas para diversos estabelecimentos, bastando para isso escolher o estabelecimento para qual a encomenda será gravada.  Esse campo é automaticamente preenchido com o estabelecimento que estiver definido nesta ficha de utilizadores de clientes.   Com esta opção ativa o campo estabelecimento nas encomendas aparece como "ReadOnly" ou seja não é possível ao utilizador alterar o seu valor. Assim o utilizador de cliente que tenha essa opção ativada só irá poder inserir/alterar e consultar encomendas do estabelecimento que estiver definido na sua ficha. Assim como consultar conta corrente, recibos, e outras opções do Front Web.    **Recebe notificações do Equipa**  Ao ativar esta opção o utilizador de cliente é notificado por email dos registos inseridos ou alterados no Equipa, caso o projeto se encontre configurado para tal.    **Cliente**  Deve ser aqui definido qual é o cliente e estabelecimento a que este utilizador pertence.    **Acessos e Outros**  Os acessos são por aplicação.   Caso o utilizador tenha acesso, por exemplo, ao módulo Front Web deve ser clicada a seguinte opção:      **Data de alteração da password**  Campo de leitura que informa a data em que o utilizador (cliente) efetuou a última alteração da password à aplicação PHC CS Web.    **Campo de Utilizador 1 e Campo de Utilizador 2**   Os nomes destes campos podem ser definidos nos parâmetros do CS, no separador PHC CS Web: - Utilizadores de clientes - campo de utilizador 1  - Utilizadores de clientes - campo de utilizador 2   Pode-se usar estes campos de duas formas: - Nos filtros de utilizador da Extranet usando os textos #USR1# e #USR2# que serão substituídos no filtro por 0 ou 1, sempre que o filtro é executado.  - Usando as propriedades xcuser.usr1 ou xcuser.usr2 dentro de código VB.     No módulo **Formação** o registo de formandos alimenta esta tabela, ou seja um formando é um utilizador de cliente. O seu registo é feito de seguinte forma:    **Nome Formando**  Permite registar o Nome completo identificativo do formando.    **Número Formando**  Número interno atribuído a cada formando. O programa dará um número automaticamente.    **Função**  Este campo serve para introduzir qual a função do formando na empresa.    **Morada**  Morada completa do formando.    **Localidade**  Localidade da morada do formando.    **Código Postal**  Este campo serve para introduzir o [código postal](tabeladecódigospostais.htm).    **Telefone**  Telefone do formador.    **E-mail**  Endereço do correio eletrónico.    **Cliente**  Este campo só se encontra disponível caso possua o módulo de Gestão. Indica se o formando pertence a alguma empresa, sendo possível consultar a ficha de cliente através do duplo clique sobre o campo.    **Observações**  Campo "texto", para informação adicional respeitante ao formador em questão |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Utilizadores de Clientes' ) |