---
title: Versãocertificadadosoftwarephc
source: versãocertificadadosoftwarephc.htm
tipo: Manual Técnico
idioma: PT
---

# Versãocertificadadosoftwarephc

Versão Certificada do Software Phc

|  |
| --- |
| Versão Certificada do Software Phc |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| A Portaria n.º 363/2010, de 23 de junho, veio regulamentar as Regras da Certificação de Software.     Atendendo a esta imposição legislativa, no dia 07 de outubro de 2010, a PHC obteve a certificação da Autoridade Tributária para a aplicação PHC CS.     Nesse momento, a versão que se encontrava em comercialização era a versão 2011.            Desde esse momento, a PHC garante que a aplicação PHC CS cumpre as regras de certificação e faturação nas respetivas áreas.    Após esta data, as regras de certificação e faturação foram alteradas nas seguintes Portarias e Despacho:    * Portaria n.º 22-A/2012, de 24 de janeiro;  * Portaria n.º 340/2013, de 22 de novembro;  * Despacho n.º 8632/2014 de 03 de julho, do Diretor-Geral da AT.      Para clarificar os Clientes sobre qual a versão em comercialização e qual a versão certificada:   - No ecrã "Status Geral", no separador "Executável" foi colocada a seguinte informação:                        *Nota:* Caso não possua a versão em comercialização, esta mensagem não aparece.    - Mensagem à entrada na aplicação a alertar os Clientes finais:    Após o lançamento de cada versão, a PHC envia uma mensagem aos Clientes que possuem versões anteriores à versão em comercialização.        Quais as mensagens que os Clientes podem obter quando entram na aplicação?    * Se ainda utiliza uma versão de Software PHC CS anterior à versão 21:            *Esta versão já não cumpre as regras e requisitos legais exigidos pela AT para a certificação de software!      Atualize o seu Software PHC para a versão atualmente certificada: PHC CS v24.*   * Se ainda utiliza o Software PHC CS na versão 21, 22 ou 23:            *A PHC possui uma nova versão disponível para si: PHC CS 24.       Apenas na versão em comercialização (v23) é que é possível garantir o cumprimento dos requisitos exigidos pela AT para a certificação do software.      Para atualizar o seu software PHC, fale com o seu Parceiro.       Obtenha mais informações <http://on.phc.pt/onphce/programs/ewpview.aspx?codigo=Faqs-software-certificado>*            E quais os timings da disponibilização desta mensagem aos Clientes?     * 3 semanas antes de ser ativada a mensagem - é colocada uma notícia na Comunidade PHC a alertar para a data de ativação da mensagem;    * 2 semanas antes de ser ativada a mensagem - é enviada uma comunicação aos Clientes finais através de uma iDirecto e PHC ON a alertar do aparecimento da mensagem;    * 3 meses após a data do lançamento da nova versão é ativada a mensagem para que possa começar a surgir aos Clientes.            **Algumas perguntas técnicas sobre esta mensagem:**        **Esta mensagem não deveria aparecer só ao administrador do sistema do PHC? Não é este que deve ser responsável por planear a sua atualização?    Alguns Parceiros sugerem que a mensagem apenas surja a perfis de "sa", excluindo utilizadores comuns, por motivos de confidencialidade de informação.**    *Resposta:* O nosso objetivo com esta mensagem é alertar as empresas para a necessidade de atualizar a versão, por isso achamos que a melhor forma de o fazer é alertando todos os utilizadores.            **A PHC pode comunicar diretamente com o Software PHC CS que o cliente adquiriu? Não será intrusivo?**    *Resposta:* No caso da mensagem não estamos a retirar dados do Cliente, o software invoca um webservice da PHC para saber qual é a versão atual e já do lado do Cliente compara, para podermos agir em conformidade no que diz respeito a assegurarmos que os Clientes tenham a versão que garantimos ser certificada.        **Que tipo de ligações são efetuadas entre o servidor/máquinas dos Clientes, que portas são utilizadas pela PHC?**     *Resposta:* É o acesso normal à internet. Ao entrar no PHC CS Desktop há uma chamada ao webservice da PHC perguntando qual é a versão atual e recebe uma mensagem que dá ao utilizador.                Para obter mais informações, clique [aqui](http://on.phc.pt/onphce/programs/ewpview.aspx?codigo=Faqs-software-certificado). |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Versão Certificada do Software Phc' ) |