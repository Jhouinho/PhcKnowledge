---
title: Versãodesktop
source: versãodesktop.htm
tipo: Manual Técnico
idioma: PT
---

# Versãodesktop

Versão Desktop

|  |
| --- |
| Versão Desktop |

|  |
| --- |
| O software PHC Manufactor CS é uma aplicação desenvolvida para sistemas operativos Microsoft.    O seu processo de instalação é simples, desde que sejam executados os seguintes procedimentos:    1º - [Instalação do Setup](instalaçãodosetup.htm)    2º - [Cópia do executável (mais recente) para diretoria](cópiadoexecutável(maisrecente)paradirectoria.htm)    3º - [Configuração de acesso a fichas Hasp](configuraçãodeacessoafichashasp.htm) ou [Configuração de Acesso a Fichas Unikey](configuraçãodeacessoafichasunikey.htm)     4º - [Definição dos módulos por utilizador (INS)](definiçãodosmódulosporutilizador(ins).htm)      Após estes passos, o software PHC Manufactor CS está pronto a funcionar! |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Versão Desktop' ) |