---
title: Versãoweb
source: versãoweb.htm
tipo: Manual Técnico
idioma: PT
---

# Versãoweb

Versão Web

|  |
| --- |
| Versão Web |

|  |
| --- |
| O software PHC Manufactor CS disponibiliza um módulo LEILÕES (Descontinuado) que permite, aos fornecedores, o acesso Web aos leilões disponibilizados pela empresa.    A utilização deste módulo é gerida por 2 validações. A próxima imagem pretende elucidar, de uma forma gráfica, o esquema a implementar:           Sempre que um fornecedor acede ao site (servidor Web do cliente), é validada uma WEB-KEY (necessária para a instalação do software no servidor Web do cliente) no nosso servidor WEB (PHC).     Após a passagem deste 1º nível de acesso, existe ainda uma 2ª validação (verificação da Web-Key na base de dados Manufactor; que é atualizada sempre que a aplicação é executada).      Para uma correta instalação, deverão ser executados 2 *Setups*:    - Web-Service de Leilões;  - Aplicação Extranet; |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Versão Web' ) |