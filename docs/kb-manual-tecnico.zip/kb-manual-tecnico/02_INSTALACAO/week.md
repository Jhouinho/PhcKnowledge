---
title: Week
source: week.htm
tipo: Manual Técnico
idioma: PT
---

# Week

## Descrição

Esta função permite
 verificar a semana actual do ano a partir de uma expressão DATE ou DATETIME.

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Expressão DATE /
 DATETIME | DATE() | Obrigatório - Indica
 a expressão do tipo DATE ou DATETIME que vai ser avaliada pela função. |
| 2 | Primeira Semana do Ano | 0,1,2 ou 3 | Opcional - Indica os
 requisitos para a primeira semana do ano. |
| 3 | Primeiro Dia da Semana | 0,1,2,3,4,5,6 ou 7 | Opcional - Indica qual
 é o primeiro dia da semana, por defeito é Domingo. |

## Exemplo

```foxpro
*
 Retorna o nº actual da semana, por exemplo, se a data de hoje for 27.09.2005
 ao fazermos: ? WEEK ( DATE ()) * Retorna 40.
```

## Notas

A
 função retorna um nº entre 1 e 53 que representa a semana actual do ano.
