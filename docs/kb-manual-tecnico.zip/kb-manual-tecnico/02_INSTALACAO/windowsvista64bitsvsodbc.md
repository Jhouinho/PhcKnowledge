---
title: Windowsvista64Bitsvsodbc
source: windowsvista64bitsvsodbc.htm
tipo: Manual Técnico
idioma: PT
---

# Windowsvista64Bitsvsodbc

Windows Vista 64 Bits Vs Odbc

|  |
| --- |
| Windows Vista 64 Bits Vs Odbc |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| Este artigo visa explicar o método para criar ODBC's na plataforma Windows Vista 64 bits.      Em máquinas com plataforma Windows Vista 64 bits acontecem os seguintes cenários:    1º - Ao criar um ODBC pela opção respectiva do Sistema Operativo, o mesmo não surge visível no ecrã de Login da aplicação PHC.    2º - Ao entrar no software PHC, surge o ODBC criado pelo setup da aplicação PHC, no entanto, não aparece nos ODBC's para alteração da sua configuração.      **Explicação:**  1º - A plataforma Windows Vista possuí dois tipos de ODBC, respectivamente, ODBC 64 bits e ODBC 32 bits.  Quando se cria um ODBC pela opção respectiva do Sistema Operativo, o mesmo é criado, naturalmente, utilizando o tipo de ODBC a 64 bits. No entanto, a aplicação PHC não lê este tipo de ODBC's, daí o mesmo não surgir no ecrã de Login da aplicação PHC.    2º - Quando é executado o Setup da aplicação PHC, é gerado automaticamente um ODBC, do tipo ODBC a 32 bits, por isso, o mesmo aparece no ecrã de Login do software PHC e não na opção ODBC do sistema operativo Windows Vista.      **Solução:**  Para criar ou alterar ODBC's do tipo 32 bits, é necessário invocar o aplicativo do sistema operativo, que permite adicionar ODBC's a 32 bits.  Para fazer isso, terá que digitar na linha de comandos o seguinte caminho: %windir%/syswow64/odbcad32.exe     Ao executar este caminho, irá surgir um ecrã que permite adicionar ou alterar ODBC's a 32 bits, sendo possível posteriormente, seleccionar estes ODBC's no ecrã de login da aplicação PHC.        Como dica final, para saber mais alguns pormenores sobre este assunto específico, aconselhamos a leitura do conteúdo do [link.](http://www.vista64.net/forums/vista-general/39647-microsoft-access-odbc-driver-vista-64-bit.html)        Gama de software PHC em que foi testado : Advanced 2008 (8.10) |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Windows Vista 64 Bits Vs Odbc' ) |