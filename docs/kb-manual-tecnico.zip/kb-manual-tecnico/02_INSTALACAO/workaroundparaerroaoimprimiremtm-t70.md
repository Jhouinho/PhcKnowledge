---
title: Workaroundparaerroaoimprimiremtm T70
source: workaroundparaerroaoimprimiremtm-t70.htm
tipo: Manual Técnico
idioma: PT
---

# Workaroundparaerroaoimprimiremtm T70

Workaround para Erro ao Imprimir em Tm-t70

|  |
| --- |
| Workaround para Erro ao Imprimir em Tm-t70 |

|  |  |
| --- | --- |
|  |  |

|  |
| --- |
| O objectivo deste artigo técnico é mostrar como é possível configurar uma impressora térmica EPSON TM-T70 com porta paralela, quando não é reconhecida pelo software ou provoca o seguinte erro ao tentar imprimir através da mesma.    **Runtime error!   Program: C:\PHC\PHCENTERPRISE.EXE  This application has requested the Runtime to terminate it in an unusual way.  Please contact the application´s support team for more information.**    Para evitar este erro, deve proceder-se da seguinte forma:    1.Instalar a versão 1.95 do OPOS   Seguir os passos do instalador:         Proceder á instalação tipica:        escolher a porta onde se encontra a impressora:         Configurar a impressora como sendo POS Printer modelo Epson TM-T88P:         2.Efectuar o upgrade do OPOS para a versão 2.1   Seguir os passos do instalador:          Proceder á instalação completa:         3.Instalar a impressora como sendo TM-T88P:           Após estes passos, a impressora passa a funcionar correctamente. |

|  |  |
| --- | --- |
|  | [Dê o seu parecer sobre este tópico diretamente para a PHC](mailto:doc@phc.pt?subject=Parecer sobre 'Workaround para Erro ao Imprimir em Tm-t70' ) |