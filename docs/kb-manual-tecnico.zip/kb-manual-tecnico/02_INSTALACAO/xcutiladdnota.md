---
title: Xcutil.addnota
source: xcutiladdnota.htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.addnota

## Descrição

Função que nos permite adicionar uma nota a uma rede, de forma fácil e rápida.
Classe:
Xcutil;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: do tipo Page | mpage as Page | Obrigatório : Página de onde vai ser retirado o título e a descrição, para colocar como título do conteúdo do URL |
| 2 | Variável numérica: nrede | nrede As Integer | Obrigatório : Número da Rede (da Rede Colaborativa) onde vai ser colocada a nota |
| 3 | Objeto: do tipo String | cResumo As String | Obrigatório : Texto que irá ser colocado no resumo da Nota da Rede |
| 4 | Objeto: do tipo String | qUrl As String | Facultativo: String que vai conter o URL da Rede para o qual o utilizador vai ser redirecionado |
| 5 | Objeto: do tipo String | dUrl As String | Facultativo: String que vai conter o URL que contém o conteúdo da nota, mas sem link |
