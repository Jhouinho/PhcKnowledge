---
title: Xcutil.alerta
source: xcutilalerta.htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.alerta

## Descrição

Esta função vai receber a variável "mpage" (contém o handle da página, permitindo aceder ás propriedades eventos e métodos da mesma) e uma mensagem do tipo
string
. Desta forma pode gerar três tipos de mensagens visualmente distintas (de acordo o parâmetro
tipo
): Sucesso (tipo 1); Informativo (tipo 2) ou Erro (tipo 3).
Nota
: Caso o parâmetro (tipo) esteja vazio, a aplicação considera por defeito o Tipo 1, ou seja, mensagem de sucesso.
Classe:
Xcutil;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Variável: mpage | mpage | Obrigatório :A mpage contém o handle da página. Ou seja, guarda o objeto "página" que permite aceder as propriedades eventos e métodos da mesma. |
| 2 | Texto: String | Texto personalizado | Obrigatório : Texto a apresentar ao utilizador, no interior do alerta. |
| 3 | Variável numérica: Tipo | 1; 2 ou 3 | Opcional : 1 (mensagem de sucesso); 2 Informativo (mensagem de informação) ou 3 (mensagem de erro); NOTA: Se esta variável estiver vazia, por defeito considera o tipo 1, mas uma vez preenchida, deve conter um valor numérico e entre os valores 1 e 3. |
