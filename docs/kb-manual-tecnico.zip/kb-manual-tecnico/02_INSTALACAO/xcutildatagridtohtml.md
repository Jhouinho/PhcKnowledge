---
title: Xcutil.datagridtohtml
source: xcutildatagridtohtml.htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.datagridtohtml

## Descrição

Esta função que recebe o parâmetro
gv
, do tipo Datagrid e é utilizada para renderizar a Datagrid para HTML
Classe:
Xcutil;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: do tipo Datagrid | gv | Obrigatório : É enviada uma DataGrid, sendo retornado o código HTML, como string |
