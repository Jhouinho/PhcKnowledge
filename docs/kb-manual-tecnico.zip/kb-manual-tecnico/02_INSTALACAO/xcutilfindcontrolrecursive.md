---
title: Xcutil.findcontrol Recursive
source: xcutilfindcontrolrecursive.htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.findcontrol Recursive

## Descrição

Esta função que recebe dois

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: ByVal Root | ByVal Root as Control | Obrigatório : ByVal Root NOTA: "Root Controlo" deve conter informação sobre o local onde de pretende procurar o controlo com id (outro parâmetro) |
| 2 | Objeto: ByVal id | ByVal id As String | Obrigatório : ByVal id NOTA: "id String" deve conter o id do controlo que se pretende encontrar |
