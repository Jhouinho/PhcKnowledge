---
title: Xcutil.firstword
source: xcutilfirstword.htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.firstword

## Descrição

Esta função que recebe o parâmetro
palavra
, do tipo Stringe é utilizada para retornar apenas a primeira palavra de uma frase.
Classe:
Xcutil;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: do tipo String | palavra | Obrigatório : É enviada uma palavra do tipo String e retorna apenas a primeira palavra da frase. |
