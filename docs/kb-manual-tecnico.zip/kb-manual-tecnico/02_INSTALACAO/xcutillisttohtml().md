---
title: Xcutil.listtohtml()
source: xcutillisttohtml().htm
tipo: Manual Técnico
idioma: PT
---

# Xcutil.listtohtml()

## Descrição

Esta função permite converter um
datatable
numa
tabela em HTML (string)
;
Classe:
Xcutil;

## Parâmetros

| Nº | Descrição | Valores | Observações |
| --- | --- | --- | --- |
| 1 | Objeto: do tipo Datatable | ctable | Obrigatório : ctable (DataTable) NOTA: ctable é a tabela com os dados da query |
| 2 | Expressão de caracteres: Classe de CSS, a aplicar na tabela | cssclass | Facultativo: default = "table table-xs table-striped"; NOTA: cssclass são as classes que vão ser adicionadas à tabela que vai ser desenhada |
