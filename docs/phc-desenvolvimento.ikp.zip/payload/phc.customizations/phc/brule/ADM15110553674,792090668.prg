* BRULE
* stamp: ADM15110553674,792090668
* tabela: FT
* mensagem:  
* descricao: RB: Valida data de Fatura
* estado: Inactivo
* inactivo: True

select ft
ld_Data = ft.fdata
TEXT TO m.msql TEXTMERGE NOSHOW
     select datediff(dd, getdate(), '<< dtos(ld_Data) >>') as dias
ENDTEXT
u_sqlexec(m.msql, 'crControlo')
select crControlo
if crControlo.dias <> 0 then
     messagebox('A data que inseriu no documento é inválida porque não reporta ao dia atual.' + chr(13) + 'Queira por favor corrigir.', 16, 'Erro Grave!!!')
     return .f.
endif
return .t.

