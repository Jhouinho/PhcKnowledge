* BRULE
* stamp: ADM19120345226,939219713
* tabela: CL
* mensagem: Desculpe, mas tem de preencher o campo Telefone
* descricao: Preencher o campo Telefone
* estado: Activo
* inactivo: False

NOT EMPTY(CL.TELEFONE)

