* BRULE
* stamp: ADM19121764425,007762959
* tabela: BO
* mensagem: Não pode gravar sem indicar a obra no documento.
* descricao: HCA | 2022 Obriga a obra em dossiers
* estado: Activo
* inactivo: False

* HCA | Jorge F 21.10.2022
* Pedido Dª Vera para obrigar Obra nos dossiers 
* 22	Custos de Obra
* 20	Devolucao de Obra
* 19	Devolucao Clientes
* 18	Guia de Retoma
* 17	Guia de Remessa
* 11	Guia de Transporte
* 15	Registo de Tempos

SELECT bo


if (bo.ndos=15) && and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .t.
endif


if (bo.ndos=17) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif

if (bo.ndos=18) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif


if (bo.ndos=19) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif


if (bo.ndos=20) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif

if (bo.ndos=22) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif

if (bo.ndos=11) and len(alltrim(SBO.Pageframe1.Page1.Fref.Combo.VALUE))=0
	return .f.
endif

