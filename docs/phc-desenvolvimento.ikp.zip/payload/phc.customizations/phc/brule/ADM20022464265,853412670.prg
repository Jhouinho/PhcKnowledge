* BRULE
* stamp: ADM20022464265,853412670
* tabela: FL
* mensagem: 
* descricao: FL -  Não Permite Criar Fornecedores
* estado: Activo
* inactivo: False

select fl
if sfl.adding = .T.

	mensagem("Desculpe, a criação é feita pela ficha do Cliente","directa")
	return .f.
endif

