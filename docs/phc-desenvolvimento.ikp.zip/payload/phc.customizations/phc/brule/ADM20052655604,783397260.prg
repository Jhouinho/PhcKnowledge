* BRULE
* stamp: ADM20052655604,783397260
* tabela: BO
* mensagem: Desculpe, mas existem linhas sem valor definido. Não é possível gravar o documento.
* descricao: BO - Validação de Valor Unitário
* estado: Inactivo
* inactivo: True

** ===================
** RB : TP :: 26/5/2020 - Criação
** RB : TP :: 27/5/2020 - Ajuste
** ===================

Local mReturn

Store .t. To mReturn

Select bo

If  InList(bo.ndos,16)

    Select bi
    Go Top
    
    Scan 
        If !Empty(bi.ref)
		    If bi.qtt<>0
		        Select bi
				    Replace bi.eslvu With Round(bi.ettdeb/bi.qtt,4),;
						    bi.slvu With Round(bi.ettdeb/bi.qtt*200.482,2),;
						    bi.esltt with bi.ettdeb,;
						    bi.sltt with Round(bi.ettdeb*200.482,2)
		    Endif
        EndIf
    EndScan

    Select bi
    Go Top
    
    Scan
        If !Empty(bi.ref)
			if bi.qtt<>0
	            If bi.eslvu = 0
    	            mReturn = .f.
        	    EndIf 
			endif
        EndIf
    Endscan
EndIf

Return mReturn

