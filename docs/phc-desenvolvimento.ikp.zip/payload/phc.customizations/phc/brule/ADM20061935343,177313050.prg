* BRULE
* stamp: ADM20061935343,177313050
* tabela: BO
* mensagem:  
* descricao: BO - Entradas Força Recalculo Stock
* estado: Inactivo
* inactivo: True

** ================================================================
** RB:VL :: 19/06/2020 Criação
** ================================================================


Local lc_strsql
store "" to lc_strsql

select bo
if inlist(bo.ndos,16,19,20)

	select bi
	go top

	scan for !empty(bi.ref)

		do stact1 with 'UM',bi.ref,.t.,.f.,.t.

		proc_act_gsaida()

		select bi
	endscan

endif

procedure proc_act_gsaida()

	Local lc_strsql, ll_soref
	Store "" to lc_strsql
	Store .f. to ll_soref

	text to lc_strsql noshow

		declare @bistamp char(25),
				@epcpond numeric(19,6),
				@pcpond numeric(18,5)

		declare crspivo scroll cursor
		for	select 
				a.epcpond, a.pcpond, a.bistamp
			from sl a (nolock)
				join bi b (nolock) on a.bistamp=b.bistamp
			where	a.ref=?bi.ref
					and a.origem='BO'
					and a.cm>50
					and a.epcpond<>b.epcusto 

		open crspivo
			fetch from crspivo into @epcpond, @pcpond, @bistamp
			while @@fetch_status=0
			begin
		
				update bi set
					epcusto = @epcpond,
					pcusto = @pcpond

				where bistamp=@bistamp		

				fetch from crspivo into @epcpond, @pcpond, @bistamp
			end

		close crspivo
		deallocate crspivo

	endtext

	actform("A processsar atualização dos custos dossiers")

	u_sqlexec(lc_strsql)

	deactform()

endproc

