* BRULE
* stamp: ADM20071735803,391066521
* tabela: CL
* mensagem: Desculpe, mas tem de preencher o campo: Moeda.
* descricao: CL - Preenchimento do campo "moeda"
* estado: Activo
* inactivo: False

NOT EMPTY(CL.MOEDA)

