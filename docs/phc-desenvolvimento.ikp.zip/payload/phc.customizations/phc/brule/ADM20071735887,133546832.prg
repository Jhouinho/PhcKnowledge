* BRULE
* stamp: ADM20071735887,133546832
* tabela: FL
* mensagem: Desculpe, mas tem de preencher o campo: Moeda.
* descricao: FL - Preenchimento do campo "moeda"
* estado: Activo
* inactivo: False

NOT EMPTY(FL.MOEDA)

