* BRULE
* stamp: ADM20071756297,414368314
* tabela: BO
* mensagem: 
* descricao: BO - Controlo de preços de custo Devoluções
* estado: Activo
* inactivo: False

select bo
if inlist(bo.ndos,19,20) and empty(alltrim(BO2.ASSINATURA))

	select bi
	go top
	locate for !empty(bi.ref) and empty(bi.oobistamp)
	if found()
		mensagem("Desculpe, as desvoluções é obrigatório copiar do documento de saída.","directa")
		return .f.
	endif

	select bi
	go top 
	scan for !empty(bi.ref)

		u_sqlexec("select ndos, epcusto, edebito, desconto, desc2, desc3, desc4, desc5, desc6 from bi (nolock) where bistamp=?bi.oobistamp","crsobi")
		select crsobi
		go top

		if !reccount()  > 0
				
				mensagem("Desculpe, por algum motivo anormal não consegui validar a origem da linha","directa")
				return .f.

			else

				select crsobi
				if !inlist(crsobi.ndos,11,17)
						
						mensagem("Desculpe, as Devoluções têm ser por copia da Guia de Remessa ou Guia de Transporte","directa")
						return .f.

					else

						select bi
						replace bi.edebito with crsobi.epcusto,;
								bi.desconto with crsobi.desconto,;
								bi.desc2 with crsobi.desc2,;
								bi.desc3 with crsobi.desc3,;
								bi.desc4 with crsobi.desc4,;
								bi.desc5 with crsobi.desc5,;
								bi.desc6 with crsobi.desc6,;
								bi.eslvu with crsobi.epcusto,;
								bi.esltt with crsobi.epcusto*bi.qtt,;
								bi.slvu with round(crsobi.epcusto*200.482,1),;
								bi.sltt with round(crsobi.epcusto*bi.qtt*200.482,1)


						do u_bottdeb with 'bi'
						Do BOTOTS with .T.
	
				endif

		endif

		select bi
	endscan

	select bi
	go top
	locate for !empty(bi.ref) and bi.epcusto=0
	if found()
		mensagem("Desculpe, existem linhas sem preço de custo.","directa")
		return .f.
	endif

endif

