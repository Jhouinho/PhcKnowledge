* BRULE
* stamp: ADM21012131814,596220298
* tabela: FT
* mensagem: 
* descricao: HCA :: Valida linha ccom Iva = 7 | Regime de iva PT-AC
* estado: Activo
* inactivo: False

select fi
locate for fi.TABIVA = 7
if found()
	select ft2
	replace ft2.DESCREGIVA with 'PT-AC'
	
	SFT.pageframe1.page2.descregiva.value = 'PT-AC'
endif

select fi
go top

