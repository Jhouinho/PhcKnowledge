* BRULE
* stamp: ADM21012242020,319904174
* tabela: BO
* mensagem:  
* descricao: HCA | Verifica duplicação de inserção dados importados | RegistoTempos
* estado: Activo
* inactivo: False

Local LvMensagem

Select bo


If bo.ndos = 15

	If sbo.adding

		Select bi
		Go Top
		Scan


			TEXT to LvSqlTxt TextMerge Noshow

	select

	bo.obrano as NrDossier,
	bo.dataobra as Data,
	bi.ref,
	bi.design as designacao,
	bi.rdata as Data,
	bi.u_peno as NrFuncionario,
	bi.u_penome as NomeFuncionario,
	bi.u_nmcl as NomeCliente,
	bi.bifref as Obra,
	bi.u_viatura as Viatura,
	bi.u_kmi as kmIniciais,
	bi.u_kmf as KmFinais,
	bi.u_km as KmPercorridos,
	bi.u_hri as HoraInicio,
	bi.u_hrf as HoraFim,
	bi.u_iextra as InicioExtra,
	bi.u_fextra as FimExtra,
	bi.u_hrsn as HorasNormais,
	bi.u_hrs50 as HorasExtra50,
	bi.u_hrs75 as HorasExtra75,
	bi.u_hrs100 as HorasExtra100,
	bi.u_obs  as Observacoes,
	bi.u_hrviagem as HorasViagem


	from bi (nolock) join bo (nolock) on bo.bostamp=bi.bostamp

		where

	bi.ref = '<<alltrim(bi.ref)>>' and
	bi.design = '<<alltrim(bi.design)>>' and
	bi.rdata = '<<dtos(bi.rdata)>>' and
	bi.u_peno = '<<astr(bi.u_peno)>>' and
	bi.u_penome = '<<alltrim(bi.u_penome)>>' and
	bi.u_nmcl = '<<alltrim(bi.u_nmcl)>>' and
	bi.bifref = '<<alltrim(bi.bifref)>>' and
	bi.u_viatura = '<<alltrim(bi.u_viatura)>>' and
	bi.u_kmi = '<<astr(bi.u_kmi)>>' and
	bi.u_kmf = '<<astr(bi.u_kmf)>>' and
	bi.u_km = '<<astr(bi.u_km)>>' and
	bi.u_hri = '<<alltrim(bi.u_hri)>>' and
	bi.u_hrf = '<<alltrim(bi.u_hrf)>>' and
	bi.u_iextra = '<<alltrim(bi.u_iextra)>>' and
	bi.u_fextra = '<<alltrim(bi.u_fextra)>>' and
	bi.u_hrsn = '<<astr(bi.u_hrsn)>>' and
	bi.u_hrs50 = '<<astr(bi.u_hrs50)>>' and
	bi.u_hrs75 = '<<astr(bi.u_hrs75)>>' and
	bi.u_hrs100 = '<<astr(bi.u_hrs100)>>' and
	bi.u_obs  = '<<alltrim(bi.u_obs)>>' and
	bi.u_hrviagem = '<<strtran(alltrim(str(bi.u_hrviagem,10,2)),',','.')>>'

	and bi.ndos = 15


			ENDTEXT


			If u_sqlexec(LvSqlTxt,"CrsExisteReg")

				If Reccount("CrsExisteReg") >0

					mostrameisto("CrsExisteReg","Registo já inserido no sistema. Por favor verifique!")
					Return .F.
				Endif
			Endif

		Endscan

	Endif


	*
	* 28.04.2021 HCA | JF.
	* Analisa a quilometragem inserida por linha

	If sbo.adding Or sbo.editing


		Select bi
		Go Top
		Scan

			LvMensagem = "Verifique o lançamento, matricula: "+Alltrim(bi.u_viatura)+" Kms Inicial ("+astr(bi.u_kmi)+") - Kms Finais ("+astr(bi.u_kmf)+") = "+astr(bi.u_kmf-bi.u_kmi)

			If Len(Alltrim(bi.u_viatura))>0 
			
				Do Case
			
					Case bi.u_km > 0 
					
						if bi.u_kmf - bi.u_kmi > 0 
							if bi.u_kmf - bi.u_kmi <> bi.u_km
									msg(LvMensagem)
									return .f.
							endif
						endif

					Case (bi.u_kmf - bi.u_kmi) <0
						msg(LvMensagem)
						Return .F.
					
					Case (bi.u_kmf - bi.u_kmi) <>  bi.u_km
						msg(LvMensagem)
						Return .F.
				Endcase

			Endif

		Endscan

	Endif

Endif

