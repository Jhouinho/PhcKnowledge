* BRULE
* stamp: ADM21012738601,096470429
* tabela: TS
* mensagem: 
* descricao: Se entra para análise obriga tipo
* estado: Activo
* inactivo: False

Select ts

If STS.pageframe1.udcpage1.u_analise.Value =.T.

	If Len(Alltrim(STS.pageframe1.udcpage1.u_tpregobr.Value)) = 0

		msg("Tem de escolher um tipo de registo!")
		Return .F.

	Else
		Return .T.

	Endif

	Return .T.

Endif

