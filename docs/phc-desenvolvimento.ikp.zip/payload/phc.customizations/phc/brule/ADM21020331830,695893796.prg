* BRULE
* stamp: ADM21020331830,695893796
* tabela: FREF
* mensagem:  
* descricao: HCA | Regras FREF
* estado: Activo
* inactivo: False

*
* HCA | CRM Gravar alteração de Status OBRA
* 03.02.2021
* HCA . Jorge F.
*
Local LvValorStatusAnterior,LvObsStatus
Select fref
If sfref.adding
	If Len(Alltrim(sfref.pageframe1.page1.u_status.Value)) = 0
		sfref.pageframe1.page1.u_status.Value ='Aberta'
	Endif
	If Len(Alltrim(sfref.pageframe1.page1.fref.Value)) = 0
		msg("Obrigatório o código de obra!")
		return .f.
	Endif
	If Len(Alltrim(fref.NMFREF)) = 0
		SFREF.Pageframe1.Page1.Nmfref.SetFocus
		SFREF.Pageframe1.Page1.Nmfref.SetFocus
		msg("Obrigatório a descrição da obra!")
		Return .F.
	Endif
	If Len(Alltrim(sfref.pageframe1.page1.u_tipo.Value)) = 0
		msg("Obrigatório o tipo de obra!")
		return .f.
	Endif
	If InsertFREFLogs(fref.frefstamp,m.m_chinis,m.m_chnome,fref.fref,fref.u_status,"") = "1"
		Select fref
		***Replace U_DATAINI With Date()
		Replace U_USSTATUS With m.m_chinis
		replace U_DTSTATUS With Date()
		Return .T.
	Else
		msg("Erro ao inserir Log de alteração de status! Por favor informe o depº de informática")
		Return .F.
	Endif
Else
	If Oldval("u_status","FREF") = 'Fechada' And m.m_chinis <>'ADM' And m.m_chinis <>'VA'  And m.m_chinis <>'MG' And m.m_chinis <>'mgm'  
		msg("Não pode alterar uma obra fechada!")
		Return .F.
	Endif
	* Gravar alteração de status FREF
	LvValorStatusAnterior = 0
	Select fref
	If Oldval("u_status","FREF") <> sfref.pageframe1.page1.u_status.Value
		If InsertFREFLogs(fref.frefstamp,m.m_chinis,m.m_chnome,fref.fref,fref.u_status,"") = "1"
			Select fref
			***Replace U_DATAFIM With Date()
			Replace U_USSTATUS With m.m_chinis
			replace U_DTSTATUS With Date()
			Return .T.
		Else
			msg("Erro ao inserir Log de alteração de status! Por favor informe o depº de informática")
			Return .F.
		Endif
	Else
		Return .T.
	Endif
endif
*
*
*
Function InsertFREFLogs
	Lparameters in_Frefstamp,in_m_chinis,in_m_chnome,in_fref,in_status,in_obs
	Local LvSqlTxt
	TEXT to LvSqlTxt TextMerge noshow
INSERT INTO [dbo].[u_Freflogs]
     (
			[u_FreflogsStamp]
           ,[Frefstamp]
           ,[Fref]
           ,[iniciais]
           ,[username]
           ,[descricao]
           ,[data]
           ,[hora]
           ,[codigo]
           ,[obs])
     VALUES
           ('<<u_stamp()>>'			/* varchar(25),> */
           ,'<<in_Frefstamp>>'		/* , varchar(25),> */
           ,'<<in_Fref>>'			/* , varchar(20),> */
           ,'<<in_m_chinis>>' 		/* , varchar(3),> */
           ,'<<in_m_chnome>>'		/* , varchar(30),> */
           ,'<<in_status>>'			/* , varchar(100),> */
           ,'<<dtosql(date())>>'	/* , datetime,> */
           ,'<<time()>>' 			/* varchar(10),> */
           ,'<<in_fref>>'			/*, varchar(30),>) */
           ,'<<in_obs>>'			/*, varchar(254),>) */
		)
	ENDTEXT
	* msg(LvSqlTxt)
	If !u_sqlexec(LvSqlTxt)
		msg("Erro ao efetuar o insert do log fref (obras)")
		Return "0"
	Else
		Return "1"
	Endif
Endfunc

