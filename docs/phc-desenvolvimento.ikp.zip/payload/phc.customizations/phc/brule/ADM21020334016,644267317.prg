* BRULE
* stamp: ADM21020334016,644267317
* tabela: FREF
* mensagem:  
* descricao: HCA | Regras FREF eliminação
* estado: Activo
* inactivo: False

*
* HCA | CRM Eliminar alteração de Status da Obra
* 03.02.2021
* HCA . Jorge F.
*
Local LvValorStatusAnterior
Select Fref
If Fref.u_status = 'Fechada' And m.m_chinis <>'ADM'
	msg("Não pode eliminar uma obra fechada!")
	Return .F.
Else
	If !u_sqlexec("delete from u_Freflogs where frefstamp = '"+Alltrim(Fref.frefstamp)+"'")
		msg("Erro ao eliminar o histórico de status da obra. Por favor informe o depº de informática!")
		Return .F.
	Else
		Return .T.
	Endif
Endif

