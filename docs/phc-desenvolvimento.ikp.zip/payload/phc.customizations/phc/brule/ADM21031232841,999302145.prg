* BRULE
* stamp: ADM21031232841,999302145
* tabela: FT
* mensagem: 
* descricao: HCA | Verifica se existe ref na linha do crédito
* estado: Activo
* inactivo: False

Select ft
If ft.tipodoc=3
	Select fi
	Locate For Len(Alltrim(fi.ref)) >0
	If Found()
		msg("Não pode ter referência nas linhas do crédito. Garanta, por favor, que o movimento de stock foi já inserido em dossier!")
		Return .F.
	Endif
Else
	Return .T.
Endif

