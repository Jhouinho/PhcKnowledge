* BRULE
* stamp: ADM21050760720,336622440
* tabela: BO
* mensagem:  
* descricao: HCA | Verifica valor entrada retoma > 0
* estado: Activo
* inactivo: False

Local LvMensagem

Select bo


If bo.ndos = 18


	Select bi
	Go Top
	Scan

		If Len(Alltrim(bi.ref))>0

			If bi.qtt>0

				If bi.edebito = 0

					LvEpcusto=GetUmValorNumerico("st","st.EPCPOND","st.ref='"+Alltrim(bi.ref)+"'")

					LvMensagem = "O artigo "+Alltrim(bi.ref)+" não pode ter custo zero. O preço custo atual é de: "+Strtran(Alltrim(Str(LvEpcusto,12,2)),',','.')+"€. Iremos utilizar o mesmo na coluna respectiva. Poderá, no entanto, alterar o mesmo, conforme o acordado."

					msg(LvMensagem)
					Select bi
					Replace bi.edebito With LvEpcusto

					Do u_bottdeb With 'bi',.F.
					Do BOTOTS With .T.

					Return .F.
				Endif
			Endif

		Endif

	Endscan

	Return .t.
Else
	Return .t.
Endif

