* BRULE
* stamp: ADM22081060135,482776886
* tabela: FO
* mensagem: 
* descricao: HCA | Não deixar alterar N/C AGUARDA N/CRÈDITO
* estado: Activo
* inactivo: False

*
* Jorge F. HCA
* Ultima Revisão: 26.01.2024
*
* Não desativar a regra sem falar com o Jorge F. HCA
* Impede alterações ao documento caso a origem seja uma Guia de Devolução de fornecedor
*


Local LvAdoc

Select fo

If sfo.editing

	* messagebox(fo.site,"GUIADEV")
	If fo.site<>"GUIADEV"
	

		LvAdoc = upper(Alltrim(Oldval("ADOC","FO")))
	
		If LvAdoc = "AGUARDA N/CRÉDITO"
			MSG("Não é possivel alterar o documento AGUARDA N/Crédito. Por favor utilize o botão para actualizar o nrº e data do documento!")
			Return .F.
		Else
			* MSG("Sem erro!")
			Return .T.
		Endif

	Else

		MSG("Este documento tem a origem numa guia de devolução fornecedor. Não é possivel a sua alteração!")
		Return .F.


	Endif

Endif

