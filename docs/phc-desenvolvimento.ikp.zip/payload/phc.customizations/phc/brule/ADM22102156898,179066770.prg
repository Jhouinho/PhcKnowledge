* BRULE
* stamp: ADM22102156898,179066770
* tabela: FT
* mensagem: Não pode gravar sem indicar a obra no documento.
* descricao: HCA | 2022 Obriga a obra em documentos FATURAÇÃO
* estado: Activo
* inactivo: False

* HCA | Jorge F 21.10.2022
* Pedido Dª Vera para obrigar Obra documentos faturação

select ft

if  LEN(ALLTRIM(SFT.Pageframe1.Page2.Fref1.Combo.VALUE))=0
	return .f.
else
	return .t.
endif

