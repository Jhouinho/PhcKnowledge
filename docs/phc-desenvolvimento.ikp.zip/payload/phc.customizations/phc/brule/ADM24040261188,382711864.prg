* BRULE
* stamp: ADM24040261188,382711864
* tabela: BO
* mensagem: Caro utilizador, não pode associar documentos a obras já Fechadas.
* descricao: Valida a Gravação - Obra aberta
* estado: Activo
* inactivo: False

local mnvalor
SELECT bo
m.mnvalor=GetUmValorNumerico("FREF","COUNT(u_status)","u_status = 'Aberta' and fref='" + ALLTRIM(BO.FREF) + "'" )
IF m.mnvalor=0 and !empty(BO.FREF)
	RETURN .F.
ENDIF

