* BRULE
* stamp: ADM24040261216,743686037
* tabela: FT
* mensagem: Caro utilizador, não pode associar documentos a obras já Fechadas.
* descricao: Valida a Gravação - Obra aberta
* estado: Activo
* inactivo: False

local mnvalor
SELECT FT
m.mnvalor=GetUmValorNumerico("FREF","COUNT(u_status)","u_status = 'Aberta' and fref='" + ALLTRIM(FT.FREF) + "'" )
IF m.mnvalor=0 and !empty(FT.FREF)
	RETURN .F.
ENDIF

