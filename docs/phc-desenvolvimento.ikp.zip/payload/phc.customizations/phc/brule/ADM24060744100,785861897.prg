* BRULE
* stamp: ADM24060744100,785861897
* tabela: BO
* mensagem: 
* descricao: Guia Transporte sem Origens
* estado: Activo
* inactivo: False

*### HCA - PT - 07.06.2024
*### alteração em 2024.06.28 - acrescentei "Guia de Remessa" (ndos=17)  
select bo
if (bo.ndos=11) or (bo.ndos=17)
	select bi
	go top
	scan
		replace obistamp with ''
		replace oobistamp with ''
	endscan	
endif

