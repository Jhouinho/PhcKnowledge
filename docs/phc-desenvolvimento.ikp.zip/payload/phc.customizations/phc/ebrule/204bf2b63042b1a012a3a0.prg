* EBRULE (Web)
* stamp: 204bf2b63042b1a012a3a0
* tabela: 
* ecran: flform
* mensagem: Desculpe, mas deve preencher o campo: Moeda.
* descricao: (flform) Preenchimento do campo "moeda"
* grau: 0
* estado: Activo
* inactivo: False

Dim lb_retval As Boolean = True

Dim dr As DataRow = mainformdataset.Tables("fl").Rows(0)

If dr("moeda") = "" Then 
    lb_retval = False
End If

Return lb_retval

