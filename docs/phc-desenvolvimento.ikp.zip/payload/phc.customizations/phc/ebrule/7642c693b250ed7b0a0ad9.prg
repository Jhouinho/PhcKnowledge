* EBRULE (Web)
* stamp: 7642c693b250ed7b0a0ad9
* tabela: 
* ecran: clform
* mensagem: Desculpe, mas deve preencher o campo: Moeda.
* descricao: (clform ) Preenchimento do campo "moeda"
* grau: 0
* estado: Activo
* inactivo: False

Dim lb_retval As Boolean = True

Dim dr As DataRow = mainformdataset.Tables("cl").Rows(0)

If dr("moeda") = "" Then 
    lb_retval = False
End If

Return lb_retval

