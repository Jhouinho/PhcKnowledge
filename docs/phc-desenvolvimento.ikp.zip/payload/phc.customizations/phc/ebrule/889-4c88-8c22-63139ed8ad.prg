* EBRULE (Web)
* stamp: 889-4c88-8c22-63139ed8ad
* tabela: 
* ecran: boform
* mensagem: Impossível gravar.
* descricao: (boform - Intranet) Obriga Forma de Pagamento
* grau: 0
* estado: Activo
* inactivo: False

Dim retval As Boolean = True
Dim dr As DataRow = mainformdataset.Tables("bo").Rows(0)

If dr("ndos") = 3 Then

	If dr("cobranca") = "" Then 
    XcUtil.Alerta(mpage, "Desculpe, mas deve preencher a Forma de Pagamento.", 3, 100000)
    	retval = False
	End If
  
End If

Return retval

