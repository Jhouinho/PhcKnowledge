* EBRULE (Web)
* stamp: 88d-4afe-9cd3-6bcb84e9d1
* tabela: 
* ecran: boform
* mensagem: Impossível gravar.
* descricao: (boform - Intranet) Preço de Custo > Preço Unitário
* grau: 0
* estado: Activo
* inactivo: False

Dim retval As Boolean = True

Dim dt As DataTable = mainformdataset.Tables("bi")

For Each dr As DataRow in dt.rows
  ' epcusto = Preço de Custo || edebito = Pr.Unit.

  if dr.RowState <> DataRowState.Deleted 


    If CType(dr("epcusto"), System.Decimal)  > CType(dr("edebito"), System.Decimal) Then
      XcUtil.Alerta(mpage, "O Preço de Custo não pode ser superior ao Preço Unitário, no artigo " & dr("design") & ".", 3, 100000)
      retval = False
      Exit For
      End If
    End If
  Next
  Return retval

