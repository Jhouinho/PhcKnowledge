* EBRULE (Web)
* stamp: 9841ca89ded860cd124472
* tabela: 
* ecran: boform
* mensagem: 
* descricao: (boform - Intranet) Validação de Campos de Orçamento
* grau: 0
* estado: Activo
* inactivo: False

Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()

Dim boolRetVal As Boolean = True
Dim dr As DataRow = mf.PropMainFormDataSet.Tables("bo").Rows(0)

If dr("ndos") = 3 Then

  ' Forma de Pagamento
  If Trim(dr("cobranca")) = "" Then
    boolRetVal = False
    XcUtil.Alerta(mpage, "Desculpe, mas deve preencher a forma de pagamento.", 3)
  Else

    If dr("u_status") = "Adjudicado" Then

      ' N.º de Adjudicação
      If String.IsNullOrEmpty(dr("trab2")) Then
        XcUtil.Alerta(mpage, "Desculpe, mas deve preencher o campo do N.º da Adjudicação", 3)
        boolRetVal = False

        ' Data de Adjudicação
      ElseIf dr("u_dtadjud") = "01.01.1900" <> String.IsNullOrEmpty(dr("u_dtadjud").ToString()) Then
        XcUtil.Alerta(mpage, "Desculpe, mas deve preencher o campo da Data de Adjudicação", 3)
        boolRetVal = False

        ' Obra
      ElseIf String.IsNullOrEmpty(dr("fref").ToString()) Then
        XcUtil.Alerta(mpage, "Desculpe, mas deve preencher o campo da Obra", 3)
        boolRetVal = False

      ElseIf dr("vendedor") = 0 Then

        XcUtil.Alerta(mpage, "Desculpe, mas deve preencher o vendedor.", 3)
        boolRetVal = False
      End If
    End If

  End If

End If

Return boolRetVal

