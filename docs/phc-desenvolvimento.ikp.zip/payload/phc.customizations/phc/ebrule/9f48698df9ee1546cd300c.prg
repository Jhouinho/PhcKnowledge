* EBRULE (Web)
* stamp: 9f48698df9ee1546cd300c
* tabela: 
* ecran: boform
* mensagem: Impossível gravar. A retoma não pode ter custo zero.

* descricao: (boform - Intranet) Verifica valor entrada retoma > 0
* grau: 0
* estado: Activo
* inactivo: False

Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()
Dim bo_cab As DataRow = mf.PropMainFormDataSet.Tables("bo").Rows(0)

Dim dt As DataTable = mainformdataset.Tables("bi")
Dim boolRetVal As Boolean = True
Dim retval As Boolean = True

If bo_cab("ndos") = 18 Then
  
For Each dr As DataRow in dt.rows
  ' epcusto = Preço de Custo || edebito = Pr.Unit.

  if dr.RowState <> DataRowState.Deleted 

    If CType(dr("edebito"), System.Decimal)  = 0 Then
      XcUtil.Alerta(mpage, "O Preço de Custo não pode ser 0, no artigo " & dr("design") & ".", 3, 100000)
      retval = False
      Exit For
      End If
    End If
  Next
  Return retval
end if    
  
  
Return boolRetVal

