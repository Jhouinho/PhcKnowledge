* EBRULE (Web)
* stamp: eb4d71870607012a8ac533
* tabela: 
* ecran: ftform
* mensagem: 
* descricao: (ftform) Corrige Descontos Comerciais
* grau: 0
* estado: Activo
* inactivo: False

#Region ""
        Dim ftcursor As DataTable = mainformdataset.tables("FT")
        Dim ficursor As DataTable = mainformdataset.tables("FI")
        Dim tdcursor As DataTable

        If bizlib.Utility.FtUtil.get_tdvalores(ftcursor.Rows(0).Item("ndoc"), tdcursor) Then
            Dim edescc As Decimal = 0
            For Each filinha In ficursor.Rows
                edescc += Math.Round(Math.Round((filinha.Item("qtt") * filinha.Item("epv")) * IIf(tdcursor.Rows(0).Item("tipodoc") = 3, -1, 1), 2) - filinha.Item("etiliquido"), 2) / IIf(filinha.Item("ivaincl"), 1 + filinha.Item("iva") / 100, 1)
            Next
            ftcursor.Rows(0).Item("edescc") = edescc
            ftcursor.Rows(0).Item("descc") = edescc * 200.482
        Else
            XcUtil.FormMensagem("Não consegui aceder à configuração da fatura.")
        End If

        Return True
#End Region

