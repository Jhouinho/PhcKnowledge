* EEVENTO (Web)
* stamp: 084ee884443e3c863898b7
* resumo: (boform - AposPreRender) Inactivar Objectos
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
Dim obj As Object
obj = mpage.Master.findcontrol("conteudo").findcontrol("carga")
obj.invisivelsempre = True
obj.visible = False
obj = mpage.Master.findcontrol("conteudo").findcontrol("descar")
obj.invisivelsempre = True
obj.visible = False

