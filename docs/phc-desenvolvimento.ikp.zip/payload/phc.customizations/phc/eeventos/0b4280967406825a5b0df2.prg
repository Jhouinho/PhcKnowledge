* EEVENTO (Web)
* stamp: 0b4280967406825a5b0df2
* resumo: (boform) Esconde Gera Encomenda
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
Dim obrano As String = CType(mpage.Master.FindControl("conteudo").FindControl("obrano"), NossoCampoTextBox).Value.ToString()

        If String.IsNullOrWhiteSpace(obrano) Then
            Dim bostamp As String = xcfox.U_sDecrypt(mpage.Request.Params("stamp"))
            Try
                If Not String.IsNullOrWhiteSpace(bostamp) Then
                    Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
                        If con.State <> ConnectionState.Open Then
                            con.Open()
                        End If
                        Using com As SqlClient.SqlCommand = con.CreateCommand()
                            com.CommandText = "SELECT obrano from bo where bostamp = @bostamp"
                            com.Parameters.AddWithValue("@bostamp", bostamp)

                            Using reader = com.ExecuteReader
                                If reader.Read Then
                                    obrano = reader(0)
                                End If
                            End Using
                        End Using
                        con.Close()
                    End Using
                End If
            Catch
            End Try
        End If
If not string.IsNullOrWhiteSpace(obrano)

        Dim x As String = cdata.GetUmValorString("DECLARE @obrano AS integer = " & obrano & "; select 1 from bi bi1 join bi bi on bi.bistamp=bi1.oobistamp where bi1.ndos=1 and bi.oobistamp <> '' and bi.ndos=3 and bi.obrano=@obrano")
        If x = "1" Then
            Dim FindControlRecursive As Func(Of Control, String, Control) = Function(rootControl As Control, controlID As String) As Control
                                                                                If rootControl.ID = controlID Then Return rootControl
                                                                                For Each controlToSearch In rootControl.Controls
                                                                                    Dim controlToReturn As Control = FindControlRecursive(controlToSearch, controlID)
                                                                                    If controlToReturn IsNot Nothing Then Return controlToReturn
                                                                                Next
                                                                                Return Nothing
                                                                            End Function

            Dim c As Control = FindControlRecursive(mpage.Master.FindControl("sbody").FindControl("MasterUpdatePanel1"), "userOption34")

            If c IsNot Nothing Then
                c.Parent.Controls.Remove(c)
            End If
        End If
End If

