* EEVENTO (Web)
* stamp: 0b4b618793ca4806ecfcb5
* resumo: Duplicar Orçamento
* ecran: BOFORM
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
'Registar o Browlist no ecrã
KoGridBase.RegisterGrid(mpage.ToMainform)
Dim mform = CType(mpage, Mainform)
Dim clstamp = ""
Dim bostampduplicado As String = ""

'Criar o butão que vai ativar o browlist
Dim button As New NossoButton
button.ID = "CLBrowlist"
button.Text = "Duplicar Orçamento"
button.AppendClass("btn btn-default btn-sm")
button.SetStyle("margin-left","5px")
mpage.Master.FindControl("conteudo").FindControl("options2").Controls.Add(button)


Dim CLList As New BrowList With {
  .ID = "CLList",
  .Title="Selecionar Cliente"
  }

'Definições do browlist
With CLList.Grid
.PaginationRowsForPage = 40
.MultiSelectRows = true
.ShowColumnToSelect = true
.FieldId = "clstamp"
.AddGridColumn("ncont", "NIF")
.AddGridColumn("no", "Numero de cliente")
.AddGridColumn("nome", "Nome do Cliente")
End With

'Adicionar Browlist ao ecrã
CLList.AddToParent(mpage.tomainform)


'Query para obter dados
CLList.ListContext.GetModelFunctionAsync = Async Function(vars)
Dim model As New PhcDynamicObject
model.SetValue("data", Await PhcCommandBuilder.
CreateSelect("cl.ncont,cl.no,cl.nome,cl.clstamp").
From("cl").Where("cl.inactivo = 0").OrderBy("cl.no").GetSqlResultAsync)

Return model
End Function

'Função que executa ação confirmar do browlist

CLList.ListContext.SetSelectRowsFunction = Function(values)
If Not values.ids.Any Then
Return JsonMessage.GetNewJsonError.AddMessage("Não foi escolhido nenhum elemento.")
Else
for each row in values.ids
  if values.ids.Count > 1 Then
    Return JsonMessage.GetNewJsonError.AddMessage("Só pode escolher um cliente.")
  Else
    Dim dt As DataTable = cdata.getdatatable("select cl.no,cl.nome from cl (nolock) where cl.clstamp = '" + row +"'")
    For Each dr As DataRow In dt.Rows

      Try
        Dim bostamp As String = ""
        Dim clNome As String = dr("nome").ToString()
        Dim clNo As String = dr("no").ToString()

        Dim outmsg As New String("")
        Dim outFim As Boolean = False

        Try
          If mform.PropMainFormDataSet.Tables(0).Columns.Contains("bostamp") Then
            bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("bostamp")
          Else
            bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ebostamp")
          End If
        Catch
        End Try
        Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
        If con.State <> ConnectionState.Open Then
          con.Open()
        End If
        Using com As SqlClient.SqlCommand = con.CreateCommand()
        com.CommandType = CommandType.StoredProcedure
        com.CommandText = "sp_VLDuplicarOrcamento"
        com.Parameters.AddWithValue("@mybostamp_origem", bostamp)
        com.Parameters.AddWithValue("@mynomecliente", clNome)
        com.Parameters.AddWithValue("@mynocliente", clNo)
        com.Parameters.AddWithValue("@myusrinis", XcUser.iniciais())
        Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
        If reader.Read() Then
          outmsg = reader("msg")
          outFim = reader("fim")
          bostampduplicado = reader("bostamp")
        End If
      End Using
   
    If Not outFim AndAlso Not String.IsNullOrWhiteSpace(outmsg) Then
      XcUtil.Alerta(mform, outmsg, 3)
    End If
  End Using
con.Close()
End Using
If Not String.IsNullOrWhiteSpace(bostampduplicado) Then
'Return JsonMessage.GetNewJsonError.AddMessage("../dos/boform.aspx?stamp=" & xcfox.U_Scrypt(bostampduplicado))
'mform.Response.Redirect("../dos/boform.aspx?stamp=" & xcfox.U_Scrypt(bostampduplicado))
'httpcontext.current.response.redirect("../boform.aspx?stamp=" &xcfox.U_Scrypt(bostampduplicado))
return JsonMessage.GetNewJsonSuccess.AddReturnUrl("../dos/boform.aspx?stamp=" & xcfox.U_Scrypt(bostampduplicado))

'Return JsonMessage.GetNewJsonSuccess.SetReloadScreen


End If
Catch ex As Exception
XcUtil.LogViewSource(mform, ex.Message & vbNewLine & ex.StackTrace)
End Try

Next
end if

next

End If

End Function

'Abrir o browlist quando se carrega no botão que criamos anteriormente
CLList.SetShowBrowListFromButton(button)

