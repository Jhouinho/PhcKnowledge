* EEVENTO (Web)
* stamp: 0ff-4303-b919-dd6edbd117
* resumo: Alteração da Designação da Obra (Modo Consulta)
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
dim mform as webcontrollib.mainform = mpage
if mform.PropEstadoDoMainForm = WebControlLib.Normalform.EstadoDoMainForm.Consultando Then
  return True
Else
  return False
end if

*=== EXPRESSAO (expressao) ===
Dim mObj As Object
mObj=mpage.master.findcontrol("conteudo").findcontrol("fref").findcontrol("combofref")

Dim mObjValue As String = Ctype(mpage.master.findcontrol("conteudo").findcontrol("fref"), fref).value

Dim sql As String
sql="SELECT CONCAT(RTRIM(LTRIM(fref)), ' : ' , nmfref) AS [LblText] FROM fref WHERE fref='"& mObjValue.tostring & "'"

Dim dt As System.data.DataTable = WebControlLib.cdata.GetDataTable(sql)
If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
    mObj.valuevalor=dt.rows(0).item("LblText").ToString
End If

