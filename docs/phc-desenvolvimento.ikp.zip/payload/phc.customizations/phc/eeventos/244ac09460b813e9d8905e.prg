* EEVENTO (Web)
* stamp: 244ac09460b813e9d8905e
* resumo: (boform - AposPreRender) Preencher Combo - Moradas de Descarga do Cliente - Guia de Transporte
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform As MainForm = mpage
Dim ndos As String 
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
If ndos = "11" Then
  If mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Adicionando OR mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Alterando Then
    Return True
  End If
Else
  Return False
End If

*=== EXPRESSAO (expressao) ===
Dim mform As MainForm = CType(mpage, MainForm)
Dim value As String 
value =  mform.PropMainFormDataSet.Tables("bbo2").Rows(0)("descar")
Dim fref As String = CType(mpage.master.findcontrol("conteudo").findcontrol("fref").findcontrol("Combofref"), NossoCampoTabPrg).ValueValor.ToString()

Dim ldescarCbx As Object
ldescarCbx = mpage.master.findcontrol("conteudo").findcontrol("ldescar")
ldescarCbx.clearItems()
ldescarCbx.expressaotsql = "SELECT szadrsdesc FROM szadrs WHERE u_fref='" + fref.ToString() + "'"
ldescarCbx.naousacache = True
ldescarCbx.Valores = ""
ldescarCbx.GeraItems()
ldescarCbx.ValueValor=Value.ToString()

