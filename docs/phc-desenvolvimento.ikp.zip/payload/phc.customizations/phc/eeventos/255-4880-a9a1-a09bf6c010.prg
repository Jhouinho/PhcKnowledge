* EEVENTO (Web)
* stamp: 255-4880-a9a1-a09bf6c010
* resumo: Ajuste de Tamanho de Colunas (Gridbi)
* ecran: boform
* qevento: AposOnLoad
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim gridbi1 As Object
gridbi1= mpage.master.findcontrol("conteudo").findcontrol("gridbi")
gridbi1.Columns(3).ItemStyle.Width = Unit.Percentage(10)    ' Referência
gridbi1.Columns(4).ItemStyle.Width = Unit.Percentage(20)    ' Designação
gridbi1.Columns(5).ItemStyle.Width = Unit.Percentage(1)     ' Quant.
gridbi1.Columns(6).ItemStyle.Width = Unit.Percentage(1)     ' Unidade
gridbi1.Columns(7).ItemStyle.Width = Unit.Percentage(20)    ' Observações
gridbi1.Columns(8).ItemStyle.Width = Unit.Percentage(10)    ' Preço de Custo
gridbi1.Columns(9).ItemStyle.Width = Unit.Percentage(5)     ' Margem
gridbi1.Columns(11).ItemStyle.Width = Unit.Percentage(5)    ' Lucro
gridbi1.Columns(16).ItemStyle.Width = Unit.Percentage(10)   ' Preço Unitário
gridbi1.Columns(21).ItemStyle.Width = Unit.Percentage(6)    ' Desconto
gridbi1.Columns(22).ItemStyle.Width = Unit.Percentage(6)    ' Desc 2
gridbi1.Columns(29).ItemStyle.Width = Unit.Percentage(10)   ' Total

