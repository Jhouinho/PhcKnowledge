* EEVENTO (Web)
* stamp: 296-433f-91c7-f2329730fa
* resumo: Calcula PrUnit e Margem
* ecran: boform
* qevento: BoAposAlterarValorEmLinha
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim mForm As WebControlLib.Mainform = mpage

Dim mData as bizlib.boclass.boaddreg.ActRefEventoClass
mData = ctype(ObjPara,bizlib.boclass.boaddreg.ActRefEventoClass)

Dim ebo, ebi, ebi2 As New DataTable
ebo = mForm.PropMainFormDataSet.Tables("ebo") 
ebi = mForm.PropMainFormDataSet.Tables("ebi")
ebi2 = mForm.PropMainFormDataSet.Tables("ebi2") 

Dim ts As New DataTable
bizlib.Utility.boutil.get_tsvalores(mForm.PropTipoDocumento.tostring(), ts)

If ebo.rows(0).RowState <> DataRowState.Deleted ANdAlso ts.rows(0).RowState <> DataRowState.Deleted Then



If (mData.Bilinha("qtt") > 0)

    Dim changedInput As String = mForm.Request("__EVENTTARGET").ToString()
    
    ' -- MARGEM 
  If changedInput.Contains("u_margem") OrElse changedInput.Contains("epcusto") Then
        
        mData.Bilinha("edebito") = mData.bilinha("epcusto") + (mData.bilinha("epcusto") * (mData.bilinha("u_margem")/100))

        bizlib.boclass.boaddreg.u_bottdeb(mData.bolinha("moeda"), mData.tslinha, mData.bilinha, mData.bolinha)
  
        bizlib.boclass.boaddreg.acttotais("", "", True, ebi, ebo.rows(0), ts.rows(0))  
    
    ' -- PREÇO UNITÁRIO 
    ElseIf changedInput.Contains("edebito")

        bizlib.boclass.boaddreg.u_bottdeb(mData.bolinha("moeda"), mData.tslinha, mData.bilinha, mData.bolinha)

        bizlib.boclass.boaddreg.acttotais("", "", True, ebi, ebo.rows(0), ts.rows(0))  

        Dim benefit As Decimal = mData.bilinha("ettdeb")-(mData.bilinha("epcusto") * mData.bilinha("qtt"))
        mData.bilinha("u_lucro")=Decimal.Round(benefit,2)  

        Dim decimalMargin As Decimal = benefit/mData.bilinha("epcusto")
        mData.bilinha("u_margem")=decimalMargin*100
    End If

    ' -- PREÇO FINAL / PREÇO LÍQUIDO
    mData.Bilinha("u_prcfinal") = mData.Bilinha("ettdeb") / mData.Bilinha("qtt")

    mForm.MetodoActualizarValoresDosObjsAndGridsDoAspx(True)
    
  End If

End If

