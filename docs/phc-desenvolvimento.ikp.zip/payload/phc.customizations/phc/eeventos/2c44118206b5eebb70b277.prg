* EEVENTO (Web)
* stamp: 2c44118206b5eebb70b277
* resumo: (boform) Esconde + Faturar
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As Integer = mform.PropTipoDocumento
If ndos <= 0 Then
  Dim bostamp As String = xcfox.U_sDecrypt(mpage.Request.Params("stamp"))
  If Not String.IsNullOrWhiteSpace(bostamp) Then
    Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
    If con.State <> ConnectionState.Open Then
      con.Open()
    End If
    Using com As SqlClient.SqlCommand = con.CreateCommand()
    com.CommandText = "SELECT ndos from bo where bostamp = @bostamp"
    com.Parameters.AddWithValue("@bostamp", bostamp)
    Using reader = com.ExecuteReader
    If reader.Read Then
      ndos = reader(0)
    End If
  End Using
If ndos <= 0 Then
  com.CommandText = "SELECT ndos from ebo where ebostamp =@bostamp"
  Using reader = com.ExecuteReader
  If reader.Read Then
    ndos = reader(0)
  End If
End Using
End If
End Using
con.Close()
End Using
End If
End If
If String.IsNullOrWhiteSpace(ndos) Then
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
End If
If String.IsNullOrWhiteSpace(ndos) AndAlso mform.PropMainFormDataSet IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables.Count > 0 AndAlso mform.PropMainFormDataSet.Tables(0).Rows?.Count > 0 Then
ndos = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ndos")
End If
If ndos = 3 Then
Return True
Else
Return False
End If

*=== EXPRESSAO (expressao) ===
Dim FindControlRecursive As Func(Of Control, String, Control) = Function(rootControl As Control, controlID As String) As Control
  If rootControl.ID = controlID Then Return rootControl
    For Each controlToSearch In rootControl.Controls
      Dim controlToReturn As Control = FindControlRecursive(controlToSearch, controlID)
      If controlToReturn IsNot Nothing Then Return controlToReturn
      Next
      Return Nothing
    End Function
    Dim c As Control = FindControlRecursive(mpage.Master.FindControl("sbody").FindControl("MasterUpdatePanel1"), "CopyBoTo")
    If c IsNot Nothing Then
      c.Parent.Controls.Remove(c)
    End If

