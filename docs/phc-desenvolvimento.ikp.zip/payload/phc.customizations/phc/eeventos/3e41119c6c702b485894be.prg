* EEVENTO (Web)
* stamp: 3e41119c6c702b485894be
* resumo: Colocar campo como readonly (introduzir)
* ecran: boform
* qevento: AoIntroduzir
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As Integer = mform.PropTipoDocumento
If ndos = 3 Then
  return true
else
  return false
end if

*=== EXPRESSAO (expressao) ===
Dim obj As Object
obj = mpage.Master.findcontrol("conteudo").findcontrol("dataobra")
obj.readonly = True

