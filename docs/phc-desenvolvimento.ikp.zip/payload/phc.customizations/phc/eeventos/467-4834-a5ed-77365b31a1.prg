* EEVENTO (Web)
* stamp: 467-4834-a5ed-77365b31a1
* resumo: Calcula PrLiq
* ecran: boform
* qevento: BoAposActualizarRef
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim mForm As WebControlLib.Mainform = mpage

Dim mData as bizlib.boclass.boaddreg.ActRefEventoClass
mData = ctype(ObjPara,bizlib.boclass.boaddreg.ActRefEventoClass)

mData.Bilinha("u_prcfinal") = mData.Bilinha("ettdeb") / mData.Bilinha("qtt")

