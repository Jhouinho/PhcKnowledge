* EEVENTO (Web)
* stamp: 46b-4a21-a087-7c01be4a08
* resumo: Calcula PrUnit [Inactivo]
* ecran: boform
* qevento: BoAposAlterarValorEmLinha
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim mForm As WebControlLib.Mainform = mpage

Dim mData as bizlib.boclass.boaddreg.ActRefEventoClass
mData = ctype(ObjPara,bizlib.boclass.boaddreg.ActRefEventoClass)

Dim ebo, ebi, ebi2 As New DataTable
ebo = mForm.PropMainFormDataSet.Tables("ebo") 
ebi = mForm.PropMainFormDataSet.Tables("ebi")
ebi2 = mForm.PropMainFormDataSet.Tables("ebi2") 

Dim ts As New DataTable
bizlib.Utility.boutil.get_tsvalores(mForm.PropTipoDocumento.tostring(), ts)

  xcutil.LogViewSource(mpage, mData.Bilinha("qtt"))

If (mData.Bilinha("qtt") > 0)
 
  mData.Bilinha("edebito") = mData.bilinha("epcusto") + (mData.bilinha("epcusto") * (mData.bilinha("u_margem")/100))
  
  bizlib.boclass.boaddreg.u_bottdeb(mData.bolinha("moeda"), mData.tslinha, mData.bilinha, mData.bolinha)
  bizlib.boclass.boaddreg.acttotais("", "", True, ebi, ebo.rows(0), ts.rows(0))

  mData.Bilinha("u_prcfinal") = mData.Bilinha("ettdeb") / mData.Bilinha("qtt")

  mForm.MetodoActualizarValoresDosObjsAndGridsDoAspx(True)

End if

