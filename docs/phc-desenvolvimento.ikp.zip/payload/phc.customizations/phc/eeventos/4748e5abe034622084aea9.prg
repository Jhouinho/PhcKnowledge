* EEVENTO (Web)
* stamp: 4748e5abe034622084aea9
* resumo: (boform - AposPreRender) Mostrar Assessorias - Inativo
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Try
  Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
  If con.State <> ConnectionState.Open Then
    con.Open()
  End If
  Dim bostamp As String = ""
  Dim mform = CType(mpage, WebControlLib.Mainform)
  Dim stringbuilder As New System.Text.StringBuilder()
  Dim valorMOMinuto As Decimal = 0
  Dim valorQuilometro As Decimal = 0
  Dim perSobreMO As Decimal = 0
  Dim perDiversos As Decimal = 0
  Dim perAdministrativo As Decimal = 0
  Try
    If mform.PropMainFormDataSet.Tables(0).Columns.Contains("bostamp") Then
      bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("bostamp")
    Else
      bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ebostamp")
    End If
  Catch
  End Try

  Using com As SqlClient.SqlCommand = con.CreateCommand()

  com.CommandText = "SELECT 
  lidesc
  ,nvalor
  FROM e2
  JOIN e1ca on e2.e1cano = e1ca.e1cano
  WHERE e1ca.cadesc ='Valores de Cálculo de Orçamentos' "
  Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
  While reader.Read()
    If reader("lidesc").ToString = "Valor Mão de Obra (Minuto)" Then
      valorMOMinuto = Convert.ToDecimal(reader("nvalor"))
    End If
    If reader("lidesc").ToString = "Valor Quilómetro" Then
      valorQuilometro = Convert.ToDecimal(reader("nvalor"))
    End If
    If reader("lidesc").ToString = "% sobre a Mão de Obra" Then
      perSobreMO = Convert.ToDecimal(reader("nvalor"))
    End If
    If reader("lidesc").ToString = "% Diversos" Then
      perDiversos = Convert.ToDecimal(reader("nvalor"))
    End If
    If reader("lidesc").ToString = "% Administrativo" Then
      perAdministrativo = Convert.ToDecimal(reader("nvalor"))
    End If
  End While
End Using
stringbuilder.AppendLine($"refreshbubblesPrograma.ValorMOMinuto = {valorMOMinuto.ToString(System.Globalization.CultureInfo.InvariantCulture)};")
stringbuilder.AppendLine($"refreshbubblesPrograma.ValorQuilometro = {valorQuilometro.ToString(System.Globalization.CultureInfo.InvariantCulture)};")
stringbuilder.AppendLine($"refreshbubblesPrograma.PerSobreMO = {perSobreMO.ToString(System.Globalization.CultureInfo.InvariantCulture)};")
stringbuilder.AppendLine($"refreshbubblesPrograma.PerDiversos = {perDiversos.ToString(System.Globalization.CultureInfo.InvariantCulture)};")
stringbuilder.AppendLine($"refreshbubblesPrograma.PerAdministrativo = {perAdministrativo.ToString(System.Globalization.CultureInfo.InvariantCulture)} ;")


If bostamp <> "" Then
com.CommandText = "SELECT
u_assessorias.bistamp
,u_assessorias.totalMaoObraTempo
,u_assessorias.totalQuilometros
,u_assessorias.valorMOMinuto
,u_assessorias.valorQuilometro
,u_assessorias.perSobreMO
,u_assessorias.perDiversos
,u_assessorias.perAdministrativo
,u_assessorias.totalConstituicaoAssessoria
,u_assessorias.totalMaoObra
,u_assessorias.valorTotalQuilometros
,u_assessorias.custosMaoObra
,u_assessorias.custosDiversos
,u_assessorias.custosAdministrativos
,u_assessorias.totalCustosIndiretos
,u_assessorias.totalCustosSemMargem
,u_assessorias.margem
,u_assessorias.totalCustosComMargem
FROM u_assessorias
join bi on u_assessorias.bistamp = bi.u_ecstamp
where bi.bostamp = @bostamp"
com.Parameters.Clear()
com.Parameters.AddWithValue("@bostamp", bostamp)

Dim bistamplist As New List(Of String)

Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
Dim firstTime = True
While reader.Read
  bistamplist.Add(CType(reader("bistamp"), String))
  stringbuilder.AppendLine($"if (refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'] === null || refreshbubblesPrograma['{reader("bistamp")}'] === undefined)
    {{
        refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'] = new CalculoAssessorias();
          refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].ConstituicaoAssessorias([]);
            refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].Key('{reader("bistamp")}');
              }}
          refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].TotalMaoObraTempo({CType(reader("totalMaoObraTempo"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture)});
            refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].TotalQuilometros({CType(reader("totalQuilometros"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture)});
              refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].ValorMOMinuto({IIf(CType(reader("valorMOMinuto"), Decimal) > 0, CType(reader("valorMOMinuto"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture), valorMOMinuto.ToString(System.Globalization.CultureInfo.InvariantCulture))});
                refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].ValorQuilometro({IIf(CType(reader("valorQuilometro"), Decimal) > 0, CType(reader("valorQuilometro"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture), valorQuilometro.ToString(System.Globalization.CultureInfo.InvariantCulture))});
                  refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].PerSobreMO({IIf(CType(reader("perSobreMO"), Decimal) > 0, CType(reader("perSobreMO"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture), perSobreMO.ToString(System.Globalization.CultureInfo.InvariantCulture))});
                    refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].PerDiversos({IIf(CType(reader("perDiversos"), Decimal) > 0, CType(reader("perDiversos"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture), perDiversos.ToString(System.Globalization.CultureInfo.InvariantCulture))});
                      refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].PerAdministrativo({IIf(CType(reader("perAdministrativo"), Decimal) > 0, CType(reader("perAdministrativo"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture), perAdministrativo.ToString(System.Globalization.CultureInfo.InvariantCulture))});
                        refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].Margem({CType(reader("margem"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture)});    
                          ")
                        End While
                      End Using
                    For Each stamp In bistamplist
                      com.CommandText = "SELECT 
                      bistamp
                      ,descricao
                      ,quantidade
                      ,valor
                      ,total
                      FROM u_assessoriaLinhas WHERE  bistamp = @bistamp
                      ORDER by linha"
                      com.Parameters.Clear()
                      com.Parameters.AddWithValue("@bistamp", stamp)
                      Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
                      Dim firstTime = True
                      While reader.Read
                        If firstTime Then
                          stringbuilder.AppendLine($"refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].ConstituicaoAssessorias([]);")
                          firstTime = False
                        End If
                        stringbuilder.AppendLine($"var item = new ConstituicaoAssessoria();
                          item.Descricao('{reader("descricao")}');
                            item.Quantidade('{CType(reader("quantidade"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture)}');
                              item.Valor('{CType(reader("valor"), Decimal).ToString(System.Globalization.CultureInfo.InvariantCulture)}');
                                refreshbubblesPrograma.CalculoAssessorias['{reader("bistamp")}'].ConstituicaoAssessorias.push(item);")
                                End While
                              End Using
                          Next
                        End If

                        Dim script As New System.Web.UI.LiteralControl With {
                          .Text = "<script type='text/javascript'> $( function () {" & stringbuilder.ToString() & "});</script>" & vbNewLine
                          }
                        mpage.Master.FindControl("sbody").Controls.Add(script)
                      End Using
                    con.Close()
                  End Using
              Catch ex As Exception
                XcUtil.LogViewSource(mpage, ex.Message & vbNewLine & ex.StackTrace)
              End Try

