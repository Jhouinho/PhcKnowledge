* EEVENTO (Web)
* stamp: 5b4d0183178c07ca4017c2
* resumo: (boform - AposPreRender) Preencher Campos de Guia de Entrada
* ecran: boform
* qevento: AoIntroduzir
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim ndos As String
Dim mform As MainForm = CType(mpage, MainForm)
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
If ndos = "16" Then
  Return True
Else
  Return False
End If

*=== EXPRESSAO (expressao) ===
Dim mform As MainForm = CType(mpage, MainForm)

If mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Adicionando OR mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Alterando then

  Dim obj As Object
  mform.PropMainFormDataSet.Tables("bbo2").Rows(0)("carga") = ""
  mform.PropMainFormDataSet.Tables("bbo2").Rows(0)("descar") = "D.F. BLOCK"

End if

