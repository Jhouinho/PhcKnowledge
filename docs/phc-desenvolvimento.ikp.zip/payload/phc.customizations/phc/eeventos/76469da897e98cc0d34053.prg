* EEVENTO (Web)
* stamp: 76469da897e98cc0d34053
* resumo: (boform - AposApagar) Eliminar Linhas tabelas u_assessorias | u_assessorialinhas
* ecran: boform
* qevento: AposApagar
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
Dim bostamp As String = ""
        Dim DelReg As String = ""
        Dim mform = CType(mpage, WebControlLib.Mainform)


        bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("bostamp")

        If bostamp <> "" Then


			DelReg = CData.UpdateData("DELETE FROM u_assessorialinhas WHERE BISTAMP IN  (SELECT A.BISTAMP FROM u_assessoriaS A WHERE A.BOSTAMP IN ('" & bostamp & "'))")
            If DelReg <> "" Then
                XcUtil.Alerta(mpage, "Desculpe, mas não foi possível eliminar as linhas da tabela u_assessorialinhas.", 3)
            End If

            DelReg = CData.UpdateData("delete from u_assessorias where bostamp ='" & bostamp & "'")
            If DelReg <> "" Then
                XcUtil.Alerta(mpage, "Desculpe, mas não foi possível eliminar as linhas da tabela u_assessorias.", 3)
            End If
  
        End If

