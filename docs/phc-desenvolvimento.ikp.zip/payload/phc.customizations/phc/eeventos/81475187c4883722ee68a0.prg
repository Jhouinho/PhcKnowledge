* EEVENTO (Web)
* stamp: 81475187c4883722ee68a0
* resumo: Colocar campo como readonly (Alterar)
* ecran: boform
* qevento: AoAlterar
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As Integer = mform.PropTipoDocumento
If ndos = 3 Then
  return true
else
  return false
end if

*=== EXPRESSAO (expressao) ===
Dim obj As Object
obj = mpage.Master.findcontrol("conteudo").findcontrol("dataobra")
obj.readonly = True

