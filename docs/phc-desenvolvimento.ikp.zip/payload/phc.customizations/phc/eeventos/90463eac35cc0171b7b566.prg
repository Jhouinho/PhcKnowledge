* EEVENTO (Web)
* stamp: 90463eac35cc0171b7b566
* resumo: (boform - AposAlterar) Preenche "etotal" e "etotiva"
* ecran: boform
* qevento: AposAlterar
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()
Dim bReturnValue As Boolean
If mf.PropTipoDocumento = 3 Then
  bReturnValue = True
Else
  bReturnValue = False
End If
Return bReturnValue

*=== EXPRESSAO (expressao) ===
Dim etotal As Decimal = CType(mpage.Master.findcontrol("conteudo").findcontrol("etotalglobal"),NossoCampoTextBox).Value
Dim etotiva As Decimal = CType(mpage.Master.findcontrol("conteudo").findcontrol("ettiva"),NossoCampoTextBox).Value
Dim stamp As String = mstamp

cdata.updatedata("UPDATE bo SET etotal="& etotal &" WHERE bostamp='" & stamp & "'")
cdata.updatedata("UPDATE bo2 SET etotiva="& etotiva &" WHERE bo2stamp='" & stamp & "'")

