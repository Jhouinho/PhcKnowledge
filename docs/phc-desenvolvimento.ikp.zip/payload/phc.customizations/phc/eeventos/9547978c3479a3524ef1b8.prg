* EEVENTO (Web)
* stamp: 9547978c3479a3524ef1b8
* resumo: (intranet - boform) Versão de Orçamento
* ecran: boform
* qevento: AposIntroduzir
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== CONDICAO (condicao) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()
Dim bReturnValue As Boolean
If mf.PropTipoDocumento = 3 Then
  bReturnValue = True
Else
  bReturnValue = False
End If
Return bReturnValue

*=== EXPRESSAO (expressao) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()
Dim sVersDoc As String = CType(mpage.Master.FindControl("conteudo").FindControl("u_versdoc"), NossoCampoTextBox).Value.ToString()
Dim sObrano As String = CType(mpage.Master.FindControl("conteudo").FindControl("obrano"), NossoCampoTextBox).Value.ToString()
Dim sBostamp As String = mf.PropMainFormDataSet.Tables("bo").Rows(0)("bostamp").ToString()
Dim sValue As String
Dim sSqlText As String
If String.IsNullOrEmpty(sVersDoc) Then
  sValue = sObrano & "." & "1"
  sSqlText = "UPDATE bo SET u_versdoc ='" & sValue & "' WHERE bo.bostamp='" & sBostamp & "'"

  cdata.UpdateData(sSqlText)

End If

