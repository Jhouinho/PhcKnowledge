* EEVENTO (Web)
* stamp: 974e5ebaeb5f0f60f622b1
* resumo: (boform - AposAlterar) Introdução/Actualização de Assessorias
* ecran: boform
* qevento: AposAlterar
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As String= mform.PropTipoDocumento
        If ndos <= 0 Then
          Dim bostamp As String = xcfox.U_sDecrypt(mpage.Request.Params("stamp"))
          If Not String.IsNullOrWhiteSpace(bostamp) Then
            Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
            If con.State <> ConnectionState.Open Then
              con.Open()
            End If
            Using com As SqlClient.SqlCommand = con.CreateCommand()
            com.CommandText = "SELECT ndos from bo where bostamp = @bostamp"
            com.Parameters.AddWithValue("@bostamp", bostamp)
            Using reader = com.ExecuteReader
            If reader.Read Then
              ndos = reader(0)
            End If
          End Using
        If ndos <= 0 Then
          com.CommandText = "SELECT ndos from ebo where ebostamp =@bostamp"
          Using reader = com.ExecuteReader
          If reader.Read Then
            ndos = reader(0)
          End If
        End Using
        End If
        End Using
        con.Close()
        End Using
        End If
        End If
        If String.IsNullOrWhiteSpace(ndos) Then
        ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
        End If
        If String.IsNullOrWhiteSpace(ndos) AndAlso mform.PropMainFormDataSet IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables.Count > 0 AndAlso mform.PropMainFormDataSet.Tables(0).Rows?.Count > 0 Then
        ndos = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ndos")
        End If
        If ndos = 3 Then
        Return True
        Else
        Return False
        End If

*=== EXPRESSAO (expressao) ===
Dim line = 0
        Try
            Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
                If con.State <> ConnectionState.Open Then
                    con.Open()
                End If
                Using com As SqlClient.SqlCommand = con.CreateCommand()
                    Dim isPost As Boolean = Web.HttpContext.Current.Request.RequestType.StartsWith("POST")
                    If isPost AndAlso Web.HttpContext.Current.Request.Form.AllKeys().Any(Function(par As String)
                                                                                             Return par = "Assessorias"
                                                                                         End Function) Then
                        Dim assessorias() As String = Web.HttpContext.Current.Request.Form.GetValues("Assessorias")
                        Dim bostamp As String = ""
                        Dim mform = CType(mpage, WebControlLib.Mainform)
                        Try
                            If mform.PropMainFormDataSet.Tables(0).Columns.Contains("bostamp") Then
                                bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("bostamp")
                            Else
                                bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ebostamp")
                            End If
                        Catch
                        End Try
                        If bostamp <> "" Then
                            For Each json In assessorias
                                If Not String.IsNullOrEmpty(json) Then
                                    Dim ob As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(json)
                                    line = 1
                                    com.CommandText = "
                                        DELETE FROM u_assessorias
                                        WHERE bostamp = @bostamp
                                        AND NOT EXISTS ( SELECT 1 FROM bi where bi.u_ecstamp = u_assessorias.bistamp);

                                        IF(EXISTS (SELECT 1 FROM u_assessorias WHERE bistamp = @bistamp)) 
                                        UPDATE  u_assessorias
                                           SET  
                                                bostamp = @bostamp 
                                                ,totalMaoObraTempo = @totalMaoObraTempo
                                                ,totalQuilometros = @totalQuilometros
                                                ,valorMOMinuto = @valorMOMinuto
                                                ,valorQuilometro = @valorQuilometro
                                                ,perSobreMO = @perSobreMO
                                                ,perDiversos = @perDiversos
                                                ,perAdministrativo = @perAdministrativo
                                                ,totalConstituicaoAssessoria  = @totalConstituicaoAssessoria
                                                ,totalMaoObra = @totalMaoObra
                                                ,valorTotalQuilometros = @valorTotalQuilometros
                                                ,custosMaoObra = @custosMaoObra
                                                ,custosDiversos = @custosDiversos
                                                ,custosAdministrativos = @custosAdministrativos
                                                ,totalCustosIndiretos = @totalCustosIndiretos
                                                ,totalCustosSemMargem = @totalCustosSemMargem
                                                ,margem = @margem
                                                ,totalCustosComMargem = @totalCustosComMargem
                                            WHERE bistamp = @bistamp;
                                     ELSE
                                        INSERT INTO u_assessorias(
                                                bistamp
                                                ,bostamp 
                                                ,totalMaoObraTempo
                                                ,totalQuilometros
                                                ,valorMOMinuto
                                                ,valorQuilometro
                                                ,perSobreMO
                                                ,perDiversos
                                                ,perAdministrativo
                                                ,totalConstituicaoAssessoria
                                                ,totalMaoObra
                                                ,valorTotalQuilometros
                                                ,custosMaoObra
                                                ,custosDiversos
                                                ,custosAdministrativos
                                                ,totalCustosIndiretos
                                                ,totalCustosSemMargem
                                                ,margem
                                                ,totalCustosComMargem
                                                )
                                                VALUES(
                                                    @bistamp
                                                    ,@bostamp 
                                                    ,@totalMaoObraTempo
                                                    ,@totalQuilometros
                                                    ,@valorMOMinuto
                                                    ,@valorQuilometro
                                                    ,@perSobreMO
                                                    ,@perDiversos
                                                    ,@perAdministrativo
                                                    ,@totalConstituicaoAssessoria
                                                    ,@totalMaoObra
                                                    ,@valorTotalQuilometros
                                                    ,@custosMaoObra
                                                    ,@custosDiversos
                                                    ,@custosAdministrativos
                                                    ,@totalCustosIndiretos
                                                    ,@totalCustosSemMargem
                                                    ,@margem
                                                    ,@totalCustosComMargem
                                                );
                                                DELETE FROM u_assessoriaLinhas WHERE bistamp =@bistamp;"

                                    com.Parameters.Clear()
                                    com.Parameters.AddWithValue("@bistamp", CType(ob("Key"), String))
                                    line = 2
                                    com.Parameters.AddWithValue("@bostamp", bostamp)
                                    line = 3
                                    com.Parameters.AddWithValue("@totalMaoObraTempo", CType(ob("TotalMaoObraTempo"), Decimal))
                                    line = 4
                                    com.Parameters.AddWithValue("@totalQuilometros", CType(ob("TotalQuilometros"), Decimal))
                                    line = 5
                                    com.Parameters.AddWithValue("@valorMOMinuto", CType(ob("ValorMOMinuto"), Decimal))
                                    line = 6
                                    com.Parameters.AddWithValue("@valorQuilometro", CType(ob("ValorQuilometro"), Decimal))
                                    line = 7
                                    com.Parameters.AddWithValue("@perSobreMO", CType(ob("PerSobreMO"), Decimal))
                                    line = 8
                                    com.Parameters.AddWithValue("@perDiversos", CType(ob("PerDiversos"), Decimal))
                                    line = 9
                                    com.Parameters.AddWithValue("@perAdministrativo", CType(ob("PerAdministrativo"), Decimal))
                                    line = 10
                                    com.Parameters.AddWithValue("@totalConstituicaoAssessoria", CType(ob("TotalConstituicaoAssessoria"), Decimal))
                                    line = 11
                                    com.Parameters.AddWithValue("@totalMaoObra", CType(ob("TotalMaoObra"), Decimal))
                                    line = 12
                                    com.Parameters.AddWithValue("@valorTotalQuilometros", CType(ob("ValorTotalQuilometros"), Decimal))
                                    line = 13
                                    com.Parameters.AddWithValue("@custosMaoObra", CType(ob("CustosMaoObra"), Decimal))
                                    line = 14
                                    com.Parameters.AddWithValue("@custosDiversos", CType(ob("CustosDiversos"), Decimal))
                                    line = 15
                                    com.Parameters.AddWithValue("@custosAdministrativos", CType(ob("CustosAdministrativos"), Decimal))
                                    line = 16
                                    com.Parameters.AddWithValue("@totalCustosIndiretos", CType(ob("TotalCustosIndiretos"), Decimal))
                                    line = 17
                                    com.Parameters.AddWithValue("@totalCustosSemMargem", CType(ob("TotalCustosSemMargem"), Decimal))
                                    line = 18
                                    com.Parameters.AddWithValue("@margem", CType(ob("Margem"), Decimal))
                                    line = 19
                                    com.Parameters.AddWithValue("@totalCustosComMargem", CType(ob("TotalCustosComMargem"), Decimal))
                                    line = 19
                                    com.ExecuteNonQuery()
                                    For Each item As Newtonsoft.Json.Linq.JToken In ob("ConstituicaoAssessorias")
                                        com.CommandText = "INSERT INTO u_assessoriaLinhas(bistamp,descricao,quantidade,valor, total, bostamp)
                                                VALUES(@bistamp,@descricao,@quantidade,@valor,@total,@bostamp)"
                                        com.Parameters.Clear()
                                        com.Parameters.AddWithValue("@bistamp", CType(ob("Key"), String))
                                        line = 20
                                        com.Parameters.AddWithValue("@descricao", CType(item("Descricao"), String))
                                        line = 21
                                        com.Parameters.AddWithValue("@quantidade", CType(item("Quantidade"), Decimal))
                                        line = 22
                                        com.Parameters.AddWithValue("@valor", CType(item("Valor"), Decimal))
                                        line = 23
                                        com.Parameters.AddWithValue("@total", CType(item("Total"), Decimal))
                                        line = 24
                                        com.Parameters.AddWithValue("@bostamp", bostamp)
                                        line = 25
                                        com.ExecuteNonQuery()
                                    Next
                                End If
                            Next
                        End If
                    End If
                End Using
                con.Close()
            End Using
        Catch ex As Exception
            XcUtil.LogViewSource(mpage, $"Linha:{line}<br/>" & ex.Message & "<br/>" & ex.StackTrace)
        End Try

