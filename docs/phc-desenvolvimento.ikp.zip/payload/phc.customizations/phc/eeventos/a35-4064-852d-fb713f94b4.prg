* EEVENTO (Web)
* stamp: a35-4064-852d-fb713f94b4
* resumo: Redireciona para a Obra (AposCancelar)
* ecran: szadrsform
* qevento: AposCancelar
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim frefstamp As String = ""
Dim frefstampValue as Object = HttpContext.Current.Request.QueryString("frefstamp")

If frefstampValue IsNot Nothing Then
  Return True
Else
  Return False
End If

*=== EXPRESSAO (expressao) ===
Dim frefstamp As String = ""
Dim frefstampValue as Object = HttpContext.Current.Request.QueryString("frefstamp")

If frefstampValue IsNot Nothing Then
  frefstamp = xcfox.u_sDecrypt(frefstampValue).ToString.Trim
  mpage.Response.Redirect("../programs/genform.aspx?codigo=frefform&stamp=" & xcfox.u_scrypt(frefstamp))
End If

