* EEVENTO (Web)
* stamp: ab3-4157-bfa3-bb0704209f
* resumo: Cálculo de Lucro e Margem (Gridbi) [Inactivo]
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
DIM mform AS WebControlLib.Mainform = mpage
If mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Adicionando OR mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Alterando then
	if mform.PropMainFormDataSet.Tables("ebi").HaveRows  then
    
		FOR EACH bilinha AS System.Data.DataRow In mform.PropMainFormDataSet.Tables("ebi").Rows
		
  			if bilinha.Item("ref") <> "" and bilinha.Item("ettdeb")>0  and bilinha.Item("qtt")>0 then
			
      			dim lucro as decimal = bilinha.Item("ettdeb")-(bilinha.Item("epcusto") * bilinha.Item("qtt"))
		  		bilinha.Item("u_lucro")=Decimal.Round(lucro,2)
		
        dim aux2 as decimal = lucro/(bilinha.Item("epcusto") * bilinha.Item("qtt"))
     			bilinha.Item("u_margem")=aux2*100
        
        'dim prcUnit As Decimal = bilinha.Item("epcusto") + (bilinha.Item("epcusto") * (bilinha.Item("u_margem")/100))
        'xcutil.LogViewSource(mpage, prcUnit.tostring())
        		
        		dim prcFinal as decimal = bilinha.Item("ettdeb")/bilinha.Item("qtt")
        bilinha.Item("u_prcfinal")=Decimal.Round(prcFinal,2)
        
   				
    		end if 
		Next
  Else
    'mform.PropMainFormDataSet.Tables("ebi").AcceptChanges()
    
	end if
  
end if

