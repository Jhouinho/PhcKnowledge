* EEVENTO (Web)
* stamp: b24d4eb637c3ed7e96d30f
* resumo: Fechar varios dossiers
* ecran: BOFORM
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
return true

*=== EXPRESSAO (expressao) ===
'Registar o Browlist no ecrã
KoGridBase.RegisterGrid(mpage.ToMainform)

'Criar o butão que vai ativar o browlist
Dim button As New NossoButton
button.ID = "TesteBrowlist"
button.Text = "Fechar vários dossiers"
button.AppendClass("btn btn-default btn-sm")
button.SetStyle("margin-left","5px")
mpage.Master.FindControl("conteudo").FindControl("sumario").Controls.Add(button)


Dim BoList As New BrowList With {
  .ID = "BoList",
  .Title="Fechar dossiers da série selecionada"
}

'Definições do browlist 
With BoList.Grid
  .PaginationRowsForPage = 40
  .MultiSelectRows = True
  .ShowColumnToSelect = True
  .FieldId = "bostamp"
.AddGridDateColumn("dataobra", "Data do dossier")
.AddGridColumn("nome", "Nome do cliente")
.AddGridColumn("nmdos", "Série")
.AddGridNumberColumn("obrano", "Número do dossier", 0)
End With

'Adicionar Browlist ao ecrã
BoList.AddToParent(mpage.tomainform)

'Inserir parâmetro do número da série
Dim bo = mpage.tomainform.GetCurrentAliasTypedRow(Of BoRow)()
if bo isnot nothing then
BoList.ContextVars.SetValue("ndos", bo.ndos)
end if

'Query para obter dados
BoList.ListContext.GetModelFunctionAsync = Async Function(vars)
  Dim model As New PhcDynamicObject
  model.SetValue("data", Await PhcCommandBuilder.
CreateSelect("bo.obrano,bo.nome, bo.bostamp,bo.dataobra,bo.nmdos").
    From("bo").Where("bo.ndos=@ndos and fechada=0").AddSqlParameter("@ndos", BoList.ContextVars.GetValue("ndos")).OrderBy("obrano").GetSqlResultAsync)
  Return model
End Function

'Função que executa ação confirmar do browlist
BoList.ListContext.SetSelectRowsFunction = Function(values)
															If Not values.ids.Any Then
                                                               Return JsonMessage.GetNewJsonError.AddMessage("Não foi escolhido nenhum elemento.")
                                                           End If

                                                            for each row in values.ids
                                                           	 PhcCommandBuilder.CreateUpdate("BO").AddUpdateColValue("fechada", "1").AddUpdateColValue("datafecho", now.date).Where("bo.bostamp =@stamp").addsqlparameter("@stamp",row).executenonquery()
                                                           	 PhcCommandBuilder.CreateUpdate("Bi").AddUpdateColValue("fechada", "1").AddUpdateColValue("datafecho", now.date).Where("bi.bostamp =@stamp").addsqlparameter("@stamp",row).executenonquery()
															next

                                                           Return JsonMessage.GetNewJsonSuccess.SetReloadScreen
                                                       End Function

'Abrir o browlist quando se carrega no botão que criamos anteriormente
BoList.SetShowBrowListFromButton(button)

