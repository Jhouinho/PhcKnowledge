* EEVENTO (Web)
* stamp: b61-48de-99e4-78f4ae9827
* resumo: Inactivar Opção de Menu
* ecran: Opcoesdomenu
* qevento: AposDefinirMenu
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
'filtrar as opções para inativar
Dim drArray As DataRow() = mainformdataset.Tables(0).Select("subsubmenu='Moradas de Carga e Descarga'")
'colocar as opções inativas
For Each row As DataRow In drArray
    row("mvisible") = True
Next

