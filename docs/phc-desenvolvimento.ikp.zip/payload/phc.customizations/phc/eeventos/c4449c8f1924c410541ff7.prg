* EEVENTO (Web)
* stamp: c4449c8f1924c410541ff7
* resumo: (boform - AposOnLoad) - BiGrid PHC
* ecran: boform
* qevento: AposOnLoad
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As Integer = mform.PropTipoDocumento
If ndos <= 0 Then
  Dim bostamp As String = xcfox.U_sDecrypt(mpage.Request.Params("stamp"))
  If Not String.IsNullOrWhiteSpace(bostamp) Then
    Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
    If con.State <> ConnectionState.Open Then
      con.Open()
    End If
    Using com As SqlClient.SqlCommand = con.CreateCommand()
    com.CommandText = "SELECT ndos from bo where bostamp = @bostamp"
    com.Parameters.AddWithValue("@bostamp", bostamp)

    Using reader = com.ExecuteReader
    If reader.Read Then
      ndos = reader(0)
    End If
  End Using
If ndos <= 0 Then
  com.CommandText = "SELECT ndos from ebo where ebostamp =@bostamp"
  Using reader = com.ExecuteReader
  If reader.Read Then
    ndos = reader(0)
  End If
End Using
End If
End Using
con.Close()
End Using
End If
End If

If String.IsNullOrWhiteSpace(ndos) Then
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
End If
If String.IsNullOrWhiteSpace(ndos) AndAlso mform.PropMainFormDataSet IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables.Count > 0 AndAlso mform.PropMainFormDataSet.Tables(0).Rows?.Count > 0 Then
ndos = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ndos")
End If

If ndos = 3 Then
Return True
Else
Return False
End If

*=== EXPRESSAO (expressao) ===
#Region "PHCScript"
        Dim actValues = Sub(args As MainformKoGridEventArgs)
                            Dim bi = args.SelectedRow.ToTypedRow(Of BiRow)
                            If bi IsNot Nothing Then
                                Dim qtt = bi.Qtt
                                If qtt > 0 Then

                                    Select Case args.ColumnId
                                        Case "u_margem", "epcusto"
                                            bi.EDebito = bi.ItemToDecimal("epcusto") * (1 + bi.ItemToDecimal("u_margem") / 100)
                                            With BoFormClass.NewInstance(args.MainformDataset, TsRow.GetNewTsRow(args.FormModel.DocType))
                                                .CalculaTotaisBi(bi)
                                                .CalculaTotais()
                                            End With
    										bi("u_fmargem") = (bi.ItemToDecimal("ettdeb") - (bi.ItemToDecimal("epcusto")) * bi.ItemToDecimal("qtt")) / (bi.ItemToDecimal("epcusto") * bi.ItemToDecimal("qtt"))  * 100
                                            

                                        Case "edebito"
                                            With BoFormClass.NewInstance(args.MainformDataset, TsRow.GetNewTsRow(args.FormModel.DocType))
                                                .CalculaTotaisBi(bi)
                                                .CalculaTotais()
                                            End With
                                            Dim epCusto = bi.ItemToDecimal("epcusto")
                                            Dim benefit As Decimal = bi.ItemToDecimal("ettdeb") - (epCusto * qtt)
                                            bi("u_lucro") = benefit.RoundPhc(2)
                                            Dim mEdebito = bi.ItemToDecimal("edebito")
                                            Dim mCusto = bi.ItemToDecimal("epcusto")
                                            bi("u_margem") = ((mEdebito - mCusto) / mCusto) * 100
                                            bi("u_fmargem") = (bi.ItemToDecimal("ettdeb") - (bi.ItemToDecimal("epcusto")) * bi.ItemToDecimal("qtt")) / (bi.ItemToDecimal("epcusto") * bi.ItemToDecimal("qtt"))  * 100

                                        Case "desconto"
                                            bi("u_prcfinal") = bi.ItemToDecimal("ettdeb") / qtt
                                           bi("u_fmargem") = (bi.ItemToDecimal("ettdeb") - (bi.ItemToDecimal("epcusto")) * bi.ItemToDecimal("qtt")) / (bi.ItemToDecimal("epcusto") * bi.ItemToDecimal("qtt"))  * 100

                                        Case "desc2"
                                            bi("u_prcfinal") = bi.ItemToDecimal("ettdeb") / qtt
                                            bi("u_fmargem") = (bi.ItemToDecimal("ettdeb") - (bi.ItemToDecimal("epcusto")) * bi.ItemToDecimal("qtt")) / (bi.ItemToDecimal("epcusto") * bi.ItemToDecimal("qtt"))  * 100
                                    End Select
                                End If
                                If args.ColumnId = "u_obs" Then
                                    bi("u_obs") = bi.ItemToString("u_obs")
                                End If
                                If args.ColumnId = "unidade" Then
                                    bi("unidade") = bi.ItemToString("unidade")
                                End If
                                If args.ColumnId = "u_refalt" Then
                                    bi("u_refalt") = bi.ItemToString("u_refalt")
                                End If
                            End If
                        End Sub

        Dim grid As MainformKoGrid = CType(mpage.ToTypeClass(Of Mainform).Conteudo.FindControl("bigrid"), MainformKoGrid)
        AddHandler grid.CreateColumns,
            Sub(bigrid)
                'Código para alterar a grid
				With bigrid.AddGridColumn("u_fmargem", "Margem Final")
					.ReadOnly = True
                    .Order = 6
                    .AddMainformColumnValueChangedFunction(actValues)
                End With

                With bigrid.AddGridColumn("u_margem", "Margem")
                    .Order = 4
                    .AddMainformColumnValueChangedFunction(actValues)
                End With
                With bigrid.AddGridColumn("epcusto", "Pr. Custo")
                    .Order = 3
                    .AddMainformColumnValueChangedFunction(actValues)
                End With
                With bigrid.AddGridColumn("u_obs", "Observações", "", DataTypeEnum.Memo)
                    .ShowOn = ShowOnEnum.InDetails
                    .Order = 2
                    .AddMainformColumnValueChangedFunction(actValues)
                End With
                With bigrid.Columns("edebito")
                    .Caption = "Pr. Unitário"
                    .AddMainformColumnValueChangedFunction(actValues)
                    .Order = 5
                End With
                With bigrid.AddGridColumn("u_ecstamp", "Stamp da Estrutura")
                    .Visible = False
                End With
                With bigrid.AddGridColumn("u_refalt", "Ref.ª Alternativa")
                    .ShowOn = ShowOnEnum.InDetails
                    .Order = 1
                    .AddMainformColumnValueChangedFunction(actValues)
                End With
                With bigrid.AddGridColumn("unidade", "Unidade")
                    .Order = 2
                    .AddMainformColumnValueChangedFunction(actValues)
                End With

                With bigrid.Columns("desconto")
                    .AddMainformColumnValueChangedFunction(actValues)
                End With

				 With bigrid.Columns("desc2")
                    .AddMainformColumnValueChangedFunction(actValues)
                End With
 
            End Sub
#End Region

