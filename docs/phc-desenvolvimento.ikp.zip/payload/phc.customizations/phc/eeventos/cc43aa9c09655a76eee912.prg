* EEVENTO (Web)
* stamp: cc43aa9c09655a76eee912
* resumo: (boform - AposPreRender)
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== CONDICAO (condicao) ===
Dim mform = CType(mpage, Mainform)
Dim ndos As Integer = mform.PropTipoDocumento
If ndos <= 0 Then
  Dim bostamp As String = xcfox.U_sDecrypt(mpage.Request.Params("stamp"))
  If Not String.IsNullOrWhiteSpace(bostamp) Then
    Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
    If con.State <> ConnectionState.Open Then
      con.Open()
    End If
    Using com As SqlClient.SqlCommand = con.CreateCommand()
    com.CommandText = "SELECT ndos from bo where bostamp = @bostamp"
    com.Parameters.AddWithValue("@bostamp", bostamp)

    Using reader = com.ExecuteReader
    If reader.Read Then
      ndos = reader(0)
    End If
  End Using
If ndos <= 0 Then
  com.CommandText = "SELECT ndos from ebo where ebostamp =@bostamp"
  Using reader = com.ExecuteReader
  If reader.Read Then
    ndos = reader(0)
  End If
End Using
End If
End Using
con.Close()
End Using
End If
End If

If String.IsNullOrWhiteSpace(ndos) Then
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
End If
If String.IsNullOrWhiteSpace(ndos) AndAlso mform.PropMainFormDataSet IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables IsNot Nothing AndAlso mform.PropMainFormDataSet.Tables.Count > 0 AndAlso mform.PropMainFormDataSet.Tables(0).Rows?.Count > 0 Then
ndos = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ndos")
End If

If ndos = 3 Then
Return True
Else
Return False
End If

*=== EXPRESSAO (expressao) ===
Dim bostamp As String = ""  
Dim mform = CType(mpage, Mainform)

if not  mform.PropMainFormDataSet is nothing andalso mform.PropMainFormDataSet.Tables?.Count>0 andalso  mform.PropMainFormDataSet.Tables(0).Rows?.Count>0  then 

  If mform.PropMainFormDataSet.Tables(0).Columns.Contains("bostamp") Then
    bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("bostamp")
  Else
    bostamp = mform.PropMainFormDataSet.Tables(0).Rows(0).Item("ebostamp")
  End If
  Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
  If con.State <> ConnectionState.Open Then
    con.Open()
  End If

  Using com As SqlClient.SqlCommand = con.CreateCommand()
  'Atualizar u_ecstamp que sejam igual ao da copia
  com.CommandText = "UPDATE b1
  SET b1.u_ecstamp = left(replace(newid(),'-',''),25)
        FROM bi b1
        JOIN bi b2 on b1.obistamp = b2.bistamp and b1.u_ecstamp =b2.u_ecstamp
        where b1.bostamp = @bostamp"

        com.Parameters.Clear()
        com.Parameters.AddWithValue("@bostamp", bostamp)
        com.ExecuteNonQuery()
        'Copiar a assesorias
        com.CommandText = "INSERT INTO u_assessorias(
        bistamp
        ,bostamp 
        ,totalMaoObraTempo
        ,totalQuilometros
        ,valorMOMinuto
        ,valorQuilometro
        ,perSobreMO
        ,perDiversos
        ,perAdministrativo
        ,totalConstituicaoAssessoria
        ,totalMaoObra
        ,valorTotalQuilometros
        ,custosMaoObra
        ,custosDiversos
        ,custosAdministrativos
        ,totalCustosIndiretos
        ,totalCustosSemMargem
        ,margem
        ,totalCustosComMargem
        ,desconto
        ,totalCustoComMargemComercial)
      SELECT 
        bid.u_ecstamp
        ,uao.bostamp 
        ,uao.totalMaoObraTempo
        ,uao.totalQuilometros
        ,uao.valorMOMinuto
        ,uao.valorQuilometro
        ,uao.perSobreMO
        ,uao.perDiversos
        ,uao.perAdministrativo
        ,uao.totalConstituicaoAssessoria
        ,uao.totalMaoObra
        ,uao.valorTotalQuilometros
        ,uao.custosMaoObra
        ,uao.custosDiversos
        ,uao.custosAdministrativos
        ,uao.totalCustosIndiretos
        ,uao.totalCustosSemMargem
        ,uao.margem
        ,uao.totalCustosComMargem
        ,uao.desconto
        ,uao.totalCustoComMargemComercial
        FROM  u_assessorias uao
        JOIN  bi bio on uao.bistamp = bio.u_ecstamp
        JOIN  bi bid on bio.bistamp = bid.obistamp
        WHERE bid.bostamp = @bostamp"

        com.ExecuteNonQuery()

        com.CommandText = "INSERT INTO u_assessoriaLinhas(bistamp,descricao,quantidade,valor, total)
        SELECT 
          bid.u_ecstamp,
          ualo.descricao,
          ualo.quantidade,
          ualo.valor, 
          ualo.total 
          FROM u_assessoriaLinhas ualo 
          JOIN  bi bio on ualo.bistamp = bio.u_ecstamp
          JOIN  bi bid on bio.bistamp = bid.obistamp
          WHERE bid.bostamp = @bostamp"
          com.ExecuteNonQuery()

        End Using
      con.Close()
    End Using
end if

