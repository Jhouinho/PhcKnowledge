* EEVENTO (Web)
* stamp: cd0-4e8e-9013-2cb3f4777e
* resumo: Cálculo de Totais do Documento
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim mform As WebControlLib.Mainform = mpage

If mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Adicionando Or mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Alterando Then

  Dim uTMargin As Decimal = 0 
  Dim uTCost As Decimal = 0 

  If mform.PropMainFormDataSet.Tables("ebi").HaveRows Then

    Dim rowsCount As Integer = 0




    For Each b As System.Data.DataRow In mform.PropMainFormDataSet.Tables("ebi").Rows
      If b.RowState <> DataRowState.Deleted  Then
        uTMargin= uTMargin + b.Item("u_margem")
        uTCost=uTCost + (b.Item("qtt") * b.Item("epcusto"))

        If b.Item("qtt") > 0 Then
          rowsCount = rowsCount + 1
        End If
      End if

    Next

    uTMargin = (  uTMargin/rowsCount)

    Dim fTCost as string = mform.PropMainFormDataSet.Tables(0).Rows(0)("u_custotal")
    Dim fTMargin as string = mform.PropMainFormDataSet.Tables(0).Rows(0)("u_mrgtotal")

    mform.PropMainFormDataSet.Tables(0).Rows(0)("u_mrgtotal") = uTMargin.tostring()
    mform.PropMainFormDataSet.Tables(0).Rows(0)("u_custotal") = uTCost.tostring()

    CType(mpage.Master.findcontrol("conteudo").findcontrol("u_mrgtotal"), NossoCampoTextBox).value = uTMargin 
    CType(mpage.Master.findcontrol("conteudo").findcontrol("u_custotal"), NossoCampoTextBox).value = uTCost

  End If

End If

