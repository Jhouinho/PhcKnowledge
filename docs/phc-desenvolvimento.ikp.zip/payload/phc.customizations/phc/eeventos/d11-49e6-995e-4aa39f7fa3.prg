* EEVENTO (Web)
* stamp: d11-49e6-995e-4aa39f7fa3
* resumo: (szadrsform - AoIntroduzir) Preenchimento Automático de Campos da Obra
* ecran: szadrsform
* qevento: AoIntroduzir
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
Dim frefstamp As String = ""
Dim frefstampValue as Object = HttpContext.Current.Request.QueryString("frefstamp")

If frefstampValue IsNot Nothing Then
  frefstamp = frefstampValue.ToString.Trim

  Dim type As String = ""
  Dim typeValue as Object = HttpContext.Current.Request.QueryString("tipo")

  Dim sql As String  = "SELECT fref, nmfref, u_nocli, u_clinome FROM fref WHERE frefstamp='" & xcfox.U_sDecrypt(frefstamp) & "'"
  Dim dt As DataTable = cdata.getdatatable(sql)

  ' ATUALIZA VALORES
  Dim mform As WebControlLib.Mainform = mpage
  mform.PropMainFormDataSet.Tables(0).Rows(0)("szadrsdesc") = Trim(dt.Rows(0)("fref")) & " | " & Trim(dt.Rows(0)("nmfref"))
  mform.PropMainFormDataSet.Tables(0).Rows(0)("u_fref") = dt.Rows(0)("fref")
  mform.PropMainFormDataSet.Tables(0).Rows(0)("u_desc") = dt.Rows(0)("nmfref")
  mform.PropMainFormDataSet.Tables(0).Rows(0)("origem") = "CL"
  mform.PropMainFormDataSet.Tables(0).Rows(0)("u_tipo") = "Descarga"
  
  If typeValue IsNot Nothing Then
    mform.PropMainFormDataSet.Tables(0).Rows(0)("no") = "1"
    mform.PropMainFormDataSet.Tables(0).Rows(0)("nome") = cdata.getumvalorstring("SELECT nome FROM cl WHERE no=1")

  Else
    mform.PropMainFormDataSet.Tables(0).Rows(0)("no") = dt.Rows(0)("u_nocli")
    mform.PropMainFormDataSet.Tables(0).Rows(0)("nome") = dt.Rows(0)("u_clinome")
  End If
End If

