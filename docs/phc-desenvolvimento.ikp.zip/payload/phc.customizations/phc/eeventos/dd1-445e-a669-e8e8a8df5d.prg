* EEVENTO (Web)
* stamp: dd1-445e-a669-e8e8a8df5d
* resumo: (boform - AposPreRender) Preenchimento ComboBox com Obras do Cliente
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (condicao) ===
Dim mform As MainForm = mpage
If mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Adicionando OR mform.PropEstadoDoMainForm=WebControlLib.Normalform.EstadoDoMainForm.Alterando Then
    Return True
Else
    Return False
End If

*=== EXPRESSAO (expressao) ===
Dim sValues as String
Dim cbxToFill as Object = mpage.master.FindControl("conteudo").FindControl("fref").FindControl("Combofref")
Dim frefValue as Object = ctype(mpage.master.FindControl("conteudo").FindControl("fref"), Fref).value
Dim cbxToFillValue as Object = ctype(mpage.master.FindControl("conteudo").FindControl("fref").FindControl("Combofref"), Nossocampotabprg).Value
Dim cbxToFillValueIndex as Object = ctype(mpage.master.FindControl("conteudo").FindControl("fref").FindControl("Combofref"), Nossocampotabprg).ValueIndex
Dim ndos As String = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
Dim sql As String

Dim x as integer = 0

Dim noValue as String = Ctype(mpage.master.FindControl("conteudo").FindControl("no"), nossocampotextbox).value

cbxToFill.clearItems()

If ndos = "11" Then
	sql = "SELECT fref, nmfref FROM fref"
Else
  sql = "SELECT fref, nmfref FROM fref WHERE u_nocli='" & noValue.tostring() & "'"
End If

Dim dt As DataTable = cdata.getdatatable(sql)
      
If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
	cbxToFill.AdicionaItems("","")
    For Each drDealer in dt.Rows
        sValues = drDealer("fref") & " : " & drDealer("nmfref")
        cbxToFill.AdicionaItems(sValues,drDealer("fref"))
    
    If  drDealer("fref") = frefValue.tostring Then
      cbxToFill.ValueValor = frefValue.tostring
    End if
    Next
  
End If

