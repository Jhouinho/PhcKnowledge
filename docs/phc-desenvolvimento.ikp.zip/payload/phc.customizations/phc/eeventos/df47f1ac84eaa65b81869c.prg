* EEVENTO (Web)
* stamp: df47f1ac84eaa65b81869c
* resumo: (boform - AposPreRender) Esconder Campos Latitude/Longitude
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Inactivo
* inactivo: True

*=== EXPRESSAO (expressao) ===
Dim mform As MainForm = CType(mpage, MainForm)

Dim obj As Object
obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSDescargalatitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSDescargalongitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSCargalatitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSCargalongitude")
obj.visible = False

