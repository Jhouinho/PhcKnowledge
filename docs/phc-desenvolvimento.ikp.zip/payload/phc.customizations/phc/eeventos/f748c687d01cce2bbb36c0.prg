* EEVENTO (Web)
* stamp: f748c687d01cce2bbb36c0
* resumo: (boform - AposPreRender) Manipular Visibilidade de Campos
* ecran: boform
* qevento: AposPreRender
* reacao: 2
* pdescricao: False
* estado: Activo
* inactivo: False

*=== EXPRESSAO (expressao) ===
Dim mform As MainForm = CType(mpage, MainForm)
Dim ndos As String
Dim obj As Object
ndos = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()
If ndos = "16" Then
  obj = mpage.Master.findcontrol("conteudo").findcontrol("fref")
  obj.visible = False

  obj = mpage.Master.findcontrol("conteudo").findcontrol("obs")
  obj.visible = False

Else If ndos = "16" Or ndos = "11"
  obj = mpage.Master.findcontrol("conteudo").findcontrol("area")
  obj.visible = False
Else
  obj = mpage.Master.findcontrol("conteudo").findcontrol("fref")
  obj.visible = True

  obj = mpage.Master.findcontrol("conteudo").findcontrol("obs")
  obj.visible = True

  obj = mpage.Master.findcontrol("conteudo").findcontrol("area")
  obj.visible = True
End If

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSDescargalatitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSDescargalongitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSCargalatitude")
obj.visible = False

obj = mpage.Master.findcontrol("conteudo").findcontrol("GPSCargalongitude")
obj.visible = False

