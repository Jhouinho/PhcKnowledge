' ESCR (Web — Scripts Framework CS Web)
' stamp: 40492da1bcc2b268f63ef2
' codigo: ScrOrcBase
' resumo: ScrOrcBase
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (BASE) #################################
'########### Prepara dados para a Tabela Base dos Orçamentos (OrcBaseTable)
Dim model = CType(ObjPara, PhcDynamicObject)
Dim cliente As String = model("cliente")
Dim clienteNo As String = model("clienteNo")
Dim vendedor As String = model("vendedor")
Dim estado As String = model("estado")
Dim titulo As String = model("titulo")
Dim anoOrc As String = model("anoOrc")
Dim obra As String = model("obra")

If String.IsNullOrEmpty(clienteNo) Then
    clienteNo = "0"
end if

Dim estadoSql As String = ""
If String.IsNullOrWhiteSpace(estado) Then
    estadoSql = ""
Else
    estadoSql = $" and bo.u_status like '{estado}' "
End If

Dim lvQueryOrc as string = ""
lvQueryOrc = $"	SELECT 
                    bo.bostamp as BoStamp,
                    bo.obrano as ObraNo,
                    CONVERT(varchar(5),bo.boano) as BoAno,
                    CONVERT(varchar, bo.dataobra, 102) as DataObra, 
                    isnull(bo.obs,'') as Titulo,
                    bo.nome as Nome, 
                    ISNULL(fref.fref,'') + ' '+ ISNULL(fref.nmfref,'') as BoFref,
                    format(bo.ecusto,'N','de-DE') as Custo,
                    format((bo.etotaldeb-bo.ecusto),'N','de-DE') as MargemValor,
                    format(((bo.etotaldeb-bo.ecusto) / nullif(bo.ecusto,0)) * 100,'N','de-DE') as MargemPerc,
                    format(bo.etotaldeb,'N','de-DE') as VendaValor,
                    format(isnull((
                        select sum(isnull(ft.ettiliq, 0))
                        from ft(nolock)
                        where ft.anulado = 0
                          and ft.tipodoc in (1, 3)
                          and rtrim(ltrim(isnull(ft.fref, ''))) <> ''
                          and ft.fref = bo.fref
                    ), 0), 'N', 'de-DE') as ValorFaturado,
                    format(
                        case
                            when bo.etotaldeb - isnull((
                                select sum(isnull(ft.ettiliq, 0))
                                from ft(nolock)
                                where ft.anulado = 0
                                  and ft.tipodoc in (1, 3)
                                  and rtrim(ltrim(isnull(ft.fref, ''))) <> ''
                                  and ft.fref = bo.fref
                            ), 0) < 0 then 0
                            else bo.etotaldeb - isnull((
                                select sum(isnull(ft.ettiliq, 0))
                                from ft(nolock)
                                where ft.anulado = 0
                                  and ft.tipodoc in (1, 3)
                                  and rtrim(ltrim(isnull(ft.fref, ''))) <> ''
                                  and ft.fref = bo.fref
                            ), 0)
                        end, 'N', 'de-DE') as PorFaturar,
                    isnull(bo.u_status,'') as Estado,
                    bo.vendnm as VendNm
                FROM bo(nolock) left join fref(nolock) on fref.fref = bo.fref
                WHERE bo.ndos=3 and boano like '%{anoOrc}%' 
                      and bo.vendnm like '%{vendedor}%' {estadoSql} and bo.obs like '%{titulo}%' 
                      and bo.fref like '%{obra}%' and bo.nome like '%{cliente}%' 
                      and (bo.no={clienteNo} or {clienteNo}=0 )
                ORDER BY bo.boano desc, bo.obrano desc "

Dim dtOrc as Datatable = cdata.getdatatable(lvQueryOrc)
Dim dvOrc As DataView = New DataView(dtOrc)
dtOrc = dvOrc.ToTable

Dim listaOrc As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtOrc.Rows
    listaOrc.Add(New Dictionary(Of String, Object)() From {
        {"BoStamp", row("BoStamp")},
        {"ObraNo", row("ObraNo")},
        {"BoAno", row("BoAno")},
        {"DataObra", row("DataObra")},
        {"Titulo", row("Titulo")},
        {"Nome", row("Nome")},
        {"BoFref", row("BoFref")},
        {"Custo", row("Custo")},
        {"MargemValor", row("MargemValor")},
        {"MargemPerc", row("MargemPerc")},
        {"VendaValor", row("VendaValor")},
        {"ValorFaturado", row("ValorFaturado")},
        {"PorFaturar", row("PorFaturar")},
        {"Estado", row("Estado")},
        {"VendNm", row("VendNm")}
    })
Next

Dim result As New Dictionary(Of String, Object)()
result.Add("ListaORC", listaOrc)

Dim meuJSONResponse as String
meuJSONResponse = Newtonsoft.Json.JsonConvert.SerializeObject(result)
Return meuJSONResponse

'=== CMENHTML (cmenhtml) ===
0

