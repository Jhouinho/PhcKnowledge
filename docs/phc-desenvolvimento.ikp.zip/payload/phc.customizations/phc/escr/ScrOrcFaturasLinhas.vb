' ESCR (Web — Scripts Framework CS Web)
' stamp: 5044c1ab7651e4466b4a21
' codigo: ScrOrcFaturasLinhas
' resumo: ScrOrcFaturasLinhas
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (FATURAS LINHAS) #################################
'########### Linhas (produtos/serviços) de um documento de faturação
Dim model = CType(ObjPara, PhcDynamicObject)
Dim ftstamp As String = If(model("ftstamp"), "").ToString().Trim()
Dim bostamp As String = If(model("bostamp"), "").ToString().Trim()

If String.IsNullOrWhiteSpace(ftstamp) Then
    Dim vazio As New Dictionary(Of String, Object)()
    vazio.Add("ListaLINHAS", New List(Of Dictionary(Of String, Object))())
    vazio.Add("Erro", "Documento de faturação não indicado.")
    Return Newtonsoft.Json.JsonConvert.SerializeObject(vazio)
End If

Dim lvQuery As String = ""
lvQuery = $"SELECT
                trim(isnull(ft.nmdoc, '')) as NomeDoc,
                CONVERT(varchar(10), ft.fdata, 102) as DataDoc,
                ft.fno as NumeroFatura,
                trim(isnull(fi.ref, '')) as Referencia,
                trim(isnull(fi.design, '')) as Designacao,
                isnull(cast(bo_orc.obrano as varchar(20)), '') as NumOrcamento,
                trim(isnull(bo_orc.bostamp, '')) as BoStampOrc,
                format(isnull(fi.qtt, 0), 'N', 'de-DE') as Quantidade,
                format(isnull(fi.epv, 0), 'N', 'de-DE') as PrecoVenda,
                format(isnull(fi.etiliquido, 0), 'N', 'de-DE') as Total
            FROM fi(nolock)
            INNER JOIN ft(nolock) ON ft.ftstamp = fi.ftstamp
            LEFT JOIN bi(nolock) ON bi.bistamp = fi.bistamp
            LEFT JOIN bo(nolock) bo_orc ON bo_orc.bostamp = bi.bostamp AND bo_orc.ndos = 3
            WHERE ft.ftstamp = '{ftstamp}'
              AND ft.anulado = 0
              AND isnull(fi.composto, 0) = 0
              AND isnull(fi.qtt, 0) <> 0
            ORDER BY fi.lordem, fi.ref"

Dim dt As DataTable = cdata.getdatatable(lvQuery)
Dim lista As New List(Of Dictionary(Of String, Object))()

For Each row As DataRow In dt.Rows
    lista.Add(New Dictionary(Of String, Object)() From {
        {"NomeDoc", row("NomeDoc")},
        {"DataDoc", row("DataDoc")},
        {"NumeroFatura", row("NumeroFatura")},
        {"Referencia", row("Referencia")},
        {"Designacao", row("Designacao")},
        {"NumOrcamento", row("NumOrcamento")},
        {"BoStampOrc", row("BoStampOrc")},
        {"Quantidade", row("Quantidade")},
        {"PrecoVenda", row("PrecoVenda")},
        {"Total", row("Total")}
    })
Next

Dim result As New Dictionary(Of String, Object)()
result.Add("ListaLINHAS", lista)
result.Add("FtStamp", ftstamp)
result.Add("BoStampContexto", bostamp)

Return Newtonsoft.Json.JsonConvert.SerializeObject(result)

'=== CMENHTML (cmenhtml) ===
0

