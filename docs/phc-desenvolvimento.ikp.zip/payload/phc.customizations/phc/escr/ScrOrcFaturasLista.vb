' ESCR (Web — Scripts Framework CS Web)
' stamp: fd4d2080b12d86f042dbd9
' codigo: ScrOrcFaturasLista
' resumo: ScrOrcFaturasLista
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (FATURAS LISTA) #################################
'########### Lista documentos de faturação associados à obra do orçamento (ft.fref = bo.fref)
Dim model = CType(ObjPara, PhcDynamicObject)
Dim bostamp As String = If(model("bostamp"), "").ToString().Trim()

If String.IsNullOrWhiteSpace(bostamp) Then
    Dim vazio As New Dictionary(Of String, Object)()
    vazio.Add("ListaFATURAS", New List(Of Dictionary(Of String, Object))())
    vazio.Add("Erro", "Orçamento não indicado.")
    Return Newtonsoft.Json.JsonConvert.SerializeObject(vazio)
End If

Dim lvQuery As String = ""
lvQuery = $"SELECT
                trim(ft.ftstamp) as FtStamp,
                trim(isnull(ft.nmdoc, '')) as NomeDoc,
                CONVERT(varchar(10), ft.fdata, 102) as DataDoc,
                ft.fno as Numero,
                format(isnull(ft.ettiliq, 0), 'N', 'de-DE') as Total
            FROM ft(nolock)
            INNER JOIN bo(nolock) ON bo.bostamp = '{bostamp}' AND bo.ndos = 3
            WHERE ft.anulado = 0
              AND ft.tipodoc IN (1, 3)
              AND rtrim(ltrim(isnull(ft.fref, ''))) <> ''
              AND ft.fref = bo.fref
            ORDER BY ft.fdata DESC, ft.fno DESC"

Dim dt As DataTable = cdata.getdatatable(lvQuery)
Dim lista As New List(Of Dictionary(Of String, Object))()

For Each row As DataRow In dt.Rows
    lista.Add(New Dictionary(Of String, Object)() From {
        {"FtStamp", row("FtStamp")},
        {"NomeDoc", row("NomeDoc")},
        {"DataDoc", row("DataDoc")},
        {"Numero", row("Numero")},
        {"Total", row("Total")}
    })
Next

Dim cab As New Dictionary(Of String, Object)()
Dim dtCab As DataTable = cdata.getdatatable($"SELECT top 1 bo.obrano as ObraNo, bo.boano as BoAno, trim(isnull(bo.obs,'')) as Titulo FROM bo(nolock) WHERE bo.bostamp='{bostamp}'")
If dtCab.Rows.Count > 0 Then
    Dim r = dtCab.Rows(0)
    cab.Add("ObraNo", r("ObraNo"))
    cab.Add("BoAno", r("BoAno"))
    cab.Add("Titulo", r("Titulo"))
End If

Dim result As New Dictionary(Of String, Object)()
result.Add("CabORC", cab)
result.Add("ListaFATURAS", lista)

Return Newtonsoft.Json.JsonConvert.SerializeObject(result)

'=== CMENHTML (cmenhtml) ===
0

