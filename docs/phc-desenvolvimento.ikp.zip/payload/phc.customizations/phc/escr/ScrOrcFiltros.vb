' ESCR (Web — Scripts Framework CS Web)
' stamp: e74a718ee8346e289b7780
' codigo: ScrOrcFiltros
' resumo: ScrOrcFiltros
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (FILTROS) ################################

'########### Prepara dados para Filtrar por Nome de Cliente
Dim lvQueryClientes as string = ""
lvQueryClientes = $"select '' as NomeCliente
                    union
                    select distinct trim(cl.nome) as NomeCliente 
                    from cl(nolock)
                    order by NomeCliente "
Dim dtClientes as Datatable = cdata.getdatatable(lvQueryClientes)
Dim dvClientes As DataView = New DataView(dtClientes)
dtClientes = dvClientes.ToTable
Dim listaClientes As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtClientes.Rows
    listaClientes.Add(New Dictionary(Of String, Object)() From {
        {"NomeCliente", row("NomeCliente")}
    }) 
Next

'########### Prepara dados para Filtrar por Nome de Vendedor
Dim lvQueryVend as string = ""
lvQueryVend = $"select 0 as Vendedor, '' as VendNm
                union all
                select distinct cm3.cm as Vendedor, cm3.cmdesc as VendNm from cm3(nolock) where inactivo=0 
                order by VendNm"
Dim dtVend as Datatable = cdata.getdatatable(lvQueryVend)
Dim dvVend As DataView = New DataView(dtVend)
dtVend = dvVend.ToTable
Dim listaVend As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtVend.Rows
    listaVend.Add(New Dictionary(Of String, Object)() From {
        {"Vendedor", row("Vendedor")},
        {"VendNm", row("VendNm")}
    })
Next

'########### Prepara dados para Filtrar por Estado do Orçamento
Dim lvQueryEstado as string = ""
lvQueryEstado = $"select '' as Estado
                union
                select distinct trim(bo.u_status) as Estado 
                from bo(nolock)
                where ndos=3
                order by Estado "
Dim dtEstado as Datatable = cdata.getdatatable(lvQueryEstado)
Dim dvEstado As DataView = New DataView(dtEstado)
dtEstado = dvEstado.ToTable
Dim listaEstado As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtEstado.Rows
    listaEstado.Add(New Dictionary(Of String, Object)() From {
        {"Estado", row("Estado")}
    })
Next

'########### Prepara dados para Filtrar por Titulo do Orçamento
Dim lvQueryTitulo as string = ""
lvQueryTitulo = $"select '' as Titulo
                union
                select distinct trim(bo.obs) as Titulo 
                from bo(nolock)
                where ndos=3
                order by Titulo "
Dim dtTitulo as Datatable = cdata.getdatatable(lvQueryTitulo)
Dim dvTitulo As DataView = New DataView(dtTitulo)
dtTitulo = dvTitulo.ToTable
Dim listaTitulo As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtTitulo.Rows
    listaTitulo.Add(New Dictionary(Of String, Object)() From {
        {"Titulo", row("Titulo")}
    })
Next

'########### Prepara dados para Filtrar por OBRA do Orçamento
Dim lvQueryObra as string = ""
lvQueryObra = $"select '' as Obra
                union
                select distinct trim(bo.fref) as Obra 
                from bo(nolock)
                where ndos=3
                order by Obra "
Dim dtObra as Datatable = cdata.getdatatable(lvQueryObra)
Dim dvObra As DataView = New DataView(dtObra)
dtObra = dvObra.ToTable
Dim listaObra As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtObra.Rows
    listaObra.Add(New Dictionary(Of String, Object)() From {
        {"Obra", row("Obra")}
    })
Next

'########### Obtém o número do vendedor logado (se existir)
Dim vendedorLogado As Integer = 0
Try
    vendedorLogado = xcuser.uservendedor()
Catch
    ' Se não conseguir obter, mantém 0 (nenhum vendedor logado)
    vendedorLogado = 0
End Try

'########### Agrupa os dados e envia a Resposta
Dim result As New Dictionary(Of String, Object)()
result.Add("ListaCLIENTES", listaClientes)
result.Add("ListaVEND", listaVend)
result.Add("ListaESTADO", listaEstado)
result.Add("ListaTITULO", listaTitulo)
result.Add("ListaOBRA", listaObra)
result.Add("VendedorLogado", vendedorLogado) ' Número do vendedor logado (0 se não houver)

Dim meuJSONResponse as String
meuJSONResponse = Newtonsoft.Json.JsonConvert.SerializeObject(result)
Return meuJSONResponse

'=== CMENHTML (cmenhtml) ===
0

