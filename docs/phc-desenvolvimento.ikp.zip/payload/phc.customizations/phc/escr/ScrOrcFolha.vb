' ESCR (Web — Scripts Framework CS Web)
' stamp: 864803bfc300b5dd8f2998
' codigo: ScrOrcFolha
' resumo: ScrOrcFolha
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (FOLHA) #################################
'########### Prepara dados para a Tabela FOLHA dos Orçamentos (OrcFolhaTable)

Dim model = CType(ObjPara, PhcDynamicObject)
Dim bostamp As String = model("bostamp")
Dim lvQueryFolha as string = ""
lvQueryFolha = $"select 
                    trim(bo.bostamp) as BoStamp,
                    bo.obrano as ObraNo,
                    CONVERT(varchar(10), bo.dataobra, 120) as DataObra, 
                    isnull(bo.obs,'') as Titulo,
                    bo.fref as BoFref,
                    bo.no as No,
                    bo.estab as Estab,
                    bo.nome as Nome,
                    bo.vendedor as Vendedor,
                    bo.vendnm as VendNm,
                    isnull(bo.u_status,'') as Estado,
                    bo.trab2 as AdjudicacaoNo,
                    CONVERT(varchar(10), bo.u_dtadjud, 120) as DataAdjudicacao,
                    bo.moeda as Moeda,
                    bo.cobranca as ModoPagamento,
                    bo.tpdesc as CondPagDescricao,
                    bo.tpstamp as CondPagStamp,
                    CONVERT(varchar(10), bo.datafinal, 120) as DataValidade,
                    CONVERT(varchar(10), bo3.TAXPOINTDT, 120) as DataEntrega,
                    bo.tabela2 as AoCuidado,
                    bo2.carga as MoradaCarga,
                    bo2.descar as MoradaDescarga,
                    bo.trab1 as PagamentoDescricao,

                    trim(bi.bistamp) as BiStamp,
                    isnull(bi.u_GrupoSub,'') as GrupoSub,
                    bi.ref as Ref,
                    bi.design as Design,
                    format(bi.qtt,'N','de-DE') as Qtt,
                    bi.unidade as Unidade,

                    format((select isnull(sum(totalCusto),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp and Hca.tipo='Material'),'N','de-DE') as CMaterial,
                    format((select isnull(sum(totalCusto),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp and Hca.tipo='Mão-Obra'),'N','de-DE') as CMaoObra,
                    format((select isnull(sum(totalCusto),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp and Hca.tipo='Deslocação'),'N','de-DE') as CDeslocacoes,
                    format((select isnull(sum(totalCusto),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp and Hca.tipo='Diversos'),'N','de-DE') as CDiversos,
                    format((select isnull(sum(custoGeralMaterial),0)+isnull(sum(custoGeralMO),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp),'N','de-DE') as CGastosGerais,
                    format((select isnull(sum(custoAdmin),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp),'N','de-DE') as CAdministrativos,
                    format((select isnull(sum(custoTotal),0) from u_HcaAssessorias(nolock) Hca where Hca.bostamp=bo.bostamp and Hca.bistamp=bi.bistamp),'N','de-DE') as CTotal,

                    format(bi.u_marpret,'N','de-DE') as MargemPretendidaPerc,
                    format(bi.edebito,'N','de-DE') as PrecoVenda,
                    format(bi.desconto,'N','de-DE') as Desconto,
                    format(bi.ettdeb,'N','de-DE') as PrecoTotal,
                    0 as MargemEfetivaValor,
                    0 as MargemEfetivaPerc,
                    bi.lordem as LOrdem,
                    isnull(bi.u_obs,'') as U_Obs,
                    isnull(bi2.u_reftemp,'') as U_RefTemp

                FROM bo(nolock) inner join bo2(nolock) on bo.bostamp=bo2.bo2stamp
                                inner join bo3(nolock) on bo.bostamp=bo3.bo3stamp
                                inner join bi(nolock) on bo.bostamp=bi.bostamp
                                left join bi2(nolock) on bi.bistamp=bi2.bi2stamp
                WHERE bo.ndos=3 and bo.bostamp='{bostamp}'
                ORDER BY bi.lordem "
Dim dtFolha as Datatable = cdata.getdatatable(lvQueryFolha)
Dim dvFolha As DataView = New DataView(dtFolha)
dtFolha = dvFolha.ToTable
Dim cabFolha As New Dictionary(Of String, Object)()
Dim linFolha As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtFolha.Rows
    If cabFolha.Count = 0 Then
        cabFolha.Add("BoStamp", row("BoStamp"))
        cabFolha.Add("ObraNo", row("ObraNo"))
        cabFolha.Add("DataObra", row("DataObra"))
        cabFolha.Add("Titulo", row("Titulo"))
        cabFolha.Add("BoFref", row("BoFref"))
        cabFolha.Add("No", row("No"))
        cabFolha.Add("Estab", row("Estab"))
        cabFolha.Add("Nome", row("Nome"))
        cabFolha.Add("Vendedor", row("Vendedor"))
        cabFolha.Add("VendNm", row("VendNm"))
        cabFolha.Add("Estado", row("Estado"))
        cabFolha.Add("AdjudicacaoNo", row("AdjudicacaoNo"))
        cabFolha.Add("DataAdjudicacao", row("DataAdjudicacao"))
        cabFolha.Add("Moeda", row("Moeda"))
        cabFolha.Add("ModoPagamento", row("ModoPagamento"))
        cabFolha.Add("CondPagDescricao", row("CondPagDescricao"))
        cabFolha.Add("CondPagStamp", row("CondPagStamp"))
        cabFolha.Add("DataValidade", row("DataValidade"))
        cabFolha.Add("DataEntrega", row("DataEntrega"))
        cabFolha.Add("AoCuidado", row("AoCuidado"))
        cabFolha.Add("MoradaCarga", row("MoradaCarga"))
        cabFolha.Add("MoradaDescarga", row("MoradaDescarga"))
        cabFolha.Add("PagamentoDescricao", row("PagamentoDescricao"))
    End If

    linFolha.Add(New Dictionary(Of String, Object)() From {
        {"BiStamp", row("BiStamp")},
        {"BoStamp", row("BoStamp")},
        {"GrupoSub", row("GrupoSub")},
        {"Ref", row("Ref")},
        {"Design", row("Design")},
        {"Qtt", row("Qtt")},
        {"Unidade", row("Unidade")},
        {"CMaterial", row("CMaterial")},
        {"CMaoObra", row("CMaoObra")},
        {"CDeslocacoes", row("CDeslocacoes")},
        {"CDiversos", row("CDiversos")},
        {"CGastosGerais", row("CGastosGerais")},
        {"CAdministrativos", row("CAdministrativos")},
        {"CTotal", row("CTotal")},
        {"MargemPretendidaPerc", row("MargemPretendidaPerc")},
        {"PrecoVenda", row("PrecoVenda")},
        {"Desconto", row("Desconto")},
        {"PrecoTotal", row("PrecoTotal")},
        {"MargemEfetivaValor", row("MargemEfetivaValor")},
        {"MargemEfetivaPerc", row("MargemEfetivaPerc")},
        {"LOrdem", row("LOrdem")},
        {"U_Obs", row("U_Obs")},
        {"U_RefTemp", row("U_RefTemp")}
    })
Next

'########### Prepara dados para as ASSESSORIAS
Dim lvQueryAssessorias as string = ""
lvQueryAssessorias = $"select 
                        HcaAssessoriasStamp,
                        isnull(tipo,'') as Tipo,
                        isnull(ref,'') as Ref,
                        isnull(design,'') as Design,
                        format(isnull(qtt,0),'N','de-DE') as Qtt,
                        isnull(unidade,'') as Unidade,
                        format(isnull(precoCusto,0),'N','de-DE') as PrecoCusto,
                        format(isnull(totalCusto,0),'N','de-DE') as TotalCusto,
                        format(isnull(custoGeralMaterial,0),'N','de-DE') as CustoGeralMaterial,
                        format(isnull(custoGeralMO,0),'N','de-DE') as CustoGeralMO,
                        format(isnull(custoAdmin,0),'N','de-DE') as CustoAdmin,
                        format(isnull(custoTotal,0),'N','de-DE') as CustoTotal,
                        isnull(coeficienteMT,0) as CoeficienteMT,
                        isnull(coeficienteMO,0) as CoeficienteMO,
                        isnull(coeficienteADM,0) as CoeficienteADM,
                        isnull(coeficienteKM,0) as CoeficienteKM,
                        isnull(LOrdem, 0) as LOrdem,
                        isnull(trim(bistamp),'') as BiStamp,
                        isnull(trim(bostamp),'') as BoStamp,
                        isnull(trim(servicoStamp),'') as ServicoStamp,
                        isnull(u_reftemp,'') as U_RefTemp
                    from u_HcaAssessorias(nolock)
                    where BoStamp='{bostamp}'
                    order by LOrdem "
Dim dtAssessorias as Datatable = cdata.getdatatable(lvQueryAssessorias)
Dim dvAssessorias As DataView = New DataView(dtAssessorias)
dtAssessorias = dvAssessorias.ToTable
Dim listaAssessorias As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtAssessorias.Rows
    listaAssessorias.Add(New Dictionary(Of String, Object)() From {
        {"HcaAssessoriasStamp", row("HcaAssessoriasStamp")},
        {"Tipo", row("Tipo")},
        {"Ref", row("Ref")},
        {"Design", row("Design")},
        {"Qtt", row("Qtt")},
        {"Unidade", row("Unidade")},
        {"PrecoCusto", row("PrecoCusto")},
        {"TotalCusto", row("TotalCusto")},
        {"CustoGeralMaterial", row("CustoGeralMaterial")},
        {"CustoGeralMO", row("CustoGeralMO")},
        {"CustoAdmin", row("CustoAdmin")},
        {"CustoTotal", row("CustoTotal")},
        {"CoeficienteMT", row("CoeficienteMT")},
        {"CoeficienteMO", row("CoeficienteMO")},
        {"CoeficienteADM", row("CoeficienteADM")},
        {"CoeficienteKM", row("CoeficienteKM")},
        {"LOrdem", row("LOrdem")},
        {"BiStamp", row("BiStamp")},
        {"BoStamp", row("BoStamp")},
        {"ServicoStamp", row("ServicoStamp")},
        {"U_RefTemp", row("U_RefTemp")}
    })
Next

'########### Prepara dados para Coeficientes (Assessorias)
Dim lvQueryCoeficientes as string = ""
lvQueryCoeficientes = $"select
                        dbo.FNHCA_PercAprovisionamento(GETDATE(),'MT') as CoeficienteMT,
                        dbo.FNHCA_PercAprovisionamento(GETDATE(),'MO') as CoeficienteMO,
                        dbo.FNHCA_PercAprovisionamento(GETDATE(),'ADM') as CoeficienteADM,
                        (select isnull(nvalor,0) from e2(nolock) where e1cano = 1001 and e1lino = 2 and ano=year(GETDATE())) as CoeficienteKM "
Dim dtCoeficientes as Datatable = cdata.getdatatable(lvQueryCoeficientes)
Dim dvCoeficientes As DataView = New DataView(dtCoeficientes)
dtCoeficientes = dvCoeficientes.ToTable
Dim listaCoeficientes As New Dictionary(Of String, Object)()
For Each row As DataRow In dtCoeficientes.Rows
    listaCoeficientes.Add("CoeficienteMT", row("CoeficienteMT"))
    listaCoeficientes.Add("CoeficienteMO", row("CoeficienteMO"))
    listaCoeficientes.Add("CoeficienteADM", row("CoeficienteADM"))
    listaCoeficientes.Add("CoeficienteKM", row("CoeficienteKM"))
Next

'########### Prepara dados para a comboBox de Cliente
Dim lvQueryClientes as string = ""
lvQueryClientes = $"select 0 as LNo, 0 as LEstab, '' as LNome
                    union
                    select distinct no as LNo, estab as LEstab, trim(cl.nome) as LNome from cl(nolock)
                    order by LNome "
Dim dtClientes as Datatable = cdata.getdatatable(lvQueryClientes)
Dim dvClientes As DataView = New DataView(dtClientes)
dtClientes = dvClientes.ToTable
Dim listaClientes As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtClientes.Rows
    listaClientes.Add(New Dictionary(Of String, Object)() From {
        {"LNo", row("LNo")},
        {"LEstab", row("LEstab")},
        {"LNome", row("LNome")}
    })
Next

'########### Prepara dados para a comboBox de Vendedor
Dim lvQueryVend as string = ""
lvQueryVend = $"select 0 as LVendedor, '' as LVendNm
                union all
                select distinct cm3.cm as LVendedor, cm3.cmdesc as LVendNm from cm3(nolock) where inactivo=0 
                order by LVendNm"
Dim dtVend as Datatable = cdata.getdatatable(lvQueryVend)
Dim dvVend As DataView = New DataView(dtVend)
dtVend = dvVend.ToTable
Dim listaVend As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtVend.Rows
    listaVend.Add(New Dictionary(Of String, Object)() From {
        {"LVendedor", row("LVendedor")},
        {"LVendNm", row("LVendNm")}
    })
Next

'########### Prepara dados para a comboBox de Estado do Orçamento
Dim lvQueryEstado as string = ""
lvQueryEstado = $"select '' as LEstado
                union
                select distinct trim(bo.u_status) as LEstado from bo(nolock) where ndos=3
                order by LEstado "
Dim dtEstado as Datatable = cdata.getdatatable(lvQueryEstado)
Dim dvEstado As DataView = New DataView(dtEstado)
dtEstado = dvEstado.ToTable
Dim listaEstado As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtEstado.Rows
    listaEstado.Add(New Dictionary(Of String, Object)() From {
        {"LEstado", row("LEstado")}
    })
Next

'########### Prepara dados para a comboBox de Condições de Pagamento
Dim lvQueryCondPagamento as string = ""
lvQueryCondPagamento = $"select '' as LTpStamp, '' as LTpDescricao
                        union all
                        select distinct tpstamp as LTpStamp, descricao as LTpDescricao
                        from tp(nolock) where tipo=1 and inativo=0
                        order by LTpDescricao "
Dim dtCondPagamento as Datatable = cdata.getdatatable(lvQueryCondPagamento)
Dim dvCondPagamento As DataView = New DataView(dtCondPagamento)
dtCondPagamento = dvCondPagamento.ToTable
Dim listaCondPagamento As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtCondPagamento.Rows
    listaCondPagamento.Add(New Dictionary(Of String, Object)() From {
        {"LTpStamp", row("LTpStamp")},
        {"LTpDescricao", row("LTpDescricao")}
    })
Next

'########### Prepara dados para a comboBox das Obras (filtrar por cliente quando existir)
Dim clienteNoObras As Object = Nothing
Try
    ' Aceitar "no", "No" ou "clienteNo" (conforme o que a API passar ao script)
    Dim noParam As Object = model("no")
    If noParam Is Nothing Then noParam = model("No")
    If noParam Is Nothing Then noParam = model("clienteNo")
    If noParam IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(noParam.ToString()) Then
        clienteNoObras = noParam.ToString().Trim()
    End If
Catch
    ' parâmetro não existe ou não é acessível
End Try
' Só usar cliente da folha se não veio no pedido (prioridade ao parâmetro do pedido para refetch ao mudar cliente)
If clienteNoObras Is Nothing AndAlso dtFolha.Rows.Count > 0 Then
    clienteNoObras = dtFolha.Rows(0)("No")
End If
Dim clienteNoObrasStr As String = If(clienteNoObras Is Nothing, "", clienteNoObras.ToString().Trim())
Dim clienteNoObrasNum As Integer = 0
Integer.TryParse(clienteNoObrasStr, clienteNoObrasNum)
Dim lvQueryObras as string = ""
If clienteNoObrasNum <> 0 Then
    ' Cliente selecionado: listar obras da tabela bo para este cliente (ndos=3) + obras abertas em fref
    lvQueryObras = $"select '' as LFrefDesign, '' as LFref
                union
                select isnull(trim(fref.fref),'') + ' - '+ isnull(trim(fref.nmfref),'') as LFrefDesign, trim(fref.fref) as LFref
                from fref(nolock) where  fref.u_nocli={clienteNoObrasNum} and (u_status='Aberta' or u_status is null or rtrim(ltrim(isnull(u_status,'')))='')
                union
                select isnull(trim(bo.fref),'') + ' - '+ isnull(trim(fref.nmfref),'') as LFrefDesign, trim(bo.fref) as LFref
                from bo(nolock) left join fref(nolock) on fref.fref = bo.fref
                where bo.ndos=3 and bo.no={clienteNoObrasNum}
                order by LFref "
Else
    ' Sem cliente: listar todas as obras com u_status='Aberta' ou vazio
    lvQueryObras = $"select '' as LFrefDesign, '' as LFref
                union all
                select isnull(trim(fref.fref),'') + ' - '+ isnull(trim(fref.nmfref),'') as LFrefDesign, trim(fref.fref) as LFref
                from fref(nolock) where (u_status='Aberta' or u_status is null or rtrim(ltrim(isnull(u_status,'')))='')
                order by LFref "
End If
Dim dtObras as Datatable = cdata.getdatatable(lvQueryObras)
Dim dvObras As DataView = New DataView(dtObras)
dtObras = dvObras.ToTable
Dim listaObras As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtObras.Rows
    listaObras.Add(New Dictionary(Of String, Object)() From {
        {"LFrefDesign", row("LFrefDesign")},
        {"LFref", row("LFref")}
    })
Next

'########### Prepara dados para os SERVIÇOS GLOBAIS
Dim lvQueryServicos as string = ""
lvQueryServicos = $"select 
                        HcaServicosStamp,
                        isnull(tipo,'') as Tipo,
                        isnull(ref,'') as Ref,
                        isnull(design,'') as Design,
                        format(isnull(qtt,0),'N','de-DE') as Qtt,
                        isnull(unidade,'') as Unidade,
                        format(isnull(precoUnitario,0),'N','de-DE') as PrecoUnitario,
                        format(isnull(valorTotal,0),'N','de-DE') as ValorTotal,
                        isnull(LOrdem, 0) as LOrdem,
                        isnull(trim(bostamp),'') as BoStamp
                    from u_HcaServicosGlobais(nolock)
                    where BoStamp='{bostamp}'
                    order by LOrdem "
Dim dtServicos as Datatable = cdata.getdatatable(lvQueryServicos)
Dim dvServicos As DataView = New DataView(dtServicos)
dtServicos = dvServicos.ToTable
Dim listaServicos As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtServicos.Rows
    listaServicos.Add(New Dictionary(Of String, Object)() From {
        {"HcaServicosStamp", row("HcaServicosStamp")},
        {"Tipo", row("Tipo")},
        {"Ref", row("Ref")},
        {"Design", row("Design")},
        {"Qtt", row("Qtt")},
        {"Unidade", row("Unidade")},
        {"PrecoUnitario", row("PrecoUnitario")},
        {"ValorTotal", row("ValorTotal")},
        {"LOrdem", row("LOrdem")},
        {"BoStamp", row("BoStamp")}
    })
Next

'########### Prepara dados para a tabela Modal de REFERENCIAS 
Dim lvQueryReferencias as string = ""
lvQueryReferencias = $";WITH B16 AS (
                                    SELECT 
                                        b.ref,
                                        COALESCE(
                                            TRY_CONVERT(datetime2(0), CONCAT(b.ousrdata,' ',b.ousrhora), 103),
                                            TRY_CONVERT(datetime2(0), CONCAT(
                                                b.ousrdata,' ',
                                                STUFF(STUFF(RIGHT('000000' + ISNULL(b.ousrhora,''),6),3,0,':'),6,0,':')
                                            ), 103),
                                            TRY_CONVERT(datetime2(0), b.rdata)
                                        ) AS dt_evento,
                                        CAST(ROUND((b.ettdeb * 1.0) / NULLIF(b.qtt, 0), 4) AS decimal(18,4)) AS ultimo_custo
                                    FROM dbo.bi b WITH (NOLOCK)
                                    WHERE b.ndos = 16
                                    ),
                                    ULT AS (
                                    SELECT ref, dt_evento, ultimo_custo,
                                            ROW_NUMBER() OVER (PARTITION BY ref ORDER BY dt_evento DESC) AS rn
                                    FROM B16
                                    )
                                    SELECT 
                                        CONCAT(
                                            TRIM(st.ref), ' | ',
                                            TRIM(st.design), ' | ',
                                            FORMAT(ISNULL(st.epcpond, 0), 'N', 'de-DE'), ' € | ',
                                            ISNULL(FORMAT(u.ultimo_custo, 'N', 'de-DE'), 0.00), ' € | ',
                                            ISNULL(FORMAT(u.dt_evento, 'dd/MM/yyyy'), '')
                                        ) AS LRefDesign,
                                        TRIM(st.ref)        AS LRef,
                                        TRIM(st.design)     AS LDesign,
                                        TRIM(st.unidade)    AS LUnidade,
                                        ISNULL(FORMAT(st.epcpond, 'N', 'de-DE'),0.00) AS LPrecoCusto,
										ISNULL(FORMAT(u.ultimo_custo, 'N', 'de-DE'),0.00) as LPrecoUltimo,
										ISNULL(FORMAT(u.dt_evento, 'dd/MM/yyyy'), '') as lDataUltimoCusto,
                                        TRIM(st.u_tipocomp) AS LTipoComponente
                                    FROM dbo.st st WITH (NOLOCK)
                                    LEFT JOIN ULT u
                                    ON u.ref = st.ref AND u.rn = 1
                                    WHERE st.inactivo = 0
                                    ORDER BY TRIM(st.design);"
Dim dtReferencias as Datatable = cdata.getdatatable(lvQueryReferencias)
Dim dvReferencias As DataView = New DataView(dtReferencias)
dtReferencias = dvReferencias.ToTable
Dim listaReferencias As New List(Of Dictionary(Of String, Object))()
For Each row As DataRow In dtReferencias.Rows
    listaReferencias.Add(New Dictionary(Of String, Object)() From {
        {"LRefDesign", row("LRefDesign")},
        {"LRef", row("LRef")},
        {"LDesign", row("LDesign")},
        {"LUnidade", row("LUnidade")},
        {"LPrecoCusto", row("LPrecoCusto")},
        {"LPrecoUltimo", row("LPrecoUltimo")},
        {"LDataUltimoCusto", row("LDataUltimoCusto")},
        {"LTipoComponente", row("LTipoComponente")}
    })
Next

'########### Agrupa os dados e envia a Resposta
Dim result As New Dictionary(Of String, Object)()
result.Add("CabFOLHA", cabFolha)
result.Add("LinFOLHA", linFolha)
result.Add("ListaASSESSORIAS", listaAssessorias)
result.Add("ListaCOEFICIENTES", listaCoeficientes)
result.Add("ListaCLIENTES", listaClientes)
result.Add("ListaVEND", listaVend)
result.Add("ListaESTADO", listaEstado)
result.Add("ListaREFERENCIAS", listaReferencias)
result.Add("ListaCONDPAGAMENTO", listaCondPagamento)
result.Add("ListaOBRAS", listaObras)
result.Add("ListaSERVICOS", listaServicos)

Dim meuJSONResponse as String
meuJSONResponse = Newtonsoft.Json.JsonConvert.SerializeObject(result)
Return meuJSONResponse

'=== CMENHTML (cmenhtml) ===
0

