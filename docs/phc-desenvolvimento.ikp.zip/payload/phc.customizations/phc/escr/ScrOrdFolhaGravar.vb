' ESCR (Web — Scripts Framework CS Web)
' stamp: 734f4cab7ea0ab9ad3bc4a
' codigo: ScrOrdFolhaGravar
' resumo: ScrOrcFolhaGravar
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
'########### Hca-PT - Script Orçamentos WEB (FOLHA GRAVAR) V002 #################################
'########### Gravar Dossier Orçamento       #################################
Dim model = CType(ObjPara, PhcDynamicObject)
Dim para_cabOrc As String = model("cabOrc")
Dim para_linOrc As String = model("linOrc")
Dim para_linAss As String = model("linAss")
Dim para_linServ As String = If(model("linServ"), "")

Dim out_BoStamp As String = ""
Dim out_ObraNo As String = ""
Dim out_Resultado As String = ""
Dim out_Mensagem As String = ""

'### Modelo cabeçalho (validação mínima)
Dim modeloCabOrc = New With {
    Key .BoStamp = "",
    Key .ObraNo = "",
    Key .DataObra = "",
    Key .Titulo = "",
    Key .BoFref = "",
    Key .No = "",
    Key .Estab = "",
    Key .Nome = "",
    Key .Vendedor = "",
    Key .VendNm = "",
    Key .Estado = "",
    Key .AdjudicacaoNo = "",
    Key .DataAdjudicacao = "",
    Key .Moeda = "",
    Key .ModoPagamento = "",
    Key .CondPagDescricao = "",
    Key .CondPagStamp = "",
    Key .DataValidade = "",
    Key .DataEntrega = "",
    Key .AoCuidado = "",
    Key .MoradaCarga = "",
    Key .MoradaDescarga = "",
    Key .PagamentoDescricao = ""
}

Dim cabOrc = JsonConvert.DeserializeAnonymousType(para_cabOrc, modeloCabOrc)
Dim cabOrcJson As String = JsonConvert.SerializeObject(cabOrc)

'### linOrc / linAss / linServ: passar JSON original ao SP (evita perder U_RefTemp, U_Obs, etc. na re-serialização)
Dim linOrcJson As String = If(String.IsNullOrWhiteSpace(para_linOrc), "[]", para_linOrc.Trim())
Dim linAssJson As String = If(String.IsNullOrWhiteSpace(para_linAss), "[]", para_linAss.Trim())
Dim linServJson As String = If(String.IsNullOrWhiteSpace(para_linServ), "[]", para_linServ.Trim())

Try
    Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
        If con.State <> ConnectionState.Open Then
            con.Open()
        End If

        Using command As SqlClient.SqlCommand = con.CreateCommand()
            command.CommandType = CommandType.StoredProcedure
            command.CommandText = "sp_HcaGravarOrcWeb_PT"
            command.Parameters.AddWithValue("@cabOrc", cabOrcJson)
            command.Parameters.AddWithValue("@linOrc", linOrcJson)
            command.Parameters.AddWithValue("@linAss", linAssJson)
            command.Parameters.AddWithValue("@linServ", linServJson)

            Dim out_BoStampParam As New SqlClient.SqlParameter("@out_BoStamp", SqlDbType.VarChar, 25)
            out_BoStampParam.Direction = System.Data.ParameterDirection.Output
            command.Parameters.Add(out_BoStampParam)

            Dim out_ObraNoParam As New SqlClient.SqlParameter("@out_ObraNo", SqlDbType.VarChar, 10)
            out_ObraNoParam.Direction = System.Data.ParameterDirection.Output
            command.Parameters.Add(out_ObraNoParam)

            Dim out_ResultadoParam As New SqlClient.SqlParameter("@out_Resultado", SqlDbType.VarChar, 10)
            out_ResultadoParam.Direction = System.Data.ParameterDirection.Output
            command.Parameters.Add(out_ResultadoParam)

            Dim out_MensagemParam As New SqlClient.SqlParameter("@out_Mensagem", SqlDbType.VarChar, 500)
            out_MensagemParam.Direction = System.Data.ParameterDirection.Output
            command.Parameters.Add(out_MensagemParam)

            command.ExecuteNonQuery()

            out_BoStamp = If(out_BoStampParam.Value, "").ToString()
            out_ObraNo = If(out_ObraNoParam.Value, "").ToString()
            out_Resultado = If(out_ResultadoParam.Value, "").ToString()
            out_Mensagem = If(out_MensagemParam.Value, "").ToString()
        End Using
        con.Close()
    End Using
Catch ex As Exception
    out_Resultado = "ERRO"
    out_Mensagem = ex.Message
End Try

Dim Resposta As New Dictionary(Of String, Object)()
Resposta.Add("out_BoStamp", out_BoStamp)
Resposta.Add("out_ObraNo", out_ObraNo)
Resposta.Add("out_Resultado", out_Resultado)
Resposta.Add("out_Mensagem", If(String.IsNullOrEmpty(out_Mensagem), "", out_Mensagem))

Return Newtonsoft.Json.JsonConvert.SerializeObject(Resposta)

'=== CMENHTML (cmenhtml) ===
0

