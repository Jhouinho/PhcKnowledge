' ESCR (Web — Scripts Framework CS Web)
' stamp: ca42b8bd60ced496513a14
' codigo: ScriptImprimirRelatorio
' resumo: ScriptImprimirRelatorio
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
' Código para impressão ou download
' CONFIG: wrstamp do relatório BO (dossier) - preencher com o stamp do relatório definido no projeto

'Impressao Atual
Const WRSTAMP_BO As String = "7bd2bdd06f8f54e4c0d7ac"

'Impressao Antiga
'Const WRSTAMP_BO As String = "51463fabbffd65c06eefd4"
   

' Router: se chamado via api/code/run com action=BO_DOWNLOAD_PDF, gera PDF do dossier e devolve JSON
Try
    If ObjPara IsNot Nothing Then
        Dim model = CType(ObjPara, PhcDynamicObject)
        Dim action As Object = model("action")
        Dim p As Object = If(model("parameter") IsNot Nothing, model("parameter"), model("bostamp"))
        Dim boStampParam As String = If(p IsNot Nothing, p.ToString().Trim(), "")
        If "BO_DOWNLOAD_PDF".Equals(If(action, "").ToString()) AndAlso Not String.IsNullOrWhiteSpace(boStampParam) Then
            If String.IsNullOrWhiteSpace(WRSTAMP_BO) Then
                Return Newtonsoft.Json.JsonConvert.SerializeObject(New With {.ok = False, .message = "Relatório BO não configurado (WRSTAMP_BO)."})
            End If
            Dim dtNdos = PhcCommandBuilder.CreateSelect("ndos").From("bo").Where("bostamp=@stamp").AddSqlStampParameter(boStampParam).GetDatatable()
            If dtNdos Is Nothing OrElse dtNdos.Rows.Count = 0 Then
                Return Newtonsoft.Json.JsonConvert.SerializeObject(New With {.ok = False, .message = "Documento não encontrado."})
            End If
            Dim nNdos As Integer = CInt(dtNdos.Rows(0)("ndos"))
            Dim fileId As String = Guid.NewGuid().ToString()
            ' Ajustar boreport para a classe equivalente do projeto se necessário (ex.: BODocumentReport)
            Dim report As New boreport(boStampParam, nNdos)
            report.wrstamp = WRSTAMP_BO
            With report.GetReportResultFromCache
                If .FilesResult.Any Then
                    report.SetObjToSession(fileId)
                    Return Newtonsoft.Json.JsonConvert.SerializeObject(New With {.ok = True, .fileId = fileId})
                Else
                    Return Newtonsoft.Json.JsonConvert.SerializeObject(New With {.ok = False, .message = "Não foi possível gerar o PDF."})
                End If
            End With
        End If
    End If
Catch ex As Exception
    Return Newtonsoft.Json.JsonConvert.SerializeObject(New With {.ok = False, .message = "Ocorreu um erro ao gerar o PDF."})
End Try

'=== CMENHTML (cmenhtml) ===
0

