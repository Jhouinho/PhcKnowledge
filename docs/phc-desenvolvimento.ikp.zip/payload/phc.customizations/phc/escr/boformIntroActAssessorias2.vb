' ESCR (Web — Scripts Framework CS Web)
' stamp: 8443ffa693fd998f8b5253
' codigo: boformIntroActAssessorias2
' resumo: (boform - AposAlterar) Introdução/Actualização de Assessorias
' reacao: 0
' rurl: 
' estado: Activo
' inactivo: False

'=== EXPRESSAO (expressao) ===
Dim model = CType(ObjPara, PhcDynamicObject)
Dim bostamp As String = model("bostamp")
Dim refreshbubblesProgramaConf As New Dynamic.ExpandoObject()
Dim valorMOMinuto As Decimal = 0
Dim valorQuilometro As Decimal = 0
Dim perSobreMO As Decimal = 0
Dim perDiversos As Decimal = 0
Dim perAdministrativo As Decimal = 0
Using con As SqlClient.SqlConnection = cdata.GetNewConnection()
If con.State <> ConnectionState.Open Then
  con.Open()
End If
Using com As SqlClient.SqlCommand = con.CreateCommand()
com.CommandText = "SELECT 
lidesc
,nvalor
FROM e2
JOIN e1ca on e2.e1cano = e1ca.e1cano
WHERE e1ca.cadesc ='Valores de Cálculo de Orçamentos' "
Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
While reader.Read()
  If reader("lidesc").ToString = "Valor Mão de Obra (Minuto)" Then
    valorMOMinuto = Convert.ToDecimal(reader("nvalor"))
  End If
  If reader("lidesc").ToString = "Valor Quilómetro" Then
    valorQuilometro = Convert.ToDecimal(reader("nvalor"))
  End If
  If reader("lidesc").ToString = "% sobre a Mão de Obra" Then
    perSobreMO = Convert.ToDecimal(reader("nvalor"))
  End If
  If reader("lidesc").ToString = "% Diversos" Then
    perDiversos = Convert.ToDecimal(reader("nvalor"))
  End If
  If reader("lidesc").ToString = "% Administrativo" Then
    perAdministrativo = Convert.ToDecimal(reader("nvalor"))
  End If
End While
End Using
refreshbubblesProgramaConf.AddKeyValue("ValorMOMinuto", valorMOMinuto)
refreshbubblesProgramaConf.AddKeyValue("ValorQuilometro", valorQuilometro)
refreshbubblesProgramaConf.AddKeyValue("PerSobreMO", perSobreMO)
refreshbubblesProgramaConf.AddKeyValue("PerDiversos", perDiversos)
refreshbubblesProgramaConf.AddKeyValue("PerAdministrativo", perAdministrativo)

If bostamp <> "" Then
com.CommandText = "SELECT 
u_assessorias.bistamp
,u_assessorias.totalMaoObraTempo
,u_assessorias.totalQuilometros
,u_assessorias.valorMOMinuto
,u_assessorias.valorQuilometro
,u_assessorias.perSobreMO
,u_assessorias.perDiversos
,u_assessorias.perAdministrativo
,u_assessorias.totalConstituicaoAssessoria
,u_assessorias.totalMaoObra
,u_assessorias.valorTotalQuilometros
,u_assessorias.custosMaoObra
,u_assessorias.custosDiversos
,u_assessorias.custosAdministrativos
,u_assessorias.totalCustosIndiretos
,u_assessorias.totalCustosSemMargem
,u_assessorias.margem
,u_assessorias.totalCustosComMargem
,u_assessorias.desconto
,u_assessorias.totalCustoComMargemComercial
FROM u_assessorias
WHERE EXISTS(SELECT 1 
  FROM bi 
  where bi.bostamp = @bostamp
  AND bi.u_ecstamp = u_assessorias.bistamp )"
com.Parameters.Clear()
com.Parameters.AddWithValue("@bostamp", bostamp)

Dim bistamplist As New List(Of String)

refreshbubblesProgramaConf.AddKeyValue("CalculoAssessorias", New Dynamic.ExpandoObject())
Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
While reader.Read
  Dim bistamp As String = CType(reader("bistamp"), String)

  bistamplist.Add(bistamp)

  Dim calculoAssessoria As New Dynamic.ExpandoObject()

  If CType(CType(refreshbubblesProgramaConf, IDictionary(Of String, Object))("CalculoAssessorias"), IDictionary(Of String, Object)).ContainsKey(bistamp) Then
    calculoAssessoria = CType(CType(refreshbubblesProgramaConf, IDictionary(Of String, Object))("CalculoAssessorias"), IDictionary(Of String, Object))(bistamp)
  Else
    CType(CType(refreshbubblesProgramaConf, IDictionary(Of String, Object))("CalculoAssessorias"), IDictionary(Of String, Object)).Add(bistamp, calculoAssessoria)
  End If

  calculoAssessoria.AddKeyValue("Key", bistamp)
  calculoAssessoria.AddKeyValue("TotalMaoObraTempo", CType(reader("totalMaoObraTempo"), Decimal))
  calculoAssessoria.AddKeyValue("TotalQuilometros", CType(reader("totalQuilometros"), Decimal))
  calculoAssessoria.AddKeyValue("ValorMOMinuto", IIf(CType(reader("valorMOMinuto"), Decimal) > 0, CType(reader("valorMOMinuto"), Decimal), valorMOMinuto))
  calculoAssessoria.AddKeyValue("ValorQuilometro", IIf(CType(reader("valorQuilometro"), Decimal) > 0, CType(reader("valorQuilometro"), Decimal), valorQuilometro))
  calculoAssessoria.AddKeyValue("PerSobreMO", IIf(CType(reader("perSobreMO"), Decimal) > 0, CType(reader("perSobreMO"), Decimal), perSobreMO))
  calculoAssessoria.AddKeyValue("PerDiversos", IIf(CType(reader("perDiversos"), Decimal) > 0, CType(reader("perDiversos"), Decimal), perDiversos))
  calculoAssessoria.AddKeyValue("PerAdministrativo", IIf(CType(reader("perAdministrativo"), Decimal) > 0, CType(reader("perAdministrativo"), Decimal), perAdministrativo))
  calculoAssessoria.AddKeyValue("Margem", CType(reader("margem"), Decimal))
  calculoAssessoria.AddKeyValue("TotalCustosComMargem", CType(IIf(reader("totalCustosComMargem") Is Nothing OrElse reader("totalCustosComMargem").Equals(DBNull.Value), 0, reader("totalCustosComMargem")), Decimal))
  calculoAssessoria.AddKeyValue("ConstituicaoAssessorias", New List(Of Dynamic.ExpandoObject))
End While
End Using
For Each stamp In bistamplist
com.CommandText = "SELECT 
bistamp
,descricao
,quantidade
,valor
,total
FROM u_assessoriaLinhas WHERE  bistamp = @bistamp
ORDER by linha"
com.Parameters.Clear()
com.Parameters.AddWithValue("@bistamp", stamp)
Using reader As SqlClient.SqlDataReader = com.ExecuteReader()
While reader.Read
Dim constituicaoAssessoria As New Dynamic.ExpandoObject()
constituicaoAssessoria.AddKeyValue("Descricao", reader("descricao"))
constituicaoAssessoria.AddKeyValue("Quantidade", CType(reader("quantidade"), Decimal))
constituicaoAssessoria.AddKeyValue("Valor", CType(reader("valor"), Decimal))

Dim ca = CType(CType(refreshbubblesProgramaConf, IDictionary(Of String, Object))("CalculoAssessorias"), IDictionary(Of String, Object))
Dim cta = CType(CType(ca(stamp), IDictionary(Of String, Object))("ConstituicaoAssessorias"), List(Of Dynamic.ExpandoObject))
cta.Add(constituicaoAssessoria)
End While
End Using
Next
End If
End Using
con.Close()
End Using

Return Newtonsoft.Json.JsonConvert.SerializeObject(refreshbubblesProgramaConf)

'=== CMENHTML (cmenhtml) ===
0

