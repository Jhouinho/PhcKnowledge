* EUDEFS (Web)
* stamp: 034d3191e77ddaf062a20a
* tabela: fref
* campo: u_Status
* ecran: sfrefform
* descricao: Colocar a Obra como aberta na abertura da mesma introduzir
* tipo: 1
* quando: 1
* estado: Activo
* inactivo: False

*=== VALORC (valorc) ===
Aberta

