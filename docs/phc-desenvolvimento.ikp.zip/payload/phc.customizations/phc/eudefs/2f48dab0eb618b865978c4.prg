* EUDEFS (Web)
* stamp: 2f48dab0eb618b865978c4
* tabela: bo
* campo: u_dtadjud
* ecran: boform
* descricao: (boform - u_dtadjud) Data de Adjudicação
* tipo: 2
* quando: 2
* estado: Inactivo
* inactivo: True

*=== EXPVB (expvb) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()

Dim ld_dtAdjud As Date

Dim lc_ndos As String = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()

If lc_ndos = "3" Then

	ld_dtAdjud = CType(mf.master.findcontrol("conteudo").findcontrol("u_dtadjud"), NossoCampoTextBox).Value()
Else If lc_ndos = "1"

	ld_dtAdjud = CType(mf.master.findcontrol("conteudo").findcontrol("u_dtadjud1"), NossoCampoTextBox).Value()
  Else
   ld_dtAdjud = DateTime.MinValue
End If

  Return ld_dtAdjud

