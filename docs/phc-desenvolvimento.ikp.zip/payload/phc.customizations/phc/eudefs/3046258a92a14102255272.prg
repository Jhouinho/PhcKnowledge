* EUDEFS (Web)
* stamp: 3046258a92a14102255272
* tabela: fref
* campo: u_Status
* ecran: sfrefform
* descricao: Colocar a Obra como aberta na abertura da mesma gravação
* tipo: 1
* quando: 2
* estado: Activo
* inactivo: False

*=== VALORC (valorc) ===
Aberta

