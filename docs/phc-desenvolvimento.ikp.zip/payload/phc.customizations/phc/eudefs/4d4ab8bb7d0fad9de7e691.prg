* EUDEFS (Web)
* stamp: 4d4ab8bb7d0fad9de7e691
* tabela: bi
* campo: u_ecstamp
* ecran: boform
* descricao: (bi) Stamp Estrutura Custos
* tipo: 2
* quando: 1
* estado: Activo
* inactivo: False

*=== EXPVB (expvb) ===
return xcfox.u_stamp()

