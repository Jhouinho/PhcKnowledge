* EUDEFS (Web)
* stamp: 502-4d67-a072-070dc67c23
* tabela: bo
* campo: u_status
* ecran: boform
* descricao: (bofotm - u_status) Estado da Proposta
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== EXPVB (expvb) ===
DIM status AS String = CType(mpage.Master.findcontrol("conteudo").findcontrol("u_status"),NossoCampoTabPrg).Value.toString()

If String.IsNullOrEmpty(status) Then
  Return "Em Preparação"
Else
  Return status
End If

