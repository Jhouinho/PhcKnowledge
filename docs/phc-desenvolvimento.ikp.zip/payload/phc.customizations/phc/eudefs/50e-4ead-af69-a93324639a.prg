* EUDEFS (Web)
* stamp: 50e-4ead-af69-a93324639a
* tabela: bo
* campo: datafinal
* ecran: boform
* descricao: (boform - datafinal) Validade da Proposta
* tipo: 2
* quando: 1
* estado: Activo
* inactivo: False

*=== EXPVB (expvb) ===
Dim vDatafinal As Date = Date.Today

return vDatafinal.Tostring()

