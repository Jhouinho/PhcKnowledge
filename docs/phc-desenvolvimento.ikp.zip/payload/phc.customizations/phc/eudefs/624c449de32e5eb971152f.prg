* EUDEFS (Web)
* stamp: 624c449de32e5eb971152f
* tabela: bo
* campo: u_mrgtotal
* ecran: boform
* descricao: (boform - Intranet) Margem Total
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== EXPVB (expvb) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()

If mf.PropTipoDocumento = 3 Then
  Dim ln_etotaldeb As Decimal = mainformdataset.tables("ebo").rows(0).item("etotaldeb")
  Dim ln_ecusto As Decimal = mainformdataset.tables("ebo").rows(0).item("ecusto")
  
  Dim ln_returnValue As Decimal = (1 -(ln_ecusto/ln_etotaldeb)) *100
  Return ln_returnValue
Else
  Return 0
End If

