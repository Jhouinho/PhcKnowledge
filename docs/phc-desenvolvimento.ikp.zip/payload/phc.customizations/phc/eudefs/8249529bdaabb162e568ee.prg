* EUDEFS (Web)
* stamp: 8249529bdaabb162e568ee
* tabela: bo
* campo: trab2
* ecran: boform
* descricao: (boform - trab2) Atualiza N.º de Adjudicação (bug PHC CS Web)
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== EXPVB (expvb) ===
Dim mf As Mainform
mf = mpage.ToType(Of Mainform)()

Dim lc_nAdjud As String
Dim lc_ndos As String = CType(mpage.Master.FindControl("conteudo").FindControl("ndos"), NossoCampoTextBox).Value.ToString()

If lc_ndos = "3" Then

  lc_nAdjud = CType(mf.master.findcontrol("conteudo").findcontrol("trab2"), NossoCampoTextBox).Value().ToString()

Else If lc_ndos = "1"

    lc_nAdjud = CType(mf.master.findcontrol("conteudo").findcontrol("trab21"), NossoCampoTextBox).Value().ToString()

End If
  
Return lc_nAdjud

