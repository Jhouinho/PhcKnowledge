* EVENTO
* stamp: ADM20010259219,170478426
* resumo: Refresh/Hca Procedimentos Gerais
* ecran: RbPrg
* qevento: Consultar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
.t.

*=== EXPRESSAO (expressao) ===
*** =======================================================================================
*** IIF(EventosExe("RbPrg", "Consultar", .F.), "", "")
*** RB 02.01.2020
*** HCA: 12/2020
*** =======================================================================================




* ===============================================================
Procedure pesquisa_clientes
	Lparameters IN_FILTRO

	Local sql_txt,ret_str

	Store '' To ret_str

	TEXT to sql_txt textmerge noshow

select clstamp,no,nome,estab from cl (nolock) where inactivo = 0 and nome like '<<'%'+in_filtro+'%'>>'

order by nome asc

	ENDTEXT
	** msg(sql_txt)


	If u_sqlexec(sql_txt,"crs_clientes")

		Do Case
			Case Reccount([crs_clientes])>0
				Select crs_clientes
				=CursorSetProp('Buffering',5,"crs_clientes")
				Declare list_tit(3),list_cam(3),list_tam(3),list_pic(3)
				list_tit(1)="Nome"
				list_tit(2)="Numero"
				list_tit(3)="Estab."
				list_cam(1)="crs_clientes.nome"
				list_cam(2)="crs_clientes.no"
				list_cam(3)="crs_clientes.estab"
				list_pic(1)=""
				list_pic(2)=""
				list_pic(3)=""
				list_tam(1)=8*20
				list_tam(2)=8*60
				list_tam(3)=8*30
				m.escolheu=.F.
				Do	browlist With "Escolha o cliente","crs_clientes","crs_clientes"
				*,.T.,.F.,.F.,.T.,.F.,'',.t.
				Do Case
					Case M.escolheu = .T.


					Otherwise
						msg("Não executou nenhuma escolha")
						Select crs_clientes
						Replace crs_clientes.clstamp With ''
				Endcase
		Endcase
	Else
		msg("Sem clientes encontrados na base de dados!")
		Return
	Endif
Endproc
* ===============================================================



* ===============================================================
Procedure pesquisa_vendedores
	Lparameters IN_FILTRO

	Local sql_txt,ret_str

	Store '' To ret_str

	TEXT to sql_txt textmerge noshow

select cm3stamp,CM,CMDESC from CM3 (nolock) where INACTIVO = 0 and CMDESC like '<<'%'+in_filtro+'%'>>'

order by CMDESC asc

	ENDTEXT
	** msg(sql_txt)


	If u_sqlexec(sql_txt,"crs_vendedores")

		Do Case
			Case Reccount([crs_vendedores])>0
				Select crs_vendedores
				=CursorSetProp('Buffering',5,"crs_vendedores")
				Declare list_tit(2),list_cam(2),list_tam(2),list_pic(2)
				list_tit(1)="Nome"
				list_tit(2)="Numero"
				list_cam(1)="crs_vendedores.cmdesc"
				list_cam(2)="crs_vendedores.cm"
				list_pic(1)=""
				list_pic(2)=""
				list_tam(1)=8*20
				list_tam(2)=8*60
				m.escolheu=.F.
				Do	browlist With "Escolha o responsável","crs_vendedores","crs_vendedores"
				*,.T.,.F.,.F.,.T.,.F.,'',.t.
				Do Case
					Case M.escolheu = .T.


					Otherwise
						msg("Não executou nenhuma escolha")
						Select crs_vendedores
						Replace crs_vendedores.cm3stamp With ''
				Endcase
		Endcase
	Else
		msg("Sem responsáveis encontrados na base de dados!")
		Return
	Endif
Endproc
* ===============================================================



** ==========================================================
** Jorge F. Moradas de carga e descarga

Procedure inserir_SZADRS
	Lparameters in_u_tipo,in_fref,in_U_NOCLI,in_U_CLINOME,in_nmfref

	Local mensag


	* Insert moradas de carga / descarga deste cliente / Processo
	Select fref

	If Len(Alltrim(fref.frefstamp)) = 0
		Return
	Endif

	If fref.U_NOCLI= 0
		msg("Deve ter um cliente escolhido")
		Return
	Endif

	mensag="Pretende  criar nova morada de "+Alltrim(in_u_tipo)

	If pergunta(mensag)
		** sfref.showsave()

		If u_sqlexec("select clstamp from cl where cl.no='"+Str(in_U_NOCLI)+"' and cl.estab='0'","mycurcl")

			Select mycurcl
			If Reccount("mycurcl")<>1
				msg("Erro ao pesquisar cliente!")
				Return
			Endif

		Else
			msg("Erro ao pesquisar cliente!")
			Return
		Endif

		Local ucstamp
		ucstamp=""
		*abre o ecrã
		If Not Used("SZADRS")
			Do dbfuseSZADRS
		Endif
		doread("SZADRS")
		* coloca em modo de introdução
		SSZADRS.dointroduzir()
		Select SZADRS

		SSZADRS.SZADRSDESC.VALUE = ALLTRIM(in_fref)+' | '+ALLTRIM(in_nmfref)     	
		SSZADRS.u_tipo.VALUE = in_u_tipo
		SSZADRS.Pageframe1.Page1.Origem.displayvalue = "CL"
		SSZADRS.pageframe1.page1.nome.value = in_U_CLINOME
		SSZADRS.pageframe1.page1.no.VALUE =  in_U_NOCLI
		sSZADRS.pageframe1.page1.estab.value = 0
		sSZADRS.fref.value = in_fref
		sSZADRS.nmfref.value = in_nmfref


		fecha("listmoradasc")



		

		sfref.doactualizar()


	Endif

Endproc




** ==============================================================
*** Moradas clientes 

Procedure moradas
	Lparameters in_origem,in_tipo,in_no,in_estab,in_fref

	Local sql_txt

	do case
	case in_fref = '%'

	TEXT to sql_txt textmerge noshow


		select fref.fref,fref.nmfref,fref.U_CLINOME
			-- ,fref.U_NOCLI,a.MORADA,a.U_DESC,a.LOCAL,a.TLMVL,a.SZADRSDESC,a.CODPOST
		from fref (nolock)
			-- join SSZADRS a (nolock) on a.U_NOCLI = '<<astr(in_no)>>' and a.U_TIPO 'Descarga' and a.inactivo = 0

		where fref.U_NOCLI = '<<astr(in_no)>>' and fref.INACTIVO = 0
				order by fref.fref desc


	ENDTEXT


	If u_sqlexec(sql_txt,"crs_fref") And Reccount("crs_fref")>0

		=CursorSetProp('Buffering',5,"crs_fref")
		Declare list_tit(2),list_cam(2),list_tam(2),list_pic(2)
		list_tit(1)="Descrição"
		list_tit(2)="Obra"

		list_cam(1)="crs_fref.fref"
		list_cam(2)="crs_fref.nmfref"

		list_pic(1)=""
		list_pic(2)=""

		list_tam(1)=8*60
		list_tam(2)=8*60

		m.escolheu=.F.
		Do	browlist With "Escolha a obra do cliente","crs_fref","crs_fref"
		*,.T.,.F.,.F.,.T.,.F.,'',.t.




		If M.escolheu = .F.
			msg("Não escolheu nenhuma obra. Não é possivel encontrar as moradas!")
			Return
		Endif



		TEXT to sql_txt textmerge noshow


		--- select fref.fref,fref.nmfref,fref.U_CLINOME,fref.U_NOCLI,a.MORADA,a.U_DESC,a.LOCAL,a.TLMVL,a.SZADRSDESC,a.CODPOST
		---				from fref (nolock)
		--- 				join SZADRS a (nolock) on a.u_fref = fref.fref

		---		where a.no = '1' and fref.INACTIVO = 0
		--- 				and a.u_tipo = 'Descarga' and a.inactivo = 0 and fref.fref = '<<crs_fref.fref>>'
		--- 				and a.estab = 0


		--- 		union all


		select fref.fref,fref.nmfref,fref.U_CLINOME,fref.U_NOCLI,a.MORADA,a.U_DESC,a.LOCAL,a.TLMVL,a.SZADRSDESC,a.CODPOST
				from fref (nolock)
				join SZADRS a (nolock) on a.u_fref = fref.fref

		where a.no = '<<astr(in_no)>>' and fref.INACTIVO = 0
				and a.u_tipo = 'Descarga' and a.inactivo = 0 and fref.fref like '<<crs_fref.fref>>'
				and a.estab = 0

		
		order by nmfref asc

		ENDTEXT

		** msg(sql_txt)

		If u_sqlexec(sql_txt,"crs_fref_moradas") And Reccount("crs_fref_moradas")>0


			=CursorSetProp('Buffering',5,"crs_fref_moradas")
			Declare list_tit(5),list_cam(5),list_tam(5),list_pic(5)
			list_tit(1)="Descrição"
			list_tit(2)="Obra"
			list_tit(3)="Morada"
			list_tit(4)="Localidade"
			list_tit(5)="Cod. Postal"


			list_cam(1)="crs_fref_moradas.SZADRSDESC"
			list_cam(2)="crs_fref_moradas.U_DESC"
			list_cam(3)="crs_fref_moradas.morada"
			list_cam(4)="crs_fref_moradas.local"
			list_cam(5)="crs_fref_moradas.codpost"

			list_pic(1)=""
			list_pic(2)=""
			list_pic(3)=""
			list_pic(4)=""
			list_pic(5)=""

			list_tam(1)=8*60
			list_tam(2)=8*60
			list_tam(3)=8*60
			list_tam(4)=8*60
			list_tam(5)=8*60

			m.escolheu=.F.
			Do	browlist With "Escolha a morada descarga obra/cliente","crs_fref_moradas","crs_fref_moradas"
			*,.T.,.F.,.F.,.T.,.F.,'',.t.
			Do Case
				Case M.escolheu = .T.

					Select bo
					Replace bo.fref With crs_fref_moradas.fref

					select bo2
					replace DESCAR with  crs_fref_moradas.SZADRSDESC
					replace morada with crs_fref_moradas.morada
					replace LOCAL with crs_fref_moradas.local
					replace codpost with crs_fref_moradas.codpost



				Otherwise

					msg("Não seleccionou nenhuma morada!")
					Return

			Endcase




		Else

			msg("O cliente não moradas abertas para esta obra!")
			Return
		Endif



	Else

		msg("O cliente não tem obras abertas ou activas!")
		Return

	Endif


	**** Caso seja encontrada a Obra logo no filtro inicial

	case in_fref <> '%'


		TEXT to sql_txt textmerge noshow


		---		select fref.fref,fref.nmfref,fref.U_CLINOME,fref.U_NOCLI,a.MORADA,a.U_DESC,a.LOCAL,a.TLMVL,a.SZADRSDESC,a.CODPOST
		--- 				from fref (nolock)
		--- 				join SZADRS a (nolock) on a.u_fref = fref.fref

		--- 		where a.no = '1' and fref.INACTIVO = 0
		--- 				and a.u_tipo = 'Descarga' and a.inactivo = 0 and fref.fref like '<<in_fref>>'
		--- 				and a.estab = 0


		--- 		union all


		select fref.fref,fref.nmfref,fref.U_CLINOME,fref.U_NOCLI,a.MORADA,a.U_DESC,a.LOCAL,a.TLMVL,a.SZADRSDESC,a.CODPOST
				from fref (nolock)
				join SZADRS a (nolock) on a.u_fref = fref.fref

		where a.no = '<<astr(in_no)>>' and fref.INACTIVO = 0
				and a.u_tipo = 'Descarga' and a.inactivo = 0 and fref.fref like '<<in_fref>>'
				and a.estab = 0

		
		order by nmfref asc

		ENDTEXT

		** msg(sql_txt)

		If u_sqlexec(sql_txt,"crs_fref_moradas") And Reccount("crs_fref_moradas")>0


			=CursorSetProp('Buffering',5,"crs_fref_moradas")
			Declare list_tit(5),list_cam(5),list_tam(5),list_pic(5)
			list_tit(1)="Descrição"
			list_tit(2)="Obra"
			list_tit(3)="Morada"
			list_tit(4)="Localidade"
			list_tit(5)="Cod. Postal"


			list_cam(1)="crs_fref_moradas.SZADRSDESC"
			list_cam(2)="crs_fref_moradas.U_DESC"
			list_cam(3)="crs_fref_moradas.morada"
			list_cam(4)="crs_fref_moradas.local"
			list_cam(5)="crs_fref_moradas.codpost"

			list_pic(1)=""
			list_pic(2)=""
			list_pic(3)=""
			list_pic(4)=""
			list_pic(5)=""

			list_tam(1)=8*60
			list_tam(2)=8*60
			list_tam(3)=8*60
			list_tam(4)=8*60
			list_tam(5)=8*60

			m.escolheu=.F.
			Do	browlist With "Escolha a morada descarga obra/cliente","crs_fref_moradas","crs_fref_moradas"
			*,.T.,.F.,.F.,.T.,.F.,'',.t.
			Do Case
				Case M.escolheu = .T.

					Select bo
					Replace bo.fref With crs_fref_moradas.fref

					select bo2
					replace DESCAR with  crs_fref_moradas.SZADRSDESC
					replace morada with crs_fref_moradas.morada
					replace LOCAL with crs_fref_moradas.local
					replace codpost with crs_fref_moradas.codpost



				Otherwise

					msg("Não seleccionou nenhuma morada!")
					Return

			Endcase




		Else

			msg("O cliente não moradas abertas para esta obra!")
			Return
		Endif






	endcase


Endproc



** =====  Editar tabelasDytable
Function editarTabelas
	Lparameters in_campo,in_titulo

	Public &in_campo
	docomando([Do Form manarray With "&in_campo","&in_titulo",10,35])

Endfunc



** ====================================================
** ============== Ordenação / Filtragem de cursores L M
** ====================================================

** p_Ordenar_Filtrar("NomeDoCursorDosDados", "NomeObjectoGrid", "Tipo_Operação")

Procedure p_Ordenar_Filtrar()

	Lparameters lc_cursor, lc_Nome_Objecto, lc_Tipo_Operacao

	** ------------------------------------ **
	** lc_Tipo_Operacao						**
	** ------------------------------------ **
	** pode conter os seguintes valores: 	**
	** 		Ordenar							**
	**		Filtrar							**
	**		Limpar Filtro					**
	** ------------------------------------ **

	Select &lc_cursor
	If Reccount("&lc_cursor") = 0

		mensagem("Não existem registos para ordenar ou filtrar na grelha.", "Directa")
		Return

	Endif


	** ------------------------------------- **
	** Tipos de Operação: Ordenar ou Filtrar **
	** ------------------------------------- **
	Local ln_Ciclo, lc_obj, lc_obj2, lc_cmd, lc_tipoflt

	Store 0 To ln_Ciclo
	Store "" To lc_obj, lc_obj2, lc_cmd, lc_tipoflt

	Declare a_tipoflt(&lc_Nome_Objecto..ColumnCount + 2)


	For ln_Ciclo = 1 To &lc_Nome_Objecto..ColumnCount

		lc_obj = lc_Nome_Objecto + ".column" + Alltrim(Str(ln_Ciclo)) + ".header1.caption"

		If Type("&lc_obj") <> "U"

			a_tipoflt(ln_Ciclo) = &lc_obj

		Endif

	Endfor

	m.escolheu = .F.

	Do Case

		Case lc_Tipo_Operacao = "Ordenar"
			lc_tipoflt = getnome("Ordenar por ", Alltrim(a_tipoflt(1)), "", "", 1, .F., "a_tipoflt", .F.)

			If m.escolheu = .T.

				ln_Ciclo = Ascan(a_tipoflt, lc_tipoflt, 1, &lc_Nome_Objecto..ColumnCount, 1)

				lc_obj = lc_Nome_Objecto + ".column" + Alltrim(Str(ln_Ciclo)) + ".header1.caption"
				lc_obj2 = lc_Nome_Objecto + ".column" + Alltrim(Str(ln_Ciclo)) + ".controlsource"
				lc_obj2 = &lc_obj2

				Select &lc_cursor
				Go Top

				lc_cmd = "index on " + Alltrim(lc_obj2) + " tag idx_tmp"
				&lc_cmd

				&lc_Nome_Objecto..Refresh()

			Endif


		Case lc_Tipo_Operacao = "Filtrar"
			a_tipoflt(ln_Ciclo + 1) = "Limpar Filtro"

			lc_tipoflt = getnome("Filtar por ", Alltrim(a_tipoflt(2)), "", "", 1, .F., "a_tipoflt", .F.)

			If m.escolheu = .T.

				Do Case

					Case lc_tipoflt = "Limpar Filtro"

						Select &lc_cursor
						Go Top

						Set Filter To
						Go Top
						&lc_Nome_Objecto..Refresh()

					Otherwise

						ln_Ciclo = Ascan(a_tipoflt, lc_tipoflt, 1, &lc_Nome_Objecto..ColumnCount, 1)

						lc_obj = lc_Nome_Objecto + ".column" + astr(ln_Ciclo) + ".header1.caption"
						lc_obj2 = lc_Nome_Objecto + ".column" + astr(ln_Ciclo) + ".controlsource"
						lc_obj2 = &lc_obj2

						Do Case

							Case Vartype(&lc_obj2) = "N"
								lc_filtro = astr(&lc_obj2)

							Case Vartype(&lc_obj2) = "C"
								lc_filtro = Alltrim(&lc_obj2)

							Case Vartype(&lc_obj2) = "L"
								lc_filtro = Iif(&lc_obj2 = .T., "S", "N")

						Endcase


						m.escolheu = .F.
						lc_filtro = getnome("Qual o valor para filtrar por " + Alltrim(&lc_obj), lc_filtro)

						If m.escolheu = .T. And !Empty(lc_filtro)

							Select &lc_cursor
							Go Top
							Set Filter To

							lc_obj = lc_Nome_Objecto + ".column" + astr(ln_Ciclo) + ".controlsource"
							lc_obj = &lc_obj

							Do Case

								Case Vartype(&lc_obj) = "N"
									lc_cmd = "set filter to " + Alltrim(lc_obj) + "=" + astr(lc_filtro)
									&lc_cmd
									&lc_Nome_Objecto..Refresh()

								Case Vartype(&lc_obj) = "C"
									lc_cmd = "set filter to '" + Alltrim(lc_filtro) + "' $ " + Alltrim(lc_obj)
									&lc_cmd
									&lc_Nome_Objecto..Refresh()

								Case Vartype(&lc_obj) = "L"
									lc_cmd = "set filter to " + Alltrim(lc_obj) + "=" + Iif(lc_filtro = "S", ".t.", ".f.")
									&lc_cmd
									&lc_Nome_Objecto..Refresh()

							Endcase

						Endif

				Endcase

			Endif

	Endcase

Endproc


** ==== data inicial
Procedure Data
	Lparameters in_campo
	Local ret

	&& variavel local do tipo data
	m.mvalor = Date()
	m.descolheu=.F.
	&& chama o calendário
	docomando("do form qdata with m.mvalor")
	If m.descolheu
		&& atribuição da data escolhida ao campo do tipo data

		ret=in_campo+".caption = dtoc(m.mvalor)"
		&ret
	Else
		ret=in_campo+".caption=''"
		&ret
	Endif
	&& refrescamento da página atual
	**??.Atualizarsopag.Nossobutton1.Click


Endproc

