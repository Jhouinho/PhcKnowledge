* EVENTO
* stamp: ADM22010761429,742683339
* resumo: HCA :: Funcões Servidor
* ecran: HCA_SERVIDOR
* qevento: Consultar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
.t.

*=== EXPRESSAO (expressao) ===
* IIF(EventosExe("HCA_SERVIDOR","Consultar",.f.),"","")

FC_VariaveisGlobais('SERVIDOR')

Function AlterarParametros
	Lparameters in_modulo,in_grelha
	Public HCAModulo
	HCAModulo = in_modulo
	Local LvSqlTxt
	If Vartype("crs_parametros") = "U"
		u_sqlexec("select u_hcapara1stamp,descricao,Valor,informacao,VarPublica from u_HCApara1 (nolock) where modulo = '"+Alltrim(in_modulo)+"' order by descricao ","crs_parametros")
	Endif
	Declare list_tit(7),list_cam(7),list_tam(7),list_pic(7),list_ronly(7),list_valid(7),list_rot(7)
	list_tit(1)="Descrição"
	list_cam(1)="crs_parametros.descricao"
	list_ronly(1)=.T.
	list_pic(1)=""
	list_tam(1)=8*60
	list_tit(2)="Valor (1 Sim; 0 Não; outros em texto)"
	list_cam(2)="crs_parametros.valor"
	list_ronly(2)=.F.
	list_pic(2)=""
	list_tam(2)=8*30
	list_tit(3)="Informação"
	list_cam(3)="crs_parametros.informacao"
	list_ronly(3)=.F.
	list_pic(3)=""
	list_tam(3)=8*60
	list_tit(4)="Variavel publica"
	list_cam(4)="crs_parametros.VarPublica"
	list_ronly(4)=.F.
	list_pic(4)="LOGIC"
	list_tam(4)=8*30
	list_tit(5)="Duplicar Registo"
	list_cam(5)=""
	list_tam(5)=10
	list_pic(5)="BOTAO IMG: duplid.bmp"
	list_ronly(5)=.F.
	list_rot(5)="ParametrosduplicarRegisto()"
	list_tit(6)="Gravar Registo"
	list_cam(6)=""
	list_tam(6)=10
	list_pic(6)="BOTAO IMG: gravar.bmp"
	list_ronly(6)=.F.
	* list_valid(6)="ValidaColuna()"
	list_rot(6)="ParametrosGravarRegisto()"
	list_tit(7)="Eliminar Registo"
	list_cam(7)=""
	list_tam(7)=10
	list_pic(7)="BOTAO IMG: delete.bmp"
	list_ronly(7)=.F.
	list_rot(7)="ParametrosEliminarRegisto()"
	=CursorSet("Buffering",5,"crs_parametros")
	Browlist('Alteração de parâmetros','crs_parametros','crs_parametros',.T.,.F.,.F.,.T.,.F.,"",.T.,.T.)
	CrsParametrosRefrescar("PDU_5VD0FVT3L.Pageframe1.U_hcapara1.Crs_parametros")
	Return .T.
Endfunc
Function ParametrosGravarRegisto
	Lparameters in_param1,in_param2
	Local LvSqlTxt,LvNovoRegisto
	Select crs_parametros
	Do Case
		Case val(crs_parametros.u_hcapara1stamp)>0
			
			TEXT to LvSqlTxt textmerge noshow
				update u_HCApara1 set
				valor = '<<alltrim(crs_parametros.valor)>>'
				,informacao='<<alltrim(crs_parametros.informacao)>>'
				,varpublica = '<<iif(crs_parametros.VarPublica=.t.,"1","0")>>'
				 where u_hcapara1stamp='<<crs_parametros.u_hcapara1stamp)>>'
			ENDTEXT
			
			If !u_sqlexec(LvSqlTxt)
				msg("Erro ao atualizar parametros. Por favor informe o depº de informática!")
			Else
				CrsParametrosRefrescar("PDU_5VD0FVT3L.Pageframe1.U_hcapara1.Crs_parametros")
			Endif
			Return 1
		Case val(crs_parametros.u_hcapara1stamp)=0
			
			* Novo Registo
			If !u_sqlexec("select count(u_hcapara1stamp)  as ultimo from u_HCApara1 (nolock) ","CrsNovoReg") Or Reccount("CrsNovoReg") <> 0
				Select CrsNovoReg
				LvNovoRegisto = CrsNovoReg.ultimo+1
			Else
				LvNovoRegisto = 1
			Endif
			TEXT to LvSqlTxt textmerge noshow
		insert into u_HCApara1
			(
			[u_HCApara1stamp]
           ,[descricao]
           ,[valor]
           ,[tipo]
           ,[dec]
           ,[tam]
           ,[memvalor]
           ,[imgvalor]
           ,[ousrinis]
           ,[ousrdata]
           ,[ousrhora]
           ,[usrinis]
           ,[usrdata]
           ,[usrhora]
           ,[marcada]
           ,[conf]
           ,[tacesso]
           ,[userno]
           ,[usernm]
           ,[acesso]
           ,[tabela]
           ,[pfcod]
           ,[pfnm]
           ,[ecran]
           ,[ecrannm]
           ,[apenasecran]
           ,[actanexos]
           ,[Informacao]
           ,[Modulo]
           ,[VarPublica])
			values
   			(
		   '<<astr(LvNovoRegisto)>>'
           ,'<<crs_parametros.descricao>>'     	/*, char(200),> */
           ,'<<alltrim(crs_parametros.valor)>>'	/*  char(100),> */
           ,'C'     							/* char(1),> */
           ,'0'		     						/* numeric(3,0),> */
           ,'0'		     						/* numeric(3,0),> */
           ,'0'			     					/* text,> */
           ,''			     					/* image,> */
           ,'<<m.m_chinis>>'     				/* varchar(30),> */
           ,'<<dtos(date())>>'     				/* datetime,> */
           ,'<<time()>>'     					/* varchar(8),> */
           ,'<<m.m_chinis>>'     				/* varchar(30),> */
           ,'<<dtos(date())>>'     				/* datetime,> */
           ,'<<time()>>'     					/* varchar(8),> */
           ,'0'			     					/*, bit,> */
           ,'0'			   						/* numeric(1,0),> */
           ,'0'			     					/* numeric(1,0),> */
           ,'0'			     					/* numeric(4,0),> */
           ,''			     					/* varchar(40),> */
           ,''			     					/* varchar(20),> */
           ,''     								/* varchar(20),> */
           ,'0'     							/* numeric(4,0),> */
           ,''     								/* varchar(50),> */
           ,'PDU_5VD0FVT3L'   					/* varchar(60),> */
           ,'servidor' 		   					/* char(80),> */
           ,'0'				     				/* bit,> */
           ,'0'				     				/* bit,> */
           ,'<<alltrim(crs_parametros.informacao)>>'	/* varchar(254),> */
           ,'servidor'	     					/* varchar(30),> */
           ,'<<iif(crs_parametros.VarPublica=.t.,1,0)>>'    				/* bit,> */
			)
			ENDTEXT
			* MSG(LvSqlTxt)
			If !u_sqlexec(LvSqlTxt)
				msg("Erro ao criar o parametro. Por favor informe o depº de informática!")
				Return .F.
			Else
				Select crs_parametros
				Replace u_hcapara1stamp With LvNovoRegisto
			Endif
	Endcase
	CrsParametrosRefrescar("PDU_5VD0FVT3L.Pageframe1.U_hcapara1.Crs_parametros")
	Return 1
Endfunc
Function ParametrosEliminarRegisto
	Lparameters in_param1,in_param2
	Select crs_parametros
	If pergunta("Tem a certeza?")
		If u_sqlexec("Delete from u_HCApara1  where u_hcapara1stamp= '"+Alltrim(crs_parametros.u_hcapara1stamp)+"'")
			Select crs_parametros
			Delete
		Endif
	Endif
Endfunc
Function ParametrosduplicarRegisto
	Lparameters in_param1,in_param2,in_param3
	Local LvNovoParametro
	LvNovoParametro = ""
	Do While Len(Alltrim(LvNovoParametro)) = 0
		LvNovoParametro = getnome("Insira o nome do novo parametro")
	Enddo
	Select crs_parametros
	Scatter Memvar
	Append Blank
	Gather Memvar
	Select crs_parametros
	Replace descricao With LvNovoParametro
	Replace u_hcapara1stamp With '0'
	Replace valor With ''
	Replace informacao With ''
	Replace modulo With HCAModulo
	Return .T.
Endfunc
Function CrsParametrosRefrescar
	Lparameters in_objeto
	Local LvObjeto
	LvObjeto = in_objeto +".refresh"
	** msg(LvObjeto)
	&LvObjeto
	* PDU_5P40Y34E7.pageframe1.parametros.crs_parametros.Refresh
Endfunc

Function FC_VariaveisGlobais
	Lparameters in_modulo
	* Parametros 
	Local LvNomeParametro,TXtSQL
	TXtSQL = Textmerge("Select * from u_hcapara1 (nolock) where modulo = '<<Alltrim(in_modulo)>>' and Varpublica=1")
	If !u_sqlexec(TXtSQL,"CrsPara1") Or Reccount("CrsPara1")=0
		msg("Erro ao carregar variáveis globais!")
		Return .F.
	Endif
	Select CrsPara1
	Go Top
	Scan
		LvNomeParametro = Alltrim(CrsPara1.descricao)

		if vartype(&LvNomeParametro) = "U"
			Public &LvNomeParametro
			&LvNomeParametro = Alltrim(CrsPara1.valor)
		endif
  
	Endscan
Endfunc

Function CarregaImagemSQL
	Local id_da_imagem
	id_da_imagem = ""
	m.escolheu = .f.
	
	id_da_imagem = getnome("Insira ID da imagem")
	if m.escolheu = .t. and len(alltrim(id_da_imagem))>0
	else
		return .f.
	endif
	
	* Lparameters ID_da_Imagem
	vl_imgcaminho = Getpic("","Selecione uma Imagem !")
	vl_imgextensao = Alltrim(Strextract(vl_imgcaminho, ".", ""))
	vl_imgnome = Alltrim(Strextract(vl_imgcaminho, "\", "."))
	Do While Occurs("\",vl_imgnome) != 0
		vl_imgnome = Alltrim(Strextract(vl_imgnome, "\", ""))
	Enddo
	TEXT to mselImg noshow textmerge
		INSERT INTO ifl (iflstamp, resumo, fname, fext, bdados)
		SELECT left(newid(), 23), '<<alltrim(ID_da_Imagem)>>','<<vl_imgnome>>.<<vl_imgextensao>>', '<<alltrim(vl_imgextensao)>>', BulkColumn
		FROM Openrowset( Bulk '<<Alltrim(vl_imgcaminho)>>', Single_Blob) as Picture
	ENDTEXT
	If !u_sqlexec(mselImg)
		msg("Erro SQL:"+Chr(13)+mselImg)
	Endif
Endfunc
******* Criar Ficheiro da Imagem presente numa Tabela do SQL *******
Function CriarFicheiro
	Lparameters ID_da_Imagem
	msel = "select ifl.bdados, ifl.fname, ifl.fext from ifl(nolock) where resumo = '" + Alltrim(ID_da_Imagem) + "'"
	u_path = PvCaminhoImgLocal 
	gnfile = ''
	If u_sqlexecbin(msel, 'crAnexos') And Reccount('crAnexos') > 0
		Select crAnexos
		gnfile = Alltrim(u_path) + Alltrim(crAnexos.fname)
		m.imagem = crAnexos.bdados
		If !Directory(u_path,1)
			Mkdir (u_path)
		Endif
		if File(gnfile) 
			*Delete File gnfile
			*m.bindados = Strtofile(m.imagem, gnfile, 0)
		else		
			m.bindados = Strtofile(m.imagem, gnfile, 0)
		endif
	Endif
Endfunc

