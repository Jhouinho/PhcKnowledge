* EVENTO
* stamp: ADM22091664113,386428936
* resumo: HCA | 2022 | Recalculo Custos Guia de entrada Ndos = 16
* ecran: sbo
* qevento: Introduzir
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
iif(bo.ndos=16,.t.,.f.)

*=== EXPRESSAO (expressao) ===
* Rotina de recalculo de PCMP 
*	HCA | JF 23.03.2021 | 
* Parametro4:	StockAtual caso utiliza PCMP relativo ao stock à data
*				QttEntrada  caso utiliza PCMP relativo ao stock acumuldado de entrada
* 				Até 24.03.2021: exec dbo.sp_HcaCalculaPcmPv1 '<<alltrim(sst.ref.value)>>','19000101','<<dtos(date())>>','QttEntrada',1,3,1
* 				Foi incluido o movimento Cm 3 e Cm 10 

Local LvSqlTxt,LvMensag



select bi
go top 

if len(alltrim(bi.ref)) >0 and bi.qtt <> 0 and bi.edebito <> 0

scan

	TEXT To LvSqlTxt TextMerge Noshow

	exec dbo.sp_HcaCalculaPcmPv2 '<<alltrim(bi.ref)>>','19000101','<<dtos(bi.dataobra)>>','StockAtual',1,3,10,1,1


	ENDTEXT

	If u_sqlexec(LvSqlTxt)
		Do stact1 With 'UM',Alltrim(bi.ref),.T.,.T.,.F.,.T.,.F.

  	Endif


endscan

endif

select bi
go top

