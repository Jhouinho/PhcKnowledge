* EVENTO
* stamp: ADM23090858041,550623423
* resumo: Controlo de Grid Conta Corrente
* ecran: SFREF
* qevento: Consultar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
.t.

*=== EXPRESSAO (expressao) ===
select fref
text to msel noshow textmerge
DECLARE 
 @CodigoObra as Varchar(30)
,@UltimaActualizacao as dateTime
set @CodigoObra = '<<ALLTRIM(FREF.FREF)>>';
set @UltimaActualizacao = Isnull((SELECT TOP 1 DataActualizacao FROM u_FrefAnalise(Nolock) where FrefCode=@CodigoObra),'19000101');
with 
tmpTotal as (
	select Isnull(count(*),0) Total
	from bo(nolock)
	 inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
	where bo.ndos in (11,17,18,19,20,22)
                    and bo.fref = @CodigoObra
                    and bo2.anulado = 0
					and Cast(bo.usrdata as Date) >= cast(@UltimaActualizacao as date)
	UNION ALL
	select Isnull(count(*),0) Total
	from bo(nolock)
	 inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
	 inner join bi(nolock) on bi.bostamp = bo.bostamp
	where bo.ndos in (15)
                    and bi.bifref = @CodigoObra
                    and bo2.anulado = 0
					and Cast(bi.usrdata as Date) >= cast(@UltimaActualizacao as date)
	UNION ALL
	select Isnull(count(*),0) Total
	FROM FT(NOLOCK)
	WHERE FT.anulado=0
		AND FT.tipodoc IN (1,3)
		AND FT.fref= @CodigoObra
		AND CAST(FT.usrdata AS DATE) >= cast(@UltimaActualizacao as date)
)
SELECT SUM(TOTAL) as Total FROM tmpTotal
endtext
IF !U_SQLEXEC(msel,"CurTotal")
	msg("Não foi possivel verificar os registos alterados, por favor contacte a assistência")
	SFREF.Pageframe1.Udcpage6.Objrefrescar.Visible = .t.
	return .f.
Endif
if CurTotal.Total > 0
	SFREF.Pageframe1.Udcpage6.Objrefrescar.Backcolor = 255
else
	SFREF.Pageframe1.Udcpage6.Objrefrescar.Backcolor = 65280
Endif

