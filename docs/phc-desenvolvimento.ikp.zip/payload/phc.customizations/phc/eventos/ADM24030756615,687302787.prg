* EVENTO
* stamp: ADM24030756615,687302787
* resumo: Adicionar: Preenchimento do Orçamento
* ecran: SFT
* qevento: Introduzir
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
iif(FT.TIPODOC=1,.t.,.f.)

*=== EXPRESSAO (expressao) ===
    replace ft.u_TmpOrca with ''
    SFT.Pageframe1.Page1.Btnorcamento.Caption = 'Selecionar Orçamento'

*=== CONDICAO (condicao) ===
SELECT FT
IF FT.TIPODOC = 1

