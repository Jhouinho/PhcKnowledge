* EVENTO
* stamp: ADM24030756644,179872168
* resumo: Alterar: Preenchimento do Orçamento
* ecran: SFT
* qevento: Alterar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
iif(FT.TIPODOC=1,.t.,.f.)

*=== EXPRESSAO (expressao) ===
    replace ft.u_TmpOrca with ''
    SFT.Pageframe1.Page1.Btnorcamento.Caption = 'Selecionar Orçamento'

