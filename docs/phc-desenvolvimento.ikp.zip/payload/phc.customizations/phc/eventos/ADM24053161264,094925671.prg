* EVENTO
* stamp: ADM24053161264,094925671
* resumo: HCA | 2024 | Painel de Devoluções
* ecran: PainelDevolucoes
* qevento: Consultar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
.t.

*=== EXPRESSAO (expressao) ===
if vartype(Pv_ObraEscolhidaDevolucao) = 'U'
    public Pv_ObraEscolhidaDevolucao
endif
Pv_ObraEscolhidaDevolucao= ''
if vartype(Pv_DocumentoEscolhidoDevolucao) = 'U'
    public Pv_DocumentoEscolhidoDevolucao
endif
Pv_DocumentoEscolhidoDevolucao= 'Guia de Transporte'
docomando("do genpdup with 'ADM24053033568,689500239'")

