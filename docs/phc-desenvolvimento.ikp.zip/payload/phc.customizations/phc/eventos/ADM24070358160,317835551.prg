* EVENTO
* stamp: ADM24070358160,317835551
* resumo: HCA | 2022 | Lançamento da Nota de cédito na criação do dossier
* ecran: sbo
* qevento: Alterar
* reacao: 3
* pdescricao: False
* estado: Activo
* inactivo: False

*=== CONDICAO (econdicao) ===
iif(bo.ndos=23,.t.,.f.)

*=== EXPRESSAO (expressao) ===
*
* HCA | Lançamento automático da N/ crédito a aguardar pelo fornecedor aquando do lançamento do dossier de devolução a fornecedor
* 24/05/2022
* evento
* Jorge F.
*



** Variáveis para guardar: referência interna,
* centro de custo e identificação interna.
Local mcfref,mccusto,mcintid,LvNo,LvNome,LvEstab,LvDataObra
m.mfref=''
m.mccusto=''
m.mcintid=''





**** Deve-se garantir que as views da
* facturação e das compras estão abertas
If Not Used("BO")
	Do dbfuseBo
Endif
If Not Used("FO")
	Do dbfusefo
Endif

** Leitura da referência interna, centro de custo
* e identificação interna dos documento de facturação
Select Bo
mcfref=Bo.fref
mccusto=Bo.ccusto
LvNo=Bo.no
LvNome=Bo.Nome
LvEstab=Bo.estab
LvDataObra = Bo.dataobra

*m.mcintid=bo.intid

** Abre as compras em modo de introdução
doread("FO","SFO")
sfo.dointroduzir

** Apaga a primeira linha de compras para não ficar em branco
Select fn
Delete

** Copia as linhas de facturas paras as linhas das compras,
* aqui o utilizador é livre de colocar os campos que achar melhor.
Select bi
Scan
	Do foine2in
	Select fn
	Replace fn.fnstamp With u_stamp()
	Replace fn.ref With bi.ref
	Replace fn.Design With bi.Design
	Replace fn.qtt With bi.qtt * -1
	Replace fn.epv With bi.edebito 
	Replace fn.desconto With bi.desconto
	Replace fn.desc2 With bi.desc2
	Replace fn.desc3 With bi.desc3
	Replace fn.bistamp With bi.bistamp

    Do Foactref With "NORMAL",.T.,""	

	*select ftma
	*locate for ftma.fistamp=fi.fistamp
	*saverecord('ftma','foma',.t.)
	*select foma
	*replace foma.fomastamp with u_stamp()
	*replace foma.fostamp with fn.fostamp

	*text to msel textmerge noshow
	*select marca, maquina,tipo, fref from ma(nolock)
	*where ma.mastamp=foma.mastamp>>
	*endtext

	*if u_sqlexec(msel,"tempma")
	*replace foma.marca with tempma.marca
	*replace foma.maquina with tempma.maquina
	*replace foma.tipo with tempma.tipo
	*endif

	*select fn
	*scan
	*replace foma.fnstamp with fn.fnstamp
	*endscan

Endscan

** Coloca no documento da compra os dados do documento
* de facturação: referência interna, centro de custo e
** identificação interna:
Select fo
Replace fo.no With LvNo
Replace fo.estab With LvEstab
Replace fo.Nome With LvNome
Replace fo.Adoc With "AGUARDA N/CRÉDITO"	
Replace fo.DOCCODE With 13
Replace fo.docnome With "V/Nt. Crédito Stock"
Replace fo.moeda With "EURO"
Replace fo.docdata With LvDataObra
Replace fo.PDATA With LvDataObra


sfo.docnome.Value = "V/Nt. Crédito Stock"

Replace fo.fref With m.mcfref
Replace fo.ccusto With m.mccusto
*replace fo.intid with m.mcintid


** Refresh ao ecrã.
sfo.Refresh()
sfo.Bok1.Okbuttomdef1.Click


* Update à FC
SELECT FO
U_SQLEXEC("UPDATE FC SET DEB=DEB*-1,EDEB=EDEB*-1 WHERE FOSTAMP='"+ALLTRIM(FO.FOSTAMP)+"'")
sfo.release

select bi
scan
	*u_sqlexec("update st set epcusto = epcusto * -1,EPCULT = EPCULT * -1 where ref = '"+alltrim(bi.ref)+"'")
	*u_sqlexec("update sl set evu = evu *-1,ett = ett *-1 where bistamp = '"+alltrim(bi.bistamp)+"'")

	u_sqlexec("update st set epcusto = epcusto * -1,EPCULT = EPCULT * -1 where ref = '"+alltrim(bi.ref)+"'")
	u_sqlexec("update sl set QTT = QTT *-1 where bistamp = '"+alltrim(bi.bistamp)+"'")



endscan
select bi
go top

*=== CONDICAO (condicao) ===
if bo.ndos=23
	if bo.obrano > 0
		if len(alltrim(bo2.assinatura))>0
			return .t.
		else
			return .f.
		endif
	else
		return .f.
	endif
else
	return .f.
endif

