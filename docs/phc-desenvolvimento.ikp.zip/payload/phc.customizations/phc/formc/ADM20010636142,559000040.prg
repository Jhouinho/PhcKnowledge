* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM20010636142,559000040
* ecran: SFREF
* nome: obj1
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

IIF(EventosExe("RbPrg", "Consultar", .F.), "", "")

text to selcarga textmerge noshow

select szadrsdesc,codpost,pais,codpais,telefone,u_desc from szadrs (nolock)
where u_tipo='Carga' and origem='CL' and no=<<str(cl.no)>> and estab=<<str(cl.estab)>>
order by u_desc
endtext

if u_sqlexec(selcarga,"crsmoradasc")
endif

