* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM21010538597,374000020
* ecran: SBO
* nome: hcaprg
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

** =====  Editar Tabelas
Function editarTabelas
	Lparameters in_campo,in_titulo

	Public &in_campo
	docomando([Do Form manarray With "&in_campo","&in_titulo",10,35])

Endfunc

