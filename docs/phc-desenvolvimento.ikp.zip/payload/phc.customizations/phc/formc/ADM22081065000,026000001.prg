* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM22081065000,026000001
* ecran: SFO
* nome: obj1
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

SELECT FO
IF LEN(ALLTRIM(FO.FOSTAMP))>0 
If Alltrim(upper(FO.Adoc))="AGUARDA N/CRÉDITO"

SFO.editfo.ENABLED = .T.

ELSE

SFO.editfo.ENABLED = .F.

ENDIF
endif

