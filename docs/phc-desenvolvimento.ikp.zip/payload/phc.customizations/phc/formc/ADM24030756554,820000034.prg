* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM24030756554,820000034
* ecran: SFT
* nome: obj95
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

*** fnChangeOrcamento(ft.u_TmpOrca)

Function fnChangeOrcamento
    Lparameters varOrcStamp

    **if !SFT.Adding or !sft.Editing
        ****Sft.ShowSave()
    **Endif

    IF EMPTY(varOrcStamp)
        select fi
        replace fi.u_BoOrcame with ''
        replace fi.u_nomeorca with ''
        return
    ENDIF

    text to lc_strsql noshow TextMerge
    select 	
	    Rtrim(bo.nmdos) + ' nº ' + CAST(obrano as varchar(10)) + '/'+ CAST(bo.boano as varchar(4))  as Orcamento
    from bo(nolock)
        where bo.bostamp='<<varOrcStamp>>'
    endtext
    if !u_sqlexec(lc_strsql,"CurOrca")
        msg("Erro ao vefificar o orçamento!")
        return
    ENDIF
    select fi
    replace fi.u_BoOrcame with varOrcStamp
    replace fi.u_nomeorca with alltrim(CurOrca.Orcamento)
    Fecha("CurOrca")
EndFunc


Function fnShowOrcamentos()
    Lparameters varCodigoObra 


    if !SFT.Adding or !sft.Editing
        Sft.ShowSave()
    Endif


    text to lc_strsql noshow TextMerge
    SELECT '' Orcamento, '' bostamp union all
    select 	
	    Rtrim(bo.nmdos) + ' nº ' + CAST(obrano as varchar(10)) + '/'+ CAST(bo.boano as varchar(4)) as Orcamento
	    ,bo.bostamp  
    from bo(nolock) 
    inner join bo2(nolock) on bo.bostamp=bo2.bo2stamp 
    where bo.ndos=3 
        and bo2.anulado=0 
        and bo.u_status='Adjudicado' 
        and bo.fref = '<<varCodigoObra>>'
        AND BO.FREF <> '' 
    endtext
    if !u_sqlexec(lc_strsql,"CurObras")
        msg("Erro ao vefificar o orçamento!")
        return
    ENDIF

    ** Agora vamos ao Browlist Editável
        DECLARE list_tit(1),list_cam(1),list_tam(1),list_pic(1),list_ronly(1)

        list_tit(1)="Orçamento"

        list_cam(1)="CurObras.Orcamento"
     
        list_ronly(1)=.t.

        list_pic=""
 
        list_tam(1)=8*100


        m.escolheu=.f.
        ** Chamamos o browlist
        browlist('Orçamento da Obra: ' + varCodigoObra,'CurObras','CurObras',.T.,.F.,.F.,.T.,.F.,'',.t.)
        if m.escolheu
            replace ft.u_TmpOrca with CurObras.Bostamp
            if !empty(CurObras.Bostamp)
                SFT.Pageframe1.Page1.Btnorcamento.Caption = 'Orç: ' + Alltrim(CurObras.Orcamento)
            else
                SFT.Pageframe1.Page1.Btnorcamento.Caption = 'Selecionar Orçamento'
            Endif
        EndIf 
        Fecha("CurObras")
EndFunc

