* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM24053061048,036000022
* ecran: PDU_6WV0JZHRL
* nome: grid_auxiliar
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

"* FORMC

