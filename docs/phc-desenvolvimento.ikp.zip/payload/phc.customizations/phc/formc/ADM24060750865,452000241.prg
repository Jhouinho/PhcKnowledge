* FORMC Xexpressao (grelha/objecto oculto)
* stamp: ADM24060750865,452000241
* ecran: SFREF
* nome: obj44
* tag: E
* tvalobj:                                                                                 
* udcVisible: False

function escolher_obra_fref
	TEXT TO msel NOSHOW TEXTMERGE
		select distinct
			fref.frefstamp,
			fref.fref as U0001,
			fref.nmfref as U0002,
			fref.u_dataini as U0003,
			fref.u_datafim as U0004,
			fref.u_dataact as U0005,
			fref.u_clinome as U0006,
			fref.u_nomevnd as U0007,
			fref.u_status as U0008,
			fref.u_tipo as U0009
		from fref(nolock)
        -- where fref.u_status='Aberta'
		order by U0002
	ENDTEXT
	If u_sqlexec(msel,"FREFLIST")
			docomando("Do form genlist with 'FREF',.f.,'FREF'")
	Else
		msg("Erro na execução da procura: "+Chr(13)+msel)
	Endif
endfunc

