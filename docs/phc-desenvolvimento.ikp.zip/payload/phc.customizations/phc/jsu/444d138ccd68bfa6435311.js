// JSU (JavaScript de Utilizador)
// stamp: 444d138ccd68bfa6435311
// titulo: Fechar varios dossiers
// ecran: boform
// ordem: 0
// estado: Activo
// inativo: False

var prm = Sys.WebForms.PageRequestManager.getInstance()
prm.add_pageLoaded(function()
{
$('#ctl00_conteudo_TesteBrowlist').insertAfter('#BUINTRODUZIR')
})

