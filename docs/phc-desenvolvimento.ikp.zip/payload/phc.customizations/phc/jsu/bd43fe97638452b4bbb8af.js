// JSU (JavaScript de Utilizador)
// stamp: bd43fe97638452b4bbb8af
// titulo: Análise de Obras - PT
// ecran: gensel
// ordem: 9
// estado: Activo
// inativo: False

function fAnaliseObrasPT (tabela, tipo_listagem) {
    // tipo_listagem = 0 --> Análise Obras
    // tipo_listagem = 1 --> Sub-Análise Custos Materiais
    // tipo_listagem = 2 --> Sub-Análise Custos Mão de Obra
    // tipo_listagem = 3 --> Sub-Análise Custos Deslocações
    // tipo_listagem = 4 --> Sub-Análise Custos Diversos
    // tipo_listagem = 5 --> Sub-Análise Custos Gastos Gerais
    // tipo_listagem = 6 --> Sub-Análise Custos Administrativos
    // tipo_listagem = 7 --> Sub-Análise Faturacao Geral
    // tipo_listagem = 8 --> Sub-Análise Faturacao Detalhe
    // tipo_listagem = 9 --> Sub-Análise Orçamentos Geral
    // tipo_listagem =10 --> Sub-Análise Orçamentos Detalhes
    // tipo_listagem =11 --> Sub-Análise ContaCorrente

    //alert("entrou");

    document.readyState == "complete" ? carrega_tabela(tabela, tipo_listagem) : window.addEventListener("load", carrega_tabela);

};

function carrega_tabela(tabela, tipo_listagem){
    //alert("loaded");
    $(tabela).DataTable({
        stripHtml: true,
        dom: "<'row'<'col-sm-12 col-md-4'B><'col-sm-12 col-md-4'l><'col-sm-12 col-md-4'f>>" +
                "<'row'<'col-'tr>>" +
                "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        buttons: [
            { 
                extend: 'excel', 
                text: 'Excel',
                exportOptions: {
                    format: {
                        body: function (data, row, column, node) {
                            data = DataTable.util.stripHtml(data);
                            if ((((tipo_listagem==0) && (column>=4 && column <=17))) ||
                                (((tipo_listagem==1) && (column==5 || column == 6 || column == 7))) ||
                                (((tipo_listagem==2) && (column>=5 && column <=15))) ||
                                (((tipo_listagem==3) && (column==14))) ||
                                (((tipo_listagem==4) && (column==5 || column == 6 || column == 7))) ||
                                (((tipo_listagem==5) && (column==5 || column == 6 || column == 7 || column == 11 || column == 12 || column == 13))) ||
                                (((tipo_listagem==6) && ((column>=5 && column <=11) || (column>=15 && column <=19)))) ||
                                (((tipo_listagem==7) && (column==3))) ||
                                (((tipo_listagem==8) && (column==6 || column == 7 || column == 8))) ||
                                (((tipo_listagem==9) && (column>=3 && column <=8))) ||
                                (((tipo_listagem==10) && (column>=2 && column <=11))) ||
                                (((tipo_listagem==11) && (column>=1 && column <=12)))
                                )
                            {
                                data = data.replace(/[.]/g,'')
                                data = data.replace(/[,]/g,'.')
                                return data;
                            }
                            else {
                                return data;
                            }
                        },
                        footer: function (data, row, column, node) {
                            data = DataTable.util.stripHtml(data);
                            data = data.replace(/[.]/g,'')
                            data = data.replace(/[,]/g,'.')
                            return data;
                        }
                    }
                }
            },
            {   extend: 'pdf', text: 'PDF' },
            {   extend: 'print', text: 'Imprimir' },
            {   extend: 'colvis', text: 'Colunas Visíveis' }
        ],
        paging: true,
        lengthChange: true,
        order: [],
        colReorder: true,
        fixedHeader: {
            header: true,
            footer: true,
            headerOffset: 50
        },
        //scrollResize: true,
        scrollY: 900,
        scrollX: true,
        scrollCollapse: true,
        language: {
            "lengthMenu": " _MENU_ Registos por página",
            "zeroRecords": "Nenhum registo encontrado",
            "info": "A mostrar _START_ a _END_ (Total de _TOTAL_ registos)",
            "infoEmpty": "Nenhum registo Encontrado",
            "infoFiltered": "(filtrados de _MAX_ registos)",
            "sSearch": "Pesquisar",
            "oPaginate": {
                "sNext": "Próximo",
                "sPrevious": "Anterior",
                "sFirst": "Primeiro",
                "sLast": "Último"
            },
            "decimal": ",",
            "thousands": "."
        },
        footerCallback: function(tfoot, data, start, end, display) {
            var api = this.api();
            var lastRow = api.rows().count();
            for (i = 0; i < api.columns().count(); i++) {
                $(tfoot).find('th').eq(i).html(api.cell(lastRow,i).data());
            }
        },
        lengthMenu: [
            [ -1, 10, 25, 50, 100],
            ['Todos', '10', '25', '50', '100']
        ]                               
    });
    if (document.getElementById('ctl00_conteudo_ana170185_t170185_8').value !== '---')
    { 
        document.getElementById('ctl00_conteudo_ana170185_p170185_1_p170185_1mBox1').value='';
        document.getElementById('ctl00_conteudo_ana170185_p170185_2_p170185_2mBox1').value='';
    };
};

