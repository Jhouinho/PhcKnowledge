* TECLA (ti.retorno)
* tistamp: ADM20010259182,9620000-1
* ecran: SFREF
* teclas: F10
* descricao: Adiciona cliente ao processo
* estado: Activo
* inactivo: False

Iif(EventosExe("RbPrg", "Consultar", .F.), "", "")
Local out_filtro
out_filtro = getnome("Nome do cliente a pesquisar?","","a pesquisa é incluida.")
Do pesquisa_clientes With out_filtro
If Len(Alltrim(fref.frefstamp))>0
	If Len(Alltrim(crs_clientes.clstamp)) > 0
		If !u_sqlexec("update fref set U_NOCLI = '"+astr(crs_clientes.no)+"',U_CLINOME =  '"+Alltrim(crs_clientes.Nome)+"' where frefstamp='"+Alltrim(fref.frefstamp)+"'")
			msg("Não foi possível adicionar o cliente para esta obra. Por favor informe o depº de informática!")
			Return
		Else
			msg("Registo actualizado!")
			sfref.doactualizar
		Endif
	Endif
Endif

