* TECLA (ti.retorno)
* tistamp: ADM20010260625,9090000-1
* ecran: SFREF
* teclas: F11
* descricao: Elimina cliente fref
* estado: Activo
* inactivo: False

Select fref
If Len(Alltrim(fref.frefstamp))>0
	If Len(Alltrim(fref.U_CLINOME))>0
		If pergunta("Tem a certeza da eliminação do cliente?")
			Select fref
			If !u_sqlexec("update fref set U_CLINOME='',U_NOCLI= 0 where frefstamp = '"+Alltrim(fref.frefstamp)+"'")
				msg("Erro ao eliminar a informação. Por favor informe o depº de informática!")
				Return
			Else
				msg("Registo eliminado!")
				sfref.doactualizar
			Endif
		Endif
	Endif
Endif

