* TECLA (ti.retorno)
* tistamp: ADM20010260780,2840000-1
* ecran: SFREF
* teclas: F8
* descricao: Adiciona vendedor ao processo
* estado: Activo
* inactivo: False

Iif(EventosExe("RbPrg", "Consultar", .F.), "", "")
Local out_filtro
out_filtro = getnome("Nome do responsável a pesquisar?","","a pesquisa é incluida.")
Do pesquisa_vendedores With out_filtro
If Len(Alltrim(fref.frefstamp))>0
	If Len(Alltrim(crs_vendedores.cm3stamp)) > 0
		If !u_sqlexec("update fref set U_NUMVND = '"+astr(crs_vendedores.cm)+"',U_NOMEVND =  '"+Alltrim(crs_vendedores.cmdesc)+"' where frefstamp='"+Alltrim(fref.frefstamp)+"'")
			msg("Não foi possível adicionar o responsável para esta obra. Por favor informe o depº de informática!")
			Return
		Else
			msg("Registo actualizado!")
			sfref.doactualizar
		Endif
	Endif
Endif

