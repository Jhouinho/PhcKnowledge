* TECLA (ti.retorno)
* tistamp: ADM20010261550,5400000-1
* ecran: SFREF
* teclas: F9
* descricao: Elimina responsável Fref
* estado: Activo
* inactivo: False

Select fref
If Len(Alltrim(fref.frefstamp))>0
	If Len(Alltrim(fref.U_NOMEVND))>0
		If pergunta("Tem a certeza da eliminação do responsável?")
			Select fref
			If !u_sqlexec("update fref set U_NOMEVND='',U_NUMVND = 0 where frefstamp = '"+Alltrim(fref.frefstamp)+"'")
				msg("Erro ao eliminar a informação. Por favor informe o depº de informática!")
				Return
			Else
				msg("Registo eliminado!")
				sfref.doactualizar
			Endif
		Endif
	Endif
Endif

