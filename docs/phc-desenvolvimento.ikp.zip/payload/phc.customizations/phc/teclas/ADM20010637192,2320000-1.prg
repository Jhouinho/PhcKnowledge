* TECLA (ti.retorno)
* tistamp: ADM20010637192,2320000-1
* ecran: SFREF
* teclas: CTRL+F1
* descricao: Adiciona morada Carga Obra
* estado: Inactivo
* inactivo: True

** ===================================================
** ===== Moradas de Carga do Cliente / Obra
** == RB: JorgeF 06.01.2020
** ==================================================
If Len(Alltrim(fref.frefstamp)) = 0
	Return
Endif
If fref.U_NOCLI= 0
	Msg("Deve ter um cliente escolhido")
	Return
Endif
if len(alltrim(fref.nmfref)) = 0 
	msg(" A obra deverá ter uma descrição para identificação!")
	return
endif
do inserir_SZADRS with 'Carga',fref.fref,fref.U_NOCLI,fref.U_CLINOME,fref.nmfref

