* TECLA (ti.retorno)
* tistamp: ADM20010639062,8480000-1
* ecran: SFREF
* teclas: CTRL+F2
* descricao: Adiciona morada DesCarga Obra
* estado: Activo
* inactivo: False

** ===================================================
** ===== Moradas de Carga do Cliente / Obra
** == RB: JorgeF 06.01.2020
** ==================================================
If Len(Alltrim(fref.frefstamp)) = 0
	Return
Endif
If fref.U_NOCLI= 0
	Msg("Deve ter um cliente escolhido")
	Return
Endif
if len(alltrim(fref.nmfref)) = 0 
	msg(" A obra deverá ter uma descrição para identificação!")
	return
endif
do inserir_SZADRS with 'Descarga',fref.fref,fref.U_NOCLI,fref.U_CLINOME,fref.nmfref

