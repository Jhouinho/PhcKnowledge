* TECLA (ti.retorno)
* tistamp: ADM20010646232,5870000-1
* ecran: SBO
* teclas: F10
* descricao: Insere obra dossier
* estado: Activo
* inactivo: False

** =================================================================
** Preenche a obra (Fref) e a morada de descarga associada
** Jorge F. 06.01.2020
** ===================================================================



Iif(EventosExe("RbPrg", "Consultar", .F.), "", "")



Local in_nome,sql_txt,in_no,in_fref

Store 0 To in_no,in_fref_find,in_nmfref_find

Select bo


Create Cursor xVars (no N(5), tipo c(1), Nome c(40), Pict c(100), lOrdem N(10), nValor N(18,5), cValor c(250), mValor m(10), tbVal m, lValor l, dValor d )

Select xVars
Append Blank
Replace xVars.no With 1
Replace xVars.tipo With "C"
Replace xVars.Nome With "Nrº da Obra"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 1
Replace xVars.cValor With ""

Select xVars
Append Blank
Replace xVars.no With 2
Replace xVars.tipo With "C"
Replace xVars.Nome With "Nome da obra"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 2
Replace xVars.cValor With ""

m.mCaption = "Pesquisa obra"

docomando("do form usqlvar with 'xvars',m.mCaption,.t.")

Select xVars
Go Top
Scan
	If no = 1
		in_fref_find = xVars.cValor
	Else
		in_nmfref_find = xVars.cValor
	Endif

Endscan


TEXT to sql_txt textmerge noshow

	select * from fref (nolock) where
		fref like '<<"%"+alltrim(in_fref_find)+"%">>'
			and nmfref like  '<<"%"+alltrim(in_nmfref_find)+"%">>'

ENDTEXT



If u_sqlexec(sql_txt,"crs_fref1") And Reccount("crs_fref1")>0

	** mostrameisto("crs_fref1")

	=CursorSetProp('Buffering',5,"crs_fref1")
	Declare list_tit(2),list_cam(2),list_tam(2),list_pic(2)
	list_tit(1)="Descrição"
	list_tit(2)="Obra"

	list_cam(1)="crs_fref1.fref"
	list_cam(2)="crs_fref1.nmfref"

	list_pic(1)=""
	list_pic(2)=""

	list_tam(1)=8*60
	list_tam(2)=8*60

	m.escolheu=.F.
	Do	browlist With "Escolha a obra do cliente","crs_fref1","crs_fref1"
	*,.T.,.F.,.F.,.T.,.F.,'',.t.




	If M.escolheu = .F.
		msg("Não escolheu nenhuma obra!")
		in_fref = "%"
	Else
		in_fref = Alltrim(crs_fref1.fref)


		** cllook(crs_fref1.U_CLINOME,"1=1")
		cllook("D. F. BLOCK, LDA  ","estab=0")

		If is_clno(CLEscolha.no,CLEscolha.estab)


			If	SBO.editing = .F. And SBO.adding = .F.

				doread("BO","SBO")
				SBO.newndos(11)
				SBO.dointroduzir

			Else
				SBO.showsave()
			Endif

			Do boclact

		Else
			msg("Não seleccionou nenhum cliente! Não é possível continuar!")
			Return
		Endif


		Select CLEscolha
		** in_no = CLEscolha.no
		in_no = 1

		Do moradas With 'CL','Descarga',in_no,0,in_fref

		Return

	Endif

Else
	msg("Sem registos")
	msg(sql_txt)

Endif


** ============== Pesquisa de cliente

Do Case

	Case SBO.Pageframe1.Page1.no.Value = 0

		m.escolheu = .F.

		in_nome = getnome("Qual o nome do cliente?","")
		in_nome = "%"+Alltrim(in_nome)+"%"


		** cllook(crs_fref1.U_CLINOME,"1=1")
		cllook("D. F. BLOCK, LDA  ","estab=0")

		If is_clno(CLEscolha.no,CLEscolha.estab)


			If	SBO.editing = .F. And SBO.adding = .F.

				doread("BO","SBO")
				SBO.newndos(11)
				SBO.dointroduzir

			Else
				SBO.showsave()
			Endif


			Do boclact




		Else
			msg("Não seleccionou nenhum cliente! Não é possível continuar!")
			Return
		Endif



		Select CLEscolha
		in_no = 1

		Do moradas With 'CL','Descarga',in_no,0,in_fref






	Case SBO.Pageframe1.Page1.no.Value <> 0

		in_no = 1
		** SBO.Pageframe1.Page1.no.Value
		cllook("D. F. BLOCK, LDA  ","estab=0")

		If SBO.editing = .F. And SBO.adding  = .F.

			SBO.showsave()

			Do moradas With 'CL','Descarga',in_no,0,in_fref

		Else

			Do moradas With 'CL','Descarga',in_no,0,in_fref

		Endif

Endcase

