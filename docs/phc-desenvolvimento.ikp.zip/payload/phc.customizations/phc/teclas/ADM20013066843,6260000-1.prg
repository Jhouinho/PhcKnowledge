* TECLA (ti.retorno)
* tistamp: ADM20013066843,6260000-1
* ecran: SFT
* teclas: F12
* descricao: Importar Excel
* estado: Activo
* inactivo: False

Local lc_ficheiro
store "" to lc_ficheiro


lc_ficheiro=GETFILE('XLS,XLSX','Escolha o ficheiro ','Abrir Ficheiro',1,'Escolha o ficheiro')
if empty(lc_ficheiro)
	return .f.
endif

if "XLSX" $ lc_ficheiro

	actform(chr(13)+"A abrir "+alltrim(lc_ficheiro))

	lc_nficheiro = justpath(lc_ficheiro)+"\"+strtran(justfname(lc_ficheiro),".XLSX","_XLS.XLS")

	oExcel = CreateObject("Excel.Application")
	oExcel.Workbooks.Open(lc_ficheiro)
	oExcel.Visible = .T.
	oExcel.DisplayAlerts = .F.
	oExcel.ActiveWorkbook.SaveAs(lc_nficheiro, 39)
	oExcel.ActiveWorkbook.Close()
	oExcel.Quit()

	deactform()

	lc_ficheiro = lc_nficheiro


endif


if used("crsxmls")
	fecha("crsxls")
endif

actform(chr(13)+"A Importar "+alltrim(lc_ficheiro))

create cursor crsxls (design c(60), refe c(60), qtt n(14,4), epv n(19,4))
select crsxls
go top
append from (lc_ficheiro) xls
select crsxls
go top
delete next 1
go top

scan

	select fi
	Do Ftine2in

	select fi
	replace fi.qtt with crsxls.qtt,;
			fi.epv with  crsxls.epv,;
			fi.stipo with 4

	do u_ftiliq

	if len(alltrim(crsxls.design) + " " +alltrim(crsxls.refe))<=60

			select fi
			replace fi.design with alltrim(crsxls.design) + " " +alltrim(crsxls.refe)

		else

			select fi
			replace fi.design with left(alltrim(crsxls.design) + " " +alltrim(crsxls.refe),60)
			
			select fi
			Do Ftine2in

			select fi
			replace fi.design with substr(alltrim(crsxls.design) + " " +alltrim(crsxls.refe),61,60)

	endif
	
	do fttots with .t.

	select crsxls
endscan

select fi
go top

sft.refresh()
sft.localrefrescar()

deactform()

mensagem("Importação concluída","directa")

