* TECLA (ti.retorno)
* tistamp: ADM20031234972,2490000-1
* ecran: SST
* teclas: SHIFT+F3
* descricao: Importação de Artigos (via Excel)
* estado: Activo
* inactivo: False

* Escolher o ficheiro em Excel para importar 
xlsFile=Getfile("XLS","Ficheiro","Escolher",0,"Selecione o Ficheiro a Importar")

If Type("xlsFile")<>"C" Or Not File(xlsFile)
    Msg("Ficheiro não encontrado")
Return
Endif
* Cria o cursor ARTIGO que vai conter os registos do ficheiro em excel 
Create cursor stCursor (ref C(18),design C(60),familia c(30), faminome c(60), marca c(20), modelo c(20), linhaProd c(35),tipoProd c(20), classe c(30), unidade c(4), epcusto N(19,6), epv1 N(19,6))

Set Point To "."

Append From (xlsFile) xls

Select stCursor
mostrameisto("stCursor")

Scan
	* Verifica se o artigo existe na bd
	mclsel=[SELECT st.ref FROM st (nolock) WHERE st.ref =']+astr(stCursor.ref)+[']
	If u_sqlexec(mclsel,"crsRef")
		Select crsRef
		If Reccount ("crsRef")=0

			Do dbfusest
			Select st
			Append Blank

			Replace st.ref  With stCursor.ref
			Replace st.design  With stCursor.design
			Replace st.familia With stCursor.familia
            Replace st.faminome With stCursor.faminome
			Replace st.usr1  With stCursor.marca && marca
            Replace st.usr2  With stCursor.modelo && modelo	
			Replace st.usr3  With stCursor.linhaProd && linha de produto 
            Replace st.usr4  With stCursor.tipoProd && tipo de produto
            Replace st.usr6  With stCursor.classe && classe
			Replace st.unidade  With stCursor.unidade 
			Replace st.epcusto  With stCursor.epcusto
			Replace st.pcusto With stCursor.epcusto*200.482
			Replace st.epv1  With stCursor.epv1
			Replace st.pv1 With stCursor.epv1*200.482
			Replace st.tabiva With 2
			Replace st.ststamp With u_stamp(Recno("stCursor"))
			Replace st.usrdata With Date()
			Replace st.usrinis With m_chinis
			Replace st.usrhora With Time()
			Replace st.ousrhora With Time()
			Replace st.ousrdata With Date()
			Replace st.ousrinis With m_chinis

			Wait Window "A inserir artigo... " Nowait

			If Not u_TabUpdate (.T.,.T.,"st")
				Tablerevert(.T.,"st")
				Msg("Não foi possível inserir o artigo. "+astr(Recno("stCursor")))
                Return
			Else
				Text to sqlTxt TextMerge NoShow
                    SELECT stobs.ref FROM stobs (nolock) WHERE stobs.ref = '<<alltrim(stCursor.ref)>>'
				EndText

				If u_sqlexec(sqlTxt,"crsStobs")
                    Select crsStobs

                    If Reccount ("crsStobs")=0
                        If !u_sqlexec("INSERT INTO stobs (stobsstamp, ref) SELECT st.ststamp, st.ref FROM st (nolock) WHERE st.ref='"+Alltrim(stCursor.ref)+"'")
                            Msg("Erro ao inserir na stobs!")
                        EndIf 

                        Text To sqlUpdStobs TextMerge NoShow
                            UPDATE stobs SET tipoprod=(SELECT stfami.tipoprod FROM stfami WHERE stfami.ref ='<<alltrim(stCursor.familia)>>') WHERE stobs.ref='<<alltrim(stCursor.ref)>>'
				        EndText

                        If !u_sqlexec(sqlUpdStobs)
                            Msg("Erro ao atualizar o tipo para inventário do artigo!")
                        EndIf
					Endif
				Else
                    Msg("Erro ao selecionar!")
				Endif
			Endif
		Endif
	Endif
Endscan

MSG("Fim de importação")

