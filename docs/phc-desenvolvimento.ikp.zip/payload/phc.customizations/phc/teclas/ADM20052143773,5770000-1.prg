* TECLA (ti.retorno)
* tistamp: ADM20052143773,5770000-1
* ecran: SSTIC
* teclas: CTRL+0
* descricao: Importação de Inventário
* estado: Activo
* inactivo: False

*
* Importação ficheiro Excel para inventário
* HCA 05.01.2020
*



Local lc_ficheiro, lc_nficheiro, ln_lordem, InArmazem
store "" to lc_ficheiro, lc_nficheiro 
store 0 to ln_lordem

Msg("As colunas do ficheiro de importação deverão ser: ref c(18), design c(60), qtt n(14,4), evalstock n(19,6), unidade c(10), armazem n(5)")



lc_ficheiro=GETFILE('XLS,XLSX','Escolha o ficheiro ','Abrir Ficheiro',1,'Escolha o ficheiro')
if empty(lc_ficheiro)
	return .f.
endif

if "XLSX" $ lc_ficheiro

	actform(chr(13)+"A abrir "+alltrim(lc_ficheiro))

	lc_nficheiro = justpath(lc_ficheiro)+"\"+strtran(justfname(lc_ficheiro),".XLSX","_XLS.XLS")

	oExcel = CreateObject("Excel.Application")
	oExcel.Workbooks.Open(lc_ficheiro)
	oExcel.Visible = .T.
	oExcel.DisplayAlerts = .F.
	oExcel.ActiveWorkbook.SaveAs(lc_nficheiro, 39)
	oExcel.ActiveWorkbook.Close()
	oExcel.Quit()

	deactform()

	lc_ficheiro = lc_nficheiro


endif

create cursor crstmp (ref c(18), design c(60), qtt n(14,4), evalstock n(19,6), unidade c(10), armazem n(5))
select crstmp
append from (lc_ficheiro) xls
go top
delete next 1
go top




actform(chr(13)+"A importar "+alltrim(lc_ficheiro))

select crstmp 
scan

	ln_lordem = ln_lordem + 1000


	* if is_stref(ALLTRIM(crstmp.ref)) 

		* msg("existe")

		select stil
		append blank

		replace stil.stilstamp	with	u_stamp(),;
				stil.sticstamp	with	stic.sticstamp,;
				stil.data		with	stic.data,;
				stil.lordem		with	ln_lordem,;
				stil.ref		with	crstmp.ref,;
				stil.design		with	crstmp.design,;
				stil.armazem	with	crstmp.armazem,;
				stil.usalote	with	.f.,;
				stil.stock		with	crstmp.qtt,;
				stil.cpoc		with	GetUmValorNumerico("ST","ST.cpoc","st.ref='"+crstmp.ref+"'"),;
				stil.evalstock  with    crstmp.evalstock,;
                stil.unidade    with    crstmp.unidade,;
				stil.valstock   with    crstmp.evalstock*200.482
				
	* endif

	select crstmp
endscan

deactform()

sstic.refresh()

mensagem("Importação Concluída...","directa")

