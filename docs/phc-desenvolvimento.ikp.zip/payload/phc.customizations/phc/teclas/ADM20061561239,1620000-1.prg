* TECLA (ti.retorno)
* tistamp: ADM20061561239,1620000-1
* ecran: SST
* teclas: CTRL+F12
* descricao: Atualização Custo Dossier Saida
* estado: Activo
* inactivo: False

Local lc_strsql, ll_soref
Store "" to lc_strsql
Store .f. to ll_soref

if !empty(st.ref)
		if pergunta("Atualizar só a ref.ª " + alltrim(st.ref),2,"Não para atualizar todas")
			ll_soref = .t.
		endif	
	else
		return .f.
endif

if ll_soref = .t.

		text to lc_strsql noshow

			declare @bistamp char(25),
					@epcpond numeric(19,6),
					@pcpond numeric(18,5)

			declare crspivo scroll cursor
			for	select 
					a.epcpond, a.pcpond, a.bistamp
				from sl a (nolock)
					join bi b (nolock) on a.bistamp=b.bistamp
				where	a.ref=?st.ref
						and a.origem='BO'
						and a.cm>50
						and a.epcpond<>b.epcusto 

			open crspivo
				fetch from crspivo into @epcpond, @pcpond, @bistamp
				while @@fetch_status=0
				begin
			
					update bi set
						epcusto = @epcpond,
						pcusto = @pcpond

					where bistamp=@bistamp		

					fetch from crspivo into @epcpond, @pcpond, @bistamp
				end

			close crspivo
			deallocate crspivo

		endtext

	else

		text to lc_strsql noshow

			declare @bistamp char(25),
					@epcpond numeric(19,6),
					@pcpond numeric(18,5)

			declare crspivo scroll cursor
			for	select 
					a.epcpond, a.pcpond, a.bistamp
				from sl a (nolock)
					join bi b (nolock) on a.bistamp=b.bistamp
				where	a.origem='BO'
						and a.cm>50
						and a.epcpond<>b.epcusto 

			open crspivo
				fetch from crspivo into @epcpond, @pcpond, @bistamp
				while @@fetch_status=0
				begin
			
					update bi set
						epcusto = @epcpond,
						pcusto = @pcpond

					where bistamp=@bistamp		

					fetch from crspivo into @epcpond, @pcpond, @bistamp
				end

			close crspivo
			deallocate crspivo
			

		endtext

endif

actform("A processsar atualização dos custos dossiers")

u_sqlexec(lc_strsql)

deactform()

