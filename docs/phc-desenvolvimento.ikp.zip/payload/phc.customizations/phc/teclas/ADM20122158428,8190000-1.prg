* TECLA (ti.retorno)
* tistamp: ADM20122158428,8190000-1
* ecran: SFL
* teclas: F4
* descricao: Aprovação de Compras
* estado: Activo
* inactivo: False

Local msel,dti,aprov


m.dti=getnome("Data do vencimento menor ou igual a: ",Ctod(""))

TEXT to Msel TextMerge Noshow

	select
	FC.ORIGEM,
	fc.nome,fc.cmdesc as docnome,fc.adoc,fc.datalc as docdata,fc.dataven as docVenc,
	isnull(fo.etotal,0) as TotalCompra,
	abs(fc.edeb-fc.ecred-(fc.edebf-fc.ecredf)) as Pendente,
	isnull(fo.fostamp,'') as fostamp,
	isnull(fo.aprovado,0) as aprovado

	from fc (nolock)
		join fl (nolock) on fl.no=fc.no and fc.estab = fl.estab
				left join fo (nolock) on fo.fostamp=fc.fostamp
	where
	1=1
	and fc.dataven <= '<<Dtos(m.dti)>>'

	and
	(case when fc.moeda like 'EURO' or fc.moeda=space(11) then abs(fc.edeb-fc.ecred-(fc.edebf-fc.ecredf))
	else abs(fc.debm-fc.credm-(fc.debfm-fc.credfm)) end) > (case when fc.moeda like 'EURO' or fc.moeda=space(11) then 0.010000 else 0 end)

	-- and isnull(fo.aprovado,0) = 0


	order by fc.dataven , fc.nome asc

ENDTEXT


*	m.dti=getnome("Qual a data do Documento <= a: ",Ctod(""))
*	msel="select nome,docnome,adoc,docdata,PDATA,etotal TotalCompra,0 as Pendente,fostamp from fo (nolock) where docdata<= '"+Dtos(m.dti)+"' and aprovado=0 order by nome asc,docdata asc "


Create Cursor compra(origem c(10), Nome c(80), docnome c(50), Adoc c(50), docdata d(12),docVenc d(12), TotalCompra N(16,2), Pendente N(16,2), simnao l(1), Saldo N(16,2),stamp c(30), aprovado l(1))


* msg(msel)

u_sqlexec(msel,"temp")

If Reccount("temp") >0
	lcColumnsTot = 11
	Declare list_tit(lcColumnsTot), list_cam(lcColumnsTot), list_tam(lcColumnsTot), list_pic(lcColumnsTot), list_ronly(lcColumnsTot),list_valid(lcColumnsTot),list_rot(lcColumnsTot)
	list_tit(1)="Fornecedor"
	list_tit(2)="Documento"
	list_tit(3)="Número do doc."
	list_tit(4)="Data do doc."
	list_tit(5)="Data Vencimento"
	list_tit(6)="Total Documento"
	list_tit(7)="Total Vencido"
	list_tit(8)="Saldo Pagar"
	list_tit(9)="Sim/Nao"
	list_tit(10)="Marcar/Desmarcar"
	list_tit(11)="Já aprovado"


	list_cam(1)="compra.nome"
	list_cam(2)="compra.docnome"
	list_cam(3)="compra.adoc"
	list_cam(4)="compra.docdata"
	list_cam(5)="compra.docVenc"
	list_cam(6)="compra.TotalCompra"
	list_cam(7)="compra.pendente"
	list_cam(8)="compra.Saldo"
	list_cam(9)="compra.simnao"
	* list_cam(9)="compra.simnao"
	list_cam(11)="compra.aprovado"

	list_pic(1)=""
	list_pic(2)=""
	list_pic(3)=""
	list_pic(4)="##.##.####"
	list_pic(5)="##.##.####"
	list_pic(6)="999,999,999.99 €"
	list_pic(7)="999,999,999.99 €"
	list_pic(8)="999,999,999.99 €"
	list_pic(9)="LOGIC"
	list_pic(11)="LOGIC"

	list_pic(10)="BOTAO TXT:Marcar/Desmarcar"
	list_ronly(1)=.T.
	list_ronly(2)=.T.
	list_ronly(3)=.T.
	list_ronly(4)=.T.
	list_ronly(5)=.T.
	list_ronly(6)=.T.
	list_ronly(7)=.T.
	list_ronly(8)=.T.
	list_ronly(9)=.T.
	list_ronly(10)=.T.
	list_rot(10) = "GetSaldo()"
	list_ronly(11)=.T.
	list_tam=8*10

	Select temp
	Scan
		Select compra
		Append Blank
		Replace compra.origem With temp.origem
		Replace compra.Nome With temp.Nome
		Replace compra.docnome With temp.docnome
		Replace compra.Adoc With temp.Adoc
		Replace compra.docdata With temp.docdata
		Replace compra.docVenc With temp.docVenc
		Replace compra.Pendente With temp.Pendente
		Replace compra.TotalCompra With temp.TotalCompra
		Replace compra.stamp With temp.fostamp
		Replace compra.aprovado With temp.aprovado
		Replace compra.simnao With temp.aprovado


	Endscan

	m.escolheu=.F.
	=CursorSetProp("Buffering",5,"compra")
	mcampobold = "compra.simnao"
	mcampoitalic = .F.
	browlist("Listagem de compras a aprovar. Nota: apenas para documentos c/ origem em FC (compras).","Compra","meubrowlista",.T.)

	If m.escolheu
		u_sqlexec("BEGIN TRANSACTION")
		Local aprov
		Select compra
		m.mactrec=1
		m.mtotrec=Reccount()
		regua(0,m.mtotrec,"A aprovar as compras!!!!")

		Scan
			If compra.simnao=.T.
				If ALLTRIM(compra.origem) = "FO"
					regua(1,m.mactrec,"Registo actual:"+compra.docnome+compra.Adoc)
					m.mactrec=m.mactrec+1
					aprov=""
					m.aprov=m.aprov+[update fo set nmaprov=']+m.m_chnome+[', aprovado=1, dtaprov=getdate() where fo.fostamp=']+compra.stamp+[']

					If Not u_sqlexec(m.aprov)
						msg("Erro ao actualizar as compras! Informe por favor o deoº de informática")
						u_sqlexec("ROLLBACK")
						regua(2)
						Return .F.
					Endif
				Endif
			Endif

			If compra.simnao=.F.
				If ALLTRIM(compra.origem) = "FO"
					If compra.aprovado=.T.
						* Messagebox("ESTA APROVADA VOU DESAPROVAR")
						regua(1,m.mactrec,"Registo actual:"+compra.docnome+compra.Adoc)
						m.mactrec=m.mactrec+1
						aprov=""
						m.aprov=m.aprov+[update fo set nmaprov=']+m.m_chnome+[', aprovado=0, dtaprov=getdate() where fo.fostamp=']+compra.stamp+[']

						If Not u_sqlexec(m.aprov)
							msg("Erro ao actualizar as compras! Informe por favor o deoº de informática")
							u_sqlexec("ROLLBACK")
							regua(2)
							Return .F.
						Endif

					Endif
				Endif
			Endif




		Endscan
		regua(2)
		u_sqlexec("COMMIT TRANSACTION")
		msg("Actualização das compras concluida")

		* Select fo
		fecha("TEMP")
	Endif
Else
	Messagebox ("Não existem compras nas datas seleccionadas !!")
Endif

Function GetSaldo()
	Lparameters param11 As Char, param12 As numeric, param13 As Char
	Select compra
	lcRowNum = Recno()
	If compra.simnao = .T.
		Replace compra.simnao With .F.
	Else
		Replace compra.simnao With .T.
	Endif
	lcValues = 0
	Select compra
	Go Top
	Scan
		If compra.simnao = .T.
			lcValues = lcValues +  compra.Pendente
			Replace compra.Saldo With lcValues
		Else
			Replace compra.Saldo With 0
		Endif
	Endscan
	Goto lcRowNum
Endfunc

