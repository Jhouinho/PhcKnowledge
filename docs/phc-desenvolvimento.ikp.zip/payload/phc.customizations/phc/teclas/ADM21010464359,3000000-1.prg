* TECLA (ti.retorno)
* tistamp: ADM21010464359,3000000-1
* ecran: SBO
* teclas: F11
* descricao: Develop Jorge HCA
* estado: Activo
* inactivo: False

*
* HCA - Jorge F. 14.01.2020 | Calcula PCMP linha à data do dossier
* Campos a afetar BI eSLVU,eSLTT,SLVU,SLTT
*
*
*
* Calcula Pcmp entre datas de uma referência excluindo os lançamentos de inventário
* Só linha com PCMP = select * from FT_HcaCalculaPcmP('FAP-425-O','2','20210113') WHERE TIPO = 'T'
* Lista com tudo = select * from FT_HcaCalculaPcmP('FAP-425-O','1','20991231') WHERE TIPO = 'L'


Local LvSqltxt

Create Cursor CrsBiPcmp (sel l(1), bistamp c(25),REF c(18),Design c(60), qtt N(10,3), EPCUSTO N(16,3) , ESLTT N(16,3) ,ESLVU N(16,3), ESLTTNovo N(16,3), ESLVUnovo N(16,3), Diferenca N(16,3))

Select bi
Go Top

Scan

	If bi.qtt > 0

		TEXT to LvSqltxt TextMerge Noshow

	select * from FT_HcaCalculaPcmP('<<alltrim(bi.ref)>>','2','<<dtos(bi.rdata))>>') WHERE TIPO = '<<"T">>'

		ENDTEXT

		If u_sqlexec(LvSqltxt,"CrsConsultaPCMP")
			If Reccount("CrsConsultaPCMP") >0

				Select CrsBiPcmp
				Append Blank
				Replace sel With .T.
				Replace bistamp With bi.bistamp
				Replace REF With bi.REF
				Replace Design With bi.Design
				Replace qtt With bi.qtt
				Replace ESLTT With bi.ESLTT
				Replace ESLVU With bi.ESLVU
				Replace EPCUSTO With bi.EPCUSTO
				Replace ESLTTNovo With CrsConsultaPCMP.pcmp * bi.qtt
				Replace ESLVUnovo With CrsConsultaPCMP.pcmp
				Replace Diferenca With CrsConsultaPCMP.pcmp - bi.EPCUSTO
			Endif


		Endif
	Endif

Endscan


* mostrameisto("CrsBiPcmp")

Declare list_tit(6),list_cam(6),list_tam(6),list_pic(6),list_ronly(6)

list_tit(1)="Sel"
list_cam(1)="CrsBiPcmp.sel"
list_tam(1)=18
list_pic(1)='LOGIC'
list_ronly(1)=.F.

list_tit(2)="Ref"
list_cam(2)="CrsBiPcmp.ref"
list_tam(2)=18
list_pic(2)=''
list_ronly(2)=.F.

list_tit(3)="Ref"
list_cam(3)="CrsBiPcmp.design"
list_tam(3)=18
list_pic(3)=''
list_ronly(3)=.F.

list_tit(4)="PCMP"
list_cam(4)="CrsBiPcmp.ESLVU"
list_tam(4)=18
list_pic(4)=''
list_ronly(4)=.F.

list_tit(5)="PCMP"
list_cam(5)="CrsBiPcmp.ESLVUnovo"
list_tam(5)=18
list_pic(5)=''
list_ronly(5)=.F.

list_tit(6)="Diferença"
list_cam(6)="CrsBiPcmp.diferenca"
list_tam(6)=18
list_pic(6)=''
list_ronly(6)=.F.


m.escolheu = .F.

=CursorSet('Buffering',5,"CrsBiPcmp")
browlist("Selecção de artigos para recalculo","CrsBiPcmp","CrsBiPcmp",.T.,.F.,.F.,.T.,.F.)

If m.escolheu = .T.

	If pergunta("Actualiza os PCMP no movimento de stocks (SL)")

		Select CrsBiPcmp

		Scan

			If CrsBiPcmp.Diferenca <> 0 And CrsBiPcmp.sel = .T.

				TEXT to LvSqlTXt TextMerge Noshow

		update bi set

			ESLTT = '<<strtran(alltrim(str(CrsBiPcmp.ESLTTNovo,16,3)),',','.') >>',
			ESLVU = '<<strtran(alltrim(str(CrsBiPcmp.ESLVUnovo,16,3)),',','.') >>',
			EPCUSTO = '<<strtran(alltrim(str(CrsBiPcmp.ESLVUnovo,16,3)),',','.') >>',

			SLTT = '<<strtran(alltrim(str(CrsBiPcmp.ESLTTNovo*200.482,16,3)),',','.') >>',
			SLVU = '<<strtran(alltrim(str(CrsBiPcmp.ESLVUnovo*200.482,16,3)),',','.') >>',
			PCUSTO = '<<strtran(alltrim(str(CrsBiPcmp.ESLVUnovo*200.482,16,3)),',','.') >>'

		where bistamp = '<<CrsBiPcmp.bistamp>>'

				ENDTEXT

				If !u_sqlexec(LvSqltxt)

					msg("Erro ao atualizar a linha do dossier. Por favor informe o depº de informática!")

				Endif


			Endif

		Endscan
		sbo.doactualizar()

		msg("Fim de procedimento!")

	Endif

Endif

