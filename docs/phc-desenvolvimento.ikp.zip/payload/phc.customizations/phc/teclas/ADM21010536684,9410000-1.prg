* TECLA (ti.retorno)
* tistamp: ADM21010536684,9410000-1
* ecran: SBO
* teclas: F12
* descricao: VL Rb
* estado: Activo
* inactivo: False

**Refresh Bubbles :: Valdemar Lopes
**Vr1 - 31/01/2020


Set Talk Off
Local lc_XLBook As String, ln_SQLHand As Integer, lc_SQLCmd As String, ln_Success As Integer, lc_Connstr As String, ln_treg, ln_nreg


Try

	if sbo.adding = .f. and sbo.editing = .f.
		sbo.dointroduzir()	
	endif

	v_agstamp = "ADM20013068625,631592588"
	u_requery("AG")

	boclact("MAIN",.f.)

	sbo.refresh()

	SBO.Pageframe1.Page1.Cont1.Grid1.setfocus()
	


	lc_XLBook = Getfile('XLS,XLSX','Escolha o ficheiro ','Abrir Ficheiro',1,'Escolha o ficheiro')
	lc_Connstr = "Driver=" + "{Microsoft Excel Driver (*.xls, *.xlsx, *.xlsm, *.xlsb)};" + "DBQ=" + lc_XLBook
	*lc_Connstr = "Driver=" + "{Microsoft Excel Driver (*.xls)};" + "DBQ=" + lc_XLBook

	If !File( lc_XLBook )
		mensagem("Excel file not found","directs","directa")
		throw 9999
	Endif

	ln_SQLHand = Sqlstringconnect(lc_Connstr)
	lc_SQLCmd = [Select * FROM "PHC$"]
	ln_Success = SQLExec( ln_SQLHand, lc_SQLCmd, "crsxls" )

	If ln_Success < 0
		Local Array laErr(1)
		Aerror( laErr )
		mensagem(laErr(3),"directa")
		SQLDisconnect( ln_SQLHand )
		throw 9999
	Endif

	SQLDisconnect( ln_SQLHand )

	actform(chr(13)+"A Importar "+alltrim(justfname(lc_XLBook)))

	Select crsxls
	go top

	scan

		select bi
		Do Boine2in

		select bi
		replace bi.ref with "HRS",;
				bi.stipo with 4


		Do BOACTREF with '',.t.,'OKPRECOS','BI'

		select bi
		if !isnull(crsxls.dia)
			replace bi.rdata with ttod(crsxls.dia)
		endif
		if !isnull(crsxls.num__functionário)
			replace bi.u_peno with crsxls.num__functionário
		endif
		if !isnull(crsxls.funcionário)
			replace bi.u_penome with crsxls.funcionário
		endif
		if !isnull(crsxls.cliente)
			replace bi.u_nmcl with crsxls.cliente
		endif
		if !isnull(crsxls.obra)
			replace bi.bifref with crsxls.Obra
		endif
		if !isnull(crsxls.veículo)
			replace bi.u_viatura with crsxls.veículo
		endif
		if !isnull(crsxls.km_iniciais)
			replace bi.u_kmi with crsxls.km_iniciais
		endif
		if !isnull(crsxls.km_finais)
			replace bi.u_kmf with crsxls.km_finais
		endif

		replace bi.u_km with bi.u_kmf-bi.u_kmi

		if !isnull(crsxls.tarefa)
			replace bi.u_tarefa  with crsxls.tarefa
		endif

		if !isnull(crsxls.início)
			replace bi.u_hri with substr(ttoc((crsxls.início)),12,5)
		endif
		if !isnull(crsxls.fim)
			replace bi.u_hrf with substr(ttoc((crsxls.fim)),12,5)
		endif
		if !isnull(crsxls.início__extra_)
			replace bi.u_iextra with substr(ttoc((crsxls.início__extra_)),12,5)
		endif
		if !isnull(crsxls.fim__extra_)
			replace bi.u_fextra with substr(ttoc((crsxls.fim__extra_)),12,5)
		endif

		if !isnull(crsxls.horas_normais)
			replace bi.u_hrsn with val(crsxls.horas_normais)
		endif
		if !isnull(crsxls.horas_extra__50__)
			replace bi.u_hrs50 with val(crsxls.horas_extra__50__)
		endif
		if !isnull(crsxls.horas_extra__75__)
			replace bi.u_hrs75 with val(crsxls.horas_extra__75__)
		endif
		if !isnull(crsxls.horas_extra__100__)
			replace bi.u_hrs100 with val(crsxls.horas_extra__100__)
		endif
		if !isnull(crsxls.observações)
			replace bi.u_obs with crsxls.observações
		endif	

		select crsxls
	endscan

	select bi
	go top

	sbo.refresh()
	sbo.localrefrescar()

	deactform()

	mensagem("Importação concluída","directa")

CATCH TO oErr WHEN oErr.UserValue=9999
	deactform()
CATCH TO oErr
	deactform()
	lc_errmsg = oErr.Message + chr(13) + ;    
				">>Linha nº     : " + astr(oErr.LineNo) + chr(13)

	mensagem(lc_errmsg,"directa")
ENDTRY

