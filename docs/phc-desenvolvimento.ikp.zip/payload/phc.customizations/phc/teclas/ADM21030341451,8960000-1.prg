* TECLA (ti.retorno)
* tistamp: ADM21030341451,8960000-1
* ecran: SST
* teclas: CTRL+F11
* descricao: Atualização Custo Dossier Saida HCA
* estado: Inactivo
* inactivo: True

*
* HCA: 03.03.21 JF
*


Local lc_strsql, ll_soref
Store "" to lc_strsql
Store .f. to ll_soref

if !empty(st.ref)
		if pergunta("Atualizar só a ref.ª " + alltrim(st.ref),2,"Não para atualizar todas")
			ll_soref = .t.
		endif	
	else
		return .f.
endif

if ll_soref = .t.

		text to lc_strsql noshow

			declare @bistamp char(25),
					@epcpond numeric(19,6),
					@pcpond numeric(18,5),
					@CalculoPCMP numeric(18,5)


			declare crspivo scroll cursor
			for	select 
					a.epcpond, a.pcpond, a.bistamp, 
					case 
					when a.cm = 3 then 
					-- isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',a.datalc) WHERE TIPO = 'T'),0) as CalculoPCMP
					isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',
							(
							case when b.obistamp = '' then a.datalc 
								when b.obistamp <> '' and 
									(select cm2.mudapcpond from cm2 (nolock) where cm2.cm = 
										(select ts.cmstocks from ts (nolock) where ts.ndos =
											(select bi.ndos from bi  (nolock) where bi.bistamp = b.obistamp))) = 0 
												then isnull((select bi.dataobra from bi (nolock) where bi.bistamp = b.obistamp),'') 
								else isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',a.datalc) WHERE TIPO = 'T'),0) 
							end)
							)
							WHERE TIPO = 'T'),0) 
					when a.cm = 20 then b.edebito			
					else isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',a.datalc) WHERE TIPO = 'T'),0) 
					end
					as CalculoPCMP
 
				from sl a (nolock)
					left join bi b (nolock) on a.bistamp=b.bistamp
				where	a.ref=?st.ref
						--and a.origem='BO'
						--and a.cm>50
						--and a.epcpond<>b.epcusto 
						order by a.datalc,a.ousrhora asc

			open crspivo
				fetch from crspivo into @epcpond, @pcpond, @bistamp, @CalculoPCMP 
				while @@fetch_status=0
				begin
			
					update bi set
						epcusto = @CalculoPCMP,
						pcusto = @CalculoPCMP*200.482,
						SLVU = @CalculoPCMP*200.482 ,
						eslvu = @CalculoPCMP, 
						SLTT = (@CalculoPCMP * 200.482)*BI.QTT, 
						ESLTT= (@CalculoPCMP*BI.QTT)

					where bistamp=@bistamp		

					fetch from crspivo into @epcpond, @pcpond, @bistamp, @CalculoPCMP 
				end

			close crspivo
			deallocate crspivo

		endtext




	else

		text to lc_strsql noshow

			declare @bistamp char(25),
					@epcpond numeric(19,6),
					@pcpond numeric(18,5)

			declare crspivo scroll cursor
			for	select 
					a.epcpond, a.pcpond, a.bistamp, 
					-- isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',a.datalc) WHERE TIPO = 'T'),0) as CalculoPCMP
					isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',
							(
							case when b.obistamp = '' then a.datalc 
								when b.obistamp <> '' and 
									(select cm2.mudapcpond from cm2 (nolock) where cm2.cm = 
										(select ts.cmstocks from ts (nolock) where ts.ndos =
											(select bi.ndos from bi  (nolock) where bi.bistamp = b.obistamp))) = 1 
												then isnull((select bi.dataobra from bi (nolock) where bi.bistamp = b.obistamp),'') 
								else isnull((select pcmp from FT_HcaCalculaPcmP(a.ref,'2',a.datalc) WHERE TIPO = 'T'),0) 
							end)
							)
							WHERE TIPO = 'T'),0) as CalculoPCMP

				from sl a (nolock)
					join bi b (nolock) on a.bistamp=b.bistamp
				where	a.origem='BO'
						-- and a.cm>50
						-- and a.epcpond<>b.epcusto 

			open crspivo
				fetch from crspivo into @epcpond, @pcpond, @bistamp, @CalculoPCMP 
				while @@fetch_status=0
				begin
			
					update bi set
						epcusto = @CalculoPCMP,
						pcusto = @CalculoPCMP*200.482,
						SLVU = @CalculoPCMP*200.482 ,
						eslvu = @CalculoPCMP, 
						SLTT = (@CalculoPCMP * 200.482)*BI.QTT, 
						ESLTT= (@CalculoPCMP*BI.QTT)

					where bistamp=@bistamp		

					fetch from crspivo into @epcpond, @pcpond, @bistamp, @CalculoPCMP 
				end

			close crspivo
			deallocate crspivo
			

		endtext

endif

msg(lc_strsql)
actform("A processsar atualização dos custos dossiers")
		
u_sqlexec(lc_strsql)

deactform()

