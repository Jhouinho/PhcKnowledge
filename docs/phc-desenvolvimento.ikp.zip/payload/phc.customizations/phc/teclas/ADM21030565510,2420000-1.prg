* TECLA (ti.retorno)
* tistamp: ADM21030565510,2420000-1
* ecran: SST
* teclas: CTRL+F9
* descricao: Atualização Custo Dossier Saida HCA1
* estado: Activo
* inactivo: False

* Rotina de recalculo de PCMP 
*	HCA | JF 23.03.2021 | 
* Parametro4:	StockAtual caso utiliza PCMP relativo ao stock à data
*				QttEntrada  caso utiliza PCMP relativo ao stock acumuldado de entrada
* 				Até 24.03.2021: exec dbo.sp_HcaCalculaPcmPv1 '<<alltrim(sst.ref.value)>>','19000101','<<dtos(date())>>','QttEntrada',1,3,1
* 				Foi incluido o movimento Cm 3 e Cm 10 

Local LvSqlTxt,LvMensag


LvMensag = "Deseja corrigir o pcmp do artigo "+Alltrim(sst.ref.Value)

If pergunta(LvMensag)

	actform(Chr(13)+LvMensag)

	TEXT To LvSqlTxt TextMerge Noshow

	exec dbo.sp_HcaCalculaPcmPv2 '<<alltrim(sst.ref.value)>>','19000101','<<dtos(date())>>','StockAtual',1,3,10,1,1


	ENDTEXT

	If u_sqlexec(LvSqlTxt)
		Do stact1 With 'UM',Alltrim(sst.ref.Value),.T.,.T.,.F.,.T.,.F.
	Endif

Endif

* msg(LvSqlTxt)

deactform()

sst.doactualizar()

