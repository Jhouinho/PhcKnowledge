* TECLA (ti.retorno)
* tistamp: ADM21030566508,1170000-1
* ecran: SST
* teclas: CTRL+F8
* descricao: Atualização Custo Dossier Saida HCA1 All
* estado: Activo
* inactivo: False

* Rotina de recalculo de PCMP 
*	HCA | JF 23.03.2021 | 
* Parametro4:	StockAtual caso utiliza PCMP relativo ao stock à data
*				QttEntrada  caso utiliza PCMP relativo ao stock acumuldado de entrada
* 				Até 24.03.2021: exec dbo.sp_HcaCalculaPcmPv1 '<<alltrim(sst.ref.value)>>','19000101','<<dtos(date())>>','QttEntrada',1,3,1
* 				Foi incluido o movimento Cm 3 e Cm 10 


Local LvSqlTxt,LvMensag

LvMensag = "Deseja corrigir o pcmp dos artigos? Processo demorado!"

If pergunta(LvMensag)

	* u_sqlexec("update st set marcada = 0 where marcada = 1")
	* u_sqlexec("update st set marcada = 1 where marcada = 0 and ref in (select distinct ref from bi (nolock) where   ndos in (19,20))")


	u_sqlexec("Select st.ref from st (nolock) where st.stns=0 and st.inactivo = 0 and marcada = 1","CrsSt")

	Select CrsSt
	Scan

		LvMensag = "...actualizar "+Alltrim(CrsSt.ref)

		actform(Chr(13)+LvMensag)

		TEXT To LvSqlTxt TextMerge Noshow

		exec dbo.sp_HcaCalculaPcmPv2 '<<alltrim(CrsSt.ref)>>','19000101','<<dtos(date())>>','StockAtual',1,3,10,1,1;

		

		ENDTEXT

		If u_sqlexec(LvSqlTxt)
			Do stact1 With 'UM',Alltrim(CrsSt.ref),.T.,.T.,.F.,.T.,.F.
		Endif

		u_sqlexec("update st set marcada = 0 where marcada = 1 and ref = '"+alltrim(CrsSt.ref)+"'")

	Endscan

Endif


deactform()
msg("Fim de procedimento...")
sst.doactualizar()

