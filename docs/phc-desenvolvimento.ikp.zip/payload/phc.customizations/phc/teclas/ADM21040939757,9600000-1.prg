* TECLA (ti.retorno)
* tistamp: ADM21040939757,9600000-1
* ecran: SBO
* teclas: F9
* descricao: Exportação linhas dossier
* estado: Activo
* inactivo: False

local LvSqltxt

text to LvSqlTxt textmerge noshow

SELECT 
obrano as NrDossier,
dataobra as Data,
nmdos as NomeDossier,
REF,
U_REFALT as Ref_alternativa,
DESIGN as designacao,
UNIDADE,
EDEBITO as PrecoUnitario,
QTT,
DESCONTO,
DESC2 as desconto2,
ETTDEB as TotalLinha 

FROM BI (nolock) 

where bostamp='<<alltrim(bo.bostamp)>>'

order by lordem asc

endtext

if !u_sqlexec(LvSqlTxt,"CrsLinhasBi")
	msg("Erro ao extrair dados. Por favor informe o depº de informática!")
else
	mostrameisto("CrsLinhasBi","Linhas do dossier")
endif

