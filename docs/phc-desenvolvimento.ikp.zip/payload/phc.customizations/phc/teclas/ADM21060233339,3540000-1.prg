* TECLA (ti.retorno)
* tistamp: ADM21060233339,3540000-1
* ecran: SBO
* teclas: CTRL+F1
* descricao: HCA | Corrigir retoma a zero
* estado: Activo
* inactivo: False

Local LvSqlTxt


If bo.ndos = 18

	Select bi


		Local LvSqlTxt

			TEXT to LvSqlTxt textmerge noshow

	select top 1 sl.EPCPOND from sl (nolock) where SL.datalc < '<<dtos(bi.rdata)>>' 
							and sl.ref = '<<alltrim(bi.ref)>>' 
									AND SL.QTT<>0 
										AND	sl.cm = 20 
						order by sl.dataLC desc

			ENDTEXT

			u_sqlexec(LvSqlTxt,"CrsPcMpSl")

			If Reccount("CrsPcMpSl") = 0

				Select bi

				If bi.epcusto = 0
					msg("Sem custos para actualização!")
					Return

				Else

					TEXT to LvSqlTxt TextMerge Noshow

			declare @LvPcmP AS	[NUMERIC] (16,3) = '<<strtran(alltrim(str(bi.epcusto,16,3)),',','.')>>'
			declare @bistamp as varchar(25) = '<<alltrim(bi.bistamp)>>'

			update bi set epcusto = @LvPcmp,
							pcusto = @LvPcmp*200.482 ,-- (case when @cm = 3 then @LvPcmp*200.482 else @VUniOrig*200.482 end),

								SLVU = @LvPcmp*200.482,
									eslvu = @LvPcmp,
										SLTT = @LvPcmp*200.482 * BI.QTT,
											ESLTT= @LvPcmp * BI.QTT
													where bistamp = @bistamp;

			update bi set qtt=qtt,ousrdata=ousrdata where bistamp = @bistamp;
			update sl set qtt=qtt,ousrdata=ousrdata where bistamp = @bistamp;

					ENDTEXT

					If !u_sqlexec(LvSqlTxt)
						msg(LvSqlTxt)
						msg("Erro ao atualizar o pcusto")
						Return
					Else


						Do stact1 With 'UM',Alltrim(bi.ref),.T.,.T.,.F.,.T.,.F.
						msg("Actualização e Recalculo efetuado!")
						Return
					Endif



				Endif


				Return

			Endif




			If Reccount("CrsPcMpSl") >0

				Select CrsPcMpSl

				TEXT to LvSqlTxt TextMerge Noshow

			declare @LvPcmP AS	[NUMERIC] (16,3) = '<<strtran(alltrim(str(CrsPcMpSl.EPCPOND,16,3)),',','.')>>'
			declare @bistamp as varchar(25) = '<<alltrim(bi.bistamp)>>'

			update bi set epcusto = @LvPcmp,
							pcusto = @LvPcmp*200.482 ,-- (case when @cm = 3 then @LvPcmp*200.482 else @VUniOrig*200.482 end),

								SLVU = @LvPcmp*200.482,
									eslvu = @LvPcmp,
										SLTT = @LvPcmp*200.482 * BI.QTT,
											ESLTT= @LvPcmp * BI.QTT
													where bistamp = @bistamp;

			update bi set qtt=qtt,ousrdata=ousrdata where bistamp = @bistamp;
			update sl set qtt=qtt,ousrdata=ousrdata where bistamp = @bistamp;

				ENDTEXT

				If !u_sqlexec(LvSqlTxt)
					msg(LvSqlTxt)
					msg("Erro ao atualizar o pcusto")

				Else


					Do stact1 With 'UM',Alltrim(bi.ref),.T.,.T.,.F.,.T.,.F.

				Endif

			Endif



	msg("Actualização e Recalculo efetuado!")


Else
	msg("Série não configurada para correcção!")
Endif

