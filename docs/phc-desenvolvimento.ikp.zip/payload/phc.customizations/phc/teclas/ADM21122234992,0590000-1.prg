* TECLA (ti.retorno)
* tistamp: ADM21122234992,0590000-1
* ecran: SCL
* teclas: F5
* descricao: Transformar em Fornecedor
* estado: Activo
* inactivo: False

Local LvSqlTxt


text to LvSqlTxt textMerge Noshow


	declare @clstamp char(25) = '<<cl.clstamp>>'
	

			insert into fl
				(
					flstamp,
					no,
					nome,
					nome2,
					morada,
					local,
					codpost,
					telefone,
					fax,
					tlmvl,
					email,
					url,
					pncont,
					ncont,
					pais,
					ousrinis,
					ousrdata,
					ousrhora,
					usrinis,
					usrdata,
					usrhora
				)
				select 
					a.clstamp,
					a.no,
					a.nome,
					a.nome2,
					a.morada,
					a.local,
					a.codpost,
					a.telefone,
					a.fax,
					a.tlmvl,
					a.email,
					a.url,
					a.pncont,
					a.ncont,
					a.pais,
					a.ousrinis,
					a.ousrdata,
					a.ousrhora,
					a.usrinis,
					a.usrdata,
					a.usrhora

				from cl a (nolock)
				where a.clstamp=@clstamp


endtext

if !u_sqlexec(LvSqlTxt)
		msg("Não foi possivel inserir o fornecedor. Por favor informe o depº de informática!")
else
		msg("Duplicação efetuada com sucesso!")
endif

