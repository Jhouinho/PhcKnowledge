* TECLA (ti.retorno)
* tistamp: ADM21122237452,2860000-1
* ecran: SBO
* teclas: CTRL+P
* descricao: Procura Refª
* estado: Activo
* inactivo: False

local var,ret
var=getnome("Insira referencia/designação a localizar","","")

RET=alltrim(UPPER(VAR))
*MEsSAGEBOX(RET)
** mensagem="Refª Encontrada: "+ref

SELECT BI
locate for bi.ref = ret
if found()

else

	SELECT BI
	locate for  like('*'+ret+'*',bi.design)
	if found()

	else
		mensagem("Não encontrada","directa")
		go top
	endif
endif

