* TECLA (ti.retorno)
* tistamp: ADM22081061574,9590000-1
* ecran: SFO
* teclas: F5
* descricao: Actualizar data N/Crédito a aguardar
* estado: Activo
* inactivo: False

Local LvAdoc,LvDocdata,lvFostamp,LvAdoc_upd 
Select fo
lvFostamp = Alltrim(fo.Fostamp)
LvAdoc_upd = ''
LvAdoc = ''

If sfo.editing
	msg("Documento em edição. Por favor cancele a edição!")
	Return
Endif

If Len(lvFostamp)>0
	If Upper(Alltrim(fo.Adoc))<>"AGUARDA N/CRÉDITO"
		msg("Não é possivel a alteração do documento. Por favor verifique se o nrº do documento é igual a AGUARDA N/CRÉDITO!")
		Return
	Endif
Endif

Create Cursor xVars ( no N(5), tipo c(1), Nome c(40), Pict c(100), lOrdem N(10), nValor N(18,5), cValor c(250), mValor m(10), tbVal m, lValor l, dValor d )


Select xVars
Append Blank
Replace xVars.no With 1
Replace xVars.tipo With "D"
Replace xVars.Nome With "Data documento"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 1
Replace xVars.dValor With Date()

Select xVars
Append Blank
Replace xVars.no With 2
Replace xVars.tipo With "C"
Replace xVars.Nome With "Nrº documento"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 2
Replace xVars.cValor With ""


m.Escolheu = .F.

m.mCaption = "Dados da N/crédito"


docomando("do form usqlvar with 'xvars',m.mCaption,.t.")

If Not m.Escolheu
	mensagem("Atribuição interrompida!","DIRECTA")
	Return
Else
	Select xVars
	Locate
	LvDocdata=xVars.dValor
	Select xVars
	Skip
	LvAdoc=xVars.cValor

	If Len(Alltrim(LvAdoc))=0
		msg("Sem nrº documento inserido. Não é possivel continuar!")
		Return
	Endif

	If datavazia(LvDocdata)
		msg("Sem data inserida. Não é possivel continuar!")
		Return
	Endif


Endif


If pergunta("Confirma a actualização?")

	** antes da alteração de 05.09.2023 (PT)
	**If u_sqlexec("update fo set adoc='"+Alltrim(LvAdoc)+"',docdata='"+Dtos(LvDocdata)+"',site='GUIADEV' where fostamp='"+lvFostamp+"'")

	If u_sqlexec("update fo set adoc='"+Alltrim(LvAdoc)+"',docdata='"+Dtos(LvDocdata)+"', data='"+Dtos(LvDocdata)+"' ,site='GUIADEV' where fostamp='"+lvFostamp+"'")

		** antes da alteração de 05.09.2023 (PT) (dentro do TextMerge)
		** update sl set adoc='<<Alltrim(LvAdoc)>>' where fnstamp in (select fnstamp from fn (nolock) where fostamp
		='<<lvFostamp>>')

		Select FN
		Go Top
		Scan
			
			if u_sqlexec("select bi.nmdoc+' '+cast(bi.obrano as varchar(10))  as docbi from bi (nolock) where bi.bistamp = '"+alltrim(fn.bistamp)+"'","CrsBiFn")
				if reccount("CrsBiFn")=1 
					if len(alltrim(CrsBiFn.docbi))>0
						LvAdoc_upd = CrsBiFn.docbi
					else
						LvAdoc_upd = LvAdoc
					endif
				endif
			endif

			TEXT to LvSqlTxt TextMerge Noshow
				update sl set adoc='<<Alltrim(LvAdoc_upd)>>', DATALC='<<dtos(LvDocdata)>>' where fnstamp = '<<alltrim(fn.fnstamp)>>'
			ENDTEXT

			**msg(LvSqlTxt) in (select fnstamp from fn (nolock) where fostamp = <<lvFostamp>>)

			If !u_sqlexec(LvSqlTxt)
				msg("Erro ao actualizar o documento na tabela SL. Por favor informe o depº de informática!")
				Return
			Endif

		Endscan



		** alteração em 05.09.2023 - acrescentei este update à tabela FC (PT)
		** VOLTEI A COLOCAR COMO ESTAVA JORGE F EM 05.06.2024 u_sqlexec("UPDATE FC SET DEB=DEB*-1,EDEB=EDEB*-1 WHERE FOSTAMP='"+lvFostamp+"'")

		If	u_sqlexec("UPDATE FC SET DEB = (CASE WHEN DEB<0 THEN DEB*-1 ELSE DEB END),EDEB=(CASE WHEN EDEB<0 THEN EDEB*-1 ELSE EDEB END) WHERE FOSTAMP='"+lvFostamp+"'")
			sfo.doactualizar()
		Else
			msg("Erro ao atualizar a conta corrente fornecedores! Por favor informe o depº de informática!")
		Endif

	Else

		msg("Erro ao actualizar o documento. Por favor informe o depº de informática!")
		Return
	Endif

Endif

