* TECLA (ti.retorno)
* tistamp: ADM22101955414,5770000-1
* ecran: SBO
* teclas: F8
* descricao: Actualizar Obra Dossier
* estado: Activo
* inactivo: False

** =================================================================
** Preenche a obra (Fref) 
** Jorge F. 19.10.2022
** ===================================================================




Local in_nome,sql_txt,in_no,in_fref

Store 0 To in_no,in_fref_find,in_nmfref_find,LvBostamp

Select bo

if len(alltrim(bo.bostamp))=0
	msg("Sem registo dossier seleccionado!")
	return
else
	LvBostamp=alltrim(bo.bostamp)
endif

Create Cursor xVars (no N(5), tipo c(1), Nome c(40), Pict c(100), lOrdem N(10), nValor N(18,5), cValor c(250), mValor m(10), tbVal m, lValor l, dValor d )

Select xVars
Append Blank
Replace xVars.no With 1
Replace xVars.tipo With "C"
Replace xVars.Nome With "Nrº da Obra"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 1
Replace xVars.cValor With ""

Select xVars
Append Blank
Replace xVars.no With 2
Replace xVars.tipo With "C"
Replace xVars.Nome With "Nome da obra"
Replace xVars.Pict With ""
Replace xVars.lOrdem With 2
Replace xVars.cValor With ""

m.mCaption = "Pesquisa obra"

docomando("do form usqlvar with 'xvars',m.mCaption,.t.")

Select xVars
Go Top
Scan
	If no = 1
		in_fref_find = xVars.cValor
	Else
		in_nmfref_find = xVars.cValor
	Endif

Endscan


TEXT to sql_txt textmerge noshow

	select * from fref (nolock) where
		fref like '<<"%"+alltrim(in_fref_find)+"%">>'
			and nmfref like  '<<"%"+alltrim(in_nmfref_find)+"%">>'

ENDTEXT



If u_sqlexec(sql_txt,"crs_fref1") And Reccount("crs_fref1")>0

	** mostrameisto("crs_fref1")

	=CursorSetProp('Buffering',5,"crs_fref1")
	Declare list_tit(2),list_cam(2),list_tam(2),list_pic(2)
	list_tit(1)="Descrição"
	list_tit(2)="Obra"

	list_cam(1)="crs_fref1.fref"
	list_cam(2)="crs_fref1.nmfref"

	list_pic(1)=""
	list_pic(2)=""

	list_tam(1)=8*60
	list_tam(2)=8*60

	m.escolheu=.F.
	Do	browlist With "Escolha a obra do cliente","crs_fref1","crs_fref1"
	*,.T.,.F.,.F.,.T.,.F.,'',.t.




	If M.escolheu = .F.
		msg("Não escolheu nenhuma obra!")
		return
	Else
		in_fref = Alltrim(crs_fref1.fref)


			If	SBO.editing = .F. And SBO.adding = .F.

				text to LvSqlTxt Textmerge Noshow

					update bo set fref = '<<alltrim(crs_fref1.fref)>>' where bo.bostamp='<<LvBostamp>>';
					update bi set bofref = '<<alltrim(crs_fref1.fref)>>',bIfref = '<<alltrim(crs_fref1.fref)>>' where bi.bostamp='<<LvBostamp>>';
				endtext

				if !u_sqlexec(LvSqlTxt)
					msg("Erro ao actualizar a obra no dossier. Por favor informe o depº de informática!")
					return
				else
					 sbo.doactualizar()
				endif
		Else
				msg("O dossier não deverá estar em introdução ou alteração!")
		Endif
	Endif

Else
	msg("Sem registos")
	msg(sql_txt)

Endif

