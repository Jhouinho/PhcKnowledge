* TECLA (ti.retorno)
* tistamp: ADM23041363385,4550000-1
* ecran: SBO
* teclas: ALT+W
* descricao: Teste
* estado: Activo
* inactivo: False

*================================================================================================================================================
* H.C.Araújo, Lda.
*      :: Data Criação:    13/04/2023
*      :: Programador:     Ulisses Araújo
*      :: Objetivo:        Criação de uma analise de Orçamentos
* Histórico de Versões
*      :: 13/04/2023 »» U.A. :: Criação
* ===============================================================================================================================================

fn_AnaliseOrcamentos()
Function fn_AnaliseOrcamentos

    
    Local lcDataInicio, lcDataFim, lcCodigoObra, lcStatusObra, lcComercial
    
    Create Cursor xVars ( no N(5), tipo c(1), Nome c(40), Pict c(100), lOrdem N(10), nValor N(18,5), cValor c(250), lValor l, dValor d, tBval M )
    
    Select xVars
    Append Blank
    Replace xVars.no With 1
    Replace xVars.tipo With "D"
    Replace xVars.Nome With "Data de inicial"
    Replace xVars.Pict With ""
    Replace xVars.lOrdem With 1
    Replace xVars.dValor With Date()

    Select xVars
    Append Blank
    Replace xVars.no With 2
    Replace xVars.tipo With "D"
    Replace xVars.Nome With "Data de final"
    Replace xVars.Pict With ""
    Replace xVars.lOrdem With 2
    Replace xVars.dValor With Date()

    Select xVars
    Append Blank
    Replace xVars.no With 3
    Replace xVars.tipo With "C"
    Replace xVars.Nome With "Código da Obra (% Todos)"
    Replace xVars.Pict With ""
    Replace xVars.lOrdem With 4
    Replace xVars.cValor with "%"

    Select xVars
    Append Blank
    Replace xVars.no With 4
    Replace xVars.tipo With "Q"
    Replace xVars.Nome With "Status (Ctrl + 0 - Todos)"
    Replace xVars.Pict With ""
    Replace xVars.lOrdem With 4
    Replace xVars.tbval with "SELECT distinct  BO.u_status FROM BO(NOLOCK) WHERE BO.NDOS = 3 order by BO.u_status asc"

    Select xVars
    Append Blank
    Replace xVars.no With 5
    Replace xVars.tipo With "Q"
    Replace xVars.Nome With "Status (Ctrl + 0 - Todos)"
    Replace xVars.Pict With ""
    Replace xVars.lOrdem With 4
    Replace xVars.tbval with "SELECT distinct BO.vendnm FROM BO(NOLOCK) WHERE BO.NDOS = 3 order by BO.vendnm asc"


    m.Escolheu = .F.

    m.mCaption = "Dados para análise de Orçaçamentos."

    docomando("do form usqlvar with 'xvars',m.mCaption,.t.")

    If Not m.Escolheu
        mensagem("Atribuição interrompida!","DIRECTA")
        Return .F.
    Else
        Select xVars
        go top
        lcDataInicio=xVars.dValor

        Select xVars
        Skip
        lcDataFim=xVars.dValor

        Select xVars
        Skip
        lcCodigoObra=xVars.cValor

        Select xVars
        Skip
        lcStatusObra=xVars.cValor
        
        Select xVars
        Skip
        lcComercial=xVars.cValor
    Endif

    If datavazia(lcDataInicio)
        lcDataInicio=Date()
    Endif

    If datavazia(lcDataFim)
        lcDataFim=Date()
    Endif

    if len(alltrim(lcCodigoObra)) = 0
        lcCodigoObra = '%'
    Endif

    if len(alltrim(lcStatusObra)) = 0
        lcStatusObra = '%'
    Endif

    if len(alltrim(lcComercial)) = 0
        lcComercial = '%'
    Endif

    text to lc_strsql noshow TextMerge
        SELECT 
            BO.BOSTAMP
            ,Cast(BO.DATAOBRA as Date) as 'Data'
            ,BO.OBRANO as 'NumeroOrcamento'
            ,ISNULL(FREF.nmfref,'') AS 'Descricao'
            ,BO.NO as 'NumeroCliente'
            ,BO.nome as 'NomeCliente'
            ,BO.ecusto as 'ValorCusto'
            ,BO.etotaldeb as 'ValorVenda'
            ,BO.vendnm as 'Comercial'
            ,BO.u_status as 'Status'
            ,BO.fref as 'CodigoObra'
        FROM BO(NOLOCK)
        INNER JOIN BO2(NOLOCK) ON BO2.BO2STAMP=BO.BOSTAMP
        LEFT JOIN fref(NOLOCK) ON FREF.fref=BO.FREF
        WHERE 
            BO.NDOS = 3 
            AND BO2.ANULADO=0
            AND BO.dataobra BETWEEN '<<dtosql(lcDataInicio)>>' AND '<<dtosql(lcDataFim)>>' 
            AND BO.fref LIKE '<<Alltrim(lcCodigoObra)>>'
            and BO.u_status like '<<Alltrim(lcStatusObra)>>'
            AND BO.vendedor LIKE '<<alltrim(lcComercial)>>'
        ORDER BY 
            BO.dataobra ASC
            ,BO.obrano ASC
    endtext

    if !u_sqlexec(lc_strsql,"CurOrcCab")
        Msg("Caro utilizador, não foi possivel criar o cursor devido ao seguinte erro: " + lc_strsql)
        return .f.
    endif    

    if  Reccount("CurOrcCab") = 0
        msg("Não foi encontrado nenhum orçamento com os dados escolhidos: ")
        return .f.
    endif

    declare list_tit(9),list_cam(9),list_tam(9),list_pic(9),list_ronly(9)

    list_tit(1)="Data"
    list_cam(1)="CurOrcCab.Data"
    list_tam(1)=18
    list_pic(1)=''
    list_ronly(1)=.t.

    list_tit(2)="Nº"
    list_cam(2)="CurOrcCab.NumeroOrcamento"
    list_tam(2)=10
    list_pic(2)='#####'
    list_ronly(2)=.t.

    list_tit(3)="Descrição"
    list_cam(3)="CurOrcCab.Descricao"
    list_tam(3)=150
    list_pic(3)=''
    list_ronly(3)=.t.

    list_tit(4)="Nome Cliente"
    list_cam(4)="CurOrcCab.NomeCliente"
    list_tam(4)=100
    list_pic(4)=''
    list_ronly(4)=.t.

    list_tit(5)="Valor Custo"
    list_cam(5)="CurOrcCab.ValorCusto"
    list_tam(5)=8
    list_pic(5)='###,###,###.##'
    list_ronly(5)=.t.

    list_tit(6)="Valor Venda"
    list_cam(6)="CurOrcCab.ValorVenda"
    list_tam(6)=8
    list_pic(6)='###,###,###.##'
    list_ronly(6)=.t.

    list_tit(7)="Reponsavel / Comercial"
    list_cam(7)="CurOrcCab.Comercial"
    list_tam(7)=50
    list_pic(7)=''
    list_ronly(7)=.t.

    list_tit(8)="Status"
    list_cam(8)="CurOrcCab.Status"
    list_tam(8)=50
    list_pic(8)=''
    list_ronly(8)=.t.

    list_tit(9)="Código Obra"
    list_cam(9)="CurOrcCab.CodigoObra"
    list_tam(9)=50
    list_pic(9)=''
    list_ronly(9)=.t.

    browlist("Analise de or;amentos","CurOrcCab","CurOrcCab",.t.,.f.,.f.,.t.,.f.)

EndFunc

Function fn_ConsultaLinhas 
    LParameters varBoStamp 

EndFunc

Function fn_ConsultaLinhasDetalhe 
    LParameters varBiStamp

EndFunc

