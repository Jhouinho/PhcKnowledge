* TECLA (ti.retorno)
* tistamp: ADM23052665942,8690000-1
* ecran: SST
* teclas: F10
* descricao: Recalculo Custos Artigos |
* estado: Inactivo
* inactivo: True

*
* HCA | Jorge F Processo de recalculo de stocks PCMP a partir de determinada data
* 28/10/2022
*

if pergunta("Recalculo total movimentos conforme regras negócio PCMP | Versão 25.05.2023. Tem certeza?")
	else
	return
endif

If u_sqlexec("select ref from st (nolock) where stns=0 and st.ref ='"+alltrim(st.ref)+"'"+"order by st.design asc","CrsSt")
	Select CrsSt
	Go Top
	Scan

		LvRef = Alltrim(CrsSt.ref)

		If Len(Alltrim(CrsSt.ref))>0


			LvMensagen = "A recalcular movimentos do artigo: "+Alltrim(CrsSt.ref)

			ACTFORM(LvMensagen)
			* msg("Executo recalculo")
			*STACT1("UM",Alltrim(bi.ref),.T.,.T.,.T.,.T.,.F.,.F.,.F.,.F.,.T.,.T.,.T.,bi.rdata,.F.,.t.,.F.,.T.,.f.,"","",.T.,.T.)

			TEXT To LvSqlTxt TextMerge Noshow

						exec dbo.sp_HcaCalculaPcmPv2 '<<alltrim(CrsSt.ref)>>','19000101','19000101','StockAtual',1,3,10,1,1

			ENDTEXT

			If u_sqlexec(LvSqlTxt)
				Do stact1 With 'UM',Alltrim(CrsSt.ref),.T.,.T.,.F.,.T.,.F.

				*stact1("UM",;		&&1
				Alltrim(CrsSt.ref),;&&2
				.T.,;				&&3
				.T.,;				&&4
				.T.,;				&&5
				.T.,;				&&6
				.F.,;				&&7
				.F.,;				&&8
				.F.,;				&&9
				.F.,;				&&10
				.T.,;				&&11
				.T.,;				&&12
				.T.,;				&&13
				'',;				&&14
				.F.,;				&&15
				.T.,;				&&16
				.F.,;				&&17
				.T.,;				&&18
				.F.,;				&&19
				"",;				&&20
				"",;				&&21
				.T.,;				&&22
				.T.;				&&23
				)

				DEACTFORM()

			Endif

		Endif



	Endscan

Endif

Select CrsSt
Go Top

Msg("Fim")

Return


* VerificaUltimoMovEntradaValorizada(bi.ref,bi.lote,bi.rdata,bi.ousrhora,bi.armazem,bi.bistamp)

Function VerificaUltimoMovEntradaValorizada
	Lparameters in_ref,in_lote,in_rdata,in_ousrhora,in_armazem,in_bistamp

	TEXT to LvSqlTxt TextMerge Noshow

		Select top 1 sl.datalc,sl.qtt,sl.ousrhora
				from sl (nolock)
					join cm2 (nolock) on cm2.cm = sl.cm
						where
							sl.ref = '<<in_ref>>'
							and sl.lote = '<<in_lote>>'
							and sl.armazem = <<in_armazem>>
							and cm2.entrada = 1
							and cm2.mudapcpond = 1
							and sl.datalc >= '<<in_rdata>>'
							and sl.ousrhora <
										(case when sl.datalc = '<<in_rdata>>' then '00:00:00'  ELSE '<<in_ousrhora>>' end)
							and sl.bistamp <> '<<in_bistamp>>'

							order by sl.datalc asc, sl.ousrhora asc


	ENDTEXT

	If m.m_chinis = 'ADM'
		* msg(LvSqlTxt)
	Endif

	If u_sqlexec(LvSqlTxt,"CrsExisteMov")
		If Reccount("CrsExisteMov")>0
			Return .T.
		Else
			Return .F.
		Endif
	Else
		Return .F.
	Endif

Endfunc







Function u_HcaLogs
	Lparameters in_Funcionalidade,in_programa,in_status,in_detalhes

	Local LvSqlTxt

	TEXT to LvSqlTxt textmerge noshow

			declare @NovoStamp as varchar(25) = 'HCA' + LEFT(Replace(Newid(), '-', ''), 22)


			INSERT INTO dbo.u_hcalogs
					   ([HcaLogsStamp]
					   ,[Data]
					   ,[Hora]
					   ,[Funcionalidade]
					   ,[programa]
					   ,[status]
					   ,[detalhes]

						)
				 VALUES
					   (
					   @NovoStamp
					   ,(select convert(date,getdate(),112))
					   ,(SELECT CONVERT(TIME, GETDATE()))
					   ,'<<in_Funcionalidade>>'
					   ,'<<in_programa>>'
					   ,'<<in_status>>'
					   ,'<<in_detalhes>>'
					   )

	ENDTEXT

	If !u_sqlexec(LvSqlTxt)
		*msg("Erro ao efetuar o insert no Log da funcionalidade. Por favor informe o depº de informática!")
		*msg(LvSqlTxt)
	Endif
Endfunc





*
* HCA | Jorge F. 17.03.2023
* Forçar dados para o calculo de PCMP
*

Function ForcaCustosBo
	TEXT to LvSqltxt TextMerge Noshow

		UPDATE BI SET BI.eslvu=(bi.ettdeb/bi.qtt),bi.slvu = (bi.ttdeb/bi.qtt),bi.esltt=bi.ettdeb,bi.sltt=bi.ttdeb,BI.QTT=BI.QTT WHERE BoSTAMP = '<<alltrim(bo.bostamp)>>'  and bi.qtt<> 0



If U_SQLEXEC(lvSqltxt)
	sbo.doactualizar()
Else
	msg("Erro ao efetuar efetuar o recalculo de pcmp. Por favor informe o depº de informática!")
Endif

endfunc

