* TECLA (ti.retorno)
* tistamp: ADM23060760327,1680000-1
* ecran: SST
* teclas: ALT+1
* descricao: DEVELOP Jorge 02.06.2023
* estado: Activo
* inactivo: False

* HCA | Jorge F Processo de recalculo de stocks PCMP a partir de determinada data
* 02/06/2023
* Validado em 10.06.2023 Sr. Gomes
*
* Caso seja um enterprise a ordenação poderá ser por data e hora (PvOdenacaoMovSl = 2)
* Outras Versão PHC ordenação por sl.datalc, sl.cm (PvOdenacaoMovSl = 1 )

Public PvOdenacaoMovSl,PvStrOdenacaoMovSl
Local LvPrecoCustolinha,LvSqlTxt2,LvSqlTxt,LvSqlTxt1

* PvOdenacaoMovSl = 2 = " order by sl.datalc asc, sl.ousrhora asc
* PvOdenacaoMovSl = 1 = " order by sl.datalc, sl.cm "

PvOdenacaoMovSl = 1

LvSqlTxt2=''
LvSqlTxt=''
LvSqlTxt1 =''
Do Case

	Case PvOdenacaoMovSl = 1
		PvStrOdenacaoMovSl= " order by sl.datalc, sl.cm "

	Case PvOdenacaoMovSl = 2
		PvStrOdenacaoMovSl= " order by sl.datalc asc, sl.ousrhora asc "
Endcase


LvPrecoCustolinha = 0

If pergunta("Artigo no ecrã ou artigos marcados (não)")
	Create Cursor CrsSt (ref c(18), stns l(1))
	Select CrsSt
	Append Blank
	Replace ref With st.ref
	Replace stns With st.stns

Else

	u_sqlexec("Select ref,stns from st (nolock) where marcada = 1 and st.stns=0 order by st.ref asc","CrsSt")

Endif

If pergunta("Tem a certeza?")
	If Reccount("CrsSt")>0
	Else
		msg("Sem registos!")
	Endif
Else
	Return
Endif



Select CrsSt
Go Top
Scan

	LvRef = Alltrim(CrsSt.ref)

	If Len(Alltrim(CrsSt.ref))>0

		Select CrsSt
		* LvEPCPOND=GetUmValorNumerico("ST","EPCPOND","st.ref='"+Alltrim(bi.ref)+"'")
		* LvStNs=GetUmValorLogico("ST","st.STNS","st.ref='"+Alltrim(bi.ref)+"'")

		If CrsSt.stns = .F.


			TEXT to LvSqlTxt TextMerge Noshow

		declare @ref as varchar(18) = '<<alltrim(CrsSt.ref)>>' --'UPA-1220-50';

		select  ROW_NUMBER () OVER (<<PvStrOdenacaoMovSl>>) AS LINHA,
				sl.slstamp from sl (nolock)	where sl.ref = '<<alltrim(CrsSt.ref)>>'
					<<PvStrOdenacaoMovSl>>

			ENDTEXT

			If u_sqlexec(LvSqlTxt,"CrsSl")

				If Reccount("CrsSl")>0

					LvMensagem = "A recalcular movimentos do artigo: "+Alltrim(CrsSt.ref)
					Select CrsSl

					ACTFORM(LvMensagem)
					Scan
						* messagebox(CrsSl.LINHA)

						TEXT to LvSqlTxt1 TextMerge Noshow


                                select
                                ROW_NUMBER () OVER (<<PvStrOdenacaoMovSl>>) AS LINHA,
                                cast(sl.datalc as date) datalc,
                                sl.ousrhora,
                                cm2.mudapcpond,
                                cm2.entrada,
                                sl.slstamp,
                                sl.fnstamp,
                                sl.bistamp,
                                sl.fistamp,
                                sl.ref,
                                sl.design,
								sl.lote,
								sl.armazem,
                                sl.qtt,
                                sl.evu,
                                sl.ett,
                                sl.cm,
                                sl.cmdesc,
								sl.EPCPOND,
								sl.origem,
                                case
                                    when sl.bistamp <> '' then (select nmdos from bi (nolock) where bistamp = sl.bistamp)
                                    when sl.fnstamp <> '' then (select docnome from fn (nolock) where fnstamp = sl.fnstamp)
                                    when sl.fistamp <> '' then (select nmdoc from fi (nolock) where fistamp = sl.fistamp)
                                    when sl.sticstamp <> '' then (select descricao from stic (nolock) where sticstamp = sl.sticstamp)
                                    else '' end as origem,


                                        isnull((bi_1.nmdos),'') as DossierOrigem,

                                        --isnull((bi_1.epcusto),0) as epcustoOrigem,
										isnull(((select sl.epcpond from sl (nolock) where sl.slstamp = bi_1.bistamp)),0) as epcustoOrigem,

										case when sl.bistamp <> '' then
		                                        isnull((bi.ettdeb/bi.qtt),0)
											when sl.fnstamp <> '' then
												 isnull((fn.ESLTT/fn.qtt),0)
											when fi.fistamp <> '' then
												 isnull((fi.ETILIQUIDO/fi.qtt),0)
											when sl.sticstamp <> '' then
												 isnull((select stil.evalstock from stil (nolock) where stil.sticstamp = sl.sticstamp and stil.ref = sl.ref),0)
											end
										as epcustoAtual,

                                        isnull(bi_1.bistamp,'') as bistampOrigem,
                                        ISNULL(cm2_1.mudapcpond,0) as RelacaoComEntrada,
										ts.BDEMPRESAS

                                    from sl (nolock)
                                        join cm2 (nolock) on cm2.cm = sl.cm
                                            left join bi (nolock) on sl.bistamp = bi.bistamp
			                                         left join ts (nolock) on ts.ndos= bi.ndos
	                                            left join fn (nolock) on fn.fnstamp = sl.fnstamp
		                                            left join fi (nolock) on fi.fistamp = sl.fistamp

                                                 left join bi bi_1 (nolock) on bi_1.bistamp = bi.oobistamp
                                                		LEFT join cm2 cm2_1 (nolock) on cm2_1.cm = (select top 1 cmstocks from ts (nolock) where ts.ndos = bi_1.ndos)
                                                    where sl.slstamp = '<<alltrim(CrsSl.Slstamp)>>'

                                         <<PvStrOdenacaoMovSl>>

						ENDTEXT


						* msg(LvSqltXT1)


						If u_sqlexec(LvSqltXT1,"CrsSlLin") And Reccount("CrsSlLin")>0


							Select CrsSlLin

							If CrsSlLin.mudapcpond = .T. And CrsSlLin.epcustoOrigem=0 And CrsSlLin.CM <>0 And CrsSlLin.BDEMPRESAS<>'FL'
								LvPrecoCustolinha = CrsSlLin.epcustoAtual

								* Messagebox(CrsSl.LINHA)
								* Messagebox(LvPrecoCustolinha,"1) LvPrecoCustolinha Inicio")

								Do Case
									Case CrsSlLin.origem = 'BO'

										TEXT to LvSqlTxt2 textMerge Noshow

                                    update bi set epcusto = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',QTT=QTT,rdata=rdata where bistamp='<<ALLTRIM(CrsSlLin.slstamp)>>';

									UPDATE SL SET QTT=QTT,DATALC=DATALC WHERE SLSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

										ENDTEXT


									Case CrsSlLin.origem = 'IF'

										TEXT to LvSqlTxt2 textMerge Noshow


									UPDATE SL SET QTT=QTT,DATALC=DATALC,
									vu = '<<strtran(alltrim(str(LvPrecoCustolinha*200.482,12,6)),',','.')>>',
									Evu = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',
									epcpond = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',
									pcpond = '<<strtran(alltrim(str(LvPrecoCustolinha*200.482,12,6)),',','.')>>'

									WHERE SLSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

										ENDTEXT
								Endcase


							Endif

							If CrsSlLin.mudapcpond = .T. And CrsSlLin.epcustoOrigem>0 And CrsSlLin.BDEMPRESAS<>'FL'


								Select CrsSlLin
								LvPrecoCustolinha = CrsSlLin.epcustoOrigem
								* messagebox(LvPrecoCustolinha,"2) LvPrecoCustolinha CrsSlLin.mudapcpond = .T. And CrsSlLin.epcustoOrigem>0")
								*
								TEXT to LvSqlTxt2 textMerge Noshow

		                    	        UPDATE BI SET epcusto = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',RDATA=RDATA,
										BI.eslvu=(bi.ettdeb/bi.qtt),bi.slvu = (bi.ttdeb/bi.qtt),bi.esltt=bi.ettdeb,bi.sltt=bi.ttdeb,
										BI.QTT=BI.QTT WHERE BiSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

										UPDATE SL SET QTT=QTT,DATALC=DATALC,
										vu = '<<strtran(alltrim(str(LvPrecoCustolinha*200.482,12,6)),',','.')>>',
										evu = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',

										tt = '<<strtran(alltrim(str((LvPrecoCustolinha*CrsSlLin.qtt)*200.482,12,6)),',','.')>>',
										ett = '<<strtran(alltrim(str((LvPrecoCustolinha*CrsSlLin.qtt),12,6)),',','.')>>'

										--epcpond = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',
										--pcpond = '<<strtran(alltrim(str(LvPrecoCustolinha*200.482,12,6)),',','.')>>'
										WHERE SLSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

								ENDTEXT


							Endif


							If CrsSlLin.mudapcpond = .F. And CrsSlLin.BDEMPRESAS<>'FL'

								LvPrecoCustolinha = VerificaUltimoPCMPArtigo(Alltrim(CrsSlLin.ref),Alltrim(CrsSlLin.lote),Dtos(CrsSlLin.datalc),CrsSlLin.ousrhora,CrsSlLin.armazem,Alltrim(CrsSlLin.slstamp))

								*IF CrsSl.SLSTAMP='SS23020758987,830000005'
								*	messagebox(CrsSl.LINHA)
								*	messagebox(LvPrecoCustolinha,"3) LvPrecoCustolinha funcao")
								*ENDIF


								TEXT to LvSqlTxt2 textMerge Noshow

		                    	        UPDATE BI SET epcusto = '<<strtran(alltrim(str(LvPrecoCustolinha,12,6)),',','.')>>',RDATA=RDATA,
										BI.eslvu=(bi.ettdeb/bi.qtt),bi.slvu = (bi.ttdeb/bi.qtt),bi.esltt=bi.ettdeb,bi.sltt=bi.ttdeb,BI.QTT=BI.QTT WHERE 	BiSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

										UPDATE SL SET QTT=QTT,DATALC=DATALC WHERE SLSTAMP = '<<ALLTRIM(CrsSlLin.slstamp)>>';

								ENDTEXT


							Endif
						

							If !u_sqlexec(LvSqlTxt2)
								msg("Erro ao atualizar o preço epcusto na linha do dossier. Por favor informe o depº de informática!")
								msg(LvSqlTxt2)
								Return
							Else
								* msg(LvSqlTxt2)

								* Do stact1 With 'UM',Alltrim(CrsSlLin.ref),.T.,.T.,.F.,.T.,.F.

								stact1("UM",;		&&1
								Alltrim(CrsSlLin.ref),;	&&2
								.T.,;				&&3
								.T.,;				&&4
								.T.,;				&&5
								.T.,;				&&6
								.F.,;				&&7
								.F.,;				&&8
								.F.,;				&&9
								.F.,;				&&10
								.T.,;				&&11
								.T.,;				&&12
								.T.,;				&&13
								CrsSlLin.datalc,;			&&14
								.F.,;				&&15
								.T.,;				&&16
								.F.,;				&&17
								.T.,;				&&18
								.F.,;				&&19
								"",;				&&20
								"",;				&&21
								.T.,;				&&22
								.T.;				&&23
								)

							Endif

						Endif

						* If m.m_chinis = 'ADM'
						*	if pergunta("Continuar?")
						*	else
						*		return
						*	endif
						* Endif


					Endscan

					DEACTFORM()

				Endif
			Endif

		Endif

	Endif
	u_sqlexec("update st set marcada=1 where ref='"+Alltrim(CrsSt.ref)+"'")


Endscan

msg("Fim")



Select st
Go Top


Return


* VerificaUltimoPCMPArtigo(sl.ref,sl.lote,sl.datalc,sl.ousrhora,sl.armazem,sl.slstamp)

Function VerificaUltimoPCMPArtigo
	Lparameters in_ref,in_lote,in_datalc,in_ousrhora,in_armazem,in_slstamp

	TEXT to LvSqlTxt TextMerge Noshow

		Select top 1 sl.epcpond
				from sl (nolock)
					join cm2 (nolock) on cm2.cm = sl.cm
						where
							sl.ref = '<<in_ref>>'
							and sl.lote = '<<in_lote>>'
							and sl.armazem = <<in_armazem>>
							and cm2.entrada = 1
							and cm2.mudapcpond = 1
							and sl.datalc <= '<<in_datalc>>'
							-- Enterpreise and sl.ousrhora <
							--			(case when sl.datalc = '<<in_datalc>>' then '<<in_ousrhora>>' else '23:59:59' end)
							and sl.slstamp <> '<<in_slstamp>>'

							-- <<PvStrOdenacaoMovSl>>
							--order by sl.datalc desc, sl.cm asc
							order by sl.datalc DESC, sl.cm DESC, sl.adoc desc


	ENDTEXT

	If m.m_chinis = 'ADM'
		*IF in_slstamp='SS23020758987,830000005'
		*		msg(LvSqlTxt)
		*if pergunta("Continuar?")
		*	else
		*		return
		*endif
	Endif


	If u_sqlexec(LvSqlTxt,"CrsExisteMov")
		If Reccount("CrsExisteMov")>0
			Return CrsExisteMov.epcpond
		Else
			Return 0
		Endif
	Else
		Return 0
	Endif

Endfunc

