* TECLA (ti.retorno)
* tistamp: ADM23060767633,4370000-1
* ecran: SFO
* teclas: F7
* descricao: Copiar Qtt Dossier Origem
* estado: Activo
* inactivo: False

If PERGUNTA("Deseja copiar as quantidades do documento copiado?")
	Select FN
	Scan
		replace qtt with GetUmValorNumerico("BI","BI.QTT","BI.BISTAMP='" + FN.BISTAMP + "'")
		do foiliq
	Endscan
	do fotots with .t.
Endif

