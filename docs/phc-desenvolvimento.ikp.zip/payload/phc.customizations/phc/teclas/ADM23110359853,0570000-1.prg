* TECLA (ti.retorno)
* tistamp: ADM23110359853,0570000-1
* ecran: SFREF
* teclas: ALT+Y
* descricao: teste
* estado: Inactivo
* inactivo: True


select FREF
fnCalculaContaCorrente(FREF.FREF)
Function fnCalculaContaCorrente
lparameters varFref
TEXT TO MSEL NOSHOW TEXTMERGE
DECLARE 
@CodigoObra as Varchar(30)
set @CodigoObra = '<<ALLTRIM(varFref)>>';
with
    ConsolaObraDatas
    as
    (
        SELECT DISTINCT DataMesAno, Mes, Ano, @CodigoObra AS CodigoObra
        FROM
            (
			    SELECT DISTINCT
                    REPLICATE('0', 2 -LEN(CAST(MONTH(BO.dataobra) AS VARCHAR(2))))+RTrim(CAST(MONTH(BO.dataobra) AS VARCHAR(2)))  +'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4)) DataMesAno
				, MONTH(BO.dataobra) Mes
				, YEAR(BO.dataobra) Ano
                FROM BO(NOLOCK)
                    inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
                WHERE bo.ndos in (11,17,18,19,20,22)
                    and bo.fref = @CodigoObra
                    and bo2.anulado = 0
            UNION ALL
                SELECT DISTINCT
                    REPLICATE('0', 2 -LEN(CAST(MONTH(BI.RDATA) AS VARCHAR(2))))+RTrim(CAST(MONTH(BI.RDATA) AS VARCHAR(2)))
				+'.'+CAST(YEAR(BI.RDATA) AS VARCHAR(4)) DataMesAno
				, MONTH(BI.RDATA) Mes
				, YEAR(BI.RDATA) Ano
                FROM BO(NOLOCK)
                    inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
                    INNER JOIN BI(NOLOCK) ON BI.bostamp=BO.bostamp
                WHERE bo.ndos in (15)
                    and bi.bifref = @CodigoObra
                    and bo2.anulado = 0
            UNION ALL
                SELECT DISTINCT
                    REPLICATE('0', 2 -LEN(CAST(MONTH(FT.fdata) AS VARCHAR(2))))+RTrim(CAST(MONTH(FT.fdata) AS VARCHAR(2)))
				+'.'+CAST(YEAR(FT.fdata) AS VARCHAR(4)) DataMesAno
				, MONTH(FT.fdata) Mes
				, YEAR(FT.fdata) Ano
                FROM FT(NOLOCK)
                WHERE 
			ft.anulado=0
                    and ft.tipodoc in (1,3)
                    and ft.fref =  @CodigoObra
				) Datas
    ),
    ConsolaObra
    as
    (
        SELECT
            FREF AS Codigo
	 , ConsolaObraDatas.DataMesAno
	 , ConsolaObraDatas.Ano
	 , ConsolaObraDatas.Mes
	, nmfref as Designacao
	, u_nocli as NumeroCliente
	, u_clinome as NomeCliente
	, isnull((
		SELECT
                sum(bi.epcusto * bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (11,17)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
           -- Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
	),0) As CustosMaterial
	, isnull
	((
		SELECT
                sum((bi.epcusto * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'MT'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
				bo.ndos in (11,17)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		)
	,0) As CustosMaterialAprovisionamento
	, isnull
	((
		SELECT
                sum((bi.epcusto * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
				bo.ndos in (11,17)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
           -- Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		)
	,0) As CustosMaterialAdminitrativos
	, isnull
	((
			SELECT
                sum(bi.edebito * bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref in ('S0300018')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		)
	,0) As CustosMaterialDiversos
	, isnull
	((
	SELECT
                sum((bi.edebito * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'MT'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref in ('S0300018')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
			)
	,0) As CustosMaterialDiversosAprovisionamento
	, isnull
	((
	SELECT
                sum((bi.edebito * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref in ('S0300018')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
			)
	,0) As CustosMaterialDiversosAdministrativos
	, isnull((
			SELECT
                sum(bi.epcusto * bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
				bo.ndos in (20,18)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		),0) As CustosRetomaMaterial
		, isnull
		((
		SELECT
                sum((bi.epcusto * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'MT'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
						bo.ndos in (20,18)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
				)
		,0) As CustosRetomaMaterialAprovisionamento
		, isnull
		((
		SELECT
                sum((bi.epcusto * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
						bo.ndos in (20,18)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
				)
		,0) As CustosRetomaMaterialAdministrativos
		, isnull
		((
		SELECT
                sum(bi.epcusto*bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (19)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
				)
		,0) As CustosDevolucaoCliente
		, isnull
		((
			SELECT
                sum((bi.epcusto*bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'MT'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
					bo.ndos in (19)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
						)
		,0) As CustosDevolucaoClienteAprovisionamento
		, isnull
		((
			SELECT
                sum((bi.epcusto*bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
					bo.ndos in (19)
                and bo.fref =  ori.fref
                and bo2.anulado = 0
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
						)
		,0) As CustosDevolucaoClienteAdministrativos
	, isnull
	((
			SELECT
                sum(bi.edebito * bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref not in ('S0300018','S0300001','S0300013')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		)
	,0) As CustosDiversos
	, isnull
	((
			SELECT
                sum(bi.edebito * bi.qtt)
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref in ('S0300001','S0300013')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
			)
	,0) As CustosDeslocacoes
	, isnull
	((
			SELECT
                sum((bi.edebito * bi.qtt) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (22)
                and bo.fref = ori.fref
                and bo2.anulado = 0
                and bi.ref not in ('S0300018')
                and MONTH(BO.dataobra) = ConsolaObraDatas.Mes and YEAR(BO.dataobra) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(BO.dataobra) AS VARCHAR(2))+'.'+CAST(YEAR(BO.dataobra) AS VARCHAR(4))
		)
	,0) As CustosDiversosAdministrativos
	, isnull
	((
	SELECT
                sum(bi2.u_valorMo)
            FROM BI(nolock)
                inner join bi2(nolock) on bi.bistamp = bi2.bi2stamp
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (15)
                and bi.bifref =  ori.fref
                and bo2.anulado = 0
                and MONTH(bi.rdata) = ConsolaObraDatas.Mes and YEAR(bi.rdata) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(bi.rdata) AS VARCHAR(2))+'.'+CAST(YEAR(bi.rdata) AS VARCHAR(4))
					)
	,0) As CustosMaoObra
	, Isnull((
	SELECT
                sum((bi2.u_valorMo) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'MO'))
            FROM BI(nolock)
                inner join bi2(nolock) on bi.bistamp = bi2.bi2stamp
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (15)
                and bi.bifref =  ori.fref
                and bo2.anulado = 0
                and MONTH(bi.rdata) = ConsolaObraDatas.Mes and YEAR(bi.rdata) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(bi.rdata) AS VARCHAR(2))+'.'+CAST(YEAR(bi.rdata) AS VARCHAR(4))
					)
	,0) As CustosMaoObraAprovisionamento
	, Isnull((
	SELECT
                sum((bi2.u_valorMo) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bi2(nolock) on bi.bistamp = bi2.bi2stamp
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
		bo.ndos in (15)
                and bi.bifref =  ori.fref
                and bo2.anulado = 0
                and MONTH(bi.rdata) = ConsolaObraDatas.Mes and YEAR(bi.rdata) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(bi.rdata) AS VARCHAR(2))+'.'+CAST(YEAR(bi.rdata) AS VARCHAR(4)) 
					)
	,0) As CustosMaoObraAdministrativos
	, isnull
	((
		SELECT
                sum(bi2.u_valorkm)
            FROM BI(nolock)
                inner join bi2(nolock) on bi.bistamp = bi2.bi2stamp
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (15)
                and bi.bifref =  ori.fref
                and bo2.anulado = 0
                and MONTH(bi.rdata) = ConsolaObraDatas.Mes and YEAR(bi.rdata) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(bi.rdata) AS VARCHAR(2))+'.'+CAST(YEAR(bi.rdata) AS VARCHAR(4)) 
						)
	,0) As CustosKm
	, isnull
	((
		SELECT
                sum((bi2.u_valorkm) * dbo.FNHCA_PercAprovisionamento(bi.rdata,'ADM'))
            FROM BI(nolock)
                inner join bi2(nolock) on bi.bistamp = bi2.bi2stamp
                inner join bo(nolock) on bo.bostamp = bi.bostamp
                inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
            where 
			bo.ndos in (15)
                and bi.bifref =  ori.fref
                and bo2.anulado = 0
                and MONTH(bi.rdata) = ConsolaObraDatas.Mes and YEAR(bi.rdata) = ConsolaObraDatas.Ano
            --Group by CAST(MONTH(bi.rdata) AS VARCHAR(2))+'.'+CAST(YEAR(bi.rdata) AS VARCHAR(4))   
						)
	,0) As CustosKmAdministrativos
	, isnull((
		Select
                sum(ettiliq)
            from ft(nolock)
            where 
			ft.anulado=0
                and ft.tipodoc in (1,3)
                and ft.fref = ori.fref
                and MONTH(ft.fdata) = ConsolaObraDatas.Mes and YEAR(ft.fdata) = ConsolaObraDatas.Ano
           -- Group by CAST(MONTH(ft.fdata) AS VARCHAR(2))+'.'+CAST(YEAR(ft.fdata) AS VARCHAR(4)) 
	),0) AS FaturacaoAcumulada
	
	, u_nomevnd as Responsavel
	, u_status as Status
	, Cast(u_dataini as Date) as InicioDataObra
	, Cast(u_dataFim as date) as FimDataObra
	, Cast(u_dtstatus as Date) as DataStatus
        FROM FREF(NOLOCK) ori
            Left JOIN ConsolaObraDatas ON ConsolaObraDatas.CodigoObra = ori.fref
        Where ori.fref like @CodigoObra
    )
	
	,
    ConsolaObraTmp
    as
    (
        select
            codigo
	, Ano
	, Mes
	, DataMesAno
	, Designacao
	, NumeroCliente
	, NomeCliente 
	--, CustosMaterial
	--, CustosMaterialDiversos
	, ((CustosMaterial + CustosMaterialDiversos) - (CustosRetomaMaterial + CustosDevolucaoCliente)) as CustoMaterais
	, CustosMaoObra as MaoDeObra
	, (CustosKm + CustosDeslocacoes) as Deslocacoes
	, CustosDiversos as Diversos
	, ((CustosMaterialAprovisionamento + CustosMaterialDiversosAprovisionamento) - (CustosRetomaMaterialAprovisionamento + CustosDevolucaoClienteAprovisionamento)) + 
	CustosMaoObraAprovisionamento as GastosGerais
	, (((CustosMaterialAdminitrativos + CustosMaterialDiversosAdministrativos) - (CustosRetomaMaterialAdministrativos + CustosDevolucaoClienteAdministrativos)) + 
	CustosMaoObraAdministrativos  + CustosKmAdministrativos + CustosDiversosAdministrativos)
	+((((CustosMaterialAprovisionamento + CustosMaterialDiversosAprovisionamento) - (CustosRetomaMaterialAprovisionamento + CustosDevolucaoClienteAprovisionamento)) + 
	CustosMaoObraAprovisionamento) * dbo.FNHCA_PercAprovisionamento(Getdate(),'ADM'))as Administrativos
	, FaturacaoAcumulada
	, (isnull((FaturacaoAcumulada - (CustosMaterial - CustosRetomaMaterial))/nullif((CustosMaterial - CustosRetomaMaterial),0),0))*100 as ResultadoRealPerc
	, Status
	, Responsavel
	, InicioDataObra
	, FimDataObra
	, DataStatus
        from ConsolaObra
    )
select
    --Codigo AS CODIGO
    DataMesAno
	--, Designacao AS DESIGNACAO
	--, Cast(NumeroCliente as Varchar) NUMERO
	--, NomeCliente as CLIENTE
	, CustoMaterais as MATERIAL
	, MaoDeObra as MAO_DE_OBRA
	, Deslocacoes as DESLOCACOES
	, Diversos AS DIVERSOS
	, GastosGerais as GASTOS_GERAIS
	, Administrativos AS ADMINISTRATIVOS
	, (CustoMaterais + MaoDeObra + Diversos + Deslocacoes + GastosGerais + Administrativos) as CUSTOS
	, FaturacaoAcumulada AS PROVEITOS
    , cast(0.00 as Numeric(12,2)) as CustosAcumuls
    , cast(0.00 as Numeric(12,2)) as ProveitosAcus
    , cast(0.00 as Numeric(12,2))  AS Saldo
    , cast(0.00 as Numeric(12,2))  as PERC
--, Status AS STATUS
--, DataStatus AS DATASTATUS
--, Responsavel as RESPONSAVEL
--, InicioDataObra AS INICIO
--, FimDataObra AS FIM
from ConsolaObraTmp
where  (CustoMaterais + MaoDeObra + Diversos + Deslocacoes + GastosGerais + Administrativos) <>0 or FaturacaoAcumulada<>0
order by Ano asc,Mes ASC
ENDTEXT
IF !U_SQLEXEC(MSEL,"CurContaCorrenteObra")
    msg("Erro ao gerar cursor: " + MSEL)
return
Endif
lcCustosAcumulados = 0
lcProveitosAcumulados = 0
lcSaldo = 0
select CurContaCorrenteObra
go top
Scan 
    lcProveitosAcumulados = lcProveitosAcumulados + CurContaCorrenteObra.PROVEITOS
    lcCustosAcumulados = lcCustosAcumulados + CurContaCorrenteObra.Custos 
    lcSaldo = lcProveitosAcumulados - lcCustosAcumulados
    replace CurContaCorrenteObra.ProveitosAcus with lcProveitosAcumulados
    replace CurContaCorrenteObra.CustosAcumuls with lcCustosAcumulados
    replace CurContaCorrenteObra.Saldo with lcSaldo
    if lcCustosAcumulados <> 0
        replace CurContaCorrenteObra.PERC with (lcSaldo/lcCustosAcumulados)*100
    Else
        replace CurContaCorrenteObra.PERC with 100
    Endif
EndScan
text to lc_strsql noshow TextMerge
delete [dbo].[u_FrefAnalise] where FrefCode = '<<varFref>>'
endtext
if !u_sqlexec(lc_strsql)
    msg("Erro ao eliminar os registos!")
    return .f.
endif
SET POINT TO '.'
select CurContaCorrenteObra
go top
scan
        text to mselInsert NoShow textmerge
        INSERT INTO [dbo].[u_FrefAnalise]
                ([u_FrefAnaliseStamp]
                ,[FrefCode]
                ,[MesAno]
                ,[Material]
                ,[MaoDeObra]
                ,[Deslocacoes]
                ,[Diversos]
                ,[GastosGerais]
                ,[Administrativos]
                ,[Custos]
                ,[Proveitos]
                ,[CustosAcum]
                ,[ProveitosAcum]
                ,[Saldo]
                ,[Perc]
                ,[DataActualizacao])
            VALUES
                ('<<u_stamp(recno("CurContaCorrenteObra"))>>'
                ,'<<varFref>>'
                ,'<<CurContaCorrenteObra.DataMesAno>>'
                ,'<<CurContaCorrenteObra.Material>>'
                ,'<<CurContaCorrenteObra.MAO_DE_OBRA>>'
                ,'<<CurContaCorrenteObra.Deslocacoes>>'
                ,'<<CurContaCorrenteObra.Diversos>>'
                ,'<<CurContaCorrenteObra.GASTOS_GERAIS>>'
                ,'<<CurContaCorrenteObra.Administrativos>>'
                ,'<<CurContaCorrenteObra.Custos>>'
                ,'<<CurContaCorrenteObra.Proveitos>>'
                ,'<<CurContaCorrenteObra.CustosAcumuls>>'
                ,'<<CurContaCorrenteObra.ProveitosAcus>>'
                ,'<<CurContaCorrenteObra.Saldo>>'
                ,'<<CurContaCorrenteObra.Perc>>'
                ,Getdate() 
                )
        EndTExt
        if !u_sqlexec(mselInsert)
                SET POINT TO ','
                msg("Erro ao Inserir os registos!, Por favor contacte a assistência: " + mselInsert)
                return .f.
        EndIf
EndScan
SET POINT TO ','
Msg("Analise actualizada com Sucesso")

