* TECLA (ti.retorno)
* tistamp: ADM24012671272,5850000-1
* ecran: SFO
* teclas: F10
* descricao: Lançar linha Extra Compra
* estado: Activo
* inactivo: False

*
* HCA - Jorge F 26.01.2024
* Lançar linha de compras extra (documentos de devolução a  fornecedores N/C)
*

** Abre as compras em modo de introdução
*doread("FO","SFO")
*sfo.dointroduzir

GE_USERBRULE = .f.

if sbo.adding or sbo.editing
	return
else
	if fo.site='GUIADEV'
		msg("Documento ainda não finalizado!")
		return
	endif
endif

sfo.showsave


** Apaga a primeira linha de compras para não ficar em branco
* select fn
* delete

m.escolheu = .f.

Lvdesign = Getnome('Descritivo da nova linha ','','','',2,.F.)

if m.escolheu 
	if len(alltrim(Lvdesign))=0
		return
	else
		LvValorUn= Getnome('Preço unitário',0.000,'','',2,.F.)
		
		if LvValorUn=0
			return
		endif
	endif
else
	return
endif



Select fn
Go Bottom

Do foine2in
Select fn
Replace fn.fnstamp With u_stamp()
Replace fn.ref With ''
Do Foactref with "NORMAL",.T.,"OKPRECOS"
Replace fn.Design With Lvdesign
Replace fn.qtt With 1
Replace fn.EPV  With LvValorUn
replace fn.IVA with 0
replace fn.TABIVA with 4
replace fn.pv with LvValorUn*200.482
replace fn.etiliquido with LvValorUn*(1)
replace fn.tiliquido with (LvValorUn*200.482)*(1)


** Do Foactref With "NORMAL",.T.,""
* Do Foactref with "NORMAL",.T.,"OKPRECOS"

select fo
do fotots with .t.
do fotots with .t.
sfo.refresh()


sfo.Bok1.Okbuttomdef1.Click



GE_USERBRULE = .t.

