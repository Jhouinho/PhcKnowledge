* TECLA (ti.retorno)
* tistamp: ADM24053162440,4360000-1
* ecran: SFREF
* teclas: CTRL+G
* descricao: Criar Dossier de Obra
* estado: Activo
* inactivo: False

*### D F BLOCK - Tecla - Criar Dossier ##################
*### HCA | PT | 2024.05.31             ##################
Local lv_nome_dossier, lv_nr_dossier
lv_nome_dossier = ''

*### XVARS para escolher Dossier
Create Cursor xvars ( no N(5), tipo c(1), Nome c(40), Pict c(100), lordem n(10), tbval m, nvalor N(18,5), cvalor c(250), mvalor m, lvalor l, dvalor d)
Select xvars
Append Blank
Replace xvars.no With 1
Replace xvars.tipo With "T"
Replace xvars.Nome With "Dossiers"
Replace xvars.Pict With ""
Replace xvars.lordem With 1
If u_sqlexec("select '' as nmdos from ts(nolock) union select nmdos from ts(nolock) where ndos in (1, 3, 11, 17, 18, 19, 20, 22) order by nmdos asc","Cur_Dossiers")
	Select Cur_Dossiers
	Scan
		Select xvars
		Replace xvars.tbval With Alltrim(xvars.tbval)+Alltrim(Cur_Dossiers.nmdos)+","
	Endscan
	fecha("Cur_Dossiers")
endif

m.mCaption = "Novo Dossier a criar..."


Do While (len(alltrim(lv_nome_dossier))=0)
	m.escolheu = .f.
	docomando("do form usqlvar with 'xvars',m.mCaption,.t.")
	if m.escolheu
		select xvars
		locate for no = 1
		lv_nome_dossier = xvars.cvalor
		if len(alltrim(lv_nome_dossier))<>0


			*## Verifica se ecrã Dossiers está em modo de introdução ou alteração
			if Wexist("SBO") and (sbo.adding or sbo.editing)
				msg("Desculpe, mas o ecrã «Dossiers Internos» está em modo de Introdução/Alteração."+chr(13)+chr(13)+"Assim não é possível continuar")
				Return
			Endif
			
			doread("BO","SBO")

			If u_sqlexec("select ndos from ts(nolock) where nmdos='"+alltrim(lv_nome_dossier)+"'","Cur_DossierNdos")
				Select Cur_DossierNdos		
				lv_nr_dossier = Cur_DossierNdos.ndos
			else
				msg("Erro. O nome do Dossier não foi encontrado.")
				return
			endif
			**msg("lv_nr_dossier = "+str(lv_nr_dossier))
			sbo.newndos(lv_nr_dossier)
			sbo.dointroduzir

			select fref
			If is_clno(fref.u_nocli,0)
				Do boclact
			else
				msg("Atenção:"+chr(13)+chr(13)+"Cliente não encontrado.")
			endif

			select bo
			replace bo.fref with fref.fref

			*## Preenche Morada de Descarga
			TEXT to sql_txt textmerge noshow
				select 
					SZADRSDESC,
					U_DESC,
					MORADA,
					LOCAL,
					CODPOST
				from SZADRS (nolock)
				where u_tipo = 'Descarga' and inactivo = 0 and u_fref = '<<alltrim(fref.fref)>>'
				order by SZADRSDESC asc
			ENDTEXT
		
			If u_sqlexec(sql_txt,"Cur_Moradas") 
				select Cur_Moradas
				**msg("registos = "+str(Reccount("Cur_Moradas")))
				if Reccount("Cur_Moradas")>0
					if Reccount("Cur_Moradas")=1
						select Cur_Moradas
						select bo2
						replace DESCAR with  Cur_Moradas.SZADRSDESC
						replace morada with Cur_Moradas.morada
						replace LOCAL with Cur_Moradas.local
						replace codpost with Cur_Moradas.codpost
					else
						**=CursorSetProp('Buffering',5,"Cur_Moradas")
						Declare list_tit(5),list_cam(5),list_tam(5),list_pic(5)
						list_tit(1)="Descrição"
						list_tit(2)="Obra"
						list_tit(3)="Morada"
						list_tit(4)="Localidade"
						list_tit(5)="Cod. Postal"
		
						list_cam(1)="Cur_Moradas.SZADRSDESC"
						list_cam(2)="Cur_Moradas.U_DESC"
						list_cam(3)="Cur_Moradas.morada"
						list_cam(4)="Cur_Moradas.local"
						list_cam(5)="Cur_Moradas.codpost"
		
						list_pic(1)=""
						list_pic(2)=""
						list_pic(3)=""
						list_pic(4)=""
						list_pic(5)=""
		
						list_tam(1)=8*60
						list_tam(2)=8*60
						list_tam(3)=8*60
						list_tam(4)=8*60
						list_tam(5)=8*60
		
						m.escolheu=.F.
						Do	browlist With "Escolha a morada descarga obra/cliente","Cur_Moradas","Cur_Moradas"
						*,.T.,.F.,.F.,.T.,.F.,'',.t.
						Do Case
							Case m.escolheu = .T.
								select bo2
								replace DESCAR with  Cur_Moradas.SZADRSDESC
								replace morada with Cur_Moradas.morada
								replace LOCAL with Cur_Moradas.local
								replace codpost with Cur_Moradas.codpost
							Otherwise
								msg("Atenção:"+chr(13)+chr(13)+"Não foi seleccionada qualquer Morada.")
						Endcase
					endif
				Else
					msg("Atenção:"+chr(13)+chr(13)+"O Cliente não tem qualquer morada aberta para esta Obra.")
				Endif
		
			Else
				msg("Erro:"+chr(13)+chr(13)+"Não foi possível consultar a(s) morada(s) abertas para este Cliente / Obra!")
			Endif

			select bo2
			replace xpddata with Date() 
			replace xpdhora with SUBSTR(TTOC(DATETIME()+(60*10)),12,11)

			sbo.refresh 

		endif
	else
		return 
	endif

Enddo

