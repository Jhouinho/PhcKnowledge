* TECLA (ti.retorno)
* tistamp: ADM24053163419,1300000-1
* ecran: SFREF
* teclas: CTRL+H
* descricao: Abrir Painel Devoluções
* estado: Activo
* inactivo: False

*##### TECLA - Abre Painel Devoluções
if vartype(Pv_ObraEscolhidaDevolucao) = 'U'
    public Pv_ObraEscolhidaDevolucao
    Pv_ObraEscolhidaDevolucao= ''
endif
if vartype(Pv_DocumentoEscolhidoDevolucao) = 'U'
    public Pv_DocumentoEscolhidoDevolucao
    Pv_DocumentoEscolhidoDevolucao= 'Guia de Transporte'
endif

select fref
if alltrim(fref.u_status)='Aberta'
    Pv_DocumentoEscolhidoDevolucao= 'Guia de Transporte'
	Pv_ObraEscolhidaDevolucao = alltrim(fref.fref)
	docomando("do genpdup with 'ADM24053033568,689500239'")
else
	msg("Atenção:"+chr(13)+chr(13)+"A Obra seleccionada está FECHADA."+chr(13)+chr(13)+"Não é possível emitir Devoluções.")
endif

