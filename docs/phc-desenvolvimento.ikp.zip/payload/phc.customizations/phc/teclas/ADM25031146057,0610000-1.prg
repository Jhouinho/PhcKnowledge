* TECLA (ti.retorno)
* tistamp: ADM25031146057,0610000-1
* ecran: SBO
* teclas: ALT+Y
* descricao: Consultar Assessorias
* estado: Activo
* inactivo: False

*#### D F Block - Listagem de Assessorias
Local lc_BoStamp, lc_colunas
lc_BoStamp = ""
select bo

if bo.ndos=3 And Not sbo.adding And Not sbo.editing && (Orçamentos)

lc_BoStamp = alltrim(bo.bostamp)

    TEXT TO MSEL NOSHOW TEXTMERGE
        with 
        AssessoriasC as
        (
            select
                'Principal' as Tipo,
                bi.ref,
                convert(varchar(60),bi.design) as design,
                bi.qtt,
                bi.edebito,
                bi.desconto,
                bi.desc2,
                bi.ettdeb,
                bi.u_ecstamp,
                bi.lordem,
                isnull(u_assessorias.totalConstituicaoAssessoria,0) as totalConstituicaoAssessoria,
				isnull(u_assessorias.totalMaoObra,0) as totalMaoObra,
				isnull(u_assessorias.valorTotalQuilometros,0) as custosDeslocacoes,
                isnull(u_assessorias.custosDiversos,0) + isnull(u_assessorias.custosMaoObra,0) as custosGastosGerais,
                isnull(u_assessorias.custosAdministrativos,0) as custosAdministrativos,
                --isnull(u_assessorias.totalCustosIndiretos,0) as totalCustosIndiretos,
                isnull(u_assessorias.totalCustosSemMargem,0) as totalCustosSemMargem,
                isnull(u_assessorias.margem,0) as margem,
                isnull(u_assessorias.totalCustosComMargem,0) as totalCustosComMargem,
                0 as linha,
                ROW_NUMBER() OVER (ORDER BY lordem) AS NumeroLinha,
                cast (1 as bit) as Bold,
                cast (0 as bit) as Italico
        
            from bi(nolock) inner join u_assessorias(nolock) on bi.u_ecstamp=u_assessorias.bistamp
            where bi.bostamp = '<<lc_BoStamp>>'
                and bi.qtt<>0
        ),
        AssessoriasL as 
        (
            select 
                '---' as Tipo,
                '' as ref,
                convert(varchar(60),AL.descricao) as design,
                AL.quantidade as qtt,
                AL.valor as edebito,
                0 as desconto,
                0 as desc2,
                0 as ettdeb,
                AssessoriasC.u_ecstamp,
                AssessoriasC.lordem,
                AL.total as totalConstituicaoAssessoria,
                0 as totalMaoObra,
                0 as custosDeslocacoes,
                0 as custosGastosGerais,
                0 as custosAdministrativos,
                --0 as totalCustosIndiretos,
                0 as totalCustosSemMargem,
                0 as margem,
                0 as totalCustosComMargem,
                AL.linha,
                AssessoriasC.NumeroLinha,
                cast (0 as bit) as Bold,
                cast (1 as bit) as Italico
            from  u_assessoriaLinhas(nolock) as AL inner join AssessoriasC on AL.bistamp=AssessoriasC.u_ecstamp 
        )
        select * from AssessoriasC
        union all
        select * from AssessoriasL
        order by NumeroLinha, Tipo desc, linha
    ENDTEXT
    IF !U_SQLEXEC(MSEL,"ListAssess")
        MSG("Caro utilizador, não foi possivel consultar as «Assessorias». Se o problema continuar por favor contacte a assistência!")
        Return .F.
    ENDIF
    if reccount("ListAssess") > 0
        select ListAssess

        lc_colunas = 16
        declare list_tit(lc_colunas), list_cam(lc_colunas), list_tam(lc_colunas), list_ronly(lc_colunas), list_node(lc_colunas), list_pic(lc_colunas)

        list_tit(1) = "Tipo"
        list_tit(2) = "Referência"
        list_tit(3) = "Descrição"
        list_tit(4) = "Quantidade"
        list_tit(5) = "Valor"
        list_tit(6) = "Desc1"
        list_tit(7) = "Desc2"
        list_tit(8) = "Total"
        list_tit(9) = "C_Materiais"
        list_tit(10) = "C_MãoObra"
        list_tit(11) = "C_Deslocações"
        list_tit(12) = "C_GastosGerais"
        list_tit(13) = "C_Administrativos"
        list_tit(14) = "T_Custos"
        list_tit(15) = "Margem"
        list_tit(16) = "Com Margem"

        list_cam(1) = "ListAssess.Tipo"
        list_cam(2) = "ListAssess.ref"
        list_cam(3) = "ListAssess.design"
        list_cam(4) = "ListAssess.qtt"
        list_cam(5) = "ListAssess.edebito"
        list_cam(6) = "ListAssess.desconto"
        list_cam(7) = "ListAssess.desc2"
        list_cam(8) = "ListAssess.ettdeb"
        list_cam(9) = "ListAssess.totalConstituicaoAssessoria"
        list_cam(10) = "ListAssess.totalMaoObra"
        list_cam(11) = "ListAssess.custosDeslocacoes"
        list_cam(12) = "ListAssess.custosGastosGerais"
        list_cam(13) = "ListAssess.custosAdministrativos"
        list_cam(14) = "ListAssess.totalCustosSemMargem"
        list_cam(15) = "ListAssess.margem"
        list_cam(16) = "ListAssess.totalCustosComMargem"

        list_tam(1) = 8*50
        list_tam(2) = 8*65
        list_tam(3) = 8*10
        list_tam(4) = 8*15
        list_tam(5) = 8*15
        list_tam(6) = 8*15
        list_tam(7) = 8*15
        list_tam(8) = 8*15
        list_tam(9) = 8*15
        list_tam(10) = 8*15
        list_tam(11) = 8*15
        list_tam(12) = 8*15
        list_tam(13) = 8*15
        list_tam(14) = 8*15
        list_tam(15) = 8*15
        list_tam(16) = 8*15

        list_ronly(1) = .t.
        list_ronly(2) = .t.
        list_ronly(3) = .t.
        list_ronly(4) = .t.
        list_ronly(5) = .t.
        list_ronly(6) = .t.
        list_ronly(7) = .t.
        list_ronly(8) = .t.
        list_ronly(9) = .t.
        list_ronly(10) = .t.
        list_ronly(11) = .t.
        list_ronly(12) = .t.
        list_ronly(13) = .t.
        list_ronly(14) = .t.
        list_ronly(15) = .t.
        list_ronly(16) = .t.

        list_pic(1) = ""
        list_pic(2) = ""
        list_pic(3) = ""
        list_pic(4) = "###,###,###.##"
        list_pic(5) = "###,###,###.##"
        list_pic(6) = "###,###,###.##"
        list_pic(7) = "###,###,###.##"
        list_pic(8) = "###,###,###.##"
        list_pic(9) = "###,###,###.##"
        list_pic(10) = "###,###,###.##"
        list_pic(11) = "###,###,###.##"
        list_pic(12) = "###,###,###.##"
        list_pic(13) = "###,###,###.##"
        list_pic(14) = "###,###,###.##"
        list_pic(15) = "###.# %"
        list_pic(16) = "###,###,###.##"

        mcampobold = "ListAssess.Bold"
        mcampoitalic = "ListAssess.Italico"
        m.escolheu = .f.

        select ListAssess
        browlist("Listagem de Detalhes das Assessorias", "ListAssess", "ListAssess", .f., .f., .f., .t., .f., "", .t., .f., "", "", "", .f.)

        fecha("ListAssess")

    else
        msg("Atenção:"+chr(13)+chr(13)+"Não encontrei Assessorias. Por favor Verifique.")
    endif
endif

