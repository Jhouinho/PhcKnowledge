* TECLA (ti.retorno)
* tistamp: ADM25122951942,3720000-1
* ecran: SFREF
* teclas: CTRL+D
* descricao: Duplicar OBRA
* estado: Activo
* inactivo: False

* CTRL + D duplicar a obra
* Jorge F. HCA | 29.11.2025
* Duplicar obra e moradas de descarga DFBLOCk
*

Local LvAno,LvFref,LvMensagem,LvExecute 

LvAno =astr(year(date()))
LvMensagem = "Duplicação da Obra"

LvAno =year(date())+1
LvMensagem = "Ano destino da(s) obra(s) "+astr(LvAno)

m.escolheu = .f.
LvAno = Getnome("Ano destino",Lvano,LvMensagem,'####',2,.F.)

if m.escolheu 

do case
	case LvAno = 0 
		msg("Erro ao definir o ano destino! Não possivel continuar!")
		return 
	case LvAno < year(date()) 
		msg("Atenção! O ano definido é igual ou inferior ao atual!")
		if pergunta("Tem a certeza da duplicação?")
			LvAno = right(astr(LvAno),2)
		else
			return 			
		endif
	otherwise
			LvAno = right(astr(LvAno),2)
endcase


select fref
if len(alltrim(fref.fref))>0

	LvMensagem = "Deseja duplicar a obra " + alltrim(fref.fref) +" no ano "+LvAno 

	if pergunta(LvMensagem)

		text to LvSqlTxt TextMerge Noshow

			EXEC dbo.Sp_HCA_DuplicarObra '<<alltrim(fref.fref)>>', '<<LvAno>>', '<<m.m_chinis>>'

		endtext
	
		u_sqlexec(LvSqlTxt,"CrsResultado")

		if CrsResultado.resultado = 1
			ActualizaComboFREF()
			msg("Registo duplicado com sucesso!")
		else
			msg("Erro!")
			select CrsResultado
			mostrameisto("CrsResultado")
			return
		endif




	else

		return

	endif

endif 

endif



Function ActualizaComboFREF

release a_mfref

Public a_mfref(1,2)
a_mfref(1,1) = ''
a_mfref(1,2) = ''


TEXT TO m.msql TEXTMERGE NOSHOW
	select fref, nmfref from fref (nolock) where inactivo = 0 order by 1
ENDTEXT
u_sqlexec(m.msql, 'crTemp')

select crTemp
goto top
scan
	Aadd2('a_mfref',Alltrim(crTemp.fref), Alltrim(crTemp.nmfref))

endscan

If wexist("SFT")
	SFT.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SFT.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SFT.Pageframe1.Page2.Fref1.Combo.clear()
	SFT.Pageframe1.Page2.Fref1.Combo.requery()
endif

If wexist("SFO")
	SFO.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SFO.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SFO.Pageframe1.Page2.Fref1.Combo.clear()
	SFO.Pageframe1.Page2.Fref1.Combo.requery()
endif

If wexist("SBO")
	SBO.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SBO.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SBO.Pageframe1.Page2.Fref1.Combo.clear()
	SBO.Pageframe1.Page2.Fref1.Combo.requery()
endif

endfunc

