* TECLA (ti.retorno)
* tistamp: ADM25123038393,0660000-1
* ecran: SFREF
* teclas: ALT+0
* descricao: Duplicar OBRA(s)
* estado: Activo
* inactivo: False

* ALT + 0 duplicar obras
* Jorge F. HCA | 30.11.2025
* Duplicar obra e moradas de descarga DFBLOCk
*

Local LvAno,LvFref,LvMensagem,LvExecute

LvAno =astr(Year(Date()))
LvMensagem = "Duplicação da Obra"

LvAno =Year(Date())+1
LvMensagem = "Ano destino da(s) obra(s) "+astr(LvAno)

m.escolheu = .F.
LvAno = Getnome("Ano destino",LvAno,LvMensagem,'####',2,.F.)

If m.escolheu

	Do Case
		Case LvAno = 0
			msg("Erro ao definir o ano destino! Não possivel continuar!")
			Return
		Case LvAno < Year(Date())
			msg("Atenção! O ano definido é igual ou inferior ao atual!")
			If pergunta("Tem a certeza da duplicação?")
				LvAno = Right(astr(LvAno),2)
			Else
				Return
			Endif
		Otherwise
			LvAno = Right(astr(LvAno),2)
	Endcase


	m.escolheu = .F.
	LvFref = Getnome("Obra(s) a pesquisar","","Iniciado por...",'!!!!!!!!!!!!!!!!!!!!',2,.F.)

	If m.escolheu
	Else
		Return
	Endif


	TEXT to LvSqltxt_0 TextMerge Noshow

declare @fref as varchar(20) = '<<alltrim(upper(LvFref))>>';
declare @AnoDestino as varchar(3) = '<<LvAno>>'

SET @fref = @fref+'%'
set @AnoDestino = left(@fref,1)+@AnoDestino

select
	case when
		isnull((select a.fref from fref a (nolock) where a.fref = @AnoDestino+substring(fref.fref,4,16)),'') = ''
			then cast(1 as bit)
		else cast(0 as bit) end
	as sel
	,fref.fref
	,fref.nmfref
	,case when
		isnull((select a.fref from fref a (nolock) where a.fref = @AnoDestino+substring(fref.fref,4,16)),'') = ''
			then ''
		else 'SIM ' + isnull((select a.fref from fref a (nolock) where a.fref = @AnoDestino+substring(fref.fref,4,16)),'')
	end
	as
	Ja_Aberta

from fref (nolock)

		where fref.fref like @fref


order by fref,ousrdata desc


	ENDTEXT

	If u_sqlexec(LvSqltxt_0,"CrsFrefs")

		If Reccount("CrsFrefs")>0

			m.escolheu = .F.

			Select CrsFrefs

			i=4
			Declare list_tit(i),list_cam(i),list_tam(i),list_pic(i),list_ronly(i)

			i=1
			list_tit(i)="Seleccionar"
			list_cam(i)="CrsFrefs.sel"
			list_tam(i)=18
			list_pic(i)='LOGIC'
			list_ronly(i)=.F.

			i=i+1
			list_tit(i)="Obra"
			list_cam(i)="CrsFrefs.fref"
			list_tam(i)=20
			list_pic(i)=''
			list_ronly(i)=.T.

			i=i+1
			list_tit(i)="Descrição"
			list_cam(i)="CrsFrefs.nmfref"
			list_tam(i)=40
			list_pic(i)=''
			list_ronly(i)=.T.

			i=i+1
			list_tit(i)="Já aberta?"
			list_cam(i)="CrsFrefs.Ja_Aberta"
			list_tam(i)=30
			list_pic(i)=''
			list_ronly(i)=.T.


			=CursorSet('Buffering',5,"CrsFrefs")
			browlist("Seleccione as obras a duplicar","CrsFrefs","CrsFrefs",.T.,.F.,.F.,.T.,.F.)

			If m.escolheu

			Else
				Return
			Endif


		Else
			msg("Não tem obras com essa filtragem!")
			Return
		Endif


	Else

		msg("Estranho...não conseguimos extrair informação. Por favor informe o depº de informática!")
		msg(LvSqltxt_0)
		Return
	Endif



	******
	LvContador = 0
	LvMensagem = "Deseja duplicar as obras no ano "+LvAno+". Tem a certeza?"
	If pergunta(LvMensagem)

		Select CrsFrefs
		Go Top
		Scan

			If CrsFrefs.sel = .T.


				TEXT to LvSqlTxt TextMerge Noshow

			EXEC dbo.Sp_HCA_DuplicarObra '<<alltrim(CrsFrefs.fref)>>', '<<LvAno>>', '<<m.m_chinis>>'

				ENDTEXT

				u_sqlexec(LvSqlTxt,"CrsResultado")

				If CrsResultado.resultado = 1
					* msg("Registo duplicado com sucesso!")
					LvContador = LvContador + 1
				Else
					msg("Erro!")
					Select CrsResultado
					mostrameisto("CrsResultado")
					Return
				Endif

			Endif

		Endscan

	ActualizaComboFREF()
	LvMensagem = astr(LvContador) + " registo(s) duplicado(s) com sucesso!"
	msg(LvMensagem)
	
	Endif


Endif


Function ActualizaComboFREF

release a_mfref

Public a_mfref(1,2)
a_mfref(1,1) = ''
a_mfref(1,2) = ''


TEXT TO m.msql TEXTMERGE NOSHOW
	select fref, nmfref from fref (nolock) where inactivo = 0 order by 1
ENDTEXT
u_sqlexec(m.msql, 'crTemp')

select crTemp
goto top
scan
	Aadd2('a_mfref',Alltrim(crTemp.fref), Alltrim(crTemp.nmfref))

endscan

If wexist("SFT")
	SFT.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SFT.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SFT.Pageframe1.Page2.Fref1.Combo.clear()
	SFT.Pageframe1.Page2.Fref1.Combo.requery()
endif

If wexist("SFO")
	SFO.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SFO.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SFO.Pageframe1.Page2.Fref1.Combo.clear()
	SFO.Pageframe1.Page2.Fref1.Combo.requery()
endif

If wexist("SBO")
	SBO.Pageframe1.Page2.Fref1.Combo.RowSourceType = 5
	SBO.Pageframe1.Page2.Fref1.Combo.Rowsource = 'a_mfref'
	SBO.Pageframe1.Page2.Fref1.Combo.clear()
	SBO.Pageframe1.Page2.Fref1.Combo.requery()
endif

endfunc

