* TECLA (ti.retorno)
* tistamp: ADM26112361223,7210000-1
* ecran: SBO
* teclas: CTRL+I
* descricao: Lança Inventario Automatico
* estado: Activo
* inactivo: False

* TECLA (ti.retorno)
* ecran: SBO
* teclas: CTRL+I
* descricao: Contagem Stock - Criar e Lancar Inventario
* inactivo: False
*
* DfBlock | Contagem Stock (ndos 24) -> Inventario fisico (STIC/STIL) armazem 1 + Lancar
* Processo automatico: sem perguntas; lanca STICLAN
* Nota: F10 em SBO ja esta ocupada (Insere obra); usar CTRL+I
*

Local lv_bostamp, lv_data, lv_desc, lv_lordem, lv_obrano, lv_nmdos, lv_ref, lv_usalote, lv_sticstamp
Local lv_clicked, lv_cment, lv_cmsai, lv_nrdoc, lv_descent, lv_descsai

if !Wexist("SBO")
	msg("Abra o ecra de Dossiers Internos (SBO).")
	return
endif

select bo

if bo.ndos <> 24
	msg("Esta tecla so esta disponivel no dossier Contagem Stock.")
	return
endif

if sbo.adding or sbo.editing
	msg("Grave o dossier antes de criar o inventario.")
	return
endif

lv_bostamp = alltrim(bo.bostamp)
lv_obrano = bo.obrano
lv_nmdos = alltrim(bo.nmdos)
lv_data = bo.dataobra
if datavazia(lv_data)
	lv_data = date()
endif

if empty(lv_bostamp)
	msg("Dossier sem identificador (bostamp).")
	return
endif

TEXT TO msel NOSHOW TEXTMERGE
	select
		rtrim(ltrim(bi.ref)) as ref,
		max(rtrim(ltrim(bi.design))) as design,
		sum(bi.qtt) as stock,
		max(rtrim(ltrim(bi.unidade))) as unidade,
		max(rtrim(ltrim(isnull(bi.lote,'')))) as lote,
		max(case when st.usalote = 1 then 1 else 0 end) as usalote_n
	from bi (nolock)
	inner join st (nolock) on st.ref = bi.ref
	where bi.bostamp = '<<strtran(lv_bostamp, "'", "''")>>'
		and rtrim(ltrim(bi.ref)) <> ''
	group by rtrim(ltrim(bi.ref)), rtrim(ltrim(isnull(bi.lote,'')))
	order by ref
ENDTEXT

fecha("curContagemInv")
if !u_sqlexec(msel, "curContagemInv")
	msg("Erro ao ler linhas da Contagem Stock.")
	return
endif

if Reccount("curContagemInv") < 1
	msg("O dossier nao tem referencias para inventariar.")
	fecha("curContagemInv")
	return
endif

actform(Chr(13)+"A criar e lancar inventario...")

doread("STIC", "SSTIC")
sstic.dointroduzir()

select stic
replace stic.data with lv_data
lv_desc = "Contagem "+lv_nmdos+" "+alltrim(str(lv_obrano))
replace stic.descricao with left(lv_desc, 50)

lv_lordem = 0
select curContagemInv
go top
scan
	lv_lordem = lv_lordem + 1000
	lv_ref = alltrim(curContagemInv.ref)
	lv_usalote = (curContagemInv.usalote_n = 1)

	select stil
	append blank
	replace stil.stilstamp with u_stamp(),;
		stil.sticstamp with stic.sticstamp,;
		stil.data with stic.data,;
		stil.lordem with lv_lordem,;
		stil.ref with lv_ref,;
		stil.design with alltrim(curContagemInv.design),;
		stil.armazem with 1,;
		stil.usalote with lv_usalote,;
		stil.lote with alltrim(curContagemInv.lote),;
		stil.stock with curContagemInv.stock,;
		stil.unidade with alltrim(curContagemInv.unidade),;
		stil.cpoc with GetUmValorNumerico("ST","ST.cpoc","st.ref='"+strtran(lv_ref,"'","''")+"'")

	select curContagemInv
endscan

lv_sticstamp = alltrim(stic.sticstamp)

sstic.refrescar()
sstic.Bok1.Okbuttomdef1.click()

fecha("curContagemInv")

* Posiciona o inventario gravado e lanca sem perguntas
if !Wexist("SSTIC")
	doread("STIC", "SSTIC")
endif
select stic
locate for alltrim(stic.sticstamp) = lv_sticstamp
if !found()
	deactform()
	msg("Inventario criado, mas nao foi possivel posicionar o registo para lancar.")
	return
endif

* Codigos cm2: 11 Entrada Contagem / 55 Saida Contagem (mudapcpond igual ao cm 6)
* STICLAN: cment/cmsai + adocin/adocout="Contagem"
lv_cment = 11
lv_cmsai = 55
lv_nrdoc = "Contagem"
lv_descent = "Entrada Contagem"
lv_descsai = "Saida Contagem"

* Defeitos lidos no init do STICLAN
upd_defeito(alltrim(m_chinis)+"STICLANcbpsg", "L", .T.)
upd_defeito(alltrim(m_chinis)+"STICLANcment", "N", lv_cment, 10, 0)
upd_defeito(alltrim(m_chinis)+"STICLANcmsai", "N", lv_cmsai, 10, 0)

* Combos: valor numerico 11/55 (evita match em "Entrada Inventario")
* Ordem: combo entrada -> Nr -> combo saida -> Nr -> Alt+L
KEYBOARD alltrim(str(lv_cment))+"{TAB}"+lv_nrdoc+"{TAB}"+alltrim(str(lv_cmsai))+"{TAB}"+lv_nrdoc+"{ALT+L}" CLEAR

doread("STICLAN", "STICLAN")

* Se o dialog ainda estiver aberto, forca 11/55 + Contagem e lanca
lv_clicked = .F.
do case
case Wexist("STICLANADM")
	if pemstatus(STICLANADM, "cment", 5)
		STICLANADM.cment = lv_cment
	endif
	if pemstatus(STICLANADM, "cmsai", 5)
		STICLANADM.cmsai = lv_cmsai
	endif
	if type("STICLANADM.adocin") = "O"
		STICLANADM.adocin.Value = lv_nrdoc
	endif
	if type("STICLANADM.adocout") = "O"
		STICLANADM.adocout.Value = lv_nrdoc
	endif
	if pemstatus(STICLANADM, "adocin", 5) and type("STICLANADM.adocin") = "C"
		STICLANADM.adocin = lv_nrdoc
	endif
	if pemstatus(STICLANADM, "adocout", 5) and type("STICLANADM.adocout") = "C"
		STICLANADM.adocout = lv_nrdoc
	endif
	if type("STICLANADM.Lancar") = "O"
		STICLANADM.Lancar.Click()
		lv_clicked = .T.
	endif
case Wexist("STICLAN")
	if pemstatus(STICLAN, "cment", 5)
		STICLAN.cment = lv_cment
	endif
	if pemstatus(STICLAN, "cmsai", 5)
		STICLAN.cmsai = lv_cmsai
	endif
	if type("STICLAN.adocin") = "O"
		STICLAN.adocin.Value = lv_nrdoc
	endif
	if type("STICLAN.adocout") = "O"
		STICLAN.adocout.Value = lv_nrdoc
	endif
	if pemstatus(STICLAN, "adocin", 5) and type("STICLAN.adocin") = "C"
		STICLAN.adocin = lv_nrdoc
	endif
	if pemstatus(STICLAN, "adocout", 5) and type("STICLAN.adocout") = "C"
		STICLAN.adocout = lv_nrdoc
	endif
	if type("STICLAN.Lancar") = "O"
		STICLAN.Lancar.Click()
		lv_clicked = .T.
	endif
	if !lv_clicked and type("STICLAN.Bok1") = "O"
		STICLAN.Bok1.Okbuttomdef1.Click()
		lv_clicked = .T.
	endif
endcase

* Garante cm 11/55 + Nr Contagem nos movimentos deste inventario
* (cm 6 e 11 tem o mesmo mudapcpond â€” seguro para PCMP)
TEXT TO msel NOSHOW TEXTMERGE
	update sl
	set adoc = 'Contagem',
		cm = <<lv_cment>>,
		cmdesc = '<<lv_descent>>'
	where rtrim(ltrim(sticstamp)) = '<<strtran(lv_sticstamp, "'", "''")>>'
		and cm < 50
ENDTEXT
u_sqlexec(msel)

TEXT TO msel NOSHOW TEXTMERGE
	update sl
	set adoc = 'Contagem',
		cm = <<lv_cmsai>>,
		cmdesc = '<<lv_descsai>>'
	where rtrim(ltrim(sticstamp)) = '<<strtran(lv_sticstamp, "'", "''")>>'
		and cm >= 50
ENDTEXT
u_sqlexec(msel)

deactform()
mensagem("Inventario criado e lancado (cm 11/55).","directa")

return

