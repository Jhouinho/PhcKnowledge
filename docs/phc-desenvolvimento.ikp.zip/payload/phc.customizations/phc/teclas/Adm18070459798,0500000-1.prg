* TECLA (ti.retorno)
* tistamp: Adm18070459798,0500000-1
* ecran: PDU_37Y12WQQI
* teclas: CTRL+F5
* descricao: Mostra valor validado
* estado: Activo
* inactivo: False

Do MOSTRA_TOTAL_PAGAMENTO With 'PDU_37Y12WQQI.valor_validado.caption'   

** ====== RB JF 04.07.2018
** Do MOSTRA_TOTAL_PAGAMENTO With 'PDU_37Y12WQQI.valor_validado.caption'
Procedure MOSTRA_TOTAL_PAGAMENTO
	Lparameters in_objeto
	Local registo,out_mensagem
	Select compra
	registo = compra.Adoc
	If Len(Alltrim(compra.Adoc))>0
		Select compra
		If compra.simnao = .F.
			Replace compra.simnao With .T.
		Else
			Replace compra.simnao With .F.
		Endif

		Select compra
		Go Top
		Calculate Sum(ETOTAL) For Len(Alltrim(Adoc))>0 And simnao = .T. To SOMA_PAGAMENTO
		out_mensagem = "Valor validado: "+ Strtran(Alltrim(Str(SOMA_PAGAMENTO,12,2)),',','.') + "€"
		** messagebox(out_mensagem)
		obj_atualizar = in_objeto +"='"+out_mensagem+"'"
		** Messagebox(obj_atualizar)
		&obj_atualizar
		Select compra
		Locate For Adoc = registo
        **      do while not found()
        **         continue
        **       enddo

	Endif
Endproc

