* TECLA (ti.retorno)
* tistamp: Adm18070560005,9710000-1
* ecran: PDU_37Y12WQQI
* teclas: F5
* descricao: Eliminação Aprovações
* estado: Activo
* inactivo: False

if pergunta("Deseja marcar os documentos como não aprovados?")
	if u_sqlexec("update fo set aprovado = 0 where aprovado = 1")
		msg("Atualização efetuada com sucesso!")
		PDU_37Y12WQQI.DOACTUALIZAR                                            
		return
	else
	
		msg("Não foi possivel atualizar os registos. Por favor informe o dep. de informática!")
		return 
	endif
endif

