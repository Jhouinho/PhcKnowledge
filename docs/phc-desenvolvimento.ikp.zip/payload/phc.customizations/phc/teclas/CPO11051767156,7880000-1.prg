* TECLA (ti.retorno)
* tistamp: CPO11051767156,7880000-1
* ecran: PDU_37Y12WQQI
* teclas: F2
* descricao: Gravar Alterações
* estado: Activo
* inactivo: False

TEXT TO mselected TEXTMERGE NOSHOW
	delete ti
    where CONVERT( DATETIME, GETDATE(), 106 ) > '2013-06-10' 
	and tcstamp=(select tcstamp from tc (nolock) where tc.ecran='PDU_37Y12WQQI')
ENDTEXT
local stampgeral
local valoriva
Select Compra
scan
stampgeral=compra.stampCAB
stampgeralfn=compra.stamp
	if Compra.simnao=.T.
	m.aprov=''
	m.aprov=m.aprov+[update fo set APROVADO=1, DTAPROV=getdate(), FO.NMAPROV=']+ASTR(m.m_chnome)+[' where fo.fostamp=']+compra.stampCAB+[']
		if not u_sqlexec(m.aprov)
			mensagem("Deu erro a actualizar as compras!!","DIRECTA")
			*regua(2)
			return .f.
		endif
	endif
endscan
PDU_37Y12WQQI.Actualizartot.Nossobutton1.click()
mensagem("Actualização das compras concluída",0,"Informação")

