* TECLA (ti.retorno)
* tistamp: MG24052340099,2250000-1
* ecran: SFO
* teclas: F11
* descricao: Develop
* estado: Activo
* inactivo: False



Select FO
If Len(Alltrim(FO.FOSTAMP))>0
msg("ok1")
msg(FO.Adoc)
	If Alltrim(upper(FO.Adoc))="AGUARDA N/CRÉDITO"
msg("ok2")

		SFO.editfo.Enabled = .T.

	Else

		SFO.editfo.Enabled = .F.

	Endif
Endif

