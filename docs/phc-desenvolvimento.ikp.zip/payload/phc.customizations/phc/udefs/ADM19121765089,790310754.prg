* UDEFS
* stamp: ADM19121765089,790310754
* tabela: BO2
* campo: BO2.XPDDATA
* descricao: 
* tipo: 2
* quando: 1
* estado: Inactivo
* inactivo: True

*=== XBASE (xbase) ===
DTOC(date())

*=== DEFSQL (defsql) ===
0

