* UDEFS
* stamp: ADM20010655306,672442675
* tabela: SZADRS
* campo: SZADRS.u_tipo
* descricao: Tipo por defeito
* tipo: 1
* quando: 1
* estado: Activo
* inactivo: False

*=== DEFSQL (defsql) ===
0

*=== VALORC (valorc) ===
Descarga

