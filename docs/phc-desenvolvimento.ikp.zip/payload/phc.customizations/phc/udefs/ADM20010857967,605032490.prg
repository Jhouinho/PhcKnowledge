* UDEFS
* stamp: ADM20010857967,605032490
* tabela: BO2
* campo: BO2.DESCAR
* descricao: Morada de Descarga
* tipo: 2
* quando: 1
* estado: Inactivo
* inactivo: True

*=== XBASE (xbase) ===
Select bo
If bo.ndos=20
	replace bo2.descar With 'D.F.BLOCK'
	Return bo2.descar
Endif

*=== DEFSQL (defsql) ===
0

