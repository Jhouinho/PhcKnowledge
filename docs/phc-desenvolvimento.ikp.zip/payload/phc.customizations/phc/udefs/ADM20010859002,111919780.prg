* UDEFS
* stamp: ADM20010859002,111919780
* tabela: BO2
* campo: BO2.CARGA
* descricao: Morada de Carga
* tipo: 2
* quando: 1
* estado: Inactivo
* inactivo: True

*=== XBASE (xbase) ===
Select bo
If bo.ndos=20
	replace bo2.carga With 'Morada do Cliente'
	Return bo2.carga
Endif

*=== DEFSQL (defsql) ===
0

