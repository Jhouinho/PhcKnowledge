* UDEFS
* stamp: ADM20010859639,518123195
* tabela: BO2
* campo: BO2.DESCAR
* descricao: Morada de Descarga gravar
* tipo: 2
* quando: 2
* estado: Inactivo
* inactivo: True

*=== XBASE (xbase) ===
Select bo
If bo.ndos=20
	replace bo2.descar With 'D.F.BLOCK'
	Return bo2.descar
Endif

*=== DEFSQL (defsql) ===
0

