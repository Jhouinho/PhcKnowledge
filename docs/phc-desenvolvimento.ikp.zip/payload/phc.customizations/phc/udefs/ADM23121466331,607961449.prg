* UDEFS
* stamp: ADM23121466331,607961449
* tabela: FREF
* campo: FREF.u_datafim
* descricao: ACtualiza a Final
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
Local lcCodigoObra,lcStatusObra
select fref
lcCodigoObra = Alltrim(fref.FREF)
lcStatusObra = Alltrim(FREF.U_STATUS)
TEXT TO MSEL NOSHOW TEXTMERGE
with 
tmpTotal as (
    select ISNULL(max(bo.dataobra),'01.01.1900') DataTotal
    from bo(nolock)
     inner join bo2(nolock) on bo2.bo2stamp = bo.bostamp
    where bo.ndos in (11,17,18,19,20,22)
                    and bo.fref = '<<lcCodigoObra>>'
                    and bo2.anulado = 0
	UNION ALL
    select ISNULL(max(BI.rdata),'01.01.1900') DataTotal
    from BI(nolock)
     inner join bo2(nolock) on bo2.bo2stamp = bI.bostamp
    where BI.ndos in (15)
                    and BI.BIfref = '<<lcCodigoObra>>'
                    and bo2.anulado = 0
    UNION ALL
    select ISNULL(max(ft.fdata),'01.01.1900') DataTotal
    FROM FT(NOLOCK)
    WHERE FT.anulado=0
        AND FT.tipodoc IN (1,3)
        AND FT.fref= '<<lcCodigoObra>>'
)
SELECT max(DataTotal) as Data FROM tmpTotal
EndTExt
if u_sqlexec(MSEL,"CurDataTemp") and reccount("CurDataTemp") > 0
	if lcStatusObra = 'Fechada'
		return CurDataTemp.Data
	else
		return ctod('01.01.1900')
	endif
else
	return ctod('01.01.1900')
Endif

*=== DEFSQL (defsql) ===
0

