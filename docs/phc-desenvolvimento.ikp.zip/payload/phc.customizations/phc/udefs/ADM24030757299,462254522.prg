* UDEFS
* stamp: ADM24030757299,462254522
* tabela: FT
* campo: FT.u_TmpOrca
* descricao: Repoe Nome do Botão
* tipo: 2
* quando: 1
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
SELECT FT
IF FT.TIPODOC = 1
    SFT.Pageframe1.Page1.Btnorcamento.Caption = 'Selecionar Orçamento'
ENDIF
RETURN FT.U_TMPORCA

*=== DEFSQL (defsql) ===
0

