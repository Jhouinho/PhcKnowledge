* UDEFS
* stamp: ADM24030757332,746116570
* tabela: FI
* campo: FI.u_BoOrcame
* descricao: Prenche Orçamento Selectionado
* tipo: 2
* quando: 1
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
Select FT
If FT.TIPODOC=1
	fnChangeOrcamento(FT.u_TmpOrca)
Endif
Return FI.u_BoOrcame

*=== DEFSQL (defsql) ===
0

