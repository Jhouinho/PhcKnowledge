* UDEFS
* stamp: ADM26112361483,862354591
* tabela: BO
* campo: BO.NO
* descricao: Entidade DF Block por defeito
* tipo: 2
* quando: 1
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
Local lv_hora
lv_hora = Left(Time(), 5)

Select bo
If bo.ndos = 24
	Replace bo2.horasl With lv_hora
	Replace bo.no With 1
	Replace bo.nome With "D. F. BLOCK, LDA"
	Return 1
Endif

Return ''

*=== DEFSQL (defsql) ===
0

