* UDEFS
* stamp: MG23011157778,028107169
* tabela: BI
* campo: BI.EPCUSTO
* descricao: Actualiza Preço custo: Guia Entrada
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
SELECT BO
IF BO.NDOS = 16 AND BI.QTT > 0 
	RETURN BI.ETTDEB/BI.QTT
ENDIF
RETURN BI.EPCUSTO

*=== DEFSQL (defsql) ===
0

