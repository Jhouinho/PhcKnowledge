* UDEFS
* stamp: MG25042961776,325212678
* tabela: FI
* campo: FI.TABIVA
* descricao: Cola Tabela iva 9 quando não tem qtt
* tipo: 2
* quando: 2
* estado: Activo
* inactivo: False

*=== XBASE (xbase) ===
SELECT FT2
IF lEN(alltrim(FT2.ASSINATURA)) = 0
	select fi
	if fi.qtt = 0
		return 9
	else
		return fi.tabiva
	endif
Else
	return fi.tabiva
endif

*=== DEFSQL (defsql) ===
0

